@echo off
cd /d "%~dp0"
start "" "%~dp0Programa\AgendaClara.exe" --config "%~dp0DEMO-config.xml" --agenda "%~dp0Datos\NexoCentro-DEMO.sqlite3"
exit /b
