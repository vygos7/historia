# Nexo Centro 4.2.2 · Memorias e informes

Esta revisión actualiza únicamente el cliente. No requiere reinstalar ni actualizar el servidor.

## Cambios

- Ventana «Seguimiento, memorias e informes» con el modelo A elegido: filtros alineados arriba, actividades en tarjetas y selección separada.
- «Período»: Anual, Primer trimestre, Segundo trimestre y Tercer trimestre.
- El selector «Curso escolar» permite consultar años anteriores. No es el curso o grupo del alumnado.
- Desde y Hasta muestran las fechas del calendario del centro. No se inventan fechas para trimestres sin configurar.
- «Grupos o cursos participantes» obligatorio al guardar una ficha. Para reuniones puede indicarse «Equipo docente», por ejemplo.
- Las actividades antiguas sin grupo se conservan; al editarlas hay que completar ese dato. Si se edita solo una fecha de una actividad antigua, hay que elegir primero «Toda la actividad» para completar su grupo común.
- Informe impreso y PDF: Actividad | Curso | Fecha | Valoración | Continuidad.

## Probar sin cambiar la agenda real

1. Extrae todo el ZIP en una carpeta nueva.
2. Abre ABRIR-DEMO.cmd. Usa una agenda ficticia y una carpeta independiente de las versiones anteriores.
3. Abre «Seguimiento, memorias e informes» y comprueba los filtros, las tarjetas y el informe.
4. Prueba crear una actividad sin grupo y después complétalo.

## Actualizar un puesto real

1. Conserva una copia de seguridad y cierra Nexo Centro.
2. Ejecuta Instalar-NexoCentro-Cliente.exe, manteniendo su .exe.config en la misma carpeta.
3. Usa la misma conexión configurada y comprueba que las actividades y sus memorias siguen visibles.
4. Actualiza el cliente en los demás puestos que vayan a usar esta interfaz.

No ejecutes ningún instalador de servidor: esta entrega no lo incluye. Tampoco incluye cambios de cortafuegos, certificados, direcciones, sincronización ni sesiones.

Las pruebas de Windows y sus resultados se documentan en Evidencias. La comprobación real en el colegio corresponde a sus puestos conectados; no se ha accedido a su instalación.
