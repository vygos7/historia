# Nexo Centro 4.2.3 · Filtro de continuidad

Actualización únicamente del cliente. No requiere reinstalar ni actualizar el servidor.

En «Seguimiento, memorias e informes» aparece el desplegable «Continuidad»:

- Todas: muestra todas las actividades del curso, período y búsqueda actuales. Selección manual.
- Sí: muestra y marca las actividades propuestas para próximos cursos.
- No: muestra y marca las actividades que no se propone repetir.
- Sin evaluar: muestra y marca las actividades cuya memoria no tiene decisión de continuidad.

Al cambiar estos filtros se seleccionan sus actividades visibles. Puedes desmarcar cualquiera antes de imprimir. «Marcar todas las visibles» y «Desmarcar todas» siguen disponibles.
El informe, el PDF y la impresión reciben solo las actividades visibles que has marcado. El encabezado indica el filtro de continuidad utilizado.

## Probar sin cambiar la instalación real

Extrae todo el ZIP y abre ABRIR-DEMO.cmd. Los datos son ficticios y se guardan en una carpeta independiente, NexoCentroDemo423, dentro de tu perfil local. No sustituye la agenda del centro.

## Actualizar un cliente existente

Cierra la aplicación y ejecuta Instalar-NexoCentro-Cliente.exe, manteniendo su .exe.config a su lado. Se conserva la conexión y la agenda existente. Actualiza cada puesto que necesite este filtro; el servidor no se actualiza.

La versión completa 4.2.2 para centros nuevos se conserva. Este paquete de cliente no configura un colegio desde cero.

Las pruebas de Windows y su estado se documentan en Evidencias. No se ha accedido a ninguna instalación real del colegio.
