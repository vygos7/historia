param([Parameter(Mandatory=$true)][string]$Entrega,[Parameter(Mandatory=$true)][string]$Resultados)
$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$false
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
if($env:OS-ne'Windows_NT'-or$env:GITHUB_ACTIONS-ne'true'-or$env:RUNNER_ENVIRONMENT-ne'github-hosted'){throw 'Estas pruebas sólo se ejecutan en un Windows efímero hospedado por GitHub, nunca sobre la instalación de un centro.'}
$Entrega=[IO.Path]::GetFullPath($Entrega)
New-Item -ItemType Directory -Force -Path $Resultados|Out-Null
$Resultados=[IO.Path]::GetFullPath($Resultados)
foreach($line in Get-Content -LiteralPath (Join-Path $Entrega 'SHA256SUMS.txt')) {
 if([string]::IsNullOrWhiteSpace($line)){continue}
 $parts=$line-split'  ',2
 if($parts.Count-ne2){throw 'Manifiesto de entrega no válido.'}
 $file=[IO.Path]::GetFullPath((Join-Path $Entrega $parts[1]))
 if(-not$file.StartsWith($Entrega+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)){throw 'Ruta fuera de la entrega.'}
 if((Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash-ne$parts[0]){throw "Archivo de entrega alterado: $($parts[1])"}
}
$root=Join-Path $env:RUNNER_TEMP ('AgendaClara-Validacion-'+[Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $root|Out-Null
$tests=Join-Path $Entrega 'Pruebas';$server=Join-Path $Entrega 'Instalar-AgendaClara-Servidor.exe';$fixture=Join-Path $tests 'agenda-v4-sintetica.sqlite3'
$script:results=@()
function Ejecutar([string]$Nombre,[string]$Programa,[string[]]$Argumentos) {
 $log=Join-Path $Resultados ($Nombre+'.txt')
 & $Programa @Argumentos *> $log
 $code=$LASTEXITCODE
 Get-Content -LiteralPath $log -Encoding utf8|ForEach-Object{Write-Host $_}
 $summary=Select-String -LiteralPath $log -Pattern 'RESUMEN:'|Select-Object -Last 1
 if($code-ne0) {
  $failure=@(Select-String -LiteralPath $log -Pattern 'Exception:|HRESULT|^FALLO:'|Select-Object -Last 5)
  $message=if($failure.Count-gt0){($failure|ForEach-Object{$_.Line})-join" | "}else{"No terminó correctamente; revisar $Nombre.txt"}
  $message=$message.Replace('%','%25').Replace("`r",'%0D').Replace("`n",'%0A')
  Write-Host "::error title=AgendaClara-$Nombre::$message"
 }
 $script:results+=[ordered]@{Prueba=$Nombre;ExitCode=$code;Resumen=$(if($null-ne$summary){$summary.Line}else{'No hay resumen: revisar el fallo.'})}
 $script:results|ConvertTo-Json -Depth 4|Set-Content -LiteralPath (Join-Path $Resultados 'baterias.json') -Encoding utf8
}
Ejecutar 'red-instalador' (Join-Path $tests 'RedTests.exe') @((Join-Path $root 'red'))
Ejecutar 'transporte' 'dotnet' @((Join-Path $tests 'transporte/AgendaClara.TransportTests.dll'),(Join-Path $root 'transporte'))
Ejecutar 'sesiones' 'dotnet' @((Join-Path $tests 'sesion/AgendaClara.SessionTests.dll'),(Join-Path $root 'sesiones'))
Ejecutar 'integracion-instaladores' (Join-Path $tests 'SimpleTests.exe') @((Join-Path $root 'integracion'),$fixture,$server)
Ejecutar 'servicio-actualizacion-reversion' (Join-Path $tests 'ServerInstallTests.exe') @((Join-Path $root 'servicio'),$server,$fixture)
$failures=@($script:results|Where-Object{$_.ExitCode-ne0})
if($script:results.Count-ne5-or$failures.Count-gt0){throw "Hay $($failures.Count) baterías fallidas. No se confirma el instalador."}
Write-Host 'VALIDACION WINDOWS COMPLETADA: cinco baterías ejecutadas y correctas.'
