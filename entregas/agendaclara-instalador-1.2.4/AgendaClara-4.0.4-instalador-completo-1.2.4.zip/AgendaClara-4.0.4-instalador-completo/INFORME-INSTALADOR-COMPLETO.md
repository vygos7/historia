# AgendaClara 4.0.4 — instalador completo 1.2.4

**Estado: compilado y comprobado localmente; validación Windows pendiente de autorización para ejecutar CI. No distribuir todavía como instalación general validada.** No se ha modificado ninguna instalación del colegio.

## Componentes preparados

- `Instalar-AgendaClara-Servidor.exe`: asistente con elevación, servidor win-x64 autocontenido con .NET 10, servicio Windows, permisos, regla de cortafuegos y generador de paquetes de puestos.
- `Instalar-AgendaClara-Cliente.exe`: actualización genérica del programa de un usuario que ya tiene su conexión. Para un puesto nuevo debe usarse el EXE específico generado por su centro.
- Los paquetes que el servidor genera para Jefatura, Dirección y Secretaría incluyen exactamente el cliente **4.0.4-http-r2 verificado en el colegio**, comprobado byte a byte. La lógica de red de ese cliente no se ha cambiado al preparar el instalador.
- No se incluyen identidades, certificados privados, claves, usuarios ni datos de centros. Cada instalación nueva los genera de forma independiente.

## Cambios del instalador

1. Eliminada la recuperación implícita de componentes desde EXE anteriores. Cada payload necesita manifiesto, revisión r2, archivos declarados y huellas SHA-256 correctas. El cliente realmente embebido y el cliente anidado del generador se verifican contra la compilación nueva.
2. Compilación por proyectos SDK y scripts reproducibles. El servidor incluye su runtime; el usuario no necesita SDK. Los asistentes y clientes requieren .NET Framework 4.8 y Windows x64.
3. Actualización del cliente con respaldo de los archivos que se sustituyen y verificación de copia. Se conservan archivos ajenos. Si falla una etapa, se intenta restaurar programa, conexión y acceso directo. Una actualización genérica valida el certificado existente antes de copiar y no reescribe la conexión.
4. Actualización del servidor con copia cifrada y respaldo protegido de configuración, certificados y seguridad. En caso de fallo se intenta detener el servicio, restaurar los archivos, la configuración y la regla anterior, y recuperar su estado de ejecución. Si hay una operación aún bloqueando los datos o falla la reversión, se conserva el respaldo y se informa del bloqueo; no se confirma una actualización correcta.
5. Los paquetes de una generación fallida se marcan expresamente como no utilizables. Los datos centrales no se sustituyen por una agenda vacía.
6. La autoridad verificada se conserva como confianza privada de AgendaClara, usando el anclaje y validación TLS del cliente r2. El asistente no añade la CA del centro a la confianza raíz general de Windows. Sigue importándose el certificado personal del puesto con su clave, y la primera instalación exige contrastar la huella por un medio independiente. No se aceptan certificados inválidos ni se desactiva TLS.
7. La detección de red no introduce una subred ficticia si no encuentra una interfaz: exige indicar la red. Se conservan perfiles Dominio, Privado y Público en la regla, limitados al programa, puerto y subredes autorizadas.

Al fallar una instalación nueva después de importar el certificado personal puede quedar ese certificado ya importado: no se borran automáticamente claves ajenas o preexistentes; el siguiente intento detecta el certificado y evita duplicarlo. La reversión de archivos no se presenta como restauración completa de todos los almacenes del sistema.

## Verificaciones realizadas

- Publicación del servidor autocontenido win-x64: correcta.
- Compilación de ambos asistentes 1.2.4 y de las tres baterías Windows: correcta, sin advertencias ni errores en la compilación final.
- **22 comprobaciones locales ejecutadas, 0 fallos**: integridad de cliente y servidor, igualdad exacta del cliente r2, recursos realmente embebidos, correspondencia entre generador y cliente, manifiestos de elevación, rechazo de archivos alterados/incompletos/ajenos o de revisiones anteriores, copia confirmada y reversión de copia parcial sin borrar archivos ajenos.
- Sintaxis de los scripts PowerShell comprobada; scripts de compilación ejecutados en este entorno.
- El servidor ocupa aproximadamente 107 MiB descomprimido y el cliente 3,1 MiB, sin contar agenda, copias, respaldo de actualización o extracción temporal. No se ha inventado una cifra universal de RAM o capacidad para todos los centros.

Las 32 comprobaciones previas de transporte y 33 de sesiones se preparan también para ejecutar en Windows. Sus resultados anteriores de desarrollo y la conexión r2 real del colegio se conservan como evidencia histórica; no sustituyen la validación del instalador nuevo.

## Verificaciones Windows preparadas, todavía no ejecutadas

- Red y configuración del cortafuegos del instalador.
- Transporte HTTPS/IPv4/IPv6 y SignalR.
- Sesiones, permisos, rechazo de credenciales y tiempos de espera.
- Generación de los tres puestos, traslado del EXE independiente, instalación y reparación de clientes, preservación de configuración y sincronización de una agenda sintética.
- Servicio Windows real: inicio automático, cuenta virtual y permisos, regla real de firewall, centros con autoridades distintas, actualización que conserva el acceso anterior y reversión de una actualización fallida que había cambiado configuración y emitido paquetes.

La batería de servicio sólo permite ejecutarse en un Windows efímero hospedado por GitHub y comprueba que no exista un servicio o regla de AgendaClara ajenos. No se debe ejecutar sobre el colegio. Los datos y certificados son sintéticos. El workflow propuesto usa únicamente `contents: read`, no conserva credenciales Git y guarda registros como artefacto de Actions, sin commits automáticos ni modificaciones del repositorio.

La primera propuesta de automatización con escritura fue rechazada por la revisión automática porque esa publicación y automatización externa no estaban autorizadas explícitamente. No se ejecutó. Se ha preparado la alternativa de sólo lectura para autorización del usuario; no se ha intentado eludir el rechazo.

## Requisitos por centro

- Objetivo de despliegue: Windows x64 de escritorio mantenido (preferentemente Windows 11); servidor Windows compatible con .NET 10. El asistente gráfico necesita escritorio: no se declara compatible con Nano Server o Server Core sólo porque el runtime los admita. La matriz final de sistemas certificados depende de las pruebas Windows y del piloto de cada centro.
- .NET Framework 4.8 en asistentes y puestos. El servidor incorpora .NET 10. No hace falta SDK para utilizar los instaladores.
- Servidor encendido, sin suspensión durante el uso, nombre resoluble y dirección estable. El servidor configurado actualmente escucha en IPv4; debe existir ruta IPv4 desde los puestos.
- Puerto TCP 7443 por defecto, o el elegido, permitido en Windows, routers, VLAN y políticas corporativas. El asistente configura sólo su regla local, no los routers ni las directivas del centro.
- Regla de entrada limitada al EXE, puerto y redes reales, con los tres perfiles de Windows habilitados. No se desactiva el cortafuegos ni se publica el puerto a Internet.
- Identidad y accesos propios: CA del centro, certificado del servidor que corresponda a su dirección, certificado de cada puesto y usuarios. No copiar accesos ni datos de otro centro.
- Base central en disco local, separada del programa y con permisos del servicio. No usar una carpeta de red o sincronizada como base central.
- Copias cifradas, copia adicional fuera del servidor y clave de recuperación separada. El asistente prepara copia local y exportación; el traslado fuera del equipo y la prueba de restauración deben organizarse en el centro.
- Antivirus y políticas que permitan el programa y su HTTPS con certificado de puesto. No se han firmado los EXE con un certificado Authenticode de una organización; si un centro exige software firmado, debe resolverse con su responsable, sin desactivar controles.
- Una instalación de servicio por equipo. Antes de extender a todos los puestos, validar dos: conectar, crear y borrar un acontecimiento, comprobar propagación y recuperación tras reiniciar.

## Reproducir la compilación

Desde los fuentes, con SDK .NET 10 y PowerShell:

```powershell
./Preparar-Instaladores.ps1 -Salida <carpeta-nueva> -DotNet dotnet
./instalador/Compilar-Pruebas.ps1 -Salida <carpeta-nueva>/pruebas -DotNet dotnet
dotnet run --project instalador/pruebas-portables/AgendaClara.Setup.PackageTests.csproj -c Release -- <carpeta-nueva> <carpeta-nueva-de-pruebas> <AgendaClara.exe-r2-verificado>
```

`instalador/ci/agendaclara-instalador.yml` contiene la propuesta revisable de CI de sólo lectura. Aún no está activada en el repositorio. El paquete candidato y sus huellas están preparados localmente para la publicación que el usuario autorice.
