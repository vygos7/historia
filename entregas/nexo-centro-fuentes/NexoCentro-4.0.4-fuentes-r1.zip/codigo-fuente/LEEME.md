> Preparación actual: instalador completo **1.2.4** con cliente **4.0.4-http-r2**. Véase `INFORME-INSTALADOR-COMPLETO.md` y `Preparar-Instaladores.ps1`. Los apartados siguientes documentan la entrega original y no certifican el instalador nuevo. La validación Windows de 1.2.4 sigue pendiente.

# AgendaClara 4.0.4 · candidato para diagnóstico y reparación de conexión

Fecha: 04/11/2026. Derivado de los fuentes de desarrollo 4.0.3, instalador 1.2.2. Nuevo instalador: 1.2.3.

Se ha corregido la recreación de la regla del cortafuegos que excluía el perfil Público y añadido diagnóstico por etapas en el cliente. La validación en los ordenadores físicos del colegio está pendiente. No se debe interpretar esta entrega como certificación de que el incidente real está resuelto.

Esta carpeta contiene únicamente código, recursos y una base de pruebas identificada como sintética. No contiene datos del colegio, certificados privados, claves, sesiones ni instaladores de puesto con identidad. MANIFIESTO-ORIGEN.json conserva los SHA-256 de los 62 archivos copiados inicialmente. LEEME-ORIGINAL-4.0.3.md conserva la documentación anterior, cuya cabecera estaba desactualizada (4.0.1).

## Compilar

Windows x64, SDK .NET 10 y referencias de .NET Framework 4.8. Paquetes NuGet indicados en los proyectos. Ejecutar aplicacion/Compilar.ps1, indicando -DotNet si el SDK no está en PATH. El servidor se publica autocontenido para win-x64. El cliente necesita .NET Framework 4.8.

Para construir instaladores, generar ZIP que contengan las carpetas raíz cliente y servidor de esa misma compilación y pasarlos a instalador/Compilar.ps1 mediante -ClienteZip y -ServidorZip. No reutilizar payloads de otra versión. La compilación no ejecuta instalaciones.

## Verificar

Verificar.ps1 -DotNet <ruta de dotnet.exe> -DirectorioPruebas <carpeta nueva y corta>

Las pruebas usan sólo agendas sintéticas y un servidor loopback. Las baterías TLS añaden y retiran certificados personales de prueba; pueden necesitar permisos fuera de un entorno restringido. La prueba de inicio de Windows usa una clave de registro propia y comprueba que el inicio real no cambia. No se añaden raíces con Verificar.ps1.

La batería completa del instalador, SimpleTests, se prepara mediante instalador/Compilar-Pruebas.ps1 una vez creados los payloads, el instalador y payload-root/cliente. Requiere confirmación humana de Windows para confiar en una raíz sintética y posteriormente la retira. No se registra un servicio en esa batería. En esta sesión se detuvo en ese aviso tras 24 comprobaciones correctas; no se considera superada.

No ejecutar el cliente o el servidor sin rutas explícitas como método de prueba: sus rutas predeterminadas corresponden al perfil normal de Windows. No ejecutar instalaciones en el equipo del colegio durante el desarrollo.

## Compatibilidad

No cambia el esquema de datos, el protocolo de AgendaClara, la autoridad del centro ni las identidades de los puestos existentes. Actualizar sin cambiar la dirección conserva el PFX de servidor. La conexión sigue usando HTTPS y certificado de puesto; no se aceptan certificados inválidos. El diagnóstico no reconfigura el cortafuegos, las redes o la confianza de Windows. Puede autenticar al usuario, renovar su sesión cifrada, leer la agenda y registrar el acceso en el servidor.