﻿#nullable enable
using System.Net;
using System.Security.Claims;
using System.Text.Encodings.Web;
using System.Text.Json;
using AgendaClara;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Server.Kestrel.Https;
using Microsoft.AspNetCore.SignalR;
using Microsoft.Extensions.Options;

namespace AgendaClara.Server;
public sealed class AgendaAuthentication(IOptionsMonitor<AuthenticationSchemeOptions> options,ILoggerFactory logger,UrlEncoder encoder,ServerEngine engine):AuthenticationHandler<AuthenticationSchemeOptions>(options,logger,encoder)
{
    protected override async Task<AuthenticateResult> HandleAuthenticateAsync()
    {
        var trace=SessionTrace.From(Context);trace?.Mark("authentication_handler_start");
        var cert=await Context.Connection.GetClientCertificateAsync();if(cert==null)return AuthenticateResult.Fail("Falta el certificado de equipo.");
        string token=Request.Headers.Authorization.ToString();token=token.StartsWith("Bearer ",StringComparison.Ordinal)?token.Substring(7):"";
        // The desktop client normally uses headers; WebSocket negotiation may use this dedicated query parameter.
        if(token.Length==0 && Request.Path.StartsWithSegments("/changes"))token=Request.Query["access_token"].ToString();
        if(token.Length>1024)return AuthenticateResult.Fail("Sesión no válida.");
        trace?.Mark("access_lookup_start");
        var p=engine.Security.Authenticate(token,SecurityState.CertificateId(cert));trace?.Mark("access_lookup_end");if(p==null)return AuthenticateResult.Fail("La sesión ha caducado.");
        var claims=new List<Claim>{new(ClaimTypes.Name,p.UserName),new(ClaimTypes.Role,p.Role),new("device",p.Device),new("admin",p.Admin?"true":"false")};
        return AuthenticateResult.Success(new AuthenticationTicket(new ClaimsPrincipal(new ClaimsIdentity(claims,Scheme.Name)),new AuthenticationProperties{ExpiresUtc=p.UntilUtc},Scheme.Name));
    }
}
[Authorize]
public sealed class ChangesHub:Hub { }
public static class ServerHost
{
    static Principal Person(HttpContext ctx)=>new(ctx.User.Identity!.Name!,ctx.User.FindFirst("device")!.Value,ctx.User.FindFirst(System.Security.Claims.ClaimTypes.Role)!.Value,ctx.User.HasClaim("admin","true"),DateTime.UtcNow.AddMinutes(15));
    static IResult Xml<T>(T value,int code=200)=>Results.Content(XmlData.Write(value),"application/xml; charset=utf-8",System.Text.Encoding.UTF8,code);
    static async Task<T> Read<T>(HttpContext ctx)
    {
        using var reader=new StreamReader(ctx.Request.Body); string text=await reader.ReadToEndAsync(ctx.RequestAborted);return XmlData.Read<T>(text);
    }
    public static WebApplication Create(string root,string[] args)
    {
        Format.ApplyCulture();
        var settings=JsonSerializer.Deserialize<ServerSettings>(File.ReadAllText(Path.Combine(root,"server.json")))??throw new IOException("Configuración no válida.");
        if(settings.Port<1024||settings.Port>65535||settings.BackupMinutes<1||settings.RetentionDays<1||settings.AllowedNetworks.Count==0)throw new IOException("Revisa puerto, redes autorizadas y copias.");
        foreach(var network in settings.AllowedNetworks)Certificates.ValidateLocalNetwork(network);
        var engine=new ServerEngine(root,settings);
        var builder=WebApplication.CreateBuilder(new WebApplicationOptions{Args=args,ContentRootPath=root});
        builder.Logging.AddFilter("Microsoft.AspNetCore.Hosting.Diagnostics",LogLevel.Warning);
        builder.Services.AddWindowsService(o=>o.ServiceName="AgendaClaraServidor");
        builder.Services.AddSingleton(_=>new SessionDiagnostics(root));
        builder.Services.AddSingleton(engine);builder.Services.AddHostedService<BackupWorker>();
        builder.Services.AddAuthentication("Agenda").AddScheme<AuthenticationSchemeOptions,AgendaAuthentication>("Agenda",_=>{});
        builder.Services.AddAuthorization(o=>o.AddPolicy("Admin",p=>p.RequireAuthenticatedUser().RequireClaim("admin","true")));
        builder.Services.AddSignalR(o=>{o.EnableDetailedErrors=false;o.MaximumReceiveMessageSize=32768;});
        var server=Certificates.Load(root,"server.pfx"); var authority=System.Security.Cryptography.X509Certificates.X509CertificateLoader.LoadCertificateFromFile(Path.Combine(root,"authority.cer"));
        builder.WebHost.ConfigureKestrel(k=>{
            k.AddServerHeader=false;k.Limits.MaxRequestBodySize=268435456;
            k.Listen(IPAddress.Parse(settings.ListenHost),settings.Port,l=>l.UseHttps(new HttpsConnectionAdapterOptions{ServerCertificate=server,ClientCertificateMode=ClientCertificateMode.RequireCertificate,ClientCertificateValidation=(cert,_,_)=>Certificates.ValidateClient(cert,authority)}));
        });
        var app=builder.Build();
        var diagnostics=app.Services.GetRequiredService<SessionDiagnostics>();
        app.Use((HttpContext ctx,RequestDelegate next)=>diagnostics.InvokeAsync(ctx,next));
        app.Use(async(ctx,next)=>{
            var trace=SessionTrace.From(ctx);trace?.Mark("network_check_start");
            if(!Certificates.NetworkAllowed(ctx.Connection.RemoteIpAddress,settings.AllowedNetworks))
            {
                var remote=ctx.Connection.RemoteIpAddress;if(remote!=null&&remote.IsIPv4MappedToIPv6)remote=remote.MapToIPv4();
                ctx.Response.StatusCode=403;ctx.Response.ContentType="application/xml";
                await ctx.Response.WriteAsync(XmlData.Write(new NetworkError{Code="network",Message="Este ordenador ("+remote+") está en una red que el servidor no tiene autorizada. Pide a Jefatura que añada su subred en «Opciones de red» del instalador del servidor."}));return;
            }
            trace?.Mark("network_check_end");trace?.Mark("client_certificate_start");
            var cert=await ctx.Connection.GetClientCertificateAsync();trace?.Mark("client_certificate_end");trace?.Mark("device_check_start");
            if(cert==null||!engine.Security.DeviceAllowed(SecurityState.CertificateId(cert))){ctx.Response.StatusCode=403;ctx.Response.ContentType="application/xml";await ctx.Response.WriteAsync(XmlData.Write(new NetworkError{Code="device",Message="El certificado de este puesto está revocado o no autorizado."}));return;}
            trace?.Mark("device_check_end");
            if(ctx.Request.Headers["X-Agenda-Protocol"]!="1"){ctx.Response.StatusCode=426;ctx.Response.ContentType="application/xml";await ctx.Response.WriteAsync(XmlData.Write(new NetworkError{Code="client-version",Message="Esta versión del cliente no es compatible con el servidor. Actualiza AgendaClara."}));return;}
            if(!ctx.Request.Path.StartsWithSegments("/api/admin/restore") && ctx.Request.ContentLength>8388608){ctx.Response.StatusCode=413;return;}
            try{await next();}
            catch(ConflictException ex){if(!ctx.Response.HasStarted){ctx.Response.StatusCode=409;ctx.Response.ContentType="application/xml";await ctx.Response.WriteAsync(XmlData.Write(new NetworkError{Code="conflict",Message=ex.Message}));}}
            catch(UnauthorizedAccessException ex){if(!ctx.Response.HasStarted){ctx.Response.StatusCode=401;ctx.Response.ContentType="application/xml";await ctx.Response.WriteAsync(XmlData.Write(new NetworkError{Code="access",Message=ex.Message}));}}
            catch(Exception ex)when(ex is ArgumentException||ex is InvalidOperationException||ex is System.Xml.XmlException){if(!ctx.Response.HasStarted){ctx.Response.StatusCode=400;ctx.Response.ContentType="application/xml";await ctx.Response.WriteAsync(XmlData.Write(new NetworkError{Code="validation",Message=ex is ArgumentException?ex.Message:"La petición no tiene el formato esperado."}));}}
            catch(System.Security.Cryptography.CryptographicException){if(!ctx.Response.HasStarted){ctx.Response.StatusCode=400;ctx.Response.ContentType="application/xml";await ctx.Response.WriteAsync(XmlData.Write(new NetworkError{Code="invalid-backup",Message="La copia está alterada o no corresponde a la clave de recuperación del servidor. No se ha restaurado."}));}}
            catch(IOException ex){diagnostics.StorageFailure(ctx,ex);app.Logger.LogError(ex,"Error de almacenamiento");if(!ctx.Response.HasStarted){ctx.Response.StatusCode=503;ctx.Response.ContentType="application/xml";await ctx.Response.WriteAsync(XmlData.Write(new NetworkError{Code="storage",Message="No se ha podido completar la operación de almacenamiento. Consulta el diagnóstico del servidor."}));}}
        });
        app.UseAuthentication();app.UseAuthorization();
        app.MapPost("/api/session",async(HttpContext ctx)=>{
            var trace=SessionTrace.From(ctx);trace?.Mark("body_read_start");
            var input=await Read<LoginRequest>(ctx);trace?.Mark("body_read_end");
            var cert=await ctx.Connection.GetClientCertificateAsync();
            var session=engine.Security.Login(input,SecurityState.CertificateId(cert!),trace==null?null:trace.Mark);
            if(!settings.OfflineCacheAllowed)session.OfflineUntilUtc=DateTime.MinValue;
            trace?.Mark("agenda_lock_wait");
            lock(engine.Gate){trace?.Mark("agenda_lock_acquired");trace?.Mark("audit_save_start");engine.Store.LogAdministration(session.UserName,SecurityState.CertificateId(cert!),"login","");trace?.Mark("audit_save_end");}
            trace?.Mark("session_reply_ready");return Xml(session);
        });
        app.MapPost("/api/logout",(HttpContext ctx)=>{var p=Person(ctx);engine.Security.Logout(p.UserName,p.Device);return Results.NoContent();}).RequireAuthorization();
        app.MapGet("/api/snapshot",()=>Xml(engine.Snapshot())).RequireAuthorization();
        app.MapGet("/api/operations/{id}",(string id,HttpContext ctx)=>{lock(engine.Gate)return Xml(engine.Store.OperationState(id,Person(ctx).UserName));}).RequireAuthorization();
        app.MapGet("/api/health",()=>Xml(engine.Health())).RequireAuthorization();
        app.MapPost("/api/commands",async(HttpContext ctx,IHubContext<ChangesHub> hub)=>{
            var command=await Read<AgendaCommand>(ctx);var result=engine.Apply(command,Person(ctx));await hub.Clients.All.SendAsync("Changed",result.Snapshot.Generation,result.Snapshot.Revision);return Xml(result);
        }).RequireAuthorization();
        app.MapGet("/api/admin/users",()=>Xml(engine.Security.Users())).RequireAuthorization("Admin");
        app.MapPost("/api/admin/users",async(HttpContext ctx)=>{var p=Person(ctx);var change=await Read<UserChange>(ctx);lock(engine.Gate){engine.Security.ChangeUser(change);engine.Store.LogAdministration(p.UserName,p.Device,"user-change",change.UserName);}return Xml(engine.Security.Users());}).RequireAuthorization("Admin");
        app.MapGet("/api/admin/devices",()=>Xml(engine.Security.Devices())).RequireAuthorization("Admin");
        app.MapPost("/api/admin/devices",async(HttpContext ctx)=>{var p=Person(ctx);var d=await Read<DeviceView>(ctx);lock(engine.Gate){engine.Security.SetDevice(d.Thumbprint,d.Enabled);engine.Store.LogAdministration(p.UserName,p.Device,"device-change",d.Thumbprint);}return Xml(engine.Security.Devices());}).RequireAuthorization("Admin");
        app.MapGet("/api/admin/audit",()=>{lock(engine.Gate)return Xml(engine.Store.Audit(500));}).RequireAuthorization("Admin");
        app.MapGet("/api/admin/backups",()=>Xml(engine.ListBackups())).RequireAuthorization("Admin");
        app.MapPost("/api/admin/backups",(HttpContext ctx)=>{var p=Person(ctx);var b=engine.Backup();lock(engine.Gate)engine.Store.LogAdministration(p.UserName,p.Device,"backup",b.Name);return Xml(b);}).RequireAuthorization("Admin");
        app.MapGet("/api/admin/backups/{name}",(string name)=>Results.File(engine.Download(name),"application/octet-stream",name)).RequireAuthorization("Admin");
        app.MapPost("/api/admin/restore",async(HttpContext ctx,IHubContext<ChangesHub> hub)=>{
            var p=Person(ctx);string gen=ctx.Request.Headers["X-Agenda-Generation"].ToString();if(!long.TryParse(ctx.Request.Headers["X-Agenda-Revision"],out var rev))throw new ArgumentException("Falta la revisión de la agenda.");
            using var stream=new MemoryStream();await ctx.Request.Body.CopyToAsync(stream,ctx.RequestAborted);engine.Restore(stream.ToArray(),gen,rev,p);await hub.Clients.All.SendAsync("Changed","restored",0L);return Results.NoContent();
        }).RequireAuthorization("Admin");
        app.MapHub<ChangesHub>("/changes", o => o.CloseOnAuthenticationExpiration = true).RequireAuthorization();
        app.Lifetime.ApplicationStopped.Register(()=>{engine.Dispose();server.Dispose();authority.Dispose();});return app;
    }
}
public static class Program
{
    static string Argument(string[] args,string name,string fallback="") { int i=Array.IndexOf(args,name);return i>=0&&i+1<args.Length?args[i+1]:fallback; }
    // A .NET Framework parent whose console encoding is UTF-8 writes a byte order mark before the password; it is never part of it.
    public static string RedirectedPassword(TextReader input)=>(input.ReadLine()??"").TrimStart('﻿');
    public static string Password(string label)
    {
        Console.Write(label+": ");if(Console.IsInputRedirected)return RedirectedPassword(Console.In);
        var password=new System.Text.StringBuilder();while(true){var k=Console.ReadKey(true);if(k.Key==ConsoleKey.Enter){Console.WriteLine();return password.ToString();}if(k.Key==ConsoleKey.Backspace){if(password.Length>0)password.Length--;}else if(!char.IsControl(k.KeyChar))password.Append(k.KeyChar);}
    }
    // Changes the address used by the clients, the authorized subnets or the port of an existing server.
    // The server certificate is renewed by the same authority, so installed clients keep trusting it.
    public static ServerSettings ConfigureNetwork(string root,string host,string network,string port)
    {
        string path=Path.Combine(root,"server.json");
        var config=JsonSerializer.Deserialize<ServerSettings>(File.ReadAllText(path))??throw new IOException("Configuración no válida.");
        bool changedHost=false;
        if(host.Length>0){if(Uri.CheckHostName(host.Trim())==UriHostNameType.Unknown)throw new ArgumentException("Nombre de servidor no válido.");changedHost=!config.PublicHost.Equals(host.Trim(),StringComparison.OrdinalIgnoreCase);config.PublicHost=host.Trim();}
        if(network.Length>0)config.AllowedNetworks=Certificates.ParseNetworks(network);
        if(port.Length>0){if(!int.TryParse(port,out int value)||value<1024||value>65535)throw new ArgumentException("Puerto no válido (1024 a 65535).");config.Port=value;}
        if(changedHost)Certificates.RenewServer(root,config.PublicHost);
        Files.Atomic(path,JsonSerializer.SerializeToUtf8Bytes(config,new JsonSerializerOptions{WriteIndented=true}));
        return config;
    }
    public static async Task<int> Main(string[] args)
    {
        if(Console.IsInputRedirected)Console.InputEncoding=new System.Text.UTF8Encoding(false);
        if(Console.IsOutputRedirected)Console.OutputEncoding=new System.Text.UTF8Encoding(false);
        string root=Path.GetFullPath(Argument(args,"--data",Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),"AgendaClaraServidor")));
        try
        {
            if(new Uri(root).IsUnc || new DriveInfo(Path.GetPathRoot(root)!).DriveType==DriveType.Network)throw new IOException("La base central debe guardarse en un disco local del servidor.");
            if(args.Contains("recover"))
            {
                Directory.CreateDirectory(root);using var lease=new FileStream(Path.Combine(root,"server.lock"),FileMode.OpenOrCreate,FileAccess.ReadWrite,FileShare.None);
                ServerEngine.Recover(root,Argument(args,"--file"),Argument(args,"--recovery-key"),Argument(args,"--host"),Argument(args,"--network"),int.Parse(Argument(args,"--port","7443")));
                Console.WriteLine("Servidor recuperado con certificados, usuarios y datos. Se requiere nueva identificación de los clientes.");return 0;
            }
            if(args.Contains("backup"))
            {
                using var lease=new FileStream(Path.Combine(root,"server.lock"),FileMode.OpenOrCreate,FileAccess.ReadWrite,FileShare.None);
                using var engine=new ServerEngine(root,JsonSerializer.Deserialize<ServerSettings>(File.ReadAllText(Path.Combine(root,"server.json")))!);Console.WriteLine(engine.Backup().Name);return 0;
            }
            if(args.Contains("renew-certificate"))
            {
                using var lease=new FileStream(Path.Combine(root,"server.lock"),FileMode.OpenOrCreate,FileAccess.ReadWrite,FileShare.None);
                var config=JsonSerializer.Deserialize<ServerSettings>(File.ReadAllText(Path.Combine(root,"server.json")))!;Certificates.RenewServer(root,config.PublicHost);Console.WriteLine("Certificado del servidor renovado. Reinicia el servicio.");return 0;
            }
            if(args.Contains("configure-network"))
            {
                // Needs the service stopped: the lock file is exclusive.
                using var lease=new FileStream(Path.Combine(root,"server.lock"),FileMode.OpenOrCreate,FileAccess.ReadWrite,FileShare.None);
                var config=ConfigureNetwork(root,Argument(args,"--host"),Argument(args,"--network"),Argument(args,"--port"));
                Console.WriteLine("Red actualizada: https://"+config.PublicHost+":"+config.Port+" · redes autorizadas: "+string.Join(", ",config.AllowedNetworks)+".");return 0;
            }
            if(args.Contains("init"))
            {
                Directory.CreateDirectory(root);using var lease=new FileStream(Path.Combine(root,"server.lock"),FileMode.OpenOrCreate,FileAccess.ReadWrite,FileShare.None);
                if(File.Exists(Path.Combine(root,"server.json")))throw new IOException("El servidor ya está configurado.");
                string host=Argument(args,"--host"),network=Argument(args,"--network"),user=Argument(args,"--user");
                if(string.IsNullOrWhiteSpace(host)||string.IsNullOrWhiteSpace(network)||string.IsNullOrWhiteSpace(user))throw new ArgumentException("Indica --host, --network y --user.");
                if(Uri.CheckHostName(host)==UriHostNameType.Unknown)throw new ArgumentException("Nombre de servidor no válido.");var networks=Certificates.ParseNetworks(network);
                if(!int.TryParse(Argument(args,"--port","7443"),out int requestedPort)||requestedPort<1024||requestedPort>65535)throw new ArgumentException("Puerto no válido (1024 a 65535).");
                string password=Password("Contraseña del administrador");SecurityState.ValidatePassword(password);
                string source=Argument(args,"--import");string database=Path.Combine(root,"agenda.sqlite3");
                if(File.Exists(database))throw new IOException("La carpeta ya contiene una agenda. Usa otra carpeta para inicializar.");
                if(source.Length>0)Store.CopyReadOnly(source,database);
                using(var store=new Store(database,false)){if(store.HasServerOwner)throw new IOException("La agenda pertenece ya a un servidor. Utiliza el procedimiento de recuperación central.");if(store.IntegrityCheck()!="ok")throw new IOException("La agenda importada no es íntegra.");store.LoadSnapshot();store.NewGeneration("migracion","consola-local");}
                Certificates.Initialize(root,host);SecurityState.Initialize(root,user,password);
                var config=new ServerSettings{PublicHost=host,Port=int.Parse(Argument(args,"--port","7443")),AllowedNetworks=networks,BackupDirectory=Path.Combine(root,"copias"),ExternalBackupDirectory=Argument(args,"--external-backups")};
                Files.Atomic(Path.Combine(root,"server.json"),JsonSerializer.SerializeToUtf8Bytes(config,new JsonSerializerOptions{WriteIndented=true}));
                Console.WriteLine("Servidor inicializado. Importación verificada. Aún no se ha instalado el servicio.");return 0;
            }
            if(args.Contains("enroll"))
            {
                using var lease=new FileStream(Path.Combine(root,"server.lock"),FileMode.OpenOrCreate,FileAccess.ReadWrite,FileShare.None);
                string name=Argument(args,"--name"),output=Argument(args,"--output");if(output.Length==0)throw new ArgumentException("Indica --output.");
                Certificates.Enroll(root,name,Password("Contraseña del paquete de equipo"),Path.GetFullPath(output),Argument(args,"--automatic-role"));Console.WriteLine("Equipo registrado y paquete creado.");return 0;
            }
            if(args.Contains("export-recovery-key"))
            {
                string output=Argument(args,"--output");if(output.Length==0)throw new ArgumentException("Indica --output en una ubicación protegida y externa al servidor.");
                using var lease=new FileStream(Path.Combine(root,"server.lock"),FileMode.OpenOrCreate,FileAccess.ReadWrite,FileShare.None);
                if(File.Exists(output))throw new IOException("El archivo de recuperación ya existe.");
                File.WriteAllText(output,Convert.ToBase64String(Certificates.Unprotect(File.ReadAllBytes(Path.Combine(root,"backup-key.dpapi")))));Console.WriteLine("Clave exportada. Guárdala fuera del ordenador y separada de las copias.");return 0;
            }
            if(args.Contains("import-recovery-key"))
            {
                using var lease=new FileStream(Path.Combine(root,"server.lock"),FileMode.OpenOrCreate,FileAccess.ReadWrite,FileShare.None);
                string file=Argument(args,"--file");byte[] key=Convert.FromBase64String(File.ReadAllText(file).Trim());if(key.Length!=32)throw new ArgumentException("Clave de recuperación no válida.");Files.Atomic(Path.Combine(root,"backup-key.dpapi"),Certificates.Protect(key));Console.WriteLine("Clave de recuperación importada.");return 0;
            }
            using(var lease=new FileStream(Path.Combine(root,"server.lock"),FileMode.OpenOrCreate,FileAccess.ReadWrite,FileShare.None))
            { var app=ServerHost.Create(root,[]);await app.RunAsync(); }
            return 0;
        }
        catch(Exception ex){Console.Error.WriteLine("AgendaClara servidor: "+ex.Message);return 1;}
    }
}
