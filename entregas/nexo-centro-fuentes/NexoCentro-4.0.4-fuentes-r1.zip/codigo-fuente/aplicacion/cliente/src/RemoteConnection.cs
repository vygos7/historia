﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Security.Principal;
using System.Security.AccessControl;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.SignalR.Client;

namespace AgendaClara
{
    public sealed class ConnectionFailure : IOException
    {
        public readonly string Code;
        public ConnectionFailure(string code,string message,Exception inner=null):base(message,inner){Code=code;}
    }
    public static class ConnectionDiagnostics
    {
        static readonly object logGate=new object();
        public static ConnectionFailure Explain(Exception error,bool cancelled,string tls="")
        {
            if(tls.Length>0)return Tls(tls,error);
            if(error is ConnectionFailure)return (ConnectionFailure)error;
            for(Exception e=error;e!=null;e=e.InnerException)
            {
                var endpointTls=e as EndpointTlsException;
                if(endpointTls!=null)return Tls(endpointTls.Code,error);
                var socket=e as System.Net.Sockets.SocketException;
                if(socket!=null)
                {
                    if(socket.SocketErrorCode==System.Net.Sockets.SocketError.HostNotFound || socket.SocketErrorCode==System.Net.Sockets.SocketError.NoData || socket.SocketErrorCode==System.Net.Sockets.SocketError.TryAgain)return new ConnectionFailure("dns",DnsMessage,error);
                    if(socket.SocketErrorCode==System.Net.Sockets.SocketError.ConnectionRefused)return new ConnectionFailure("refused","Jefatura no acepta la conexión. Puede estar apagado el servidor o detenido el servicio de AgendaClara; pide que comprueben ambos.",error);
                    if(socket.SocketErrorCode==System.Net.Sockets.SocketError.TimedOut)return new ConnectionFailure("timeout",TimeoutMessage,error);
                    return new ConnectionFailure("network","No se puede acceder al puerto del servidor de Jefatura. Comprueba la conexión de red y pide que revisen el servicio."+SubnetHint(),error);
                }
                var web=e as WebException;
                if(web!=null)
                {
                    if(web.Status==WebExceptionStatus.NameResolutionFailure)return new ConnectionFailure("dns",DnsMessage,error);
                    if(web.Status==WebExceptionStatus.TrustFailure)return Tls("untrusted",error);
                    if(web.Status==WebExceptionStatus.Timeout)return new ConnectionFailure("timeout",TimeoutMessage,error);
                    if(web.Status==WebExceptionStatus.SecureChannelFailure)return Tls("handshake",error);
                }
                var native=e as System.ComponentModel.Win32Exception;
                if(native!=null)
                {
                    if(native.NativeErrorCode==unchecked((int)0x80090325)||native.NativeErrorCode==unchecked((int)0x800B0109))return Tls("untrusted",error);
                    if(native.NativeErrorCode==unchecked((int)0x80090322))return Tls("name",error);
                    if(native.NativeErrorCode==unchecked((int)0x80090328))return Tls("expired",error);
                    if(native.NativeErrorCode==unchecked((int)0x80090327)||native.NativeErrorCode==unchecked((int)0x8009030e))return Tls("handshake",error);
                }
                if(e is System.Security.Authentication.AuthenticationException)return Tls("handshake",error);
                if(e is PathTooLongException || e is UnauthorizedAccessException || e is System.Security.SecurityException)return new ConnectionFailure("local-storage","No se puede guardar o consultar la sesión local. Comprueba la longitud de la ruta y los permisos del perfil de Windows; no es una prueba de fallo de red.",error);
            }
            if(error is OperationCanceledException)return cancelled?new ConnectionFailure("cancelled","Se ha cancelado la operación.",error):new ConnectionFailure("timeout",TimeoutMessage,error);
            return new ConnectionFailure("connection","No se ha podido completar la conexión con Jefatura. Consulta el registro de diagnóstico para identificar el fallo.",error);
        }
        static string DnsMessage{get{return "No se puede resolver el nombre de Jefatura. Ejecuta «Diagnosticar conexión con Jefatura» y comprueba la dirección configurada.";}}
        static string TimeoutMessage{get{return "La operación no se completó dentro del plazo. Este resultado no identifica por sí solo un fallo de red, TLS o de la API. Ejecuta «Diagnosticar conexión con Jefatura». Direcciones locales: "+String.Join(", ",LocalAddresses())+".";}}
        // Names this computer's own address, which is what Jefatura must authorize when the puesto is on another subnet.
        public static string SubnetHint()
        {
            var own=LocalAddresses();
            return " Si este ordenador"+(own.Count>0?" ("+String.Join(", ",own)+")":"")+" está en otra subred que Jefatura, el servidor debe tenerla autorizada en «Opciones de red» y el router del centro debe dejar pasar el puerto del servidor.";
        }
        public static List<string> LocalAddresses()
        {
            var result=new List<string>();
            try
            {
                foreach(var adapter in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces().Where(n=>n.OperationalStatus==System.Net.NetworkInformation.OperationalStatus.Up && n.NetworkInterfaceType!=System.Net.NetworkInformation.NetworkInterfaceType.Loopback))
                    foreach(var unicast in adapter.GetIPProperties().UnicastAddresses.Where(a=>a.Address.AddressFamily==System.Net.Sockets.AddressFamily.InterNetwork))
                    {
                        byte[] b=unicast.Address.GetAddressBytes();
                        if(b[0]==10 || b[0]==172&&b[1]>=16&&b[1]<=31 || b[0]==192&&b[1]==168)result.Add(unicast.Address.ToString());
                    }
            }
            catch(System.Net.NetworkInformation.NetworkInformationException){}
            return result.Distinct().ToList();
        }
        static ConnectionFailure Tls(string code,Exception error)
        {
            string message=code=="name"?"El certificado no corresponde al nombre del servidor. Usa la dirección facilitada por Jefatura.":
                code=="expired"?"El certificado HTTPS del servidor o su autoridad ha caducado o aún no es válido. Comprueba la fecha del equipo y pide a Jefatura que lo revise.":
                code=="untrusted"?"No se confía en el certificado HTTPS de Jefatura. Ejecuta la reparación del cliente entregada por Jefatura; no aceptes certificados desconocidos.":
                code=="client"?"El servidor ha rechazado el certificado de este puesto. Pide a Jefatura que revise su autorización y su fecha de validez.":
                "No se ha podido establecer la conexión segura. El servidor puede haber rechazado el certificado del puesto; pide a Jefatura que revise el diagnóstico TLS.";
            return new ConnectionFailure("tls-"+code,message,error);
        }
        public static void Record(string directory,ConnectionFailure failure)
        {
            try
            {
                lock(logGate)
                {
                    string folder=Path.Combine(directory,"diagnostico");
                    Directory.CreateDirectory(folder);
                    var acl=new System.Security.AccessControl.DirectorySecurity();acl.SetAccessRuleProtection(true,false);
                    foreach(var id in new IdentityReference[]{WindowsIdentity.GetCurrent().User,new SecurityIdentifier(WellKnownSidType.LocalSystemSid,null),new SecurityIdentifier(WellKnownSidType.BuiltinAdministratorsSid,null)})acl.AddAccessRule(new System.Security.AccessControl.FileSystemAccessRule(id,System.Security.AccessControl.FileSystemRights.FullControl,System.Security.AccessControl.InheritanceFlags.ContainerInherit|System.Security.AccessControl.InheritanceFlags.ObjectInherit,System.Security.AccessControl.PropagationFlags.None,System.Security.AccessControl.AccessControlType.Allow));
                    new DirectoryInfo(folder).SetAccessControl(acl);
                    string path=Path.Combine(folder,"conexion.log");if(File.Exists(path)&&new FileInfo(path).Length>262144){string old=path+".anterior";if(File.Exists(old))File.Delete(old);File.Move(path,old);}
                    var detail=new StringBuilder(DateTime.UtcNow.ToString("o")+" code="+failure.Code);
                    for(Exception e=failure.InnerException;e!=null;e=e.InnerException){detail.Append(" type="+e.GetType().Name+" hresult="+e.HResult.ToString("X8"));var socket=e as System.Net.Sockets.SocketException;if(socket!=null)detail.Append(" socket="+socket.SocketErrorCode);var web=e as WebException;if(web!=null)detail.Append(" web="+web.Status);}
                    File.AppendAllText(path,detail+Environment.NewLine,Encoding.UTF8);
                }
            }
            catch(IOException){}catch(UnauthorizedAccessException){}catch(System.Security.SecurityException){}
        }
    }
    public sealed class SharedConfiguration
    {
        public bool Shared, AllowOffline, AutomaticAccess;
        public string ServerAuthority = "";
        public string ServerUrl = "", UserName = "", ClientThumbprint = "", IndividualDatabase = "";
        public SharedConfiguration EditConnection(string server,string user,string thumbprint,bool offline)
        {
            return new SharedConfiguration{Shared=true,ServerUrl=server,UserName=user,ClientThumbprint=thumbprint,AllowOffline=offline,IndividualDatabase=IndividualDatabase,ServerAuthority=ServerAuthority,AutomaticAccess=AutomaticAccess && UserName.Equals(user,StringComparison.OrdinalIgnoreCase) && ClientThumbprint.Equals(thumbprint,StringComparison.OrdinalIgnoreCase)};
        }
        public static string DefaultPath { get { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "AgendaClara", "TrabajoCompartido.xml"); } }
        public static SharedConfiguration Load(string path) { return File.Exists(path) ? XmlData.Read<SharedConfiguration>(File.ReadAllText(path)) : new SharedConfiguration(); }
        public void Save(string path) { Directory.CreateDirectory(Path.GetDirectoryName(path)); Atomic(path, Encoding.UTF8.GetBytes(XmlData.Write(this))); }
        public static void Atomic(string path, byte[] data)
        {
            string temp = path + "." + Guid.NewGuid().ToString("N") + ".tmp";
            try { using (var file = new FileStream(temp, FileMode.CreateNew, FileAccess.Write, FileShare.None)) { file.Write(data, 0, data.Length); file.Flush(true); } if (File.Exists(path)) File.Replace(temp, path, null); else File.Move(temp, path); }
            finally { if (File.Exists(temp)) File.Delete(temp); }
        }
    }
    public sealed class ProtectedCache
    {
        public string WindowsUser = "", Origin = "", Certificate = "", PendingRequestId = "";
        public DateTime LastSyncUtc;
        public SessionReply Session = new SessionReply();
        public AgendaSnapshot Snapshot = new AgendaSnapshot();
    }
    public sealed class UncertainOperationException : IOException
    {
        public UncertainOperationException() : base("Se ha perdido la respuesta del servidor y el resultado aún debe verificarse. No repitas este guardado. Conserva tus anotaciones y consulta la agenda cuando se recupere la conexión; esta ventana queda bloqueada para evitar duplicados.") { }
    }
    public sealed class RequestRejectedException : IOException { public RequestRejectedException(string message) : base(message) { } }
    public sealed class SessionExpiredException : IOException { public SessionExpiredException(string message) : base(message) { } }
    public sealed partial class RemoteConnection : IRemoteAgenda, IDisposable
    {
        readonly object gate = new object();
        readonly SemaphoreSlim synchronization = new SemaphoreSlim(1,1), authentication = new SemaphoreSlim(1,1);
        readonly SharedConfiguration configuration;
        readonly HttpClient http;
        readonly EndpointRouter endpointRouter;
        readonly X509Certificate2 certificate;
        readonly string cachePath;
        volatile string tlsFailure="";
        readonly CancellationTokenSource lifetime = new CancellationTokenSource();
        ProtectedCache cache;
        HubConnection hub;
        bool online, authenticated, disposed;
        string status = "Conectando", lastNotice = "";
        public event Action Changed;
        long notifications;
        public long NotificationsReceived { get { return Interlocked.Read(ref notifications); } }
        public bool RealtimeConnected { get { return hub != null && hub.State == HubConnectionState.Connected; } }
        public string LastNotice { get { lock(gate) return lastNotice; } }
        public DateTime LastSyncUtc { get { lock(gate) return cache.LastSyncUtc; } }
        public SharedConfiguration Configuration { get { return configuration; } }
        public bool CanReadOffline { get { lock(gate) return configuration.AllowOffline && certificate.NotAfter.ToUniversalTime() > DateTime.UtcNow && cache.Session.OfflineUntilUtc > DateTime.UtcNow && cache.Snapshot.Generation.Length > 0; } }
        public bool HasSession { get { lock(gate) return cache.Session.RefreshToken.Length > 0; } }
        public bool CanWrite { get { lock(gate) return online && authenticated && cache.PendingRequestId.Length == 0; } }
        public bool IsAdmin { get { lock(gate) return online && authenticated && cache.Session.Admin; } }
        public string Status { get { lock(gate) return status + (cache.LastSyncUtc == DateTime.MinValue ? " · sin datos sincronizados" : " · última sincronización " + cache.LastSyncUtc.ToLocalTime().ToString("dd/MM/yyyy HH:mm:ss")) + (lastNotice.Length==0 ? "" : " · " + lastNotice); } }
        public AgendaSnapshot Snapshot { get { lock(gate) return XmlData.Read<AgendaSnapshot>(XmlData.Write(online || CanReadOffline ? cache.Snapshot : new AgendaSnapshot())); } }
        public static List<X509Certificate2> AvailableCertificates()
        {
            using(var store = new X509Store(StoreName.My, StoreLocation.CurrentUser)) { store.Open(OpenFlags.ReadOnly); return store.Certificates.Cast<X509Certificate2>().Where(c => c.HasPrivateKey && c.NotAfter.ToUniversalTime() > DateTime.UtcNow && c.NotBefore.ToUniversalTime() <= DateTime.UtcNow && c.Extensions.OfType<X509EnhancedKeyUsageExtension>().Any(e=>e.EnhancedKeyUsages.Cast<Oid>().Any(o=>o.Value=="1.3.6.1.5.5.7.3.2"))).ToList(); }
        }
        static string Fingerprint(X509Certificate2 c) { using(var sha=SHA256.Create())return BitConverter.ToString(sha.ComputeHash(c.RawData)).Replace("-",""); }
        public RemoteConnection(SharedConfiguration configuration, string configPath)
        {
            Uri address;
            if(!Uri.TryCreate(configuration.ServerUrl,UriKind.Absolute,out address) || address.Scheme!="https" || address.UserInfo.Length!=0 || address.Query.Length!=0 || address.Fragment.Length!=0 || address.AbsolutePath!="/")throw new ArgumentException("Indica una dirección HTTPS con nombre o IP y puerto, sin rutas adicionales.");
            this.configuration=configuration;
            using(var personal=new X509Store(StoreName.My,StoreLocation.CurrentUser))
            {
                personal.Open(OpenFlags.ReadOnly);
                var selected=personal.Certificates.Find(X509FindType.FindByThumbprint,configuration.ClientThumbprint,false).Cast<X509Certificate2>().FirstOrDefault();
                if(selected!=null && (selected.NotAfter.ToUniversalTime()<DateTime.UtcNow || selected.NotBefore.ToUniversalTime()>DateTime.UtcNow))throw new ConnectionFailure("client-expired","El certificado de acceso de este puesto ha caducado o aún no es válido. Comprueba la fecha y pide a Jefatura un instalador actualizado.");
            }
            certificate=AvailableCertificates().FirstOrDefault(c=>c.Thumbprint.Equals(configuration.ClientThumbprint,StringComparison.OrdinalIgnoreCase)) ?? throw new ConnectionFailure("client-certificate","No se encuentra un certificado vigente de este puesto con clave privada y uso de autenticación de cliente. Revisa el paquete de acceso.");
            var handler = new HttpClientHandler { AllowAutoRedirect = false, UseCookies = false, UseProxy = false };
            endpointRouter=new EndpointRouter(address,certificate,configuration.ServerAuthority);
            http=new HttpClient(ConfigureHandler(handler)) { BaseAddress=address, Timeout=TimeSpan.FromSeconds(10) };
            string id; using(var sha=SHA256.Create())id=BitConverter.ToString(sha.ComputeHash(Encoding.UTF8.GetBytes(address.AbsoluteUri+"|"+configuration.UserName))).Replace("-","");
            Directory.CreateDirectory(Path.GetDirectoryName(configPath));cachePath=Path.Combine(Path.GetDirectoryName(configPath),"consulta-"+id+".dpapi");
            cache=new ProtectedCache { WindowsUser=WindowsIdentity.GetCurrent().User.Value, Origin=address.AbsoluteUri, Certificate=Fingerprint(certificate) };
            if(File.Exists(cachePath))
            {
                try {
                    var restored=XmlData.Read<ProtectedCache>(Encoding.UTF8.GetString(ProtectedData.Unprotect(File.ReadAllBytes(cachePath),null,DataProtectionScope.CurrentUser)));
                    if(restored.WindowsUser==cache.WindowsUser && restored.Origin==cache.Origin && restored.Certificate==cache.Certificate && restored.Session.UserName.Equals(configuration.UserName,StringComparison.OrdinalIgnoreCase)) cache=restored;
                }catch(CryptographicException){}catch(InvalidOperationException){}catch(IOException){}
            }
            if(!configuration.AllowOffline || cache.Session.OfflineUntilUtc<=DateTime.UtcNow)cache.Snapshot=new AgendaSnapshot();
        }
        HttpMessageHandler ConfigureHandler(HttpClientHandler handler)
        {
            handler.AllowAutoRedirect=false;handler.UseCookies=false;handler.UseProxy=false;
            handler.ClientCertificates.Add(certificate);
            handler.ServerCertificateCustomValidationCallback=(request,cert,chain,errors)=>
            {
                tlsFailure=endpointRouter.ValidateHttp(request,cert,errors);
                bool valid=tlsFailure.Length==0;
                IEnumerable<string> ids;
                string id=request.Headers.TryGetValues("X-Agenda-Request-Id",out ids)?ids.FirstOrDefault():"signalr";
                ReportDetail("HTTP id="+id+" validación del certificado HTTPS="+(valid?"correcta":"rechazada")+"; política="+errors+". Esto no demuestra todavía autorización de la API.");
                return valid;
            };
            return new AddressFallbackHandler(endpointRouter,handler,ReportDetail);
        }
        public bool ValidateServerCertificate(X509Certificate2 cert,System.Net.Security.SslPolicyErrors errors)
        {
            tlsFailure=ServerTlsTrust.Check(configuration.ServerAuthority,cert,errors);
            return tlsFailure.Length==0;
        }
        void Notify() { var handler=Changed; if(handler!=null)handler(); }
        void Persist()
        {
            lock(gate)
            {
                var copy=XmlData.Read<ProtectedCache>(XmlData.Write(cache));if(!configuration.AllowOffline || copy.Session.OfflineUntilUtc<=DateTime.UtcNow)copy.Snapshot=new AgendaSnapshot();
                SharedConfiguration.Atomic(cachePath,ProtectedData.Protect(Encoding.UTF8.GetBytes(XmlData.Write(copy)),null,DataProtectionScope.CurrentUser));
            }
        }
        async Task<HttpResponseMessage> Request(string method,string route, object body, bool authorized, CancellationToken token)
        {
            string stage=route=="api/session"?"Autenticación del puesto y del usuario":route=="api/snapshot"?"Recuperación de los datos iniciales":"Solicitud a la API";
            ReportStage(stage+" · "+method+" /"+route.Split('/').Take(2).Aggregate((a,b)=>a+"/"+b));
            var elapsed=System.Diagnostics.Stopwatch.StartNew();
            var request=new HttpRequestMessage(new HttpMethod(method),route);
            string requestId=Guid.NewGuid().ToString("N");
            request.Headers.Add("X-Agenda-Request-Id",requestId);
            ReportDetail("HTTP id="+requestId+" inicio; plazo total 10000 ms; DNS/TCP/TLS/cabeceras/cuerpo incluidos. No hay reintento automático.");
            var observation=ConnectionDetail==null?null:HttpSocketObservation.Start(http.BaseAddress.Port,detail=>ReportDetail("HTTP id="+requestId+" ms="+elapsed.ElapsedMilliseconds+" · "+detail));
            request.Headers.Add("X-Agenda-Protocol","1");
            if(authorized) { string access;lock(gate)access=cache.Session.AccessToken;request.Headers.Authorization=new AuthenticationHeaderValue("Bearer",access); }
            if(body!=null)request.Content=new StringContent(Serialize(body),Encoding.UTF8,"application/xml");
            tlsFailure="";
            try
            {
                var response=await HttpRequestTiming.SendAsync(http,request,detail=>ReportDetail("HTTP id="+requestId+" "+detail),token).ConfigureAwait(false);
                RecordStep(stage,"http-"+(int)response.StatusCode,elapsed.ElapsedMilliseconds);return response;
            }
            catch(Exception ex)when(ex is HttpRequestException || ex is OperationCanceledException || ex is WebException)
            {var failure=ConnectionDiagnostics.Explain(ex,token.IsCancellationRequested,tlsFailure);if(failure.Code=="timeout")failure=new ConnectionFailure("request-timeout",stage+": la solicitud no se completó en 10 segundos. El plazo incluye resolución del nombre, TCP, TLS y respuesta HTTP; ejecuta el diagnóstico por etapas para distinguirlos.",ex);RecordStep(stage,failure.Code,elapsed.ElapsedMilliseconds);ConnectionDiagnostics.Record(Path.GetDirectoryName(cachePath),failure);throw failure;}
            finally{if(observation!=null)await observation.StopAsync().ConfigureAwait(false);ReportDetail("HTTP id="+requestId+" fin; ms="+elapsed.ElapsedMilliseconds);request.Dispose();}
        }
        static string Serialize(object value)
        {
            using(var text=new StringWriter(System.Globalization.CultureInfo.InvariantCulture)){new System.Xml.Serialization.XmlSerializer(value.GetType()).Serialize(text,value);return text.ToString();}
        }
        async Task<T> Decode<T>(HttpResponseMessage response)
        {
            using(response)
            {
                string content=await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                if(!response.IsSuccessStatusCode)
                {
                    string message="El servidor rechazó la operación ("+(int)response.StatusCode+").";
                    try { message=XmlData.Read<NetworkError>(content).Message; }catch(InvalidOperationException){}
                    if(response.StatusCode==HttpStatusCode.Conflict)throw new ConflictException(message);
                    if(response.StatusCode==HttpStatusCode.Forbidden && routeDeviceError(content))throw new ConnectionFailure("tls-client","El certificado de este puesto está revocado o no autorizado. Pide a Jefatura un acceso válido.");
                    if(response.StatusCode==HttpStatusCode.Forbidden && ErrorCode(content)=="network")throw new ConnectionFailure("network-denied",message);
                    if(response.StatusCode==HttpStatusCode.Unauthorized || response.StatusCode==HttpStatusCode.Forbidden)throw new SessionExpiredException("El usuario no está autorizado, sus credenciales no son válidas o la sesión ha caducado. "+message);
                    if((int)response.StatusCode >= 500) throw new IOException(message);
                    throw new RequestRejectedException(message);
                }
                return XmlData.Read<T>(content);
            }
        }
        static bool routeDeviceError(string content){return ErrorCode(content)=="device";}
        static string ErrorCode(string content){try{return XmlData.Read<NetworkError>(content).Code??"";}catch(InvalidOperationException){return "";}}
        async Task EnsureSession(bool force=false,CancellationToken token=default(CancellationToken))
        {
            using(var linked=CancellationTokenSource.CreateLinkedTokenSource(lifetime.Token,token))
            {
            await authentication.WaitAsync(linked.Token).ConfigureAwait(false);
            try
            {
                SessionReply current;lock(gate)current=cache.Session;
                if(!force && current.ExpiresUtc>DateTime.UtcNow.AddMinutes(1) && current.AccessToken.Length>0)return;
                if(current.RefreshToken.Length==0 && !configuration.AutomaticAccess)throw new SessionExpiredException("Identifícate para conectar con el servidor.");
                var reply=await Decode<SessionReply>(await Request("POST","api/session",new LoginRequest { UserName=configuration.UserName,RefreshToken=configuration.AutomaticAccess?"":current.RefreshToken,Automatic=configuration.AutomaticAccess },false,linked.Token).ConfigureAwait(false)).ConfigureAwait(false);
                AcceptSession(reply);
            }
            finally{authentication.Release();}
            }
        }
        void AcceptSession(SessionReply reply)
        {
            lock(gate)
            {
                if(cache.Session.ServerId.Length>0 && cache.Session.ServerId!=reply.ServerId)throw new SessionExpiredException("La identidad del servidor ha cambiado. Revisa la configuración antes de volver a identificarte.");
                if(!reply.UserName.Equals(configuration.UserName,StringComparison.OrdinalIgnoreCase))throw new SessionExpiredException("La sesión corresponde a otro usuario.");
                cache.Session=reply;authenticated=true;
            }
            ReportStage("Guardar la sesión cifrada en el perfil local");Persist();
        }
        public async Task ConnectAsync(string password,CancellationToken token=default(CancellationToken))
        {
            using(var linked=CancellationTokenSource.CreateLinkedTokenSource(lifetime.Token,token))
            {
            lock(gate){status="Conectando";lastNotice="";}Notify();
            try
            {
                if(!configuration.AutomaticAccess && !string.IsNullOrEmpty(password))
                {
                    var reply=await Decode<SessionReply>(await Request("POST","api/session",new LoginRequest { UserName=configuration.UserName,Password=password },false,linked.Token).ConfigureAwait(false)).ConfigureAwait(false);AcceptSession(reply);
                }
                else await EnsureSession(true,linked.Token).ConfigureAwait(false);
                await SynchronizeAsync(linked.Token).ConfigureAwait(false);
                if(!CanWrite && !online)throw new IOException("No se ha recuperado el estado de la agenda.");
            }
            catch(SessionExpiredException){InvalidateSession();throw;}
            catch(Exception ex) { SetOffline(ex is ConnectionFailure?ex.Message:"Sin conexión");throw; }
            }
        }
        void InvalidateSession()
        {
            lock(gate){cache.Session=new SessionReply();cache.Snapshot=new AgendaSnapshot();online=false;authenticated=false;status="Identificación necesaria";}
            if(File.Exists(cachePath))File.Delete(cachePath);Notify();
        }
        void SetOffline(string text) { lock(gate){online=false;status=text; if (configuration.AllowOffline && cache.LastSyncUtc != DateTime.MinValue && !CanReadOffline) status += " · la copia de consulta ha caducado; conecta para actualizarla";}Notify(); }
        public void Start()
        {
            Task.Run(async()=> {
                while(!lifetime.IsCancellationRequested)
                {
                    try { await SynchronizeAsync().ConfigureAwait(false); if(online) { try { await CheckRealtimeAsync().ConfigureAwait(false); } catch(Exception ex) { RecordStep("SignalR","failed-"+ex.GetType().Name,0);lock(gate) lastNotice="Avisos en tiempo real no disponibles; comprobación periódica activa. Ejecuta el diagnóstico de conexión."; Notify(); } } }
                    catch(SessionExpiredException){InvalidateSession();}
                    catch(OperationCanceledException){if(lifetime.IsCancellationRequested)break;SetOffline("Tiempo de espera agotado");}
                    catch(ConnectionFailure ex){SetOffline(ex.Message);}
                    catch(Exception){SetOffline("Sin conexión");}
                    try{await Task.Delay(TimeSpan.FromSeconds(10),lifetime.Token).ConfigureAwait(false);}catch(OperationCanceledException){break;}
                }
            });
        }
        async Task EnsureHub(CancellationToken token)
        {
            if(hub!=null){if(hub.State==HubConnectionState.Disconnected)await hub.StartAsync(token).ConfigureAwait(false);return;}
            hub=new HubConnectionBuilder().WithUrl(new Uri(http.BaseAddress,"changes"),o=>{o.ClientCertificates = new X509CertificateCollection { certificate };o.Transports=Microsoft.AspNetCore.Http.Connections.HttpTransportType.LongPolling;o.HttpMessageHandlerFactory=h=>{var clientHandler=h as HttpClientHandler;if(clientHandler==null)throw new IOException("No se ha podido configurar la conexión del puesto.");return ConfigureHandler(clientHandler);};o.Headers["X-Agenda-Protocol"]="1";o.AccessTokenProvider=async()=>{await EnsureSession().ConfigureAwait(false);lock(gate)return cache.Session.AccessToken;};}).WithAutomaticReconnect(new[]{TimeSpan.Zero,TimeSpan.FromSeconds(2),TimeSpan.FromSeconds(10),TimeSpan.FromSeconds(30)}).Build();
            hub.On<string,long>("Changed",async(generation,revision)=>{Interlocked.Increment(ref notifications);try{await SynchronizeAsync().ConfigureAwait(false);}catch(SessionExpiredException){InvalidateSession();}catch{SetOffline("Error de sincronización");}});
            hub.Reconnected+=async id=>{await SynchronizeAsync().ConfigureAwait(false);};
            hub.Reconnecting+=ex=>{lock(gate) status="Conectado · recuperando avisos";Notify();return Task.CompletedTask;};
            await hub.StartAsync(token).ConfigureAwait(false);
        }
        public async Task SynchronizeAsync(CancellationToken token=default(CancellationToken))
        {
            using(var linked=CancellationTokenSource.CreateLinkedTokenSource(lifetime.Token,token))
            {
            if(disposed)return;await synchronization.WaitAsync(linked.Token).ConfigureAwait(false);
            try
            {
                await EnsureSession(false,linked.Token).ConfigureAwait(false);
                var response=await Request("GET","api/snapshot",null,true,linked.Token).ConfigureAwait(false);
                if(response.StatusCode==HttpStatusCode.Unauthorized){response.Dispose();await EnsureSession(true,linked.Token).ConfigureAwait(false);response=await Request("GET","api/snapshot",null,true,linked.Token).ConfigureAwait(false);}
                var snapshot=await Decode<AgendaSnapshot>(response).ConfigureAwait(false);AcceptSnapshot(snapshot);
                string pending;lock(gate)pending=cache.PendingRequestId;
                if(pending.Length>0)
                {
                    var result=await Decode<OperationStatus>(await Request("GET","api/operations/"+pending,null,true,lifetime.Token).ConfigureAwait(false)).ConfigureAwait(false);
                    lock(gate){cache.PendingRequestId="";lastNotice=result.Known?"La operación pendiente fue confirmada. Revisa la agenda.":"La operación pendiente no fue aplicada. Reabre el formulario para repetirla.";}
                }
                lock(gate){online=true;authenticated=true;status="Conectado y sincronizado";cache.LastSyncUtc=DateTime.UtcNow;}Persist();Notify();
            }
            finally{synchronization.Release();}
            }
        }
        void AcceptSnapshot(AgendaSnapshot snapshot)
        {
            lock(gate)
            {
                if(snapshot.Generation==cache.Snapshot.Generation && snapshot.Revision<cache.Snapshot.Revision)return;
                cache.Snapshot=snapshot;
            }
        }
        public AgendaReply Execute(AgendaCommand command) { return ExecuteAsync(command).GetAwaiter().GetResult(); }
        async Task<AgendaReply> ExecuteAsync(AgendaCommand command)
        {
            await synchronization.WaitAsync(lifetime.Token).ConfigureAwait(false);
            try
            {
                if(!CanWrite)throw new IOException("No se pueden modificar datos compartidos sin conexión y sincronización confirmadas.");
                await EnsureSession().ConfigureAwait(false);
                lock(gate){cache.PendingRequestId=command.RequestId;}Persist();
                try
                {
                    var reply=await Decode<AgendaReply>(await Request("POST","api/commands",command,true,lifetime.Token).ConfigureAwait(false)).ConfigureAwait(false);
                    AcceptSnapshot(reply.Snapshot);lock(gate){cache.PendingRequestId="";cache.LastSyncUtc=DateTime.UtcNow;}Persist();Notify();return reply;
                }
                catch(ConflictException){lock(gate)cache.PendingRequestId="";Persist();throw;}
                catch(SessionExpiredException){lock(gate)cache.PendingRequestId="";InvalidateSession();throw;}
                catch(HttpRequestException){SetOffline("Sin conexión · guardado por verificar");throw new UncertainOperationException();}
                catch(TaskCanceledException){SetOffline("Sin conexión · guardado por verificar");throw new UncertainOperationException();}
                catch(RequestRejectedException){lock(gate)cache.PendingRequestId="";Persist();throw;}
                catch(IOException){SetOffline("Error de sincronización · guardado por verificar");throw new UncertainOperationException();}
                catch(InvalidOperationException){SetOffline("Respuesta no válida · guardado por verificar");throw new UncertainOperationException();}
            }
            finally{synchronization.Release();}
        }
        public IRemoteAgenda Fork(){return new PinnedRemote(this,Snapshot);}
        sealed class PinnedRemote : IRemoteAgenda
        {
            readonly RemoteConnection owner;AgendaSnapshot snapshot;
            public PinnedRemote(RemoteConnection owner,AgendaSnapshot snapshot){this.owner=owner;this.snapshot=snapshot;}
            public AgendaSnapshot Snapshot {get{return XmlData.Read<AgendaSnapshot>(XmlData.Write(snapshot));}}
            public bool CanWrite {get{return owner.CanWrite;}}public bool IsAdmin {get{return owner.IsAdmin;}}public string Status {get{return owner.Status;}}
            public event Action Changed {add{owner.Changed+=value;}remove{owner.Changed-=value;}}
            public AgendaReply Execute(AgendaCommand c){var r=owner.Execute(c);snapshot=r.Snapshot;return r;}
            public IRemoteAgenda Fork(){return new PinnedRemote(owner,owner.Snapshot);}
        }
        public async Task<T> Admin<T>(string method,string route,object body=null)
        {
            await EnsureSession().ConfigureAwait(false);return await Decode<T>(await Request(method,route,body,true,lifetime.Token).ConfigureAwait(false)).ConfigureAwait(false);
        }
        public async Task<byte[]> Download(string name)
        {
            await EnsureSession().ConfigureAwait(false);using(var r=await Request("GET","api/admin/backups/"+Uri.EscapeDataString(name),null,true,lifetime.Token).ConfigureAwait(false)){r.EnsureSuccessStatusCode();return await r.Content.ReadAsByteArrayAsync().ConfigureAwait(false);}
        }
        public async Task Restore(byte[] data)
        {
            await synchronization.WaitAsync(lifetime.Token).ConfigureAwait(false);
            try
            {
                if(!IsAdmin || !CanWrite)throw new IOException("La restauración necesita un administrador conectado.");await EnsureSession().ConfigureAwait(false);var s=Snapshot;
                using(var request=new HttpRequestMessage(HttpMethod.Post,"api/admin/restore"))
                {
                    lock(gate)request.Headers.Authorization=new AuthenticationHeaderValue("Bearer",cache.Session.AccessToken);
                    request.Headers.Add("X-Agenda-Protocol","1");request.Headers.Add("X-Agenda-Generation",s.Generation);request.Headers.Add("X-Agenda-Revision",s.Revision.ToString());request.Content=new ByteArrayContent(data);
                    using(var response=await http.SendAsync(request,lifetime.Token).ConfigureAwait(false)){if(!response.IsSuccessStatusCode){await Decode<NetworkError>(response).ConfigureAwait(false);}}
                }
                InvalidateSession();
            }
            finally{synchronization.Release();}
        }
        public async Task LogoutAsync()
        {
            try{using(var r=await Request("POST","api/logout",null,true,lifetime.Token).ConfigureAwait(false)){} }catch{}
            InvalidateSession();
        }
        public void Dispose()
        {
            disposed=true;lifetime.Cancel();if(hub!=null)hub.DisposeAsync().AsTask().GetAwaiter().GetResult();http.Dispose();certificate.Dispose();
        }
    }
}
