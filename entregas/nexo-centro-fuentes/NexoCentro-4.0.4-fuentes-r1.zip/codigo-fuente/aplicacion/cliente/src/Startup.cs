using System;
using System.IO;
using Microsoft.Win32;

namespace AgendaClara
{
    // Opening the daily summary when the user signs in to Windows: one value in the user's own Run key
    // (no administrator rights, no scheduled tasks). It is on by default; unticking the option removes
    // the value and records the choice, so that it is not turned on again.
    public static class Startup
    {
        public const string Argument = "--resumen";
        const string ValueName = "AgendaClara", OptOutName = "NoMostrarAlIniciarWindows";
        // Replaced by the tests so that they never touch the real keys.
        internal static string KeyPath = @"Software\Microsoft\Windows\CurrentVersion\Run";
        internal static string SettingsPath = @"Software\AgendaClara";

        public static string ExecutablePath() { return typeof(Startup).Assembly.Location; }

        public static string Command(string databasePath)
        {
            string command = "\"" + ExecutablePath() + "\" " + Argument;
            if (databasePath.StartsWith("Servidor local", StringComparison.Ordinal)) return command;
            if (!String.Equals(Path.GetFullPath(databasePath), Path.GetFullPath(Program.DefaultDatabasePath()), StringComparison.OrdinalIgnoreCase))
                command += " --agenda \"" + Path.GetFullPath(databasePath) + "\"";
            return command;
        }

        public static string Registered()
        {
            using (var key = Registry.CurrentUser.OpenSubKey(KeyPath)) return key == null ? null : key.GetValue(ValueName) as string;
        }

        public static bool IsEnabled { get { return Registered() != null; } }

        public static bool OptedOut
        {
            get { using (var key = Registry.CurrentUser.OpenSubKey(SettingsPath)) return key != null && key.GetValue(OptOutName) != null; }
        }

        public static void Enable(string databasePath)
        {
            using (var key = Registry.CurrentUser.CreateSubKey(KeyPath)) key.SetValue(ValueName, Command(databasePath), RegistryValueKind.String);
            using (var key = Registry.CurrentUser.OpenSubKey(SettingsPath, true)) if (key != null) key.DeleteValue(OptOutName, false);
        }

        public static void Disable()
        {
            using (var key = Registry.CurrentUser.OpenSubKey(KeyPath, true)) if (key != null) key.DeleteValue(ValueName, false);
            using (var key = Registry.CurrentUser.CreateSubKey(SettingsPath)) key.SetValue(OptOutName, 1, RegistryValueKind.DWord);
        }

        // Called whenever the personal agenda is opened: turns the option on unless the user unticked it,
        // and keeps it pointing at this copy of the program (for example after installing a new version).
        public static void ApplyDefault(string databasePath)
        {
            if (!OptedOut && Registered() != Command(databasePath)) Enable(databasePath);
        }
    }
}
