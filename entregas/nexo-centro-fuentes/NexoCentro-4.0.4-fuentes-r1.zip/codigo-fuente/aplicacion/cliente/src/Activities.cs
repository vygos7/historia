using System;
using System.Collections.Generic;
using System.Linq;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Automation;

namespace AgendaClara
{
    public sealed class ActivityPanel : StackPanel
    {
        readonly AgendaEvent draft;
        readonly Store store;
        readonly TextBox title;
        readonly DatePicker start;
        readonly TextBox key = new TextBox();
        readonly DataGrid tasks = new DataGrid { AutoGenerateColumns = false, CanUserAddRows = false, CanUserDeleteRows = false, MinHeight = 130, MaxHeight = 270 };
        readonly ObservableCollection<PreparationTask> rows;
        readonly TextBox rating = Box(), positives = Box(), difficulties = Box(), improvements = Box(), justification = Box();
        readonly ComboBox continuity = new ComboBox { ItemsSource = new[] { "", "Sí", "No" } };
        readonly TextBlock prominentWarning;
        readonly TextBlock warning = Theme.Text("", 13, Theme.Warning, true);
        static TextBox Box() { return new TextBox { AcceptsReturn = true, TextWrapping = TextWrapping.Wrap, MinHeight = 65, MaxHeight = 180, VerticalScrollBarVisibility = ScrollBarVisibility.Auto }; }
        static void Field(Panel p, string name, Control c) { p.Children.Add(Theme.Label(name)); p.Children.Add(c); c.Margin = new Thickness(0, 0, 0, 10); AutomationProperties.SetName(c, name); }
        public ActivityPanel(Store store, AgendaEvent draft, TextBox title, DatePicker start, TextBlock prominentWarning)
        {
            this.prominentWarning = prominentWarning; this.store = store; this.draft = draft; this.title = title; this.start = start;
            Children.Add(Theme.Text("Preparación y memoria · toda la actividad", 18, Theme.Ink, true));
            Children.Add(Theme.Text("En actividades repetidas, las tareas y la memoria son comunes a todas sus fechas. Se guardan con el botón Guardar de la actividad.", 12, Theme.Muted));
            rows = new ObservableCollection<PreparationTask>(draft.Options.Tasks);
            tasks.Columns.Add(new DataGridCheckBoxColumn { Header = "Hecha", Binding = new Binding("Completed") });
            tasks.Columns.Add(new DataGridTextColumn { Header = "Preparativo", Binding = new Binding("Description"), Width = new DataGridLength(2, DataGridLengthUnitType.Star) });
            tasks.Columns.Add(new DataGridTextColumn { Header = "Responsable", Binding = new Binding("Responsible"), Width = new DataGridLength(1, DataGridLengthUnitType.Star) });
            var template = new DataTemplate(); var date = new FrameworkElementFactory(typeof(DatePicker));
            date.SetBinding(DatePicker.SelectedDateProperty, new Binding("Due") { Mode = BindingMode.TwoWay, UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged }); template.VisualTree = date;
            tasks.Columns.Add(new DataGridTemplateColumn { Header = "Fecha límite", CellTemplate = template, Width = 130 });
            tasks.Columns.Add(new DataGridCheckBoxColumn { Header = "Atención", Binding = new Binding("Attention") });
            var cellStyle = new Style(typeof(TextBlock)); cellStyle.Setters.Add(new Setter(TextBlock.TextWrappingProperty, TextWrapping.Wrap));
            foreach (var column in tasks.Columns.OfType<DataGridTextColumn>()) column.ElementStyle = cellStyle;
            tasks.ItemsSource = rows; AutomationProperties.SetName(tasks, "Preparativos"); Children.Add(tasks);
            var actions = new WrapPanel();
            actions.Children.Add(Theme.Button("Añadir tarea", () => { rows.Add(new PreparationTask()); tasks.SelectedIndex = rows.Count - 1; tasks.ScrollIntoView(tasks.SelectedItem); }));
            actions.Children.Add(Theme.Button("Quitar tarea seleccionada", () => { var r = tasks.SelectedItem as PreparationTask; if (r != null) rows.Remove(r); })); Children.Add(actions);
            Children.Add(Theme.Text("Las tareas pendientes con atención marcada, vencidas o con la actividad ya iniciada se destacan en la agenda.", 12, Theme.Muted));
            var history = new StackPanel();
            Field(history, "Identificador de actividad entre cursos (vacío = mismo título)", key); key.Text = draft.Options.HistoryKey;
            history.Children.Add(warning);
            history.Children.Add(Theme.Button("Consultar memorias anteriores", () => {
                var e = HistoryDraft(); var related = ActivityHistory.Related(store.EditSession().AllEvents(), e);
                if (related.Count == 0) MessageBox.Show(Window.GetWindow(this), "No hay memorias anteriores con este identificador o título.", "Memoria organizativa");
                else ActivityReports.Preview(Window.GetWindow(this), related, "Memorias de cursos anteriores" + (store.IsShared ? "\n" + store.ConnectionStatus : ""));
            }));
            Children.Add(new Expander { Header = "Memoria organizativa de cursos anteriores", IsExpanded = true, Content = history, Margin = new Thickness(0, 12, 0, 12) });
            var memo = new StackPanel();
            memo.Children.Add(Theme.Text("Completa la memoria tras celebrar la actividad. Para guardarla, indica valoración, continuidad y justificación.", 12, Theme.Muted));
            Field(memo, "Valoración general", rating); Field(memo, "Aspectos positivos", positives); Field(memo, "Incidencias y dificultades", difficulties); Field(memo, "Propuestas de mejora", improvements);
            Field(memo, "Continuidad en próximos cursos: Sí / No", continuity); Field(memo, "Justificación de la continuidad", justification);
            var m = draft.Options.Memory; rating.Text = m.Rating; positives.Text = m.Positives; difficulties.Text = m.Difficulties; improvements.Text = m.Improvements; continuity.SelectedItem = m.Continuity; justification.Text = m.Justification;
            Children.Add(new Expander { Header = "Evaluación y memoria de la actividad", Content = memo, IsExpanded = m.HasContent, Margin = new Thickness(0, 0, 0, 12) });
            key.TextChanged += (s, e) => RefreshWarning(); title.TextChanged += (s, e) => RefreshWarning(); start.SelectedDateChanged += (s, e) => RefreshWarning(); RefreshWarning();
        }
        AgendaEvent HistoryDraft() { var e = draft.Copy(); e.Title = title.Text; e.Start = start.SelectedDate ?? draft.Start; e.Options.HistoryKey = key.Text; return e; }
        public void RefreshFromServer() { RefreshWarning(); }
        void RefreshWarning()
        {
            var old = ActivityHistory.Related(store.AllEvents(), HistoryDraft()).Where(e => e.Options.Memory.Continuity == "No").ToList();
            prominentWarning.Text = old.Count == 0 ? "" : "ADVERTENCIA: una memoria anterior desaconseja repetir esta actividad. Revisa el historial en Preparación y memoria.";
            warning.Text = old.Count == 0 ? "Sin advertencias de continuidad anteriores." : "ADVERTENCIA: se desaconsejó repetir esta actividad.\n" + String.Join("\n", old.Select(e => Format.Date(e.Start) + " · " + e.Title + ": " + e.Options.Memory.Justification));
        }
        public void Read(EventOptions o)
        {
            if (!tasks.CommitEdit(DataGridEditingUnit.Cell, true) || !tasks.CommitEdit(DataGridEditingUnit.Row, true)) throw new ArgumentException("Revisa los datos de los preparativos.");
            o.Tasks = rows.Select(t => new PreparationTask { Description = t.Description, Responsible = t.Responsible, Due = t.Due, Completed = t.Completed, Attention = t.Attention }).ToList();
            o.HistoryKey = key.Text.Trim();
            var m = new ActivityMemory { Rating = rating.Text.Trim(), Positives = positives.Text.Trim(), Difficulties = difficulties.Text.Trim(), Improvements = improvements.Text.Trim(), Continuity = continuity.SelectedItem as string ?? "", Justification = justification.Text.Trim() };
            if (m.HasContent) m.Updated = DateTime.Now; o.Memory = m; ActivityHistory.Validate(o);
        }
    }
}
