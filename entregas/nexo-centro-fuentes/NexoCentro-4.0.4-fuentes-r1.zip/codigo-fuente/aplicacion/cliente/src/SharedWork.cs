using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using Microsoft.Win32;

namespace AgendaClara
{
    public static class SharedRuntime
    {
        public static string ConfigurationPath = SharedConfiguration.DefaultPath;
        public static RemoteConnection Connection;
        public static Store OpenStore(string individualPath)
        {
            var config=SharedConfiguration.Load(ConfigurationPath);
            if(!config.Shared)return new Store(string.IsNullOrWhiteSpace(config.IndividualDatabase)?individualPath:config.IndividualDatabase);
            try { Connection=new RemoteConnection(config,ConfigurationPath); }
            catch(Exception ex) { MessageBox.Show("No se ha abierto una agenda individual alternativa.\n\n"+Branding.Error(ex.Message),"Trabajo compartido");var setup=new ConnectionWindow(ConfigurationPath);setup.ShowDialog();return null; }
            var login=new LoginWindow(Connection);if(login.ShowDialog()!=true){Connection.Dispose();Connection=null;return null;}
            Connection.Start();return new Store(Connection);
        }
        public static void ShowSettings(Window owner,Store store)
        {
            if(Connection==null) { var config=new ConnectionWindow(ConfigurationPath){Owner=owner};if(config.ShowDialog()==true){MessageBox.Show(owner,"Configuración guardada. Vuelve a abrir Nexo Centro para iniciar el trabajo compartido. La agenda individual anterior se conserva y no se usará como alternativa si falla el servidor.","Trabajo compartido");Application.Current.Shutdown();} }
            else new SharedStatusWindow(Connection,ConfigurationPath){Owner=owner}.ShowDialog();
        }
    }
    public static class SharedUi
    {
        public static IEnumerable<DependencyObject> Elements(DependencyObject root)
        {yield return root;foreach(object child in LogicalTreeHelper.GetChildren(root)){var d=child as DependencyObject;if(d!=null)foreach(var item in Elements(d))yield return item;}}
        public static void ReadOnly(DependencyObject root,bool readOnly)
        {
            foreach(var d in Elements(root))
            {
                var text=d as TextBox;if(text!=null)text.IsReadOnly=readOnly;
                var combo=d as ComboBox;if(combo!=null)combo.IsEnabled=!readOnly;
                var date=d as DatePicker;if(date!=null)date.IsEnabled=!readOnly;
                var check=d as CheckBox;if(check!=null)check.IsEnabled=!readOnly;
                var grid=d as DataGrid;if(grid!=null){grid.IsReadOnly=readOnly;grid.IsEnabled=!readOnly;}
                var button=d as Button;if(button!=null && ((button.Content as string)=="Añadir tarea"||(button.Content as string)=="Quitar tarea seleccionada"))button.IsEnabled=!readOnly;
            }
        }
        public static void Field(Panel p,string label,Control c){p.Children.Add(Theme.Label(label));c.Margin=new Thickness(0,0,0,12);p.Children.Add(c);AutomationProperties.SetName(c,label);}
    }
    public sealed class LoginWindow:Window
    {
        readonly RemoteConnection remote;
        readonly PasswordBox password=new PasswordBox();
        readonly TextBlock message=Theme.Text("",13,Theme.Warning);
        readonly Button connect,offline;
        bool busy;
        public LoginWindow(RemoteConnection remote)
        {
            this.remote=remote;Theme.ApplyWindow(this);Title="Identificación · Nexo Centro compartida";Width=540;Height=460;MinWidth=430;MinHeight=360;WindowStartupLocation=WindowStartupLocation.CenterScreen;
            var p=new StackPanel{Margin=new Thickness(24)};p.Children.Add(Theme.Text("Trabajo compartido",24,Theme.Ink,true));
            p.Children.Add(Theme.Text(remote.Configuration.ServerUrl+"\nUsuario: "+remote.Configuration.UserName,13,Theme.Muted));if(!remote.Configuration.AutomaticAccess)SharedUi.Field(p,"Contraseña personal",password);else p.Children.Add(Theme.Text("Acceso automático de este puesto",13,Theme.Muted));
            connect=Theme.Button("Conectar",async()=>await Connect(password.Password),"Primary");p.Children.Add(connect);
            offline=Theme.Button("Consultar sin conexión",()=>{if(remote.CanReadOffline)DialogResult=true;});offline.IsEnabled=remote.CanReadOffline;p.Children.Add(offline);p.Children.Add(message);
            p.Children.Add(Theme.Button("Cambiar configuración",()=>{var w=new ConnectionWindow(SharedRuntime.ConfigurationPath){Owner=this};if(w.ShowDialog()==true){MessageBox.Show(this,"Configuración guardada. Abre Nexo Centro de nuevo.",Title);DialogResult=false;}}));
            p.Children.Add(Theme.Button("Diagnosticar conexión con Jefatura",()=>{new ConnectionDiagnosisWindow(remote,password.Password){Owner=this}.ShowDialog();password.Clear();}));
            p.Children.Add(Theme.Button("Salir",()=>{DialogResult=false;}));Content=new ScrollViewer{Content=p,VerticalScrollBarVisibility=ScrollBarVisibility.Auto};
            Loaded+=async(s,e)=>{if(remote.HasSession || remote.Configuration.AutomaticAccess)await Connect("");else{message.Text="Introduce tu contraseña para acceder. Si es el primer uso, el servidor debe estar disponible.";password.Focus();}};
            Closing+=(s,e)=>{if(busy)e.Cancel=true;};
        }
        async Task Connect(string secret)
        {
            if(busy)return;busy=true;connect.IsEnabled=false;offline.IsEnabled=false;message.Text="Conectando y recuperando la agenda…";
            try{await remote.ConnectAsync(secret);busy=false;DialogResult=true;}
            catch(Exception ex){message.Text=Branding.Error(ex.Message)+"\n"+remote.Status;if(remote.CanReadOffline){busy=false;DialogResult=true;}}
            finally{busy=false;connect.IsEnabled=true;offline.IsEnabled=remote.CanReadOffline;password.Clear();}
        }
    }
    public sealed class CertificateChoice
    {
        public string Thumbprint,Label;
        public override string ToString(){return Label;}
    }
    public sealed class ConnectionWindow:Window
    {
        readonly string path;
        readonly ComboBox mode=new ComboBox{ItemsSource=new[]{"Uso individual","Servidor de red local"}},certificate=new ComboBox();
        readonly TextBox server=new TextBox(),user=new TextBox();
        readonly PasswordBox password=new PasswordBox();
        readonly CheckBox offline=new CheckBox{Content="Permitir consulta sin conexión en este perfil personal de Windows"};
        readonly TextBlock message=Theme.Text("",13,Theme.Warning);
        public ConnectionWindow(string path)
        {
            this.path=path;var config=SharedConfiguration.Load(path);Theme.ApplyWindow(this);Title="Configuración · Trabajo compartido";Width=620;Height=700;MinWidth=480;MinHeight=450;WindowStartupLocation=WindowStartupLocation.CenterOwner;
            var p=new StackPanel{Margin=new Thickness(24)};p.Children.Add(Theme.Text("Trabajo compartido",24,Theme.Ink,true));
            p.Children.Add(Theme.Text("El servidor mantiene la agenda central. Los certificados se importan con el paquete de acceso de este equipo.",13,Theme.Muted));
            SharedUi.Field(p,"Modalidad",mode);mode.SelectedIndex=config.Shared?1:0;
            SharedUi.Field(p,"Dirección HTTPS del servidor",server);server.Text=config.ServerUrl;
            SharedUi.Field(p,"Usuario personal",user);user.Text=config.UserName;
            SharedUi.Field(p,"Contraseña (solo para comprobar el acceso)",password);
            certificate.ItemsSource=RemoteConnection.AvailableCertificates().Select(c=>new CertificateChoice{Thumbprint=c.Thumbprint,Label=c.GetNameInfo(X509NameType.SimpleName,false)+" · caduca "+c.NotAfter.ToString("dd/MM/yyyy")}).ToList();
            certificate.SelectedItem=certificate.Items.Cast<CertificateChoice>().FirstOrDefault(c=>c.Thumbprint==config.ClientThumbprint);if(certificate.SelectedIndex<0&&certificate.Items.Count>0)certificate.SelectedIndex=0;
            SharedUi.Field(p,"Certificado de equipo autorizado",certificate);offline.IsChecked=config.AllowOffline;p.Children.Add(offline);
            p.Children.Add(Theme.Text("Activa la consulta local solo si este perfil de Windows es de uso exclusivo. Los datos y la sesión se cifran para ese usuario. Al cambiar de usuario de Nexo Centro se debe cerrar la sesión anterior.",12,Theme.Muted));
            var save=Theme.Button("Comprobar conexión y guardar",async()=>await Save(),"Primary");p.Children.Add(save);
            p.Children.Add(Theme.Button("Diagnosticar conexión con Jefatura",Diagnose));
            p.Children.Add(message);p.Children.Add(Theme.Button("Cancelar",Close));Content=new ScrollViewer{Content=p,VerticalScrollBarVisibility=ScrollBarVisibility.Auto};
        }
        void Diagnose()
        {
            var choice=certificate.SelectedItem as CertificateChoice;
            if(choice==null){message.Text="Selecciona el certificado de acceso del puesto.";return;}
            try
            {
                var next=SharedConfiguration.Load(path).EditConnection(server.Text.Trim().TrimEnd('/'),user.Text.Trim(),choice.Thumbprint,offline.IsChecked==true);
                using(var connection=new RemoteConnection(next,path))new ConnectionDiagnosisWindow(connection,password.Password){Owner=this}.ShowDialog();
            }
            catch(Exception ex){message.Text=Branding.Error(ex.Message);}
            finally{password.Clear();}
        }
        async Task Save()
        {
            var config=SharedConfiguration.Load(path);
            if(mode.SelectedIndex==0)
            {
                if(config.Shared && !Dialogs.Confirm(this,"Pasar a uso individual","Se desvinculará este perfil del servidor y se creará una agenda individual vacía. No se copiarán ni modificarán los datos centrales. La agenda individual anterior no se reabrirá automáticamente.","Crear agenda individual"))return;
                if(config.Shared)config.IndividualDatabase=Path.Combine(Path.GetDirectoryName(path),"Individual-"+Guid.NewGuid().ToString("N")+".sqlite3");
                config.Shared=false;config.Save(path);DialogResult=true;return;
            }
            var choice=certificate.SelectedItem as CertificateChoice;if(choice==null){message.Text="Importa primero el certificado de acceso de este equipo.";return;}
            var next=config.EditConnection(server.Text.Trim().TrimEnd('/'),user.Text.Trim(),choice.Thumbprint,offline.IsChecked==true);
            if(next.UserName.Length==0){message.Text="Indica tu usuario personal.";return;}
            IsEnabled=false;message.Text="Comprobando credenciales y sincronización…";
            RemoteConnection connection=null;
            try
            {
                connection=new RemoteConnection(next,path);await connection.ConnectAsync(password.Password);next.Save(path);DialogResult=true;
            }
            catch(Exception ex){message.Text=Branding.Error(ex.Message);}
            finally{if(connection!=null)connection.Dispose();password.Clear();IsEnabled=true;}
        }
    }
    public sealed class SharedStatusWindow:Window
    {
        readonly RemoteConnection remote;
        readonly string configPath;
        readonly TextBlock state=Theme.Text("",13,Theme.Ink),message=Theme.Text("",13,Theme.Warning);
        readonly StackPanel data=new StackPanel();
        readonly ListBox backups=new ListBox{MaxHeight=180};
        readonly TextBox username=new TextBox();readonly PasswordBox password=new PasswordBox();
        readonly ComboBox role=new ComboBox{ItemsSource=new[]{"Direccion","Jefatura","Secretaria"},SelectedIndex=0};
        readonly CheckBox admin=new CheckBox{Content="Administrador"},enabled=new CheckBox{Content="Usuario habilitado",IsChecked=true};
        readonly DataGrid users=new DataGrid{AutoGenerateColumns=true,IsReadOnly=true,MaxHeight=190};
        public SharedStatusWindow(RemoteConnection remote,string configPath)
        {
            this.remote=remote;this.configPath=configPath;Theme.ApplyWindow(this);Title="Trabajo compartido · Estado y administración";Width=760;Height=790;MinWidth=560;MinHeight=450;WindowStartupLocation=WindowStartupLocation.CenterOwner;
            var p=new StackPanel{Margin=new Thickness(24)};p.Children.Add(Theme.Text("Trabajo compartido",24,Theme.Ink,true));p.Children.Add(state);
            p.Children.Add(Theme.Button("Comprobar conexión",async()=>await Run(async()=>{await remote.SynchronizeAsync();message.Text="Estado actualizado.";})));
            p.Children.Add(Theme.Button("Diagnosticar conexión con Jefatura",()=>new ConnectionDiagnosisWindow(remote,""){Owner=this}.ShowDialog()));
            p.Children.Add(Theme.Button("Configuración de conexión",()=>{var w=new ConnectionWindow(configPath){Owner=this};if(w.ShowDialog()==true){MessageBox.Show(this,"Configuración guardada. Vuelve a abrir Nexo Centro.",Title);Application.Current.Shutdown();}}));
            p.Children.Add(Theme.Button("Cerrar sesión y salir",async()=>{await remote.LogoutAsync();Application.Current.Shutdown();}));
            p.Children.Add(message);p.Children.Add(data);
            if(remote.IsAdmin)
            {
                data.Children.Add(Theme.Text("Administración del servidor",19,Theme.Ink,true));
                data.Children.Add(Theme.Button("Actualizar usuarios, copias y diagnóstico",async()=>await Load()));
                users.SelectionChanged+=(s,e)=>{var u=users.SelectedItem as UserRow;if(u!=null){username.Text=u.UserName;role.SelectedItem=u.Role;admin.IsChecked=u.Admin;enabled.IsChecked=u.Enabled;password.Clear();}};data.Children.Add(users);
                SharedUi.Field(data,"Usuario (selecciona uno o escribe uno nuevo)",username);SharedUi.Field(data,"Perfil",role);SharedUi.Field(data,"Contraseña nueva (vacía = conservar)",password);data.Children.Add(admin);data.Children.Add(enabled);
                data.Children.Add(Theme.Button("Guardar usuario",async()=>await Run(async()=>{await remote.Admin<List<UserView>>("POST","api/admin/users",new UserChange{UserName=username.Text.Trim(),Role=role.SelectedItem as string,Password=password.Password,Admin=admin.IsChecked==true,Enabled=enabled.IsChecked==true});password.Clear();message.Text="Usuario guardado. Sus sesiones anteriores se invalidan.";await Load();})));
                data.Children.Add(Theme.Text("Copias cifradas",17,Theme.Ink,true));data.Children.Add(backups);
                data.Children.Add(Theme.Button("Crear copia ahora",async()=>await Run(async()=>{await remote.Admin<BackupRecord>("POST","api/admin/backups");await Load();})));
                data.Children.Add(Theme.Button("Descargar copia seleccionada",async()=>await Download()));
                data.Children.Add(Theme.Button("Restaurar copia cifrada…",async()=>await Restore()));
                data.Children.Add(Theme.Button("Consultar registro de operaciones",async()=>await Run(async()=>{var rows=await remote.Admin<List<AuditRow>>("GET","api/admin/audit");ShowText("Registro de operaciones",String.Join("\n",rows.Select(r=>r.Utc.ToLocalTime().ToString("dd/MM/yyyy HH:mm:ss")+" · "+r.Actor+" · "+r.Operation+" · "+r.Entity+" · equipo "+r.Device)));})));
                data.Children.Add(Theme.Button("Equipos autorizados",async()=>await Devices()));
            }
            p.Children.Add(Theme.Button("Cerrar",Close));Content=new ScrollViewer{Content=p,VerticalScrollBarVisibility=ScrollBarVisibility.Auto};
            Action update=()=>Dispatcher.BeginInvoke(new Action(()=>state.Text=remote.Status));remote.Changed+=update;Closed+=(s,e)=>remote.Changed-=update;state.Text=remote.Status;Loaded+=async(s,e)=>{if(remote.IsAdmin)await Load();};
        }
        sealed class UserRow { public string UserName{get;set;} public string Role{get;set;} public bool Admin{get;set;} public bool Enabled{get;set;} }
        async Task Run(Func<Task> action){try{await action();}catch(Exception ex){message.Text=Branding.Error(ex.Message);}}
        async Task Load(){await Run(async()=>{var list=await remote.Admin<List<UserView>>("GET","api/admin/users");users.ItemsSource=list.Select(u=>new UserRow{UserName=u.UserName,Role=u.Role,Admin=u.Admin,Enabled=u.Enabled}).ToList();backups.ItemsSource=(await remote.Admin<List<BackupRecord>>("GET","api/admin/backups")).Select(b=>b.Name).ToList();var health=await remote.Admin<ServerHealth>("GET","api/health");message.Text="Servidor "+health.Version+" · revisión "+health.Revision+" · última copia "+(health.LastBackupUtc.HasValue?health.LastBackupUtc.Value.ToLocalTime().ToString():"pendiente")+(health.BackupError.Length>0?" · ERROR DE COPIA: "+health.BackupError:"");});}
        async Task Download()
        {
            string name=backups.SelectedItem as string;if(name==null){message.Text="Selecciona una copia.";return;}
            var save=new SaveFileDialog{FileName=name,Filter="Copia cifrada Nexo Centro|*.acbackup"};if(save.ShowDialog(this)!=true)return;
            await Run(async()=>{var bytes=await remote.Download(name);await Task.Run(()=>SharedConfiguration.Atomic(save.FileName,bytes));message.Text="Copia cifrada descargada. La clave de recuperación se conserva por separado.";});
        }
        async Task Restore()
        {
            var open=new OpenFileDialog{Filter="Copia cifrada Nexo Centro|*.acbackup"};if(open.ShowDialog(this)!=true)return;
            if(!Dialogs.Confirm(this,"Restauración central","Se sustituirán los datos compartidos y los usuarios por los de la copia. El servidor guardará antes un respaldo de seguridad. Se cerrarán todas las sesiones y los clientes deberán identificarse de nuevo. La clave de recuperación de esta copia debe estar disponible en el servidor.","Restaurar para todos"))return;
            await Run(async()=>{await remote.SynchronizeAsync();var bytes=await Task.Run(()=>File.ReadAllBytes(open.FileName));await remote.Restore(bytes);MessageBox.Show(this,"Copia restaurada. Abre Nexo Centro de nuevo para identificarte.",Title);Application.Current.Shutdown();});
        }
        void ShowText(string title,string text){var w=new Window{Title=title,Width=820,Height=600,Owner=this,WindowStartupLocation=WindowStartupLocation.CenterOwner};Theme.ApplyWindow(w);w.Content=new TextBox{Text=text,IsReadOnly=true,TextWrapping=TextWrapping.Wrap,VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Margin=new Thickness(16)};w.ShowDialog();}
        async Task Devices()
        {
            await Run(async()=>{
                var list=await remote.Admin<List<DeviceView>>("GET","api/admin/devices");var w=new Window{Title="Equipos autorizados",Width=650,Height=480,Owner=this,WindowStartupLocation=WindowStartupLocation.CenterOwner};Theme.ApplyWindow(w);var p=new StackPanel{Margin=new Thickness(20)};
                p.Children.Add(Theme.Text("Para añadir un equipo usa el procedimiento de inscripción local del servidor. Puedes revocar aquí un certificado perdido.",13,Theme.Muted));
                foreach(var d in list){var device=d;var button=Theme.Button((d.Enabled?"Revocar ":"Habilitar ")+d.Name,async()=>{try{device.Enabled=!device.Enabled;await remote.Admin<List<DeviceView>>("POST","api/admin/devices",device);w.Close();}catch(Exception ex){message.Text=Branding.Error(ex.Message);}});p.Children.Add(button);}
                p.Children.Add(Theme.Button("Cerrar",w.Close));w.Content=new ScrollViewer{Content=p,VerticalScrollBarVisibility=ScrollBarVisibility.Auto};w.ShowDialog();
            });
        }
    }
    public sealed class ConnectionDiagnosisWindow:Window
    {
        readonly System.Threading.CancellationTokenSource cancellation=new System.Threading.CancellationTokenSource();
        readonly TextBox output=new TextBox{IsReadOnly=true,AcceptsReturn=true,TextWrapping=TextWrapping.Wrap,VerticalScrollBarVisibility=ScrollBarVisibility.Auto,MinHeight=280};
        bool running=true;
        public ConnectionDiagnosisWindow(RemoteConnection remote,string secret)
        {
            Theme.ApplyWindow(this);Title="Diagnosticar conexión con Jefatura";Width=820;Height=650;MinWidth=550;MinHeight=430;WindowStartupLocation=WindowStartupLocation.CenterOwner;
            var panel=new DockPanel{Margin=new Thickness(20)};
            var actions=new StackPanel();DockPanel.SetDock(actions,Dock.Bottom);panel.Children.Add(actions);
            var close=Theme.Button("Cancelar",()=>{if(running)cancellation.Cancel();else Close();});actions.Children.Add(close);
            var export=Theme.Button("Guardar informe…",()=>
            {
                var dialog=new SaveFileDialog{FileName="NexoCentro-diagnostico-"+DateTime.Now.ToString("yyyyMMdd-HHmmss")+".txt",Filter="Informe de texto|*.txt"};
                if(dialog.ShowDialog(this)==true)try{File.WriteAllText(dialog.FileName,output.Text,System.Text.Encoding.UTF8);}catch(IOException ex){MessageBox.Show(this,Branding.Error(ex.Message),Title);}catch(UnauthorizedAccessException ex){MessageBox.Show(this,Branding.Error(ex.Message),Title);}
            });export.IsEnabled=false;actions.Children.Add(export);panel.Children.Add(output);Content=panel;
            Closing+=(s,e)=>{if(running){cancellation.Cancel();e.Cancel=true;}};
            Closed+=(s,e)=>cancellation.Dispose();
            Loaded+=async(s,e)=>
            {
                var progress=new Progress<string>(text=>{output.Text=Branding.Diagnostic(text);output.ScrollToEnd();});
                try
                {
                    cancellation.CancelAfter(TimeSpan.FromSeconds(90));
                    var report=await Task.Run(()=>remote.DiagnoseAsync(secret,progress,cancellation.Token));output.Text=Branding.Diagnostic(report.Text);
                }
                catch(Exception ex){output.Text="El diagnóstico no pudo completarse. Tipo técnico: "+ex.GetType().Name+". No se ha modificado la agenda.";}
                finally{secret="";running=false;close.Content="Cerrar";export.IsEnabled=true;}
            };
        }
    }
}

