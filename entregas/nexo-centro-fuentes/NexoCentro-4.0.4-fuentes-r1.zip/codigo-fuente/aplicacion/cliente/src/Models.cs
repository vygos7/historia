using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
#if !SERVER
using System.Windows;
using System.Windows.Markup;
#endif
using System.Xml.Serialization;
using System.Xml;

namespace AgendaClara
{
    public sealed class AgendaEvent
    {
        public long Id;
        public long Version;
        public long ConfigVersion;
        public string Generation = "";
        public string Title = "";
        public string Notes = "";
        public DateTime Start;
        public DateTime End;
        public int StartMinute = 540;
        public int EndMinute = 600;
        public bool AllDay;
        public EventOptions Options = new EventOptions();

        public const int MaxSpanDays = 731;

        public bool MultiDay { get { return End.Date > Start.Date; } }
        public string TimeLabel { get { return AllDay ? "Todo el día" : Clock(StartMinute) + "–" + Clock(EndMinute); } }
        public string DateLabel { get { return MultiDay ? "Del " + Format.Date(Start) + " al " + Format.Date(End) : Format.Date(Start); } }
        public static string Clock(int minutes) { return (minutes / 60).ToString("00") + ":" + (minutes % 60).ToString("00"); }

        public AgendaEvent Copy()
        {
            var copy = (AgendaEvent)MemberwiseClone();
            copy.Options = XmlData.Read<EventOptions>(XmlData.Write(Options));
            return copy;
        }

        // Rules that do not depend on the school calendar; Store.Save adds the calendar checks.
        public void Validate()
        {
            ActivityHistory.Validate(Options);
            if (String.IsNullOrWhiteSpace(Title)) throw new ArgumentException("Escribe un título para la actividad.");
            if (Title.Trim().Length > 200) throw new ArgumentException("El título es demasiado largo (máximo 200 caracteres).");
            if (End.Date < Start.Date) throw new ArgumentException("La fecha de finalización no puede ser anterior a la fecha de inicio.");
            if ((End.Date - Start.Date).TotalDays > MaxSpanDays) throw new ArgumentException("El intervalo no puede superar dos años. Divide la actividad en varios cursos.");
            if (!AllDay) ValidateTimes(StartMinute, EndMinute);
            if (Options.SpecificDates.Count == 0 && (Options.Weekdays & 127) == 0) throw new ArgumentException("Marca al menos un día de la semana en la repetición.");
            if (Options.ReminderDays < -1 || Options.ReminderDays > 365) throw new ArgumentException("El aviso debe estar entre 0 y 365 días de antelación, o desactivado.");
            foreach (var d in Options.SpecificDates)
                if (d.Date < Start.Date || d.Date > End.Date) throw new ArgumentException("La fecha concreta " + Format.Date(d) + " está fuera del intervalo de la actividad.");
            foreach (var d in Options.ExcludedDates)
                if (d.Date < Start.Date || d.Date > End.Date) throw new ArgumentException("La fecha excluida " + Format.Date(d) + " está fuera del intervalo de la actividad.");
            foreach (var c in Options.Changes)
            {
                if (c.Title != null && String.IsNullOrWhiteSpace(c.Title)) throw new ArgumentException("La fecha " + Format.Date(c.Date) + " necesita un título.");
                if (!c.AllDay) ValidateTimes(c.StartMinute, c.EndMinute);
            }
        }

        public static void ValidateTimes(int start, int end)
        {
            if (start < 0 || start > 1439 || end < 0 || end > 1439) throw new ArgumentException("Las horas deben estar entre 00:00 y 23:59.");
            if (end <= start) throw new ArgumentException("La hora de finalización debe ser posterior a la hora de inicio, dentro del mismo día.");
        }
    }

    public class EventOptions
    {
        public string HistoryKey = "";
        public List<PreparationTask> Tasks = new List<PreparationTask>();
        public ActivityMemory Memory = new ActivityMemory();
        public string Category = "Otros", Group = "", Responsible = "", Location = "";
        // Days of notice, in calendar days; -1 disables the reminder.
        public int ReminderDays = 7;
        // Bit 0 = Monday ... bit 6 = Sunday. Ignored when SpecificDates is used.
        public int Weekdays = 127;
        public bool AllowNonSchool;
        public List<DateTime> SpecificDates = new List<DateTime>();
        public List<DateTime> ExcludedDates = new List<DateTime>();
        public List<OccurrenceChange> Changes = new List<OccurrenceChange>();
    }

    // Changes that apply to a single date of an activity. Date is the date produced by the rule.
    public class OccurrenceChange
    {
        public DateTime Date;
        public string Title = "", Notes = "";
        public int StartMinute, EndMinute;
        public bool AllDay;
        public string Location;          // null: same as the activity (version 2 data has none)
        public DateTime? MovedTo;        // null: the occurrence stays on Date
        public bool AllowNonSchool;      // the new date may be a non-school day
    }

    public sealed class Category
    {
        public string Name = "";
        public string Color = "";
        public int Position;
        public int Count;
    }

    public static class CategoryPalette
    {
        public static readonly string[] DefaultNames = { "Salida / excursión", "Charla", "Taller", "Concurso", "Celebración", "Reunión", "Ausencia de profesorado", "Otros" };
        public static readonly string[] Colors = { "#2F6DB5", "#7B52C1", "#2E8556", "#B07C0A", "#C2407A", "#16808F", "#C05A2B", "#66747B", "#3E4FA8", "#8C5A2B", "#5B8A1E", "#A33A3A", "#00897B", "#9A4DB0", "#D06F00", "#4A6572" };
        public static readonly string[] ColorNames = { "Azul", "Violeta", "Verde", "Ámbar", "Rosa", "Turquesa", "Naranja", "Gris", "Añil", "Marrón", "Oliva", "Granate", "Verde azulado", "Morado", "Mandarina", "Pizarra" };
        public static string DefaultColor(string name)
        {
            int n = Array.IndexOf(DefaultNames, name);
            return n >= 0 ? Colors[n] : null;
        }
        public static string Next(IEnumerable<string> used)
        {
            var taken = new HashSet<string>(used.Where(c => c != null), StringComparer.OrdinalIgnoreCase);
            foreach (var c in Colors) if (!taken.Contains(c)) return c;
            return Colors[taken.Count % Colors.Length];
        }
        public static string ColorName(string hex)
        {
            int n = Array.FindIndex(Colors, c => String.Equals(c, hex, StringComparison.OrdinalIgnoreCase));
            return n >= 0 ? ColorNames[n] : hex;
        }
    }

    public class SchoolYear
    {
        public string Name = "";
        public DateTime Start, End;
        public SchoolYear() { }
        public SchoolYear(string name, string start, string end) { Name = name; Start = Format.ParseDate(start); End = Format.ParseDate(end); }
    }

    public class DatePeriod
    {
        public string Name = "";
        public string Kind = "";
        public DateTime Start;
        public DateTime End;
        public DatePeriod() { }
        public DatePeriod(string name, string kind, string start, string end) { Name = name; Kind = kind; Start = Format.ParseDate(start); End = Format.ParseDate(end); }
        public bool Contains(DateTime d) { return Start.Date <= d.Date && End.Date >= d.Date; }
    }

    public class SchoolCalendar
    {
        public long ConfigVersion;
        public static readonly string[] Kinds = { "Vacaciones", "Festivo", "Festivo nacional", "Festivo autonómico", "Festivo local", "No lectivo", "No lectivo local", "Cambio del centro" };

        public List<SchoolYear> Years = new List<SchoolYear>();
        public List<DatePeriod> Terms = new List<DatePeriod>();
        public List<DatePeriod> Breaks = new List<DatePeriod>();
        public string Source = "";
        // Version 2 stored a single class period in these two fields; Upgrade() moves it to Years.
        public DateTime Start, End;

        public const string HuelvaSource = "Precargado a partir del PDF «calendario Huelva 2026-27_dias_locales.pdf» (Junta de Andalucía, Delegación Territorial de Huelva, calendario escolar 2026/27), revisado el 27/10/2026. Los trimestres no figuran en el PDF: son una propuesta editable basada en las vacaciones.";

        public static SchoolCalendar Huelva()
        {
            var c = new SchoolCalendar { Source = HuelvaSource };
            c.Years.Add(new SchoolYear("Curso 2026/27 · Educación Primaria", "10/09/2026", "22/06/2027"));
            c.Terms.Add(new DatePeriod("Primer trimestre (propuesta)", "", "10/09/2026", "22/12/2026"));
            c.Terms.Add(new DatePeriod("Segundo trimestre (propuesta)", "", "08/01/2027", "19/03/2027"));
            c.Terms.Add(new DatePeriod("Tercer trimestre (propuesta)", "", "29/03/2027", "22/06/2027"));
            c.Breaks.Add(new DatePeriod("Festivo por el día de la Hispanidad", "Festivo", "12/10/2026", "12/10/2026"));
            c.Breaks.Add(new DatePeriod("Día de todos los Santos", "Festivo", "02/11/2026", "02/11/2026"));
            c.Breaks.Add(new DatePeriod("Día de la Constitución", "Festivo", "07/12/2026", "07/12/2026"));
            c.Breaks.Add(new DatePeriod("Día de la Inmaculada Concepción", "Festivo", "08/12/2026", "08/12/2026"));
            c.Breaks.Add(new DatePeriod("Vacaciones de Navidad", "Vacaciones", "23/12/2026", "06/01/2027"));
            c.Breaks.Add(new DatePeriod("Día de Navidad", "Festivo", "25/12/2026", "25/12/2026"));
            c.Breaks.Add(new DatePeriod("Día de Año Nuevo", "Festivo", "01/01/2027", "01/01/2027"));
            c.Breaks.Add(new DatePeriod("Epifanía del Señor", "Festivo", "06/01/2027", "06/01/2027"));
            c.Breaks.Add(new DatePeriod("Día no lectivo provincial", "No lectivo", "07/01/2027", "07/01/2027"));
            c.Breaks.Add(new DatePeriod("Día de la Comunidad Educativa", "No lectivo", "26/02/2027", "26/02/2027"));
            c.Breaks.Add(new DatePeriod("Día de Andalucía", "Festivo", "01/03/2027", "01/03/2027"));
            c.Breaks.Add(new DatePeriod("Vacaciones de Semana Santa", "Vacaciones", "22/03/2027", "28/03/2027"));
            c.Breaks.Add(new DatePeriod("Jueves Santo", "Festivo", "25/03/2027", "25/03/2027"));
            c.Breaks.Add(new DatePeriod("Viernes Santo", "Festivo", "26/03/2027", "26/03/2027"));
            c.Breaks.Add(new DatePeriod("Día del Trabajo", "Festivo", "01/05/2027", "01/05/2027"));
            c.Breaks.Add(new DatePeriod("Día no lectivo local", "No lectivo local", "13/05/2027", "13/05/2027"));
            c.Breaks.Add(new DatePeriod("Día no lectivo local", "No lectivo local", "14/05/2027", "14/05/2027"));
            c.Breaks.Add(new DatePeriod("Día no lectivo local", "No lectivo local", "17/05/2027", "17/05/2027"));
            return c;
        }

        public void Upgrade()
        {
            if (Years.Count == 0 && Start != default(DateTime) && End >= Start)
                Years.Add(new SchoolYear { Name = "Curso " + Start.Year + "/" + (End.Year % 100).ToString("00"), Start = Start.Date, End = End.Date });
            Start = default(DateTime); End = default(DateTime);
            foreach (var b in Breaks) if (String.IsNullOrEmpty(b.Kind)) b.Kind = b.Start.Date == b.End.Date ? "No lectivo" : "Vacaciones";
            if (Source == null) Source = "";
        }

        // The shortest matching period wins, so "Día de Navidad" shows inside the Christmas break.
        public DatePeriod BreakFor(DateTime date)
        {
            return Breaks.Where(p => p.Contains(date)).OrderBy(p => (p.End - p.Start).TotalDays).FirstOrDefault();
        }

        // Empty when the date is a school day; otherwise a readable reason.
        public string Reason(DateTime date)
        {
            var period = BreakFor(date);
            if (period != null) return period.Name;
            if (IsWeekend(date)) return "Fin de semana";
            if (Years.Count > 0 && !Years.Any(y => y.Start.Date <= date.Date && y.End.Date >= date.Date)) return "Fuera del periodo de clases";
            return "";
        }
        public bool IsSchoolDay(DateTime date) { return Reason(date).Length == 0; }
        public static bool IsWeekend(DateTime date) { return date.DayOfWeek == DayOfWeek.Saturday || date.DayOfWeek == DayOfWeek.Sunday; }

        public string Term(DateTime date)
        {
            var p = Terms.FirstOrDefault(t => t.Contains(date));
            return p == null ? "" : p.Name;
        }
        public string YearName(DateTime date)
        {
            var y = Years.FirstOrDefault(t => t.Start.Date <= date.Date && t.End.Date >= date.Date);
            return y == null ? "" : y.Name;
        }

        public SchoolCalendar Copy() { return XmlData.Read<SchoolCalendar>(XmlData.Write(this)); }

        public void Validate()
        {
            foreach (var y in Years)
            {
                if (String.IsNullOrWhiteSpace(y.Name)) throw new ArgumentException("Cada periodo de clases necesita un nombre.");
                if (y.End.Date < y.Start.Date) throw new ArgumentException("Revisa «" + y.Name + "»: la fecha final es anterior a la inicial.");
            }
            var years = Years.OrderBy(y => y.Start).ToList();
            for (int i = 1; i < years.Count; i++)
                if (years[i].Start.Date <= years[i - 1].End.Date) throw new ArgumentException("Los periodos de clases «" + years[i - 1].Name + "» y «" + years[i].Name + "» se solapan.");
            foreach (var p in Terms.Concat(Breaks))
            {
                if (String.IsNullOrWhiteSpace(p.Name)) throw new ArgumentException("Cada trimestre o periodo no lectivo necesita un nombre.");
                if (p.End.Date < p.Start.Date) throw new ArgumentException("Revisa «" + p.Name + "»: la fecha final es anterior a la inicial.");
                if ((p.End.Date - p.Start.Date).TotalDays > 400) throw new ArgumentException("Revisa «" + p.Name + "»: el periodo es demasiado largo.");
            }
            var terms = Terms.OrderBy(t => t.Start).ToList();
            for (int i = 1; i < terms.Count; i++)
                if (terms[i].Start.Date <= terms[i - 1].End.Date) throw new ArgumentException("Los trimestres «" + terms[i - 1].Name + "» y «" + terms[i].Name + "» se solapan.");
        }
    }

    public static class XmlData
    {
        static readonly Dictionary<Type, XmlSerializer> serializers = new Dictionary<Type, XmlSerializer>();
        static XmlSerializer For(Type t)
        {
            lock (serializers)
            {
                XmlSerializer s;
                if (!serializers.TryGetValue(t, out s)) { s = new XmlSerializer(t); serializers[t] = s; }
                return s;
            }
        }
        public static string Write<T>(T item) { using (var writer = new StringWriter(CultureInfo.InvariantCulture)) { For(typeof(T)).Serialize(writer, item); return writer.ToString(); } }
        public static T Read<T>(string value) { using (var text = new StringReader(value)) using (var reader = XmlReader.Create(text, new XmlReaderSettings { DtdProcessing = DtdProcessing.Prohibit, XmlResolver = null, MaxCharactersInDocument = 33554432 })) return (T)For(typeof(T)).Deserialize(reader); }
    }

    public static class Format
    {
        public static readonly CultureInfo Spanish = CreateCulture();
        static CultureInfo CreateCulture()
        {
            var c = (CultureInfo)CultureInfo.GetCultureInfo("es-ES").Clone();
            c.DateTimeFormat.ShortDatePattern = "dd/MM/yyyy";
            c.DateTimeFormat.ShortTimePattern = "HH:mm";
            c.DateTimeFormat.LongTimePattern = "HH:mm:ss";
            c.DateTimeFormat.FirstDayOfWeek = DayOfWeek.Monday;
            return c;
        }
        public static void ApplyCulture()
        {
            Thread.CurrentThread.CurrentCulture = Spanish;
            Thread.CurrentThread.CurrentUICulture = Spanish;
            CultureInfo.DefaultThreadCurrentCulture = Spanish;
            CultureInfo.DefaultThreadCurrentUICulture = Spanish;
#if !SERVER
            try { FrameworkElement.LanguageProperty.OverrideMetadata(typeof(FrameworkElement), new FrameworkPropertyMetadata(XmlLanguage.GetLanguage("es-ES"))); }
            catch (ArgumentException) { } // already applied in this process
#endif
        }
        public static string Date(DateTime d) { return d.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture); }
        public static string DayMonth(DateTime d) { return d.ToString("dd/MM", CultureInfo.InvariantCulture); }
        public static string Weekday(DateTime d) { return Spanish.DateTimeFormat.GetDayName(d.DayOfWeek); }
        public static string ShortWeekday(DateTime d) { return Capitalize(Spanish.DateTimeFormat.GetAbbreviatedDayName(d.DayOfWeek).TrimEnd('.')); }
        public static string LongDate(DateTime d) { return Capitalize(Weekday(d)) + ", " + Date(d); }
        public static string MonthYear(DateTime d) { return Capitalize(Spanish.DateTimeFormat.GetMonthName(d.Month)) + " " + d.Year; }
        public static string Capitalize(string s) { return String.IsNullOrEmpty(s) ? s : Char.ToUpper(s[0], Spanish) + s.Substring(1); }
        public static string Count(int n, string one, string many) { return n + " " + (n == 1 ? one : many); }
        public static DateTime ParseDate(string s) { return DateTime.ParseExact(s, "dd/MM/yyyy", CultureInfo.InvariantCulture); }
        public static bool TryParseDate(string s, out DateTime d)
        {
            return DateTime.TryParseExact((s ?? "").Trim(), new[] { "dd/MM/yyyy", "d/M/yyyy", "dd/M/yyyy", "d/MM/yyyy" }, CultureInfo.InvariantCulture, DateTimeStyles.None, out d);
        }
        public static List<DateTime> ParseDateList(string text, string fieldName)
        {
            var result = new List<DateTime>();
            foreach (string part in (text ?? "").Split(new[] { ';', ',', '\r', '\n', ' ' }, StringSplitOptions.RemoveEmptyEntries))
            {
                DateTime value;
                if (!TryParseDate(part, out value)) throw new ArgumentException("En «" + fieldName + "», «" + part.Trim() + "» no es una fecha válida. Escribe las fechas como DD/MM/AAAA separadas por punto y coma.");
                result.Add(value.Date);
            }
            return result.Distinct().OrderBy(d => d).ToList();
        }
        public static string DateList(IEnumerable<DateTime> dates) { return String.Join("; ", dates.OrderBy(d => d).Select(d => Date(d))); }
        public static bool TryParseTime(string text, out int minutes)
        {
            minutes = 0; DateTime result;
            string t = (text ?? "").Trim().Replace('.', ':').Replace('h', ':').TrimEnd(':');
            if (t.Length > 0 && t.Length <= 2 && t.All(Char.IsDigit)) t += ":00";
            if (!DateTime.TryParseExact(t, new[] { "H:mm", "HH:mm" }, CultureInfo.InvariantCulture, DateTimeStyles.None, out result)) return false;
            minutes = result.Hour * 60 + result.Minute; return true;
        }
        // Lower case without accents, used by the search.
        public static string Fold(string s)
        {
            if (String.IsNullOrEmpty(s)) return "";
            var sb = new StringBuilder(s.Length);
            foreach (char c in s.Normalize(NormalizationForm.FormD))
                if (CharUnicodeInfo.GetUnicodeCategory(c) != UnicodeCategory.NonSpacingMark) sb.Append(Char.ToLowerInvariant(c));
            return sb.ToString().Normalize(NormalizationForm.FormC);
        }
    }
}
