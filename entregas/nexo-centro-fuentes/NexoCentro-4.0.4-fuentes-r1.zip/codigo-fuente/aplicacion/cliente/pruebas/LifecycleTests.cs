using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Automation;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using AgendaClara;
namespace AgendaClara.Pruebas
{
    public static class LifecycleTests
    {
        static AgendaEvent Sample()
        {
            var e = new AgendaEvent { Title = "Visita al museo · Educación y ciencia", Start = new DateTime(2026, 9, 15), End = new DateTime(2026, 9, 15), AllDay = true };
            e.Options.HistoryKey = "Museo anual";
            e.Options.Tasks.Add(new PreparationTask { Description = "Confirmar autorización de las familias", Responsible = "Jefatura de estudios", Due = new DateTime(2026, 9, 10), Attention = true });
            e.Options.Tasks.Add(new PreparationTask { Description = "Reservar autobús", Responsible = "Secretaría", Completed = true });
            e.Options.Memory = new ActivityMemory { Rating = "Satisfactoria, aunque mejorable", Positives = "Buena participación del alumnado. Explicaciones accesibles y materiales útiles.", Difficulties = "Retraso del transporte y acceso complicado para el grupo.", Improvements = "Revisar el itinerario y confirmar el horario con una semana de antelación.", Continuity = "No", Justification = "No repetir hasta garantizar el transporte y la accesibilidad.", Updated = DateTime.Now };
            return e;
        }
        public static void Data(string folder)
        {
            T.Section("Preparación, memoria, historial y actualización v4");
            var path = Path.Combine(folder, "lifecycle.sqlite3");
            using (var s = new Store(path, false))
            {
                var e = Sample(); s.Save(e); var got = s.Find(e.Id);
                T.Check(got.Options.Tasks.Count == 2 && got.Options.Tasks[1].Completed && got.Options.Tasks[0].Due == new DateTime(2026,9,10), "Tareas, responsables, fechas y estados sobreviven a SQLite");
                T.Check(got.Options.Memory.Continuity == "No" && got.Options.Memory.Justification == e.Options.Memory.Justification, "Memoria completa vinculada a la actividad");
                var copy = got.Copy(); copy.Options.Tasks[0].Description = "Alterada"; copy.Options.Memory.Rating = "Alterada";
                T.Check(got.Options.Tasks[0].Description != "Alterada" && got.Options.Memory.Rating != "Alterada", "Editar o cancelar un borrador no altera las tareas ni la memoria guardada");
                T.Check(ActivityHistory.AttentionCount(got, new DateTime(2026,9,11)) == 1, "Solo las pendientes vencidas o señaladas requieren atención");
                got.Options.Tasks[0].Completed = true; T.Check(ActivityHistory.AttentionCount(got, DateTime.Today) == 0, "Las tareas completadas dejan de requerir atención");
                var next = Sample(); next.Title = "Museo con nuevo título"; next.Id = 88; next.Start = new DateTime(2027,9,15);
                T.Check(ActivityHistory.Related(s.AllEvents(), next).Count == 1, "El identificador relaciona memorias de cursos anteriores aunque cambie el título");
                next.Options.HistoryKey = "Otra"; T.Check(ActivityHistory.Related(s.AllEvents(), next).Count == 0, "El historial no mezcla actividades diferentes");
                var m = new ActivityMemory { Rating = "Buena", Continuity = "No" }; T.Throws(m.Validate, "justificación", "No se guarda una recomendación sin justificación");
                next = Sample(); next.Options.Tasks[0].Responsible = ""; T.Throws(() => s.Save(next), "responsable", "Las tareas necesitan responsable");
                var old = XmlData.Read<EventOptions>("<EventOptions><Category>Otros</Category></EventOptions>"); T.Check(old.Tasks.Count == 0 && !old.Memory.HasContent, "Las opciones antiguas reciben listas y memoria vacías");
                s.BackupTo(Path.Combine(folder, "lifecycle-backup.sqlite3"));
                s.Delete(e.Id); s.RestoreFrom(Path.Combine(folder, "lifecycle-backup.sqlite3"));
                T.Check(s.Find(e.Id).Options.Memory.Continuity == "No" && s.Find(e.Id).Options.Tasks.Count == 2, "Copia y restauración conservan las nuevas funciones");
                var moved = Sample(); moved.Options.Changes.Add(new OccurrenceChange { Date = moved.Start, MovedTo = new DateTime(2026,10,8), AllDay = true, Title = moved.Title });
                T.Check(ReportsWindow.InPeriod(moved, s.Calendar, new DateTime(2026,10,1), new DateTime(2026,10,31)) && !ReportsWindow.InPeriod(moved,s.Calendar,new DateTime(2026,9,1),new DateTime(2026,9,30)), "Los informes por periodo usan la fecha real de las ocurrencias trasladadas");
            }
            Raw.Exec(path,"UPDATE settings SET value='3' WHERE name='schema_version'");
            using(var s = new Store(path,false)) { T.Check(s.MigratedFrom == 3 && File.Exists(s.MigrationBackup), "La actualización desde v3 crea una copia previa"); }
            using(var s = new Store(path,false)) { T.Check(s.MigratedFrom == 0 && s.AllEvents().Single().Options.Memory.Continuity == "No", "Reabrir conserva memorias sin repetir la migración"); }
        }
        static IEnumerable<DependencyObject> Tree(DependencyObject root)
        {
            yield return root; foreach(var child in LogicalTreeHelper.GetChildren(root)) { var d=child as DependencyObject; if(d!=null) foreach(var x in Tree(d)) yield return x; }
        }
        static void Click(DependencyObject root, string name) { Tree(root).OfType<Button>().First(b=>(b.Content as string)==name).RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent)); UiTests.Pump(); }
        static void Capture(Window w, string path) { w.UpdateLayout(); var root=(FrameworkElement)w.Content; var p=root as Panel; if(p!=null) p.Background=Theme.Background; UiTests.Pump(); var image=new RenderTargetBitmap((int)(root.ActualWidth+root.Margin.Left+root.Margin.Right),(int)(root.ActualHeight+root.Margin.Top+root.Margin.Bottom),96,96,PixelFormats.Pbgra32); var bg=new DrawingVisual(); using(var dc=bg.RenderOpen()) dc.DrawRectangle(Theme.Background,null,new Rect(0,0,image.PixelWidth,image.PixelHeight)); image.Render(bg); image.Render(root); var enc=new PngBitmapEncoder(); enc.Frames.Add(BitmapFrame.Create(image)); using(var f=File.Create(path))enc.Save(f); }
        public static void UI(string folder)
        {
            T.Section("Interfaz de nuevas funciones y PDF");
            using(var store = new Store(Path.Combine(folder,"new-functions.sqlite3"),false))
            {
                var e=Sample(); store.Save(e);
                var editor = new EventEditor(store,store.Find(e.Id),null,e.Start); editor.Show(); UiTests.Pump();
                var panel=Tree(editor).OfType<ActivityPanel>().Single();
                Tree(panel).OfType<TextBox>().First(t=>AutomationProperties.GetName(t)=="Valoración general").Text="Excelente";
                var grid=Tree(panel).OfType<DataGrid>().Single(); ((PreparationTask)grid.Items[0]).Completed=true;
                Click(editor,"Guardar"); T.Check(editor.Changed && store.Find(e.Id).Options.Memory.Rating=="Excelente" && store.Find(e.Id).Options.Tasks[0].Completed,"Guardar desde el editor conserva memoria y estado de las tareas");
                var next=Sample(); next.Title="Museo siguiente curso"; next.Start=new DateTime(2027,9,15); next.End=next.Start; next.Options.Memory=new ActivityMemory(); next.Options.AllowNonSchool=true; store.Save(next);
                editor=new EventEditor(store,store.Find(next.Id),null,next.Start); editor.Show(); UiTests.Pump();
                T.Check(Tree(editor).OfType<TextBlock>().Any(t=>t.Text.Contains("ADVERTENCIA:")),"El editor advierte cuando una memoria anterior desaconseja repetir");
                var scroll=Tree(editor).OfType<ScrollViewer>().First(); scroll.ScrollToEnd(); UiTests.Pump(); Capture(editor,Path.Combine(folder,"24-preparacion-memoria.png")); editor.Close();
                var w=new ReportsWindow(store); w.Show(); UiTests.Pump(); Click(w,"Marcar todas las visibles");
                T.Check(Tree(w).OfType<CheckBox>().Count(c=>c.IsChecked==true)==2,"Las casillas permiten seleccionar varias actividades");
                Capture(w,Path.Combine(folder,"25-informes.png")); Click(w,"Desmarcar todas"); T.Check(Tree(w).OfType<CheckBox>().All(c=>c.IsChecked!=true),"Desmarcar deja vacía la selección de informes"); w.Close();
                var longEvent=Sample(); longEvent.Title="Prueba de paginación: valoración extensa"; longEvent.Options.Memory.Difficulties=String.Join("\n",Enumerable.Range(1,100).Select(i=>"Incidencia "+i+": ÁÉÍÓÚ, ñ, ¿qué mejorar? Coordinación, transporte y evaluación."));
                var doc=ActivityReports.Build(new[]{store.Find(e.Id),longEvent},"Informe trimestral de prueba"); var paginator=((IDocumentPaginatorSource)doc).DocumentPaginator; paginator.ComputePageCount();
                T.Check(paginator.PageCount>=4,"Las memorias extensas se paginan sin truncar su contenido"); ActivityReports.ExportPdf(paginator,Path.Combine(folder,"informe-prueba.pdf"));
                var bytes=File.ReadAllBytes(Path.Combine(folder,"informe-prueba.pdf")); T.Check(System.Text.Encoding.ASCII.GetString(bytes,0,8)=="%PDF-1.4" && bytes.Length>10000,"Exportación directa a un PDF real con todas las páginas");
            }
        }
    }
}

