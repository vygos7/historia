using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using AgendaClara;

namespace AgendaClara.Pruebas
{
    public static class T
    {
        public static readonly List<string> Log = new List<string>();
        public static int Passed, Failed;
        public static void Section(string name) { Log.Add(""); Log.Add("== " + name + " =="); }
        public static void Check(bool ok, string name)
        {
            if (ok) { Passed++; Log.Add("CORRECTO: " + name); }
            else { Failed++; Log.Add("FALLO:    " + name); }
        }
        public static void Throws(Action action, string expected, string name)
        {
            try { action(); Check(false, name + " (no se produjo el error esperado)"); }
            catch (Exception ex)
            {
                bool ok = ex.Message.IndexOf(expected, StringComparison.CurrentCultureIgnoreCase) >= 0;
                Check(ok, name + (ok ? "" : " (mensaje: " + ex.Message + ")"));
            }
        }
        public static void Run(string name, Action action)
        {
            try { action(); }
            catch (Exception ex) { Failed++; Log.Add("FALLO:    " + name + " — excepción inesperada: " + ex); }
        }
        public static DateTime D(string s) { return Format.ParseDate(s); }
        public static string Dates(IEnumerable<Occurrence> list) { return String.Join(",", list.Select(o => Format.DayMonth(o.Date))); }
    }

    // Minimal raw SQLite access to build databases with the formats of earlier versions.
    static class Raw
    {
        [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)] static extern int sqlite3_open16(string path, out IntPtr db);
        [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)] static extern int sqlite3_close(IntPtr db);
        [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)] static extern int sqlite3_prepare16_v2(IntPtr db, string sql, int bytes, out IntPtr stmt, IntPtr tail);
        [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)] static extern int sqlite3_step(IntPtr stmt);
        [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)] static extern int sqlite3_finalize(IntPtr stmt);
        [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)] static extern int sqlite3_bind_text16(IntPtr stmt, int index, string value, int bytes, IntPtr destructor);
        [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)] static extern IntPtr sqlite3_column_text16(IntPtr stmt, int column);
        public static void Exec(string path, string sql, params string[] values)
        {
            IntPtr db; sqlite3_open16(path, out db);
            try
            {
                IntPtr stmt;
                if (sqlite3_prepare16_v2(db, sql, -1, out stmt, IntPtr.Zero) != 0) throw new Exception("SQL: " + sql);
                for (int i = 0; i < values.Length; i++) sqlite3_bind_text16(stmt, i + 1, values[i], -1, new IntPtr(-1));
                int code; do { code = sqlite3_step(stmt); } while (code == 100);
                sqlite3_finalize(stmt);
                if (code != 101) throw new Exception("SQL " + code + ": " + sql);
            }
            finally { sqlite3_close(db); }
        }
        public static string Scalar(string path, string sql)
        {
            IntPtr db; sqlite3_open16(path, out db);
            try
            {
                IntPtr stmt; sqlite3_prepare16_v2(db, sql, -1, out stmt, IntPtr.Zero);
                string v = sqlite3_step(stmt) == 100 ? Marshal.PtrToStringUni(sqlite3_column_text16(stmt, 0)) : null;
                sqlite3_finalize(stmt); return v;
            }
            finally { sqlite3_close(db); }
        }
    }

    public static class Program
    {
        [STAThread]
        public static int Main(string[] args)
        {
            Format.ApplyCulture();
            if (args.Length < 1) { Console.WriteLine("Uso: AgendaClara.Pruebas.exe <carpeta-de-pruebas> [copia-agenda-v1.sqlite3]"); return 2; }
            string folder = Path.GetFullPath(args[0]);
            string real = Program.DefaultReal();
            if (folder.StartsWith(Path.GetDirectoryName(real), StringComparison.OrdinalIgnoreCase)) { Console.WriteLine("La carpeta de pruebas no puede estar dentro de la carpeta de la agenda real."); return 2; }
            Directory.CreateDirectory(folder);
            string legacyCopy = args.Length > 1 ? Path.GetFullPath(args[1]) : null;
            T.Log.Add("Agenda Clara " + AgendaClara.Program.Version + " · pruebas ejecutadas el " + DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"));
            T.Log.Add("Ejecutable probado: " + typeof(Store).Assembly.Location);
            T.Log.Add("Carpeta aislada: " + folder);
            DataTests.Run(Path.Combine(folder, "datos"), legacyCopy);
            int dataPassed = T.Passed, dataFailed = T.Failed;
            UiTests.Run(Path.Combine(folder, "interfaz"));
            T.Log.Add("");
            T.Log.Add("RESUMEN: datos " + dataPassed + " correctas / " + dataFailed + " fallos · interfaz " + (T.Passed - dataPassed) + " correctas / " + (T.Failed - dataFailed) + " fallos.");
            File.WriteAllLines(Path.Combine(folder, "resultado-pruebas.txt"), T.Log);
            foreach (var line in T.Log) Console.WriteLine(line);
            return T.Failed;
        }
        public static string DefaultReal() { return AgendaClara.Program.DefaultDatabasePath(); }
    }

    public static class DataTests
    {
        static string folder;
        static string NewDb(string name) { return Path.Combine(folder, name + "-" + Guid.NewGuid().ToString("N").Substring(0, 8) + ".sqlite3"); }
        static AgendaEvent Ev(string title, string start, string end, string category = "Otros")
        {
            var e = new AgendaEvent { Title = title, Start = T.D(start), End = T.D(end), AllDay = true };
            e.Options.Category = category;
            return e;
        }

        public static void Run(string dir, string legacyCopy)
        {
            folder = dir; Directory.CreateDirectory(folder);
            var cal = SchoolCalendar.Huelva();
            T.Run("Calendario", () => Calendar(cal));
            T.Run("Planificación", () => PlanningRules(cal));
            T.Run("Validaciones", Validation);
            T.Run("Persistencia", Persistence);
            T.Run("Seguimiento y memorias", () => LifecycleTests.Data(dir));
            T.Run("Ocurrencias", Occurrences);
            T.Run("Búsqueda", Search);
            T.Run("Avisos", Reminders);
            T.Run("Categorías", Categories);
            T.Run("Cambios de calendario", CalendarChanges);
            T.Run("Copias", Backups);
            T.Run("Errores", Errors);
            T.Run("Migración", () => Migration(legacyCopy));
        }

        static void Calendar(SchoolCalendar c)
        {
            T.Section("Calendario escolar precargado (Huelva 2026/27)");
            T.Check(c.IsSchoolDay(T.D("10/09/2026")) && !c.IsSchoolDay(T.D("09/09/2026")), "Las clases empiezan el 10/09/2026");
            T.Check(c.IsSchoolDay(T.D("22/06/2027")) && !c.IsSchoolDay(T.D("23/06/2027")), "Las clases terminan el 22/06/2027 (incluido)");
            T.Check(Planning.Days(T.D("23/12/2026"), T.D("06/01/2027")).All(d => !c.IsSchoolDay(d)), "Navidad 23/12/2026–06/01/2027 no lectiva");
            T.Check(!c.IsSchoolDay(T.D("07/01/2027")) && c.IsSchoolDay(T.D("08/01/2027")), "07/01/2027 no lectivo provincial; regreso el 08/01/2027");
            T.Check(Planning.Days(T.D("22/03/2027"), T.D("28/03/2027")).All(d => !c.IsSchoolDay(d)) && c.IsSchoolDay(T.D("29/03/2027")), "Semana Santa 22–28/03/2027 no lectiva; regreso el 29/03/2027");
            string[] off = { "12/10/2026", "02/11/2026", "07/12/2026", "08/12/2026", "07/01/2027", "26/02/2027", "01/03/2027", "01/05/2027", "13/05/2027", "14/05/2027", "17/05/2027" };
            T.Check(off.All(d => !c.IsSchoolDay(T.D(d))), "Los 11 días no lectivos sueltos del PDF");
            T.Check(c.Reason(T.D("25/12/2026")) == "Día de Navidad" && c.Reason(T.D("28/12/2026")) == "Vacaciones de Navidad", "El festivo concreto se nombra dentro de las vacaciones");
            T.Check(c.Reason(T.D("17/10/2026")) == "Fin de semana" && c.Reason(T.D("01/07/2027")) == "Fuera del periodo de clases", "Motivos legibles: fin de semana y fuera del periodo");
            T.Check(c.Term(T.D("15/01/2027")).StartsWith("Segundo trimestre"), "Trimestres (propuesta editable)");
            var copy = XmlData.Read<SchoolCalendar>(XmlData.Write(c));
            T.Check(copy.Breaks.Count == c.Breaks.Count && copy.Years.Count == 1, "El calendario se guarda y se lee sin pérdidas");
        }

        static void PlanningRules(SchoolCalendar c)
        {
            T.Section("Intervalos, días de la semana, fechas concretas y exclusiones");
            T.Check(T.Dates(Planning.All(Ev("Mayo", "10/05/2027", "18/05/2027"), c)) == "10/05,11/05,12/05,18/05", "Actividad del 10 al 18/05/2027: solo 10, 11, 12 y 18");
            var mm = Ev("Lunes a lunes", "19/10/2026", "26/10/2026");
            T.Check(T.Dates(Planning.All(mm, c)) == "19/10,20/10,21/10,22/10,23/10,26/10", "Lunes a lunes: sin sábado ni domingo");
            T.Check(T.Dates(Planning.All(Ev("Puente", "05/10/2026", "12/10/2026"), c)) == "05/10,06/10,07/10,08/10,09/10", "El festivo del 12/10 queda fuera del intervalo");
            T.Check(Planning.All(Ev("Navidad", "21/12/2026", "11/01/2027"), c).Select(o => o.Date).SequenceEqual(new[] { T.D("21/12/2026"), T.D("22/12/2026"), T.D("08/01/2027"), T.D("11/01/2027") }), "Las vacaciones de Navidad no reciben actividades");
            var tt = Ev("Martes y jueves", "01/10/2026", "31/10/2026"); tt.Options.Weekdays = (1 << 1) | (1 << 3);
            var ttDates = Planning.All(tt, c);
            T.Check(ttDates.Count == 9 && ttDates.All(o => o.Date.DayOfWeek == DayOfWeek.Tuesday || o.Date.DayOfWeek == DayOfWeek.Thursday), "Repetición solo martes y jueves (9 fechas en octubre)");
            var sp = Ev("Concretas", "05/10/2026", "24/10/2026"); sp.Options.SpecificDates = new List<DateTime> { T.D("05/10/2026"), T.D("12/10/2026"), T.D("17/10/2026"), T.D("21/10/2026") };
            T.Check(T.Dates(Planning.All(sp, c)) == "05/10,21/10", "Fechas concretas: se omiten el festivo y el sábado de la lista");
            sp.Options.AllowNonSchool = true;
            T.Check(T.Dates(Planning.All(sp, c)) == "05/10,12/10,17/10,21/10", "Con la excepción expresa sí se admiten días no lectivos");
            var ex = Ev("Exclusiones", "19/10/2026", "23/10/2026"); ex.Options.ExcludedDates = new List<DateTime> { T.D("21/10/2026") };
            T.Check(T.Dates(Planning.All(ex, c)) == "19/10,20/10,22/10,23/10", "Fecha excluida");
            T.Check(new AgendaEvent().Options.AllowNonSchool == false, "La excepción para días no lectivos está desactivada por defecto");
            var sat = Ev("Fiesta del sábado", "17/10/2026", "17/10/2026");
            T.Check(Planning.All(sat, c).Count == 0, "Una actividad en sábado sin excepción no aparece");
            sat.Options.AllowNonSchool = true;
            T.Check(Planning.All(sat, c).Count == 1, "Con la excepción expresa aparece el sábado");
            var sameDay = new List<AgendaEvent>();
            for (int i = 0; i < 6; i++) { var e = Ev("Cita " + i, "20/10/2026", "20/10/2026"); e.Id = i + 1; e.AllDay = i == 3; e.StartMinute = 600 - i * 30; e.EndMinute = 660; sameDay.Add(e); }
            var day = Planning.Day(sameDay, T.D("20/10/2026"), c);
            T.Check(day.Count == 6 && day[0].View.Title == "Cita 3" && day[1].View.Title == "Cita 5", "Varias actividades el mismo día, ordenadas (todo el día primero, luego por hora)");
        }

        static void Validation()
        {
            T.Section("Validaciones");
            var e = Ev("", "10/05/2027", "10/05/2027");
            T.Throws(e.Validate, "título", "Sin título no se guarda");
            e = Ev("X", "12/05/2027", "10/05/2027");
            T.Throws(e.Validate, "anterior", "La fecha final no puede ser anterior a la inicial");
            e = Ev("X", "10/05/2027", "10/05/2027"); e.AllDay = false; e.StartMinute = 600; e.EndMinute = 600;
            T.Throws(e.Validate, "posterior", "La hora final debe ser posterior a la inicial");
            e.EndMinute = 540; T.Throws(e.Validate, "posterior", "La hora final anterior a la inicial se rechaza");
            int m;
            T.Check(Format.TryParseTime("9:30", out m) && m == 570 && Format.TryParseTime("14", out m) && m == 840 && !Format.TryParseTime("25:00", out m) && !Format.TryParseTime("ab", out m), "Formato de 24 horas");
            T.Throws(() => Format.ParseDateList("10/05/2027; 31/02/2027", "Excluir"), "no es una fecha válida", "Fecha inexistente en una lista");
            T.Check(Format.ParseDateList("1/5/2027, 10/05/2027", "x").Count == 2, "Listas de fechas DD/MM/AAAA separadas por punto y coma o coma");
        }

        static void Persistence()
        {
            T.Section("Crear, editar, eliminar y conservar");
            string path = NewDb("persistencia");
            long id;
            using (var s = new Store(path))
            {
                var e = Ev("Excursión a Doñana", "20/10/2026", "20/10/2026", "Salida / excursión");
                e.Notes = "Llevar almuerzo"; e.Options.Group = "5º A, 5º B"; e.Options.Responsible = "Jefatura"; e.Options.Location = "Parque Nacional";
                s.Save(e); id = e.Id;
                T.Check(id > 0 && s.AllEvents().Count == 1, "Crear actividad");
                var bad = Ev("", "20/10/2026", "20/10/2026");
                try { s.Save(bad); } catch (ArgumentException) { }
                T.Check(bad.Id == 0 && s.AllEvents().Count == 1, "Un error de validación no inserta nada");
                bad.Title = "Corregida"; s.Save(bad);
                T.Check(s.AllEvents().Count == 2, "El reintento tras el error inserta una sola vez");
                s.Delete(bad.Id);
            }
            using (var s = new Store(path))
            {
                var e = s.Find(id);
                T.Check(e != null && e.Title == "Excursión a Doñana" && e.Notes == "Llevar almuerzo" && e.Options.Group == "5º A, 5º B" && e.Options.Location == "Parque Nacional", "Se conserva tras cerrar y abrir (con tildes y eñes)");
                e.Title = "Excursión a Doñana (modificada)"; e.AllDay = false; e.StartMinute = 510; e.EndMinute = 870; s.Save(e);
                T.Check(s.AllEvents().Count == 1 && s.Find(id).TimeLabel == "08:30–14:30", "Editar conserva el identificador sin duplicar");
            }
            using (var s = new Store(path))
            {
                T.Check(s.Find(id).Title.EndsWith("(modificada)"), "La edición se conserva tras reabrir");
                s.Delete(id);
            }
            using (var s = new Store(path)) T.Check(s.AllEvents().Count == 0, "La eliminación se conserva tras reabrir");
        }

        static void Occurrences()
        {
            T.Section("Una sola ocurrencia: editar, trasladar, eliminar");
            using (var s = new Store(NewDb("ocurrencias")))
            {
                var e = Ev("Taller de robótica", "10/05/2027", "18/05/2027", "Taller"); e.AllDay = false; e.StartMinute = 600; e.EndMinute = 660;
                s.Save(e);
                var c = s.Calendar;
                var stored = s.Find(e.Id);
                stored.Options.Changes.Add(new OccurrenceChange { Date = T.D("11/05/2027"), Title = "Taller de robótica (aula 2)", Notes = "", StartMinute = 720, EndMinute = 780 });
                s.Save(stored);
                var all = Planning.All(s.Find(e.Id), c);
                T.Check(all.Count == 4 && all[1].View.Title == "Taller de robótica (aula 2)" && all[1].View.TimeLabel == "12:00–13:00" && all[0].View.Title == "Taller de robótica" && all[2].View.TimeLabel == "10:00–11:00", "Editar solo el 11/05 no altera las demás fechas");
                stored = s.Find(e.Id);
                stored.Options.Changes.Add(new OccurrenceChange { Date = T.D("12/05/2027"), Title = stored.Title, Notes = "", StartMinute = 600, EndMinute = 660, MovedTo = T.D("19/05/2027") });
                s.Save(stored);
                all = Planning.All(s.Find(e.Id), c);
                T.Check(T.Dates(all) == "10/05,11/05,18/05,19/05" && all.Single(o => o.Date == T.D("19/05/2027")).OriginalDate == T.D("12/05/2027"), "Trasladar solo el 12/05 al 19/05");
                T.Check(Planning.At(s.Find(e.Id), T.D("12/05/2027"), c) == null, "No se ofrece una ocurrencia en la fecha original trasladada");
                var clash = s.Find(e.Id); clash.Options.Changes.First(x => x.Date == T.D("12/05/2027")).MovedTo = T.D("18/05/2027");
                T.Throws(() => s.Save(clash), "coincidirían", "No se puede trasladar a un día que ya tiene la actividad");
                var weekend = s.Find(e.Id); weekend.Options.Changes.First(x => x.Date == T.D("12/05/2027")).MovedTo = T.D("15/05/2027");
                T.Check(Planning.All(weekend, c).All(o => o.Date != T.D("15/05/2027")), "El traslado a sábado sin excepción no aparece");
                weekend.Options.Changes.First(x => x.Date == T.D("12/05/2027")).AllowNonSchool = true;
                T.Check(Planning.All(weekend, c).Any(o => o.Date == T.D("15/05/2027")), "El traslado a sábado con excepción expresa aparece");
                var one = s.Find(e.Id); one.Options.ExcludedDates.Add(T.D("10/05/2027")); s.Save(one);
                T.Check(T.Dates(Planning.All(s.Find(e.Id), c)) == "11/05,18/05,19/05", "Eliminar solo el 10/05 conserva las demás");
                T.Check(EventEditor.DeletionText("Taller", true, T.D("11/05/2027"), 3).Contains("solo el martes, 11/05/2027") && EventEditor.DeletionText("Taller", true, T.D("11/05/2027"), 3).Contains("Las otras 2 fechas") && !EventEditor.DeletionText("Taller", true, T.D("11/05/2027"), 3).Contains("todas"), "Mensaje «solo esta fecha» sin anunciar que se borran todas");
                T.Check(EventEditor.DeletionText("Taller", false, null, 3).Contains("con todas sus fechas (3)"), "Mensaje «toda la actividad»");
                T.Check(EventEditor.DeletionText("Taller", false, T.D("11/05/2027"), 1).Contains("única fecha"), "Mensaje claro para la última fecha");
                var last = Ev("Solo dos", "18/05/2027", "19/05/2027"); s.Save(last);
                last.Options.ExcludedDates.Add(T.D("18/05/2027")); last.Options.ExcludedDates.Add(T.D("19/05/2027"));
                T.Throws(() => s.Save(last), "ninguna fecha", "Excluir la última fecha da un mensaje comprensible en vez de un error técnico");
            }
        }

        static void Search()
        {
            T.Section("Búsqueda y filtros");
            var e = Ev("Excursión a Doñana", "20/10/2026", "20/10/2026", "Salida / excursión"); e.Options.Responsible = "María Pérez"; e.Options.Group = "6º B"; e.Options.Location = "Almonte"; e.Notes = "Autobús a las 8";
            T.Check(Planning.Matches(e, "excursion", "") && Planning.Matches(e, "EXCURSIÓN", "") && Planning.Matches(e, "donana", ""), "Sin distinguir mayúsculas ni tildes");
            T.Check(Planning.Matches(e, "perez", "") && Planning.Matches(e, "6º b", "") && Planning.Matches(e, "almonte", "") && Planning.Matches(e, "autobus", "") && Planning.Matches(e, "salida", ""), "Busca en responsable, grupo, lugar, notas y categoría");
            T.Check(Planning.Matches(e, "doñana maria", "") && !Planning.Matches(e, "doñana charla", ""), "Varias palabras: deben aparecer todas");
            T.Check(Planning.Matches(e, "doñana", "Salida / excursión") && !Planning.Matches(e, "doñana", "Charla"), "Búsqueda combinada con filtro de categoría");
            T.Check(Planning.Matches(e, "", "") , "Sin búsqueda ni filtro se muestra todo");
        }

        static void Reminders()
        {
            T.Section("Avisos de proximidad");
            var c = SchoolCalendar.Huelva();
            var a = Ev("Charla de seguridad vial", "12/10/2026", "14/10/2026", "Charla"); a.Id = 1; a.Options.ReminderDays = 7;
            var r = Planning.Reminders(new[] { a }, T.D("09/10/2026"), c);
            T.Check(r.Count == 1 && r[0].Occurrence.Date == T.D("13/10/2026") && r[0].DaysLeft == 4 && r[0].Message.StartsWith("Faltan 4 días"), "El aviso usa la próxima fecha real (salta el festivo del 12/10)");
            T.Check(Planning.Reminders(new[] { a }, T.D("12/10/2026"), c)[0].Message.StartsWith("Mañana"), "«Mañana» el día anterior");
            T.Check(Planning.Reminders(new[] { a }, T.D("13/10/2026"), c)[0].Message.StartsWith("Hoy"), "«Hoy» el mismo día");
            T.Check(Planning.Reminders(new[] { a }, T.D("01/10/2026"), c).Count == 0, "Fuera del plazo no hay aviso");
            a.Options.ExcludedDates.Add(T.D("13/10/2026"));
            T.Check(Planning.Reminders(new[] { a }, T.D("09/10/2026"), c)[0].Occurrence.Date == T.D("14/10/2026"), "Las exclusiones se respetan");
            a.Options.ReminderDays = -1;
            T.Check(Planning.Reminders(new[] { a }, T.D("09/10/2026"), c).Count == 0, "Aviso desactivado");
            var w = Ev("Reunión de coordinación", "01/10/2026", "30/10/2026", "Reunión"); w.Id = 2; w.Options.Weekdays = 1 << 2; w.Options.ReminderDays = 1;
            var rw = Planning.Reminders(new[] { w }, T.D("13/10/2026"), c);
            T.Check(rw.Count == 1 && rw[0].Occurrence.Date == T.D("14/10/2026") && rw[0].Message.StartsWith("Mañana"), "Repetición semanal: aviso de la próxima ocurrencia");
            var moved = Ev("Concurso de dibujo", "20/10/2026", "20/10/2026", "Concurso"); moved.Id = 3; moved.Options.ReminderDays = 3;
            moved.Options.Changes.Add(new OccurrenceChange { Date = T.D("20/10/2026"), Title = "Concurso de dibujo", Notes = "", AllDay = true, MovedTo = T.D("22/10/2026") });
            var rm = Planning.Reminders(new[] { moved }, T.D("19/10/2026"), c);
            T.Check(rm.Count == 1 && rm[0].DaysLeft == 3, "El traslado de una fecha cambia el aviso");
        }

        static void Categories()
        {
            T.Section("Categorías");
            string path = NewDb("categorias");
            using (var s = new Store(path))
            {
                var names = s.Categories().Select(c => c.Name).ToList();
                T.Check(names.SequenceEqual(CategoryPalette.DefaultNames), "Categorías iniciales en orden");
                T.Check(s.Categories().Select(c => c.Color).Distinct().Count() == 8, "Cada categoría inicial tiene un color propio");
                var e = Ev("Taller de cocina", "20/10/2026", "20/10/2026", "Taller"); s.Save(e);
                var f = Ev("Taller de pintura", "21/10/2026", "21/10/2026", "taller"); s.Save(f);
                T.Check(s.Find(f.Id).Options.Category == "Taller", "Escribir una categoría con otras mayúsculas usa la existente");
                var g = Ev("Feria del libro", "22/10/2026", "22/10/2026", "Feria"); s.Save(g);
                T.Check(s.Categories().Any(c => c.Name == "Feria" && c.Color.Length == 7), "Escribir una categoría nueva la crea con color");
                s.RenameCategory("Taller", "Taller de familias");
                T.Check(s.Find(e.Id).Options.Category == "Taller de familias" && s.Find(f.Id).Options.Category == "Taller de familias" && !s.Categories().Any(c => c.Name == "Taller"), "Renombrar actualiza sus actividades");
                T.Throws(() => s.RenameCategory("Feria", "charla"), "Ya existe", "No se puede renombrar a un nombre existente");
                T.Throws(() => s.DeleteCategory("Feria", "Feria"), "Elige otra", "Eliminar exige otra categoría de destino");
                int moved = s.DeleteCategory("Taller de familias", "Otros");
                T.Check(moved == 2 && s.Find(e.Id).Options.Category == "Otros" && s.AllEvents().Count == 3, "Eliminar categoría mueve sus actividades sin perderlas");
                s.SetCategoryColor("Charla", "#A33A3A");
                s.MoveCategory("Otros", -1);
                s.AddCategory("Claustro", null);
                T.Throws(() => s.AddCategory("CLAUSTRO", null), "Ya existe", "No se duplica una categoría");
            }
            using (var s = new Store(path))
            {
                var list = s.Categories();
                T.Check(!list.Any(c => c.Name == "Taller de familias") && !list.Any(c => c.Name == "Taller"), "Una categoría eliminada no reaparece al reabrir");
                T.Check(list.First(c => c.Name == "Charla").Color == "#A33A3A" && list.Any(c => c.Name == "Claustro"), "Color y categorías nuevas se conservan");
            }
        }

        static void CalendarChanges()
        {
            T.Section("Cambiar el calendario no borra actividades");
            using (var s = new Store(NewDb("calendario")))
            {
                var e = Ev("Jornada de convivencia", "18/05/2027", "18/05/2027", "Celebración"); s.Save(e);
                var c = s.Calendar.Copy();
                c.Breaks.Add(new DatePeriod { Name = "Fiesta del centro", Kind = "Cambio del centro", Start = T.D("18/05/2027"), End = T.D("18/05/2027") });
                s.SaveCalendar(c);
                T.Check(s.AllEvents().Count == 1 && Planning.All(s.Find(e.Id), s.Calendar).Count == 0, "La actividad queda oculta pero no se borra");
                T.Check(s.WithoutVisibleDates().Count == 1 && Planning.Matches(s.Find(e.Id), "convivencia", ""), "Sigue localizable por búsqueda");
                T.Throws(() => { var bad = s.Calendar.Copy(); bad.Terms[0].End = bad.Terms[0].Start.AddDays(-1); s.SaveCalendar(bad); }, "anterior", "El calendario valida las fechas de los periodos");
                c.Breaks.RemoveAll(b => b.Name == "Fiesta del centro"); s.SaveCalendar(c);
                T.Check(Planning.All(s.Find(e.Id), s.Calendar).Count == 1, "Al deshacer el cambio vuelve a aparecer");
            }
        }

        static void Backups()
        {
            T.Section("Copias de seguridad y restauración");
            string path = NewDb("copias");
            var clock = new DateTime(2026, 10, 27, 9, 0, 0);
            using (var s = new Store(path))
            {
                s.Clock = () => clock;
                var e = Ev("Charla de nutrición", "10/05/2027", "18/05/2027", "Charla");
                e.Options.ExcludedDates.Add(T.D("11/05/2027"));
                e.Options.Changes.Add(new OccurrenceChange { Date = T.D("12/05/2027"), Title = "Charla de nutrición (salón)", Notes = "", AllDay = true, MovedTo = T.D("19/05/2027") });
                s.Save(e);
                s.AddCategory("Claustro", "#3E4FA8");
                var cal = s.Calendar.Copy(); cal.Breaks.Add(new DatePeriod { Name = "Día del centro", Kind = "Cambio del centro", Start = T.D("04/06/2027"), End = T.D("04/06/2027") }); s.SaveCalendar(cal);
                T.Check(File.Exists(s.DailyBackupPath(clock)) && s.LastBackup == clock && s.BackupError == null, "Copia automática del día tras guardar");
                string manual = Path.Combine(folder, "usb", "copia-manual.sqlite3");
                s.BackupTo(manual);
                var info = Store.Inspect(manual);
                T.Check(info.Error == "" && info.Events == 1 && info.HasCalendar && info.Categories == 9, "Copia manual en otra carpeta, válida y completa");
                T.Check(!File.Exists(manual + "-wal") && Raw.Scalar(manual, "PRAGMA journal_mode") == "delete", "La copia es un único archivo autónomo");
                clock = clock.AddDays(1);
                s.EnsureDailyBackup();
                T.Check(File.Exists(s.DailyBackupPath(clock)) && File.Exists(s.DailyBackupPath(clock.AddDays(-1))), "Al cambiar de día se crea la copia nueva y se conserva la anterior");
                s.Delete(e.Id);
                var other = s.Calendar.Copy(); other.Breaks.Clear(); s.SaveCalendar(other);
                s.DeleteCategory("Claustro", "Otros");
                T.Check(s.AllEvents().Count == 0, "Situación alterada antes de restaurar");
                string safety = s.RestoreFrom(manual);
                var back = s.AllEvents().SingleOrDefault();
                T.Check(back != null && back.Options.ExcludedDates.Contains(T.D("11/05/2027")) && back.Options.Changes.Any(x => x.MovedTo == T.D("19/05/2027")), "Restaurar recupera actividades, exclusiones y traslados");
                T.Check(s.Calendar.Breaks.Any(b => b.Name == "Día del centro") && s.Categories().Any(c => c.Name == "Claustro" && c.Color == "#3E4FA8"), "Restaurar recupera calendario y categorías");
                var before = Store.Inspect(safety);
                T.Check(File.Exists(safety) && before.Error == "" && before.Events == 0, "Antes de restaurar se guarda la agenda actual");
                T.Check(s.BackupError == null, "Tras restaurar se actualiza la copia del día");
                File.WriteAllText(Path.Combine(folder, "no-es-agenda.sqlite3"), "texto cualquiera");
                T.Throws(() => s.RestoreFrom(Path.Combine(folder, "no-es-agenda.sqlite3")), "no es una agenda", "Restaurar un archivo que no es una agenda se rechaza sin tocar los datos");
                T.Check(s.AllEvents().Count == 1, "La agenda sigue intacta tras el rechazo");
            }
            T.Section("Fallo de la copia automática");
            string path2 = NewDb("fallo-copia");
            using (var s = new Store(path2))
            {
                Directory.Delete(s.BackupDirectory, true);
                File.WriteAllText(s.BackupDirectory, "bloquea la carpeta de copias");
                var e = Ev("Reunión de ciclo", "20/10/2026", "20/10/2026", "Reunión");
                s.Save(e);
                T.Check(s.BackupError != null && s.AllEvents().Count == 1 && e.Id > 0, "Si la copia falla, la actividad queda guardada una sola vez y el fallo se informa aparte");
                File.Delete(s.BackupDirectory);
                s.EnsureDailyBackup();
                T.Check(s.BackupError == null && s.AllEvents().Count == 1, "Al recuperarse la carpeta, la copia vuelve a funcionar");
            }
        }

        static void Errors()
        {
            T.Section("Errores comprensibles");
            string junk = Path.Combine(folder, "basura.sqlite3");
            File.WriteAllText(junk, new string('x', 5000));
            T.Throws(() => new Store(junk, false).Dispose(), "no es una agenda válida", "Abrir un archivo que no es una agenda");
            string ro = NewDb("solo-lectura");
            using (var s = new Store(ro, false)) s.Save(Ev("Prueba", "20/10/2026", "20/10/2026"));
            foreach (var f in Directory.GetFiles(folder, Path.GetFileName(ro) + "*")) File.SetAttributes(f, FileAttributes.ReadOnly);
            try
            {
                T.Throws(() => { using (var s = new Store(ro, false)) s.Save(Ev("Otra", "21/10/2026", "21/10/2026")); }, "solo lectura", "Agenda en solo lectura: mensaje claro");
            }
            finally { foreach (var f in Directory.GetFiles(folder, Path.GetFileName(ro) + "*")) File.SetAttributes(f, FileAttributes.Normal); }
        }

        static void Migration(string legacyCopy)
        {
            T.Section("Migración desde versiones anteriores");
            if (legacyCopy != null && File.Exists(legacyCopy))
            {
                string path = Path.Combine(folder, "migracion-agenda-real-v1.sqlite3");
                File.Copy(legacyCopy, path, true);
                var titles = new List<string>();
                using (var s = new Store(path))
                {
                    var events = s.AllEvents();
                    titles = events.Select(e => e.Title).ToList();
                    T.Check(s.MigratedFrom == 1 && File.Exists(s.MigrationBackup), "Copia de la agenda real (v1.1): copia previa a la migración");
                    T.Check(Store.Inspect(s.MigrationBackup).Events == events.Count, "La copia previa contiene todas las actividades originales");
                    T.Check(events.All(e => e.Options.Category == "Otros") && s.Calendar.Years.Count == 1, "Actividades v1.1 en «Otros» y calendario de Huelva aplicado");
                    var baja = events.FirstOrDefault(e => e.Title == "Baja de Pepe");
                    if (baja != null) T.Check(T.Dates(Planning.All(baja, s.Calendar)) == "26/10,27/10,28/10,29/10,30/10", "«Baja de Pepe» (26/10–02/11) solo en días lectivos");
                }
                using (var s = new Store(path)) T.Check(s.MigratedFrom == 0 && s.AllEvents().Select(e => e.Title).SequenceEqual(titles), "Reabrir no repite la migración y conserva los datos");
                Log("Actividades en la copia de la agenda real: " + String.Join(" | ", titles));
            }
            else T.Log.Add("AVISO:    no se indicó copia de la agenda real; se omite esa comprobación.");

            string v2 = Path.Combine(folder, "migracion-v2.sqlite3");
            Raw.Exec(v2, "CREATE TABLE events (id INTEGER PRIMARY KEY, title TEXT NOT NULL, notes TEXT NOT NULL, start_date TEXT NOT NULL, end_date TEXT NOT NULL CHECK(end_date>=start_date), start_min INTEGER NOT NULL, end_min INTEGER NOT NULL, all_day INTEGER NOT NULL, options TEXT NOT NULL DEFAULT '')");
            Raw.Exec(v2, "CREATE TABLE settings (name TEXT PRIMARY KEY, value TEXT NOT NULL)");
            Raw.Exec(v2, "CREATE TABLE categories (name TEXT PRIMARY KEY)");
            foreach (var n in CategoryPalette.DefaultNames.Concat(new[] { "Huerto escolar" })) Raw.Exec(v2, "INSERT INTO categories(name) VALUES(?)", n);
            string options = "<?xml version=\"1.0\" encoding=\"utf-16\"?><EventOptions xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\"><Category>Huerto escolar</Category><Group>3º</Group><Responsible>Ana</Responsible><Location>Patio</Location><ReminderDays>3</ReminderDays><Weekdays>31</Weekdays><AllowNonSchool>false</AllowNonSchool><SpecificDates /><ExcludedDates><dateTime>2026-10-21T00:00:00</dateTime></ExcludedDates><Changes><OccurrenceChange><Date>2026-10-22T00:00:00</Date><Title>Huerto (lluvia)</Title><Notes /><StartMinute>720</StartMinute><EndMinute>780</EndMinute><AllDay>false</AllDay></OccurrenceChange></Changes></EventOptions>";
            Raw.Exec(v2, "INSERT INTO events VALUES(1,'Huerto','notas','2026-10-19','2026-10-23',600,660,0,?)", options);
            string calendar = "<?xml version=\"1.0\" encoding=\"utf-16\"?><SchoolCalendar xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\"><Start>2026-09-10T00:00:00</Start><End>2027-06-22T00:00:00</End><Breaks><DatePeriod><Name>Día local de prueba</Name><Start>2026-10-20T00:00:00</Start><End>2026-10-20T00:00:00</End></DatePeriod></Breaks><Terms><DatePeriod><Name>Primer trimestre</Name><Start>2026-09-10T00:00:00</Start><End>2026-12-22T00:00:00</End></DatePeriod></Terms></SchoolCalendar>";
            Raw.Exec(v2, "INSERT INTO settings VALUES('calendar',?)", calendar);
            using (var s = new Store(v2))
            {
                var e = s.AllEvents().Single();
                T.Check(s.MigratedFrom == 2 && File.Exists(s.MigrationBackup), "Versión 2: copia previa a la migración");
                T.Check(e.Options.Category == "Huerto escolar" && e.Options.Responsible == "Ana" && e.Options.ReminderDays == 3 && e.Options.ExcludedDates.Count == 1, "Versión 2: opciones de la actividad conservadas");
                T.Check(s.Calendar.Years.Count == 1 && s.Calendar.Years[0].Start == T.D("10/09/2026") && s.Calendar.Breaks.Single().Kind == "No lectivo" && s.Calendar.Terms.Count == 1, "Versión 2: calendario convertido sin pérdidas");
                T.Check(T.Dates(Planning.All(e, s.Calendar)) == "19/10,22/10,23/10" && Planning.All(e, s.Calendar)[1].View.Title == "Huerto (lluvia)", "Versión 2: calendario, exclusión y cambio de una fecha siguen aplicándose");
                T.Check(s.Categories().All(c => c.Color.Length == 7) && s.Categories().Any(c => c.Name == "Huerto escolar"), "Versión 2: categorías con color, incluida la personalizada");
            }
        }

        static void Log(string text) { T.Log.Add("INFO:     " + text); }
    }
}
