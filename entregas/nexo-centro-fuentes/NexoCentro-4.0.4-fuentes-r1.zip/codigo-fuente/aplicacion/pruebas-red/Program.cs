#nullable enable
using System.Net;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.Json;
using AgendaClara;
using AgendaClara.Server;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
[assembly:System.Runtime.Versioning.SupportedOSPlatform("windows")]

public static class Tests
{
    static readonly List<string> log=[];
    static int passed;
    static void Check(bool ok,string name){log.Add((ok?"CORRECTO: ":"FALLO: ")+name);Console.WriteLine(log[^1]);if(!ok)throw new Exception(name);passed++;}
    static async Task Until(Func<bool> condition,string name,int seconds=20)
    {var until=DateTime.UtcNow.AddSeconds(seconds);while(!condition() && DateTime.UtcNow<until)await Task.Delay(100);Check(condition(),name);}
    static string Fingerprint(string file)=>Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(file)));
    static AgendaEvent New(Store store,string title)
    {
        var e=new AgendaEvent{Title=title,Start=new DateTime(2026,10,29),End=new DateTime(2026,10,30),AllDay=true};store.StampNew(e);
        e.Options.Tasks.Add(new PreparationTask{Description="Confirmar transporte",Responsible="Ana",Due=new DateTime(2026,10,28),Attention=true});return e;
    }
    static async Task Reject(Func<Task> action,string name)
    {bool rejected=false;try{await action();}catch{rejected=true;}Check(rejected,name);}
    public static async Task<int> Main(string[] args)
    {
        string workspace=Path.GetFullPath(args[0]),fixture=Path.GetFullPath(args[1]);Directory.CreateDirectory(workspace);string root=Path.Combine(workspace,"server");Directory.CreateDirectory(root);
        List<X509Certificate2> imported=[];X509Certificate2? authority=null;WebApplication? app=null;List<RemoteConnection> remotes=[]; System.Diagnostics.Process? probe=null;
        try
        {
            string original=Fingerprint(fixture);Store.CopyReadOnly(fixture,Path.Combine(root,"agenda.sqlite3"));
            using(var store=new Store(Path.Combine(root,"agenda.sqlite3"),false)){Check(store.MigratedFrom==4 && File.Exists(store.MigrationBackup),"Importación desde una base auténtica v4 con copia previa");Check(store.AllEvents().Single().Options.Memory.Continuity=="No" && store.AllEvents().Single().Options.Tasks.Count==2,"La migración conserva tareas, memoria y recomendación");Check(store.IntegrityCheck()=="ok","Integridad tras la migración");store.NewGeneration("migracion","prueba");}
            Check(Fingerprint(fixture)==original,"La importación no modifica la base v4 de origen");
            var listener=new TcpListener(IPAddress.Loopback,0);listener.Start();int port=((IPEndPoint)listener.LocalEndpoint).Port;listener.Stop();
            var settings=new ServerSettings{ListenHost="127.0.0.1",PublicHost="localhost",Port=port,AllowedNetworks=["127.0.0.1/32"],BackupDirectory=Path.Combine(root,"copias"),ExternalBackupDirectory=Path.Combine(workspace,"copias-externas"),BackupMinutes=60};
            File.WriteAllText(Path.Combine(root,"server.json"),JsonSerializer.Serialize(settings));Certificates.Initialize(root,"localhost");SecurityState.Initialize(root,"ana","Prueba-Admin-2026!");
            var security=new SecurityState(root);security.ChangeUser(new UserChange{UserName="beatriz",Role="Direccion",Password="Prueba-Direccion-2026!",Enabled=true});security.ChangeUser(new UserChange{UserName="carmen",Role="Secretaria",Password="Prueba-Secretaria-2026!",Enabled=true});
            authority=X509CertificateLoader.LoadCertificateFromFile(Path.Combine(root,"authority.cer"));
            // La integración usa la autoridad pública fijada en cada cliente, sin añadir raíces a Windows.
            for(int i=0;i<4;i++)
            {
                string folder=Path.Combine(workspace,"enrollment-"+i);Certificates.Enroll(root,"equipo-prueba-"+i,"Paquete-Prueba-2026!",folder);
                var cert=X509CertificateLoader.LoadPkcs12FromFile(Path.Combine(folder,"equipo.pfx"),"Paquete-Prueba-2026!",X509KeyStorageFlags.UserKeySet|X509KeyStorageFlags.PersistKeySet);imported.Add(cert); Check(cert.HasPrivateKey && Certificates.ValidateClient(cert,authority),"Certificado de prueba y cadena TLS válidos "+i);
                using var personal=new X509Store(StoreName.My,StoreLocation.CurrentUser);personal.Open(OpenFlags.ReadWrite);personal.Add(cert);
            }
            security=new SecurityState(root);security.SetDevice(SecurityState.CertificateId(imported[3]),false);
            app=ServerHost.Create(root,[]);await app.StartAsync();
            Check(!Certificates.NetworkAllowed(IPAddress.Parse("10.1.0.50"),["192.168.1.0/24"]),"Las redes fuera de la lista autorizada se rechazan");
            string[] people=["ana","beatriz","carmen"], passwords=["Prueba-Admin-2026!","Prueba-Direccion-2026!","Prueba-Secretaria-2026!"];
            for(int i=0;i<3;i++)
            {
                var config=new SharedConfiguration{ServerAuthority=Convert.ToBase64String(authority.RawData),Shared=true,AllowOffline=true,UserName=people[i],ServerUrl="https://localhost:"+port,ClientThumbprint=imported[i].Thumbprint};
                string location=Path.Combine(workspace,"client-"+i,"config.xml");config.Save(location);var remote=new RemoteConnection(config,location);await remote.ConnectAsync(passwords[i]);remote.Start();remotes.Add(remote);
            }
            await Until(()=>remotes.All(r=>r.RealtimeConnected),"Los tres clientes establecen el canal SignalR",25);
            Check(remotes.All(r=>r.CanWrite),"Tres clientes con usuarios y certificados distintos autenticados por HTTPS");
            using(var invalid=new RemoteConnection(new SharedConfiguration{ServerAuthority=Convert.ToBase64String(authority.RawData),Shared=true,UserName="ana",ServerUrl="https://localhost:"+port,ClientThumbprint=imported[3].Thumbprint},Path.Combine(workspace,"invalid-config.xml")))await Reject(()=>invalid.ConnectAsync(passwords[0]),"Un certificado válido pero revocado no permite acceder");
            await Reject(()=>remotes[2].Admin<List<UserView>>("GET","api/admin/users"),"Secretaría no puede administrar usuarios mediante la API");
            await Reject(()=>remotes[0].Admin<List<UserView>>("POST","api/admin/users",new UserChange{UserName="ana",Role="Jefatura",Enabled=false,Admin=false}),"No se puede deshabilitar al último administrador");
            Check(!File.ReadAllText(Path.Combine(root,"security.json")).Contains(passwords[0]),"El servidor almacena hashes y no la contraseña del usuario");
            var switchPath=Path.Combine(workspace,"switch-user","config.xml");
            var switchConfig=new SharedConfiguration{ServerAuthority=Convert.ToBase64String(authority.RawData),Shared=true,AllowOffline=true,UserName="beatriz",ServerUrl="https://localhost:"+port,ClientThumbprint=imported[0].Thumbprint};
            using(var switched=new RemoteConnection(switchConfig,switchPath)){await switched.ConnectAsync(passwords[1]);await switched.LogoutAsync();Check(!switched.CanReadOffline && switched.Snapshot.Events.Count==0,"Cerrar sesión retira la caché del usuario anterior");}
            switchConfig.UserName="carmen";using(var switched=new RemoteConnection(switchConfig,switchPath)){await switched.ConnectAsync(passwords[2]);Check(switched.CanWrite&&!switched.IsAdmin,"Cambio de usuario con credenciales y permisos individuales");}
            Store[] stores=remotes.Select(r=>new Store(r)).ToArray();
            var e=New(stores[0],"Actividad multiusuario de prueba");await Task.Run(()=>stores[0].Save(e));
            await Until(()=>remotes[1].Snapshot.Events.Any(x=>x.Id==e.Id && x.Title==e.Title)&&remotes[2].Snapshot.Events.Any(x=>x.Id==e.Id && x.Title==e.Title),"Creación y actividad recurrente visibles automáticamente en los otros dos clientes");
            Check(remotes[1].NotificationsReceived>0 && remotes[2].NotificationsReceived>0,"Los cambios llegan mediante notificaciones SignalR reales");
            Check(Planning.All(stores[1].Find(e.Id),stores[1].Calendar).Count==2,"Las fechas recurrentes y de varios días se mantienen");
            var first=stores[1].EditSession();var second=stores[2].EditSession();var a=first.Find(e.Id);var b=second.Find(e.Id);
            a.Options.Tasks[0].Completed=true;await Task.Run(()=>first.Save(a));
            b.Options.Memory=new ActivityMemory{Rating="Buena",Continuity="Sí",Justification="Participación adecuada"};
            await Reject(()=>Task.Run(()=>second.Save(b)),"La memoria abierta antes de completar una tarea no sobrescribe la nueva versión");
            await Until(()=>stores[2].Find(e.Id).Options.Tasks[0].Completed,"La finalización de una tarea se sincroniza");
            var memoStore=stores[2].EditSession();var memo=memoStore.Find(e.Id);memo.Options.Memory=b.Options.Memory;await Task.Run(()=>memoStore.Save(memo));
            await Until(()=>stores[0].Find(e.Id).Options.Memory.Continuity=="Sí" && stores[1].Find(e.Id).Options.Memory.Rating=="Buena","Memoria y valoración disponibles en todos los clientes");
            var staleDelete=stores[1].EditSession();var modified=stores[0].Find(e.Id);modified.Notes="Cambio posterior";await Task.Run(()=>stores[0].Save(modified));
            await Reject(()=>Task.Run(()=>staleDelete.Delete(e.Id)),"Una eliminación basada en una versión antigua se bloquea");
            var beforeConfig=stores[1].EditSession();var stale=beforeConfig.Find(e.Id);await Task.Run(()=>stores[0].EditSession().RenameCategory("Otros","General"));
            await Reject(()=>Task.Run(()=>beforeConfig.Save(stale)),"Renombrar una categoría invalida los formularios anteriores");
            await Until(()=>stores[2].Find(e.Id).Options.Category=="General","El cambio de categoría llega a actividades y clientes");
            await remotes[0].SynchronizeAsync();var snapshot=remotes[0].Snapshot;var duplicate=New(stores[0],"Petición idempotente");
            var command=new AgendaCommand{Operation="save",Generation=snapshot.Generation,ConfigVersion=snapshot.ConfigVersion,Event=duplicate};
            var r1=await Task.Run(()=>remotes[0].Execute(command));var r2=await Task.Run(()=>remotes[0].Execute(command));
            Check(r1.ResultId==r2.ResultId && remotes[0].Snapshot.Events.Count(x=>x.Title==duplicate.Title)==1,"Repetir el mismo identificador no duplica una creación");
            var changedReceipt = XmlData.Read<AgendaCommand>(XmlData.Write(command));changedReceipt.Event.Title="No debe sobrescribir la petición original";
            await Reject(()=>Task.Run(()=>remotes[2].Execute(changedReceipt)),"Un usuario no puede reutilizar la operación confirmada de otra persona");
            var missedRemote=remotes[1];var channel=(Microsoft.AspNetCore.SignalR.Client.HubConnection)typeof(RemoteConnection).GetField("hub",System.Reflection.BindingFlags.NonPublic|System.Reflection.BindingFlags.Instance)!.GetValue(missedRemote)!;
            await channel.StopAsync();long notified=missedRemote.NotificationsReceived;var missedEvent=stores[0].Find(e.Id);missedEvent.Notes="Actualización sin notificación";await Task.Run(()=>stores[0].Save(missedEvent));
            await Until(()=>stores[1].Find(e.Id).Notes==missedEvent.Notes,"La comprobación periódica recupera un cambio perdido por SignalR",20);
            Check(missedRemote.NotificationsReceived==notified,"La recuperación del aviso perdido utiliza el estado de la API");
            var cal=stores[0].EditSession();var calendar=cal.Calendar.Copy();calendar.Source="Calendario sincronizado de prueba";await Task.Run(()=>cal.SaveCalendar(calendar));
            await Until(()=>stores[2].Calendar.Source==calendar.Source,"El calendario escolar también se sincroniza");
            var backup=await remotes[0].Admin<BackupRecord>("POST","api/admin/backups");var bytes=await remotes[0].Download(backup.Name);
            Check(Encoding.ASCII.GetString(bytes,0,4)=="ACB1" && !Encoding.UTF8.GetString(bytes).Contains("Actividad multiusuario"),"La copia central está cifrada");
            string recoveryKey=Path.Combine(workspace,"recovery-test.key");File.WriteAllText(recoveryKey,Convert.ToBase64String(Certificates.Unprotect(File.ReadAllBytes(Path.Combine(root,"backup-key.dpapi")))));
            string coldRoot=Path.Combine(workspace,"recovered-server");ServerEngine.Recover(coldRoot,Path.Combine(settings.BackupDirectory,backup.Name),recoveryKey,"localhost","127.0.0.1/32",port);
            using(var cold = new ServerEngine(coldRoot,JsonSerializer.Deserialize<ServerSettings>(File.ReadAllText(Path.Combine(coldRoot,"server.json")))!)) Check(cold.Store.Find(e.Id).Options.Memory.Rating=="Buena" && cold.Security.Users().Count==3 && File.ReadAllBytes(Path.Combine(coldRoot,"authority.cer")).SequenceEqual(File.ReadAllBytes(Path.Combine(root,"authority.cer"))),"Recuperación en una carpeta nueva usando clave externa, con usuarios y autoridad de equipos");
            Check(File.Exists(Path.Combine(settings.ExternalBackupDirectory,backup.Name)),"Copia automática o manual conservada fuera de la carpeta del servidor");
            Check(Fingerprint(Path.Combine(settings.ExternalBackupDirectory,backup.Name))==Convert.ToHexString(SHA256.HashData(bytes)),"La copia externa es idéntica a la copia descargada");
            var corrupted=(byte[])bytes.Clone();corrupted[^1]^=1;await Reject(()=>remotes[0].Restore(corrupted),"Una copia alterada no puede restaurarse");
            await remotes[0].SynchronizeAsync();
            string probeFolder=Path.Combine(workspace,"wpf"); Directory.CreateDirectory(probeFolder);
            if(args.Length>2)
            {
                var start=new System.Diagnostics.ProcessStartInfo(Path.GetFullPath(args[2])){UseShellExecute=false,CreateNoWindow=true,RedirectStandardInput=true,RedirectStandardOutput=true,RedirectStandardError=true};
                start.ArgumentList.Add(probeFolder);start.ArgumentList.Add(Path.Combine(workspace,"client-0","config.xml"));start.ArgumentList.Add(Path.Combine(workspace,"client-1","config.xml"));start.ArgumentList.Add(Path.Combine(root,"agenda.sqlite3"));
                probe=System.Diagnostics.Process.Start(start)!;probe.StandardInput.WriteLine(passwords[0]);probe.StandardInput.WriteLine(passwords[1]);probe.StandardInput.Close();
                probe.OutputDataReceived+=(s,e)=>{if(e.Data!=null)Console.WriteLine("WPF: "+e.Data);};probe.BeginOutputReadLine();
                await Until(()=>File.Exists(Path.Combine(probeFolder,"ready"))||probe.HasExited,"El cliente WPF inicia la prueba compartida",50);
                if(probe.HasExited)Console.WriteLine("ERROR WPF: "+await probe.StandardError.ReadToEndAsync());
                Check(!probe.HasExited,"Los formularios WPF completan guardado y conflicto con el servidor real");
                for(int i=0;i<3;i++)await remotes[i].SynchronizeAsync();
            }
            int total=stores[0].EventCount();await app.StopAsync();await app.DisposeAsync();app=null;
            await Until(()=>!remotes[0].CanWrite&&!remotes[1].CanWrite&&!remotes[2].CanWrite,"Al detener Jefatura los tres clientes bloquean las modificaciones",25);
            Check(remotes.All(r=>r.CanReadOffline) && stores.All(s=>s.EventCount()==total),"Los clientes desconectados conservan la agenda, tareas y memorias");
            await Reject(()=>Task.Run(()=>stores[1].Save(New(stores[1],"No debe guardarse"))),"El almacén del cliente impide guardar sin conexión");
            string cacheFile=Directory.GetFiles(Path.Combine(workspace,"client-1"),"*.dpapi").Single();byte[] encrypted=File.ReadAllBytes(cacheFile);
            Check(!Encoding.UTF8.GetString(encrypted).Contains("Actividad multiusuario")&&!Encoding.UTF8.GetString(encrypted).Contains("Prueba-Direccion"),"La caché local y la sesión no contienen datos legibles");
            using(var reopened=new RemoteConnection(SharedConfiguration.Load(Path.Combine(workspace,"client-1","config.xml")),Path.Combine(workspace,"client-1","config.xml")))Check(reopened.CanReadOffline&&reopened.Snapshot.Events.Count==total,"Consulta local al volver a abrir el cliente con el servidor apagado");
            if(probe!=null)await Until(()=>File.Exists(Path.Combine(probeFolder,"offline"))||probe.HasExited,"El cliente WPF completa consulta e informe sin conexión",50);
            app=ServerHost.Create(root,[]);await app.StartAsync();
            await Until(()=>remotes.All(r=>r.CanWrite),"Reconexión automática tras reiniciar el servidor usando sesiones renovables",30);
            Check(stores.All(s=>s.EventCount()==total),"Reiniciar Jefatura conserva todos los datos");
            if(probe!=null){await probe.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(60));Check(probe.ExitCode==0,"Pruebas reales del cliente WPF .NET Framework superadas");}
            var extra=New(stores[0],"Creada después de la copia");await Task.Run(()=>stores[0].Save(extra));await remotes[0].SynchronizeAsync();
            await remotes[0].Restore(bytes);
            await Until(()=>remotes.All(r=>!r.CanWrite),"La restauración invalida las sesiones anteriores",25);
            for(int i=0;i<3;i++)await remotes[i].ConnectAsync(passwords[i]);
            Check(stores.All(s=>s.Find(extra.Id)==null)&&stores[0].Find(e.Id).Options.Memory.Rating=="Buena","La restauración recupera actividades, tareas y memorias y descarta cambios posteriores");
            var audit=await remotes[0].Admin<List<AuditRow>>("GET","api/admin/audit");Check(audit.Any(x=>x.Operation=="restore")&&audit.Any(x=>x.Actor=="carmen"&&x.Operation=="save"),"El registro identifica usuario, equipo, modificación y restauración");
            await remotes[0].Admin<List<UserView>>("POST","api/admin/users",new UserChange{UserName="carmen",Role="Secretaria",Enabled=false,Admin=false});
            await Until(()=>!remotes[2].CanWrite&&!remotes[2].CanReadOffline,"La revocación del usuario retira sesión y copia de consulta al reconectar",25);
            await remotes[0].SynchronizeAsync();var delete=stores[0].EditSession();await Task.Run(()=>delete.Delete(e.Id));await Until(()=>stores[1].Find(e.Id)==null,"La eliminación se propaga a los demás clientes");
            Check(app.Services.GetRequiredService<ServerEngine>().Store.IntegrityCheck()=="ok","Integridad final de SQLite");
            log.Add("RESUMEN: "+passed+" comprobaciones de red correctas, 0 fallos.");Console.WriteLine(log[^1]);return 0;
        }
        catch(Exception ex){foreach(var r in remotes)Console.WriteLine("ESTADO: "+r.Status);log.Add("FALLO: "+ex);Console.WriteLine(log[^1]);return 1;}
        finally
        {
            if(probe!=null && !probe.HasExited){try{probe.Kill(true);await probe.WaitForExitAsync();}catch{}}
            foreach(var remote in remotes)remote.Dispose();if(app!=null){await app.StopAsync();await app.DisposeAsync();}
            File.WriteAllLines(Path.Combine(workspace,"resultado-red.txt"),log);
            foreach(var cert in imported)
            {
                using(var personal=new X509Store(StoreName.My,StoreLocation.CurrentUser)){personal.Open(OpenFlags.ReadWrite);personal.Remove(cert);}
                try{using var rsa=cert.GetRSAPrivateKey();if(rsa is RSACng cng)cng.Key.Delete();}catch{}cert.Dispose();
            }
            if(authority!=null)authority.Dispose();
            File.WriteAllLines(Path.Combine(workspace,"resultado-red.txt"),log);
        }
    }
}



