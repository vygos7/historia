param(
 [string]$Salida=(Join-Path $PSScriptRoot 'compilado'),
 [string]$ClienteZip=(Join-Path $PSScriptRoot 'payload/cliente.zip'),
 [string]$ServidorZip=(Join-Path $PSScriptRoot 'payload/servidor.zip'),
 [string]$DotNet='dotnet'
)
$ErrorActionPreference='Stop'
$env:DOTNET_CLI_TELEMETRY_OPTOUT='1'
Add-Type -AssemblyName System.IO.Compression.FileSystem
function Verificar-Payload([string]$Archivo,[string]$Rol) {
 if(-not(Test-Path -LiteralPath $Archivo -PathType Leaf)){throw "Falta $Archivo. Compila los componentes actuales; no se recuperan payloads de instaladores antiguos."}
 $zip=[IO.Compression.ZipFile]::OpenRead([IO.Path]::GetFullPath($Archivo))
 try {
  $entry=$zip.GetEntry("$Rol/manifiesto.json")
  if($null-eq$entry){throw "Falta el manifiesto de $Rol."}
  $reader=[IO.StreamReader]::new($entry.Open())
  try{$manifest=$reader.ReadToEnd()|ConvertFrom-Json}finally{$reader.Dispose()}
  if($manifest.Format-ne1-or$manifest.Role-ne$Rol-or$manifest.ClientRevision-ne'4.0.4-http-r2'-or$manifest.Files.Count-lt1){throw "Payload de $Rol de otra compilación."}
  $seen=[Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
  foreach($file in $manifest.Files) {
   if($file.Path-match'(^/|\\|(^|/)\.\.?(/|$)|//)' -or -not$seen.Add($file.Path)){throw 'Ruta de payload no válida o duplicada.'}
   $name=($file.Path-split'/')[-1]
   if($name-match'(?i)(\.pfx$|\.dpapi$|\.key$|^server\.json$|^security\.json$|^TrabajoCompartido\.xml$|^agenda\.sqlite3$)'){throw 'Un paquete general no puede incluir identidades o datos de un centro.'}
   $part=$zip.GetEntry("$Rol/$($file.Path)")
   if($null-eq$part){throw "Falta $($file.Path)."}
   $stream=$part.Open();$sha=[Security.Cryptography.SHA256]::Create()
   try{$actual=[BitConverter]::ToString($sha.ComputeHash($stream)).Replace('-','')}finally{$sha.Dispose();$stream.Dispose()}
   if($actual-ne$file.Sha256){throw "Huella incorrecta: $($file.Path)."}
  }
  $actualFiles=@($zip.Entries|Where-Object{-not$_.FullName.EndsWith('/')-and$_.FullName-ne"$Rol/manifiesto.json"})
  if($seen.Count-ne$actualFiles.Count -or @($actualFiles|Where-Object{-not$_.FullName.StartsWith("$Rol/")}).Count-gt0){throw 'El ZIP contiene archivos fuera del manifiesto.'}
  $required=if($Rol-eq'cliente'){@('AgendaClara.exe','AgendaClara.exe.config','Microsoft.AspNetCore.SignalR.Client.dll')}else{@('AgendaClara.Server.exe','AgendaClara.Server.dll','AgendaClara.Server.runtimeconfig.json','coreclr.dll','hostfxr.dll')}
  foreach($name in $required){if(-not$seen.Contains($name)){throw "Falta un componente necesario: $name"}}
  if($Rol-eq'cliente') {
   $tmp=Join-Path ([IO.Path]::GetTempPath()) ('AgendaClara-Revision-'+[Guid]::NewGuid().ToString('N')+'.exe')
   try {
    $inputStream=$zip.GetEntry('cliente/AgendaClara.exe').Open();$outputStream=[IO.File]::Create($tmp)
    try{$inputStream.CopyTo($outputStream)}finally{$outputStream.Dispose();$inputStream.Dispose()}
    if(-not([Diagnostics.FileVersionInfo]::GetVersionInfo($tmp).ProductVersion.StartsWith('4.0.4-http-r2'))){throw 'El cliente incluido no incorpora r2.'}
   } finally{if(Test-Path -LiteralPath $tmp){Remove-Item -LiteralPath $tmp}}
  }
 } finally{$zip.Dispose()}
}
Verificar-Payload $ClienteZip 'cliente'
Verificar-Payload $ServidorZip 'servidor'
New-Item -ItemType Directory -Force -Path $Salida|Out-Null
$Salida=[IO.Path]::GetFullPath($Salida);$ClienteZip=[IO.Path]::GetFullPath($ClienteZip);$ServidorZip=[IO.Path]::GetFullPath($ServidorZip)
& $DotNet build (Join-Path $PSScriptRoot 'proyectos/cliente/AgendaClara.Setup.Client.csproj') -c Release -o $Salida "-p:ClientPayload=$ClienteZip" --nologo
if($LASTEXITCODE-ne0){throw 'No se ha compilado el instalador del cliente.'}
$client=Join-Path $Salida 'Instalar-AgendaClara-Cliente.exe'
& $DotNet build (Join-Path $PSScriptRoot 'proyectos/servidor/AgendaClara.Setup.Server.csproj') -c Release -o $Salida "-p:ClientPayload=$ClienteZip" "-p:ServerPayload=$ServidorZip" "-p:ClientInstaller=$client" --nologo
if($LASTEXITCODE-ne0){throw 'No se ha compilado el instalador del servidor.'}
$release=[ordered]@{InstallerVersion='1.2.5';ClientRevision='4.0.4-http-r2';ClientPayloadSha256=(Get-FileHash -LiteralPath $ClienteZip -Algorithm SHA256).Hash;ServerPayloadSha256=(Get-FileHash -LiteralPath $ServidorZip -Algorithm SHA256).Hash;ClientInstallerSha256=(Get-FileHash -LiteralPath $client -Algorithm SHA256).Hash;ServerInstallerSha256=(Get-FileHash -LiteralPath (Join-Path $Salida 'Instalar-AgendaClara-Servidor.exe') -Algorithm SHA256).Hash}
$release|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $Salida 'compilacion.json') -Encoding utf8
Get-Item -LiteralPath $client,(Join-Path $Salida 'Instalar-AgendaClara-Servidor.exe')|Select-Object Name,Length
