using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.AccessControl;
using System.Security.Cryptography.X509Certificates;
using System.Security.Principal;
using System.ServiceProcess;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using Microsoft.Win32;

namespace AgendaClara.Setup
{
    public sealed class ServerPlan
    {
        public string Mode="new",Host="",Network="",AdminUser="",AdminPassword="",PackagePassword="",Agenda="",Backup="",RecoveryKey="",ExportKey="",Packages="",Program="",Data="";
        public int Port=7443;
        // Network may hold several subnets (one per line or separated by commas): one per group of puestos.
        public List<string> Networks{get{return NetworkChoice.ParseList(Network);}}
        public void Validate()
        {
            if(!new[]{"new","update","recover","resume"}.Contains(Mode))throw new ArgumentException("Operación de instalación no válida.");
            Files.SafeProgramFolder(Program);Files.SafeProgramFolder(Data);
            if(Files.Inside(Program,Data)||Files.Inside(Data,Program))throw new ArgumentException("Las carpetas del programa y de los datos deben estar separadas.");
            if(new Uri(Files.Full(Data)).IsUnc||new DriveInfo(Path.GetPathRoot(Files.Full(Data))).DriveType==DriveType.Network)throw new ArgumentException("Los datos del servidor deben guardarse en su disco local.");
            if(Mode=="resume" && !File.Exists(Path.Combine(Data,"server.json")))throw new ArgumentException("No se encuentra una configuración preparada en esa carpeta. Selecciona una instalación nueva en otra carpeta vacía.");
            if(Mode=="update")
            {if(!File.Exists(Path.Combine(Data,"server.json"))||!File.Exists(Path.Combine(Program,"AgendaClara.Server.exe")))throw new ArgumentException("No se encuentra la instalación del servidor que se va a actualizar.");}
            if(Uri.CheckHostName(Host)==UriHostNameType.Unknown)throw new ArgumentException("Indica el nombre o la IP estable del ordenador de Jefatura.");NetworkChoice.ParseList(Network);
            if(Port<1024||Port>65535)throw new ArgumentException("El puerto debe estar entre 1024 y 65535.");
            if(Mode!="resume" && Mode!="update" && Directory.Exists(Data)&&Directory.EnumerateFileSystemEntries(Data).Any())throw new ArgumentException("Elige una carpeta de datos nueva y vacía. No se sobrescribirá una agenda existente.");
            if(Mode=="new" || Mode=="resume" || Mode=="update")
            {
                if(Mode=="new" && (String.IsNullOrWhiteSpace(AdminUser)||AdminUser.Length>80||AdminUser.Any(Char.IsControl)))throw new ArgumentException("Escribe el usuario personal que administrará Nexo Centro.");
                if(Mode=="new") Password(AdminPassword,"contraseña del administrador");Password(PackagePassword,"contraseña de los paquetes");
                if(Mode=="new" && AdminPassword==PackagePassword)throw new ArgumentException("Usa una contraseña distinta para proteger los paquetes de los equipos.");
                if(!String.IsNullOrWhiteSpace(Agenda)&&!File.Exists(Agenda))throw new ArgumentException("No se encuentra el archivo de la agenda que quieres importar.");
                if(String.IsNullOrWhiteSpace(Packages))throw new ArgumentException("Elige dónde guardar los paquetes de acceso.");
                if(Directory.Exists(Packages)&&Directory.EnumerateFileSystemEntries(Packages).Any())throw new ArgumentException("La carpeta de paquetes debe estar vacía para no mezclar accesos.");
                if(Files.Inside(Packages,Data)||Files.Inside(Packages,Program)||Files.Inside(Data,Packages)||Files.Inside(Program,Packages))throw new ArgumentException("Guarda los paquetes fuera de las carpetas del programa y de sus datos.");
                if(String.IsNullOrWhiteSpace(ExportKey)||File.Exists(ExportKey))throw new ArgumentException("Elige un archivo nuevo para guardar la clave de recuperación.");
                if(Files.Inside(ExportKey,Data)||Files.Inside(ExportKey,Program))throw new ArgumentException("Guarda la clave de recuperación separada de los datos y de los paquetes de acceso.");
            }
            else if(Mode=="recover")
            {if(!File.Exists(Backup)||!File.Exists(RecoveryKey))throw new ArgumentException("Selecciona la copia cifrada y su archivo de clave de recuperación.");}
        }
        public static void Password(string value,string label){if(String.IsNullOrEmpty(value)||value.Length<12||value.Length>256||value.Contains('\r')||value.Contains('\n'))throw new ArgumentException("La "+label+" debe tener entre 12 y 256 caracteres.");}
    }
    public static class ServerInstaller
    {
        public const string Service="AgendaClaraServidor";
        public static bool Exists(){return ServiceController.GetServices().Any(s=>s.ServiceName.Equals(Service,StringComparison.OrdinalIgnoreCase));}
        public static void ReadConfiguration(ServerPlan plan)
        {
            string path=Path.Combine(plan.Data,"server.json");if(!File.Exists(path))return;var data=new System.Web.Script.Serialization.JavaScriptSerializer().Deserialize<Dictionary<string,object>>(File.ReadAllText(path));
            object value;if(data.TryGetValue("PublicHost",out value))plan.Host=Convert.ToString(value);if(data.TryGetValue("Port",out value))plan.Port=Convert.ToInt32(value);if(data.TryGetValue("AllowedNetworks",out value)){var list=value as System.Collections.IEnumerable;if(list!=null)plan.Network=String.Join(", ",list.Cast<object>().Select(Convert.ToString));}
        }
        public static void ReadExisting(ServerPlan plan)
        {
            using(var key=Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Services\AgendaClaraServidor"))
            {
                if(key==null)return;string command=Convert.ToString(key.GetValue("ImagePath"));var exe=Regex.Match(command,"^\\s*\"(?<path>[^\"]+)\"|^\\s*(?<path>\\S+)");var data=Regex.Match(command,"--data\\s+\"(?<path>[^\"]+)\"|--data\\s+(?<path>\\S+)");
                if(exe.Success)plan.Program=Path.GetDirectoryName(Environment.ExpandEnvironmentVariables(exe.Groups["path"].Value));if(data.Success)plan.Data=Environment.ExpandEnvironmentVariables(data.Groups["path"].Value);
            }
        }
        public static void Prepare(ServerPlan plan,string source,IProgress<string> progress)
        {
            plan.Validate();PayloadIntegrity.Validate(source,"servidor");if(plan.Mode=="update")throw new InvalidOperationException("La actualización usa otro procedimiento.");
            progress.Report("Preparando carpetas y protegiendo los datos…");Files.OwnFolder(plan.Data,false);Directory.CreateDirectory(plan.Program);Files.CopyTree(source,plan.Program);string exe=Path.Combine(plan.Program,"AgendaClara.Server.exe");
            var arguments=new List<string>{plan.Mode=="recover"?"recover":"init","--data",plan.Data,"--host",plan.Host,"--network",String.Join(",",plan.Networks),"--port",plan.Port.ToString()};
            if(plan.Mode=="recover"){arguments.AddRange(new[]{"--file",plan.Backup,"--recovery-key",plan.RecoveryKey});progress.Report("Verificando y recuperando la copia cifrada…");}
            else{arguments.AddRange(new[]{"--user",plan.AdminUser});if(!String.IsNullOrWhiteSpace(plan.Agenda))arguments.AddRange(new[]{"--import",plan.Agenda});progress.Report(String.IsNullOrWhiteSpace(plan.Agenda)?"Creando la agenda central…":"Importando una copia de la agenda actual; el original se conserva…");}
            if(plan.Mode!="resume")progress.Report(Files.Run(exe,arguments,plan.Mode=="new"?plan.AdminPassword:null,240).Replace("Contraseña del administrador: ",""));
            else progress.Report("Se conservan la agenda y los usuarios de la configuración preparada.");
            GenerateClients(plan,exe,progress);
        }
        // Written next to the installers: what a school's IT person needs to check when a puesto cannot connect.
        public static string ConnectionGuide(ServerPlan plan)
        {
            var own=NetworkChoice.Detect();
            var lines=new List<string>
            {
                "Nexo Centro · red y conexión del servidor ("+DateTime.Now.ToString("dd/MM/yyyy HH:mm")+")","",
                "Dirección que usan los puestos: https://"+plan.Host+":"+plan.Port,
                "Direcciones de este ordenador: "+(own.Count>0?String.Join(", ",own.Select(n=>n.Address+" ("+n.Network+")")):"no detectadas"),
                "Redes autorizadas: "+String.Join(", ",plan.Networks),"",
                "Para que un puesto conecte:",
                "1. Su dirección IP debe estar dentro de una red autorizada. En el puesto, «ipconfig» muestra su dirección.",
                "2. Debe encontrar «"+plan.Host+"». Si está en otra subred y el centro no tiene DNS interno, usa como dirección la IP fija de este ordenador y genera de nuevo los instaladores.",
                "3. Los routers o cortafuegos que separan las subredes deben permitir TCP "+plan.Port+" hacia este ordenador.",
                "4. La regla «Nexo Centro servidor HTTPS» debe estar habilitada en el perfil activo. Este instalador admite Dominio, Privado y Público, manteniendo las redes autorizadas, el programa y el puerto.","",
                "Comprobación desde un puesto (PowerShell):",
                "   Test-NetConnection "+plan.Host+" -Port "+plan.Port,
                "Si no encuentra el nombre, revisa el paso 2. Si «TcpTestSucceeded» es False, el bloqueo está en los pasos 1, 3 o 4.","",
                "Para cambiar la dirección, las redes o el puerto: abre el instalador del servidor, elige «Actualizar el servidor» y abre «Opciones de red». La agenda se conserva y se generan instaladores nuevos para los puestos."
            };
            var warnings=NetworkChoice.Warnings(plan.Host,plan.Networks);
            if(warnings.Count>0){lines.Add("");lines.Add("Avisos detectados al preparar el servidor:");lines.AddRange(warnings.Select(w=>"- "+w));}
            return String.Join(Environment.NewLine,lines);
        }
        public static void GenerateClients(ServerPlan plan,string exe,IProgress<string> progress)
        {
                Files.OwnFolder(plan.Packages,false);
                File.WriteAllText(Path.Combine(plan.Packages,"Huella-HTTPS.txt"),"Servidor: https://"+plan.Host+":"+plan.Port+Environment.NewLine+"SHA-256 autoridad: "+Files.Hash(Path.Combine(plan.Data,"authority.cer"))+Environment.NewLine+"Comprueba esta huella en Jefatura. Comunícala al puesto por un medio independiente del instalador. No incluye claves privadas.");
                File.WriteAllText(Path.Combine(plan.Packages,"Red-y-conexion.txt"),ConnectionGuide(plan),new UTF8Encoding(true));
                foreach(string role in new[]{"Jefatura","Direccion","Secretaria"})
                {
                    progress.Report("Creando el instalador de "+role+"…");string folder=Path.Combine(plan.Packages,role);
                    Files.Run(exe,new[]{"enroll","--data",plan.Data,"--name",plan.Mode=="new"?role:role+"-"+DateTime.UtcNow.ToString("yyyyMMddHHmmss"),"--output",folder,"--automatic-role",role},plan.PackagePassword,120);
                    string baseInstaller=Path.Combine(folder,"cliente-base.exe");Files.EmbeddedFile("AgendaClara.Setup.Client",baseInstaller);
                    SimplePackage.Create(baseInstaller,folder,Path.Combine(plan.Packages,"Instalar-NexoCentro-"+role+".exe"),role,plan.PackagePassword);
                    if(!Files.Inside(folder,plan.Packages)||Files.Full(folder)==Files.Full(plan.Packages))throw new IOException("Ruta temporal no válida.");Directory.Delete(Files.Full(folder),true);
                }
                progress.Report("Preparando el respaldo del servidor automáticamente…");Directory.CreateDirectory(Path.GetDirectoryName(Files.Full(plan.ExportKey)));
                Files.Run(exe,new[]{"export-recovery-key","--data",plan.Data,"--output",plan.ExportKey},null,60);
                File.WriteAllText(Path.Combine(Path.GetDirectoryName(Files.Full(plan.ExportKey)),"Clave-instaladores.txt"),"Clave de transporte de los instaladores de esta generación (comunicar por separado, no enviar junto al EXE):"+Environment.NewLine+plan.PackagePassword);
                try
                {
                    var security=new FileSecurity();security.SetAccessRuleProtection(true,false);foreach(var id in new IdentityReference[]{WindowsIdentity.GetCurrent().User,new SecurityIdentifier(WellKnownSidType.LocalSystemSid,null),new SecurityIdentifier(WellKnownSidType.BuiltinAdministratorsSid,null)})security.AddAccessRule(new FileSystemAccessRule(id,FileSystemRights.FullControl,AccessControlType.Allow));File.SetAccessControl(plan.ExportKey,security);
                }catch(PlatformNotSupportedException){}catch(NotSupportedException){}
                progress.Report("Los tres instaladores están preparados. La carpeta de respaldo se ha preparado automáticamente.");
        }
        public static void Install(ServerPlan plan,string source,IProgress<string> progress)
        {
            plan.Validate();if(plan.Mode=="update"){Update(plan,source,progress);return;}if(Exists() && plan.Mode!="resume")throw new IOException("Ya existe un servidor instalado. Selecciona Actualizar servidor.");
            if(plan.Mode=="resume" && Exists())using(var prior=new ServiceController(Service)){if(prior.Status!=ServiceControllerStatus.Stopped)throw new IOException("El servicio ya está funcionando. Utiliza Actualizar servidor.");}
            Prepare(plan,source,progress);string exe=Path.Combine(plan.Program,"AgendaClara.Server.exe");string sc=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System),"sc.exe");
            progress.Report("Registrando el servicio de Windows con inicio automático…");
            if(!Exists())Files.Run(sc,new[]{"create",Service,"binPath=",Files.Quote(exe)+" --data "+Files.Quote(plan.Data),"start=","delayed-auto","obj=",@"NT SERVICE\AgendaClaraServidor","DisplayName=","Nexo Centro · servidor del centro"},null,30);
            Files.Run(sc,new[]{"description",Service,"Agenda institucional local: HTTPS, sincronización y copias de seguridad."},null,30);
            Files.Run(sc,new[]{"failure",Service,"reset=","86400","actions=","restart/10000/restart/30000/restart/60000"},null,30);
            Files.Run(sc,new[]{"sidtype",Service,"unrestricted"},null,30);
            progress.Report("Aplicando los permisos de la cuenta del servicio…");Files.OwnFolder(plan.Data,true);
            foreach(string item in Directory.GetFileSystemEntries(plan.Data))Files.Run(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System),"icacls.exe"),new[]{item,"/reset","/T","/Q"},null,120);
            progress.Report("Configurando el acceso solo desde las redes elegidas ("+String.Join(", ",plan.Networks)+")…");Firewall(exe,plan.Port,plan.Networks);
            progress.Report("Iniciando el servidor…");using(var service=new ServiceController(Service)){service.Start();service.WaitForStatus(ServiceControllerStatus.Running,TimeSpan.FromSeconds(60));}
            progress.Report("Servidor iniciado. Se pondrá en marcha automáticamente cuando arranque Windows.");
            if(plan.Mode=="new" || plan.Mode=="resume")progress.Report("Siguiente paso: lleva a cada puesto su instalador y ábrelo con doble clic. Instala también el cliente de Jefatura en su perfil habitual de Windows.");
            else progress.Report("Se han recuperado los usuarios y equipos de la copia. Los clientes deben identificarse de nuevo.");
        }
        public static string FirewallAddresses(IEnumerable<string> networks){return String.Join(",",networks);}
        public static void ConfigureFirewallRule(object target,string executable,int port,IEnumerable<string> networks)
        {
            if(port<1024||port>65535)throw new ArgumentException("Puerto no válido.");
            string network=FirewallAddresses(NetworkChoice.ParseList(FirewallAddresses(networks)));
            dynamic rule=target;
            rule.Name="AgendaClara servidor HTTPS";rule.Description="Nexo Centro: sólo el programa, puerto y redes privadas autorizadas; perfiles Dominio, Privado y Público";
            rule.ApplicationName=executable;rule.Protocol=6;rule.LocalPorts=port.ToString();rule.Direction=1;rule.Action=1;
            rule.Profiles=1|2|4;rule.RemoteAddresses=network;rule.Enabled=true;
        }
        static void Firewall(string executable,int port,IEnumerable<string> networks)
        {
            dynamic rule=Activator.CreateInstance(Type.GetTypeFromProgID("HNetCfg.FWRule"));
            ConfigureFirewallRule((object)rule,executable,port,networks);
            dynamic policy=Activator.CreateInstance(Type.GetTypeFromProgID("HNetCfg.FwPolicy2"));const string name="AgendaClara servidor HTTPS";
            try{policy.Rules.Remove(name);}catch(System.Runtime.InteropServices.COMException){}
            policy.Rules.Add(rule);
        }
        static bool MissingFirewallRule(Exception error)
        {return error is FileNotFoundException || error is System.Runtime.InteropServices.COMException&&error.HResult==unchecked((int)0x80070002);}
        static FirewallSnapshot CaptureFirewall()
        {
            dynamic policy=Activator.CreateInstance(Type.GetTypeFromProgID("HNetCfg.FwPolicy2"));
            try{return FirewallSnapshot.Capture((object)policy.Rules.Item("AgendaClara servidor HTTPS"));}
            catch(Exception ex)when(MissingFirewallRule(ex)){return null;}
        }
        static void RestoreFirewall(FirewallSnapshot previous)
        {
            dynamic policy=Activator.CreateInstance(Type.GetTypeFromProgID("HNetCfg.FwPolicy2"));
            try{policy.Rules.Remove("AgendaClara servidor HTTPS");}catch(Exception ex)when(MissingFirewallRule(ex)){}
            if(previous==null)return;
            dynamic rule=Activator.CreateInstance(Type.GetTypeFromProgID("HNetCfg.FWRule"));
            previous.Apply((object)rule);policy.Rules.Add(rule);
            // La reversión no se confirma sólo porque Add haya devuelto el control.
            dynamic fresh=Activator.CreateInstance(Type.GetTypeFromProgID("HNetCfg.FwPolicy2"));
            if(!previous.Matches((object)fresh.Rules.Item(previous.Name)))throw new IOException("La regla restaurada no coincide con el respaldo del cortafuegos.");
        }
#if SETUP_TESTS
        internal static Action<string> UpdateCheckpoint=null;
#endif
        static void Checkpoint(string stage)
        {
#if SETUP_TESTS
            if(UpdateCheckpoint!=null)UpdateCheckpoint(stage);
#endif
        }
        static void Update(ServerPlan plan,string source,IProgress<string> progress)
        {
            PayloadIntegrity.Validate(source,"servidor");
            if(!Exists())throw new IOException("No existe el servicio que se va a actualizar.");
            string backup=Path.Combine(Path.GetTempPath(),"AgendaClara-Instalacion-"+Guid.NewGuid().ToString("N"));
            Files.OwnFolder(backup,false);
            bool wasRunning=false,stateChanged=false,firewallChanged=false,keepBackup=false;
            var state=new Dictionary<string,byte[]>();FirewallSnapshot previousFirewall=CaptureFirewall();FileDeployment deployment=null;
            try
            {
                using(var service=new ServiceController(Service))
                {wasRunning=service.Status!=ServiceControllerStatus.Stopped;if(wasRunning){progress.Report("Deteniendo el servicio para actualizar…");service.Stop();service.WaitForStatus(ServiceControllerStatus.Stopped,TimeSpan.FromSeconds(60));}}
                foreach(string name in new[]{"server.json","server.pfx","authority.pfx","authority.cer","security.json","certificate-password.dpapi","backup-key.dpapi"})
                {byte[] bytes=File.ReadAllBytes(Path.Combine(plan.Data,name));state.Add(name,bytes);string target=Path.Combine(backup,"configuracion",name);Directory.CreateDirectory(Path.GetDirectoryName(target));File.WriteAllBytes(target,bytes);}
                progress.Report("Creando una copia cifrada antes de sustituir el programa…");
                Files.Run(Path.Combine(plan.Program,"AgendaClara.Server.exe"),new[]{"backup","--data",plan.Data},null,180);
                deployment=new FileDeployment(source,plan.Program,Path.Combine(backup,"programa"));
                progress.Report("Actualizando y verificando los archivos del servidor…");deployment.Apply();
                string exe=Path.Combine(plan.Program,"AgendaClara.Server.exe");stateChanged=true;
                progress.Report(Files.Run(exe,new[]{"configure-network","--data",plan.Data,"--host",plan.Host,"--network",String.Join(",",plan.Networks),"--port",plan.Port.ToString()},null,120));
                firewallChanged=true;Firewall(exe,plan.Port,plan.Networks);Checkpoint("firewall");
                GenerateClients(plan,exe,progress);Checkpoint("packages");
                using(var service=new ServiceController(Service)){service.Start();service.WaitForStatus(ServiceControllerStatus.Running,TimeSpan.FromSeconds(60));}
                Checkpoint("started");deployment.Commit();progress.Report("Servidor actualizado e iniciado. Se conservan la agenda y los accesos anteriores.");
            }
            catch(Exception error)
            {
                var failures=new List<Exception>();bool stopped=true;
                try{using(var service=new ServiceController(Service)){service.Refresh();if(service.Status!=ServiceControllerStatus.Stopped){service.Stop();service.WaitForStatus(ServiceControllerStatus.Stopped,TimeSpan.FromSeconds(60));}}}
                catch(Exception ex){stopped=false;failures.Add(ex);}
                if(stopped)
                {
                    // Si una operación de consola continúa después de su plazo, su bloqueo
                    // impide restaurar archivos de seguridad mientras todavía los utiliza.
                    try
                    {
                        using(var lease=new FileStream(Path.Combine(plan.Data,"server.lock"),FileMode.OpenOrCreate,FileAccess.ReadWrite,FileShare.None))
                        {
                            if(deployment!=null)deployment.Restore();
                            if(stateChanged)foreach(var item in state)Files.RestoreBytes(Path.Combine(plan.Data,item.Key),item.Value);
                            if(firewallChanged)RestoreFirewall(previousFirewall);
                        }
                    }
                    catch(Exception ex){failures.Add(ex);}
                }
                try{if(Directory.Exists(plan.Packages))File.WriteAllText(Path.Combine(plan.Packages,"NO-USAR-ACTUALIZACION-INCOMPLETA.txt"),"Esta generación no se ha confirmado. No distribuyas sus instaladores. Repite la preparación cuando el servidor esté recuperado.");}catch(Exception ex){failures.Add(ex);}
                if(failures.Count==0&&wasRunning)
                    try{using(var service=new ServiceController(Service)){service.Start();service.WaitForStatus(ServiceControllerStatus.Running,TimeSpan.FromSeconds(60));}}catch(Exception ex){failures.Add(ex);}
                if(failures.Count>0){keepBackup=true;failures.Insert(0,error);throw new IOException("No se ha completado la actualización y la reversión requiere revisión. Conserva el respaldo en "+backup,new AggregateException(failures));}
                throw new IOException("No se ha completado la actualización. Se han restaurado el programa, la configuración, los certificados y los accesos anteriores. No uses los paquetes de la generación incompleta.",error);
            }
            finally{if(!keepBackup)Files.RemoveTemporary(backup);}
        }
    }
    public sealed class ClientPlan
    {
        public string Package="",PackagePassword="",ExpectedHash="",VerifiedAuthorityHash="",User="",Program="",Server="",Configuration="";public bool Offline,UseExisting,AutomaticAccess;
        public void Validate()
        {
            Files.SafeProgramFolder(Program);
            if(UseExisting){if(!File.Exists(Configuration))throw new ArgumentException("No se encuentra una configuración anterior para actualizar.");return;}
            if(String.IsNullOrWhiteSpace(User)||User.Length>80||User.Any(Char.IsControl))throw new ArgumentException("Escribe tu usuario personal de Nexo Centro.");
            foreach(string file in new[]{"equipo.pfx","servidor-raiz.cer","servidor.txt"})if(!File.Exists(Path.Combine(Package,file)))throw new ArgumentException("La carpeta de acceso no contiene "+file+". Selecciona el paquete entregado por Jefatura.");
            string actual=Files.Hash(Path.Combine(Package,"servidor-raiz.cer"));string expected=Regex.Replace(ExpectedHash??"","[\\s:-]","").ToUpperInvariant();
            if(expected.Length!=64||expected!=actual)throw new ArgumentException("El código de verificación no coincide con el del paquete. Compruébalo con Jefatura antes de instalar.");
            Server=File.ReadAllText(Path.Combine(Package,"servidor.txt")).Trim();Uri address;if(!Uri.TryCreate(Server,UriKind.Absolute,out address)||address.Scheme!="https"||address.UserInfo.Length!=0||address.AbsolutePath!="/"||address.Query.Length!=0||address.Fragment.Length!=0)throw new ArgumentException("La dirección del servidor no es válida.");
            if(String.IsNullOrEmpty(PackagePassword))throw new ArgumentException("Introduce la contraseña del paquete de acceso, no la de tu usuario.");
            using(var root=new X509Certificate2(Path.Combine(Package,"servidor-raiz.cer")))
            using(var existing=CertificateTrust.ExistingAuthority(Configuration))
            {
                string verified=existing!=null && existing.RawData.SequenceEqual(root.RawData)?CertificateTrust.Fingerprint(existing):VerifiedAuthorityHash;
                CertificateTrust.ValidateRoot(root,verified);
            }
            ValidateCertificate(this);
        }
        public static void ValidateCertificate(ClientPlan plan)
        {
            using(var root=new X509Certificate2(Path.Combine(plan.Package,"servidor-raiz.cer")))
            using(var cert=new X509Certificate2(File.ReadAllBytes(Path.Combine(plan.Package,"equipo.pfx")),plan.PackagePassword,X509KeyStorageFlags.EphemeralKeySet))
            {
                if(!cert.HasPrivateKey)throw new ArgumentException("El paquete no contiene la clave de acceso del equipo.");
                if(!root.Extensions.OfType<X509BasicConstraintsExtension>().Any(e=>e.CertificateAuthority))throw new ArgumentException("La autoridad del paquete no es válida.");
                using(var chain=new X509Chain())
                {
                    chain.ChainPolicy.ExtraStore.Add(root);chain.ChainPolicy.RevocationMode=X509RevocationMode.NoCheck;chain.ChainPolicy.VerificationFlags=X509VerificationFlags.AllowUnknownCertificateAuthority;chain.ChainPolicy.ApplicationPolicy.Add(new System.Security.Cryptography.Oid("1.3.6.1.5.5.7.3.2"));
                    if(!chain.Build(cert)||!chain.ChainElements[chain.ChainElements.Count-1].Certificate.RawData.SequenceEqual(root.RawData))throw new ArgumentException("El certificado de acceso no corresponde a esta autoridad o ha caducado.");
                }
            }
        }
    }
    public static class ClientInstaller
    {
        public static void Install(ClientPlan plan,string source,IProgress<string> progress,bool createShortcut=true)
        {
            plan.Validate();PayloadIntegrity.Validate(source,"cliente");
            if(Process.GetProcessesByName("AgendaClara").Any())throw new IOException("Cierra Nexo Centro antes de instalar o actualizar.");
            string backup=Path.Combine(Path.GetTempPath(),"AgendaClara-Instalacion-"+Guid.NewGuid().ToString("N"));
            Files.OwnFolder(backup,false);
            byte[] oldConfiguration=File.Exists(plan.Configuration)?File.ReadAllBytes(plan.Configuration):null;
            string shortcut=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory),"Nexo Centro.lnk");
            byte[] oldShortcut=createShortcut&&File.Exists(shortcut)?File.ReadAllBytes(shortcut):null;
            bool configurationChanged=false,shortcutAttempted=false,keepBackup=false;
            FileDeployment deployment=null;
            try
            {
                if(oldConfiguration!=null)File.WriteAllBytes(Path.Combine(backup,"conexion-anterior.xml"),oldConfiguration);
                if(oldShortcut!=null)File.WriteAllBytes(Path.Combine(backup,"acceso-anterior.lnk"),oldShortcut);
                // Una actualización comprueba primero el acceso existente. No reescribe la
                // conexión ni importa certificados para reparar sólo los archivos del programa.
                if(plan.UseExisting)CertificateTrust.Repair(plan.Configuration,progress);
                deployment=new FileDeployment(source,plan.Program,Path.Combine(backup,"programa"));
                progress.Report("Copiando y verificando Nexo Centro y sus bibliotecas…");deployment.Apply();
                if(!plan.UseExisting)
                {
                    using(var root=new X509Certificate2(Path.Combine(plan.Package,"servidor-raiz.cer")))
                    using(var existing=CertificateTrust.ExistingAuthority(plan.Configuration))
                        CertificateTrust.VerifyForApplication(root,existing!=null&&existing.RawData.SequenceEqual(root.RawData)?CertificateTrust.Fingerprint(existing):plan.VerifiedAuthorityHash,progress);
                    string thumbprint;
                    using(var certificate=new X509Certificate2(File.ReadAllBytes(Path.Combine(plan.Package,"equipo.pfx")),plan.PackagePassword,X509KeyStorageFlags.EphemeralKeySet))
                    {
                        thumbprint=certificate.Thumbprint;
                        using(var store=new X509Store(StoreName.My,StoreLocation.CurrentUser))
                        {
                            store.Open(OpenFlags.ReadWrite);
                            if(!store.Certificates.Cast<X509Certificate2>().Any(c=>c.RawData.SequenceEqual(certificate.RawData)&&c.HasPrivateKey))
                                using(var persisted=new X509Certificate2(File.ReadAllBytes(Path.Combine(plan.Package,"equipo.pfx")),plan.PackagePassword,X509KeyStorageFlags.UserKeySet|X509KeyStorageFlags.PersistKeySet))store.Add(persisted);
                        }
                    }
                    using(var store=new X509Store(StoreName.My,StoreLocation.CurrentUser)){store.Open(OpenFlags.ReadOnly);if(!store.Certificates.Find(X509FindType.FindByThumbprint,thumbprint,false).Cast<X509Certificate2>().Any(c=>c.HasPrivateKey))throw new IOException("Windows no ha guardado el certificado del puesto con su clave privada.");}
                    progress.Report("Guardando la conexión para tu perfil de Windows…");var document=new XmlDocument{XmlResolver=null};var element=document.CreateElement("SharedConfiguration");document.AppendChild(element);
                    var values=new Dictionary<string,string>{{"Shared","true"},{"AllowOffline",plan.Offline?"true":"false"},{"ServerUrl",plan.Server},{"UserName",plan.User.Trim()},{"ClientThumbprint",thumbprint},{"IndividualDatabase",""},{"AutomaticAccess",plan.AutomaticAccess?"true":"false"},{"ServerAuthority",Convert.ToBase64String(File.ReadAllBytes(Path.Combine(plan.Package,"servidor-raiz.cer")))}};
                    foreach(var value in values){var item=document.CreateElement(value.Key);item.InnerText=value.Value;element.AppendChild(item);}
                    Files.AtomicText(plan.Configuration,document.OuterXml);configurationChanged=true;
                }
                if(createShortcut){shortcutAttempted=true;Files.Shortcut(Path.Combine(plan.Program,"AgendaClara.exe"));}
                deployment.Commit();
                progress.Report(plan.UseExisting?"Programa actualizado; se conservan la conexión, el certificado, los usuarios y la agenda.":"Cliente instalado. La confianza en el servidor se limita a Nexo Centro; el acceso del puesto está preparado.");
            }
            catch(Exception error)
            {
                var failures=new List<Exception>();
                try{if(deployment!=null)deployment.Restore();}catch(Exception ex){failures.Add(ex);}
                try{if(configurationChanged)Files.RestoreBytes(plan.Configuration,oldConfiguration);}catch(Exception ex){failures.Add(ex);}
                try{if(shortcutAttempted)Files.RestoreBytes(shortcut,oldShortcut);}catch(Exception ex){failures.Add(ex);}
                if(failures.Count>0){keepBackup=true;failures.Insert(0,error);throw new IOException("La instalación no se ha completado y la reversión requiere revisión. Conserva el respaldo en "+backup,new AggregateException(failures));}
                throw;
            }
            finally{if(!keepBackup)Files.RemoveTemporary(backup);}
        }
    }
}
