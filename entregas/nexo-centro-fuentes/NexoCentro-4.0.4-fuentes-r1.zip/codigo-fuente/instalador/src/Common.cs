using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Reflection;
using System.Security.AccessControl;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Security.Principal;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Win32;

namespace AgendaClara.Setup
{
    public static class Files
    {
#if SETUP_TESTS
        internal static Assembly TestPayload=null;
#endif
        static Assembly PayloadAssembly
        {
            get
            {
#if SETUP_TESTS
                if(TestPayload!=null)return TestPayload;
#endif
                return Assembly.GetExecutingAssembly();
            }
        }
        public static string Full(string path) { return Path.GetFullPath(Environment.ExpandEnvironmentVariables(path.Trim())); }
        public static bool Inside(string path,string directory) { return Full(path).StartsWith(Full(directory).TrimEnd('\\')+"\\",StringComparison.OrdinalIgnoreCase)||Full(path).Equals(Full(directory),StringComparison.OrdinalIgnoreCase); }
        public static void OwnFolder(string path,bool service)
        {
            Directory.CreateDirectory(path);var security=new DirectorySecurity();security.SetAccessRuleProtection(true,false);
            var identities=new List<IdentityReference>{new SecurityIdentifier(WellKnownSidType.LocalSystemSid,null),new SecurityIdentifier(WellKnownSidType.BuiltinAdministratorsSid,null),WindowsIdentity.GetCurrent().User};
            foreach(var id in identities.Distinct())security.AddAccessRule(new FileSystemAccessRule(id,FileSystemRights.FullControl,InheritanceFlags.ContainerInherit|InheritanceFlags.ObjectInherit,PropagationFlags.None,AccessControlType.Allow));
            if(service)security.AddAccessRule(new FileSystemAccessRule(new NTAccount("NT SERVICE","AgendaClaraServidor"),FileSystemRights.Modify,InheritanceFlags.ContainerInherit|InheritanceFlags.ObjectInherit,PropagationFlags.None,AccessControlType.Allow));
            new DirectoryInfo(path).SetAccessControl(security);
        }
        public static string Extract(string resource)
        {
            string destination=Path.Combine(Path.GetTempPath(),"AgendaClara-Instalacion-"+Guid.NewGuid().ToString("N"));OwnFolder(destination,false);
            using(var stream=PayloadAssembly.GetManifestResourceStream(resource))
            {
                if(stream==null)throw new IOException("No se encuentra el programa incluido en el instalador.");
                using(var zip=new ZipArchive(stream,ZipArchiveMode.Read))foreach(var entry in zip.Entries)
                {
                    string target=Full(Path.Combine(destination,entry.FullName.Replace('/', '\\')));if(!Inside(target,destination))throw new IOException("El paquete contiene una ruta no válida.");
                    if(entry.FullName.EndsWith("/")){Directory.CreateDirectory(target);continue;}Directory.CreateDirectory(Path.GetDirectoryName(target));
                    using(var input=entry.Open())using(var output=File.Create(target))input.CopyTo(output);
                }
            }
            string role=resource=="AgendaClara.Setup.ClientPayload"?"cliente":resource=="AgendaClara.Setup.ServerPayload"?"servidor":"";
            if(role.Length==0)throw new IOException("Recurso de programa no reconocido.");
            PayloadIntegrity.Validate(Path.Combine(destination,role),role);
            return destination;
        }
        public static void RemoveTemporary(string path)
        {
            if(String.IsNullOrEmpty(path))return;string root=Full(Path.GetTempPath());string final=Full(path);
            if(!Inside(final,root)||!Path.GetFileName(final).StartsWith("AgendaClara-Instalacion-",StringComparison.Ordinal))return;
            try{Directory.Delete(final,true);}catch(IOException){}catch(UnauthorizedAccessException){}
        }
        public static void CopyTree(string source,string destination)
        {
            source=Full(source);destination=Full(destination);if(Inside(destination,source)||Inside(source,destination))throw new IOException("Las carpetas de origen y destino no pueden contenerse entre sí.");
            Directory.CreateDirectory(destination);
            foreach(string file in Directory.GetFiles(source,"*",SearchOption.AllDirectories))
            {string relative=file.Substring(source.Length).TrimStart('\\');string target=Path.Combine(destination,relative);Directory.CreateDirectory(Path.GetDirectoryName(target));File.Copy(file,target,true);}
        }
        public static void SafeProgramFolder(string path)
        {
            path=Full(path);var forbidden=new[]{Path.GetPathRoot(path),Environment.GetFolderPath(Environment.SpecialFolder.Windows),Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData)};
            if(forbidden.Any(f=>!String.IsNullOrEmpty(f)&&Full(f).TrimEnd('\\').Equals(path.TrimEnd('\\'),StringComparison.OrdinalIgnoreCase)))throw new ArgumentException("Elige una carpeta propia de Nexo Centro, no una carpeta general del sistema.");
        }
        public static string Hash(string path) { using(var sha=SHA256.Create())using(var file=File.OpenRead(path))return BitConverter.ToString(sha.ComputeHash(file)).Replace("-",""); }
        public static void AtomicText(string path,string text)
        {
            Directory.CreateDirectory(Path.GetDirectoryName(Full(path)));string temporary=path+"."+Guid.NewGuid().ToString("N")+".tmp";
            try{File.WriteAllText(temporary,text,new UTF8Encoding(true));if(File.Exists(path))File.Replace(temporary,path,null);else File.Move(temporary,path);}finally{if(File.Exists(temporary))File.Delete(temporary);}
        }
        public static void RestoreBytes(string path,byte[] previous)
        {
            if(previous==null){if(File.Exists(path))File.Delete(path);return;}
            Directory.CreateDirectory(Path.GetDirectoryName(Full(path)));
            string temporary=path+"."+Guid.NewGuid().ToString("N")+".tmp";
            try{File.WriteAllBytes(temporary,previous);if(File.Exists(path))File.Replace(temporary,path,null);else File.Move(temporary,path);}
            finally{if(File.Exists(temporary))File.Delete(temporary);}
        }
        public static void Shortcut(string executable)
        {
            Type type=Type.GetTypeFromProgID("WScript.Shell");dynamic shell=Activator.CreateInstance(type);dynamic shortcut=shell.CreateShortcut(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory),"Nexo Centro.lnk"));shortcut.TargetPath=executable;shortcut.WorkingDirectory=Path.GetDirectoryName(executable);shortcut.IconLocation=executable+",0";shortcut.Save();
        }
        public static string Quote(string argument)
        {
            if(argument==null)argument="";var text=new StringBuilder("\"");int slashes=0;
            foreach(char c in argument){if(c=='\\'){slashes++;continue;}if(c=='"'){text.Append('\\',slashes*2+1);text.Append(c);}else{text.Append('\\',slashes);text.Append(c);}slashes=0;}
            text.Append('\\',slashes*2);text.Append('"');return text.ToString();
        }
        public static string Run(string executable,IEnumerable<string> args,string password,int timeoutSeconds)
        {
            var info=new ProcessStartInfo(executable,String.Join(" ",args.Select(Quote))){UseShellExecute=false,CreateNoWindow=true,WindowStyle=ProcessWindowStyle.Hidden,RedirectStandardOutput=true,RedirectStandardError=true,RedirectStandardInput=true,WorkingDirectory=Path.GetDirectoryName(executable)};
            if(Path.GetFileName(executable).Equals("AgendaClara.Server.exe",StringComparison.OrdinalIgnoreCase)){info.StandardOutputEncoding=Encoding.UTF8;info.StandardErrorEncoding=Encoding.UTF8;}
            using(var process=Process.Start(info))
            {
                Task<string> output=process.StandardOutput.ReadToEndAsync(),error=process.StandardError.ReadToEndAsync();
                if(password!=null){byte[] input=Encoding.UTF8.GetBytes(password+"\n");process.StandardInput.BaseStream.Write(input,0,input.Length);process.StandardInput.BaseStream.Flush();Array.Clear(input,0,input.Length);}process.StandardInput.Close();
                if(!process.WaitForExit(timeoutSeconds*1000))throw new IOException("La operación tarda más de lo esperado. Comprueba su estado antes de repetirla; no se ha forzado el cierre del servidor.");
                Task.WaitAll(output,error);if(process.ExitCode!=0)throw new IOException((error.Result+"\n"+output.Result).Trim());return output.Result.Trim();
            }
        }
        public static void EmbeddedFile(string resource,string destination)
        {using(var input=PayloadAssembly.GetManifestResourceStream(resource)){if(input==null)throw new IOException("Falta el instalador del cliente incluido en el paquete.");using(var output=File.Create(destination))input.CopyTo(output);}}
    }
    public sealed class NetworkChoice
    {
        public string Label,Address,Network;
        public override string ToString(){return Label;}
        public static List<NetworkChoice> Detect()
        {
            var result=new List<NetworkChoice>();
            foreach(var adapter in NetworkInterface.GetAllNetworkInterfaces().Where(n=>n.OperationalStatus==OperationalStatus.Up&&n.NetworkInterfaceType!=NetworkInterfaceType.Loopback))
            {
                foreach(var ip in adapter.GetIPProperties().UnicastAddresses.Where(a=>a.Address.AddressFamily==AddressFamily.InterNetwork))
                {
                    if(ip.IPv4Mask==null)continue;byte[] address=ip.Address.GetAddressBytes(),mask=ip.IPv4Mask.GetAddressBytes();int bits=0;bool zero=false,valid=true;
                    foreach(byte b in mask)for(int i=7;i>=0;i--){bool one=(b&(1<<i))!=0;if(one&&zero)valid=false;if(one)bits++;else zero=true;}
                    if(!valid)continue;var net=new byte[4];for(int i=0;i<4;i++)net[i]=(byte)(address[i]&mask[i]);
                    string range=new IPAddress(net)+"/"+bits;try{Validate(range);}catch(ArgumentException){continue;}
                    result.Add(new NetworkChoice{Label=adapter.Name+" · "+ip.Address+" · "+range,Address=ip.Address.ToString(),Network=range});
                }
            }
            return result;
        }
        public static void Validate(string range)
        {
            string[] parts=range.Trim().Split('/');IPAddress ip;int bits;
            if(parts.Length!=2||!IPAddress.TryParse(parts[0],out ip)||ip.AddressFamily!=AddressFamily.InterNetwork||!Int32.TryParse(parts[1],out bits)||bits<0||bits>32)throw new ArgumentException("Selecciona una red local válida. Ejemplo: 192.168.1.0/24.");
            byte[] b=ip.GetAddressBytes();bool valid=b[0]==10&&bits>=8 || b[0]==172&&b[1]>=16&&b[1]<=31&&bits>=12 || b[0]==192&&b[1]==168&&bits>=16 || b[0]==127&&bits>=8;
            if(!valid)throw new ArgumentException("Solo se admite la red privada del centro; no se puede abrir el servicio a Internet.");
        }
        // Every private range, for schools whose puestos are spread over many subnets. Never includes Internet addresses.
        public const string AllPrivateRanges="10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16";
        // One or more subnets separated by commas, semicolons, spaces or lines.
        public static List<string> ParseList(string text)
        {
            var list=(text??"").Split(new[]{',',';',' ','\r','\n','\t'},StringSplitOptions.RemoveEmptyEntries).Select(s=>s.Trim()).Where(s=>s.Length>0).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
            if(list.Count==0)throw new ArgumentException("Indica al menos una red desde la que se conectarán los puestos. Ejemplo: 192.168.1.0/24.");
            if(list.Count>32)throw new ArgumentException("Se admiten como máximo 32 redes autorizadas.");
            foreach(string item in list)
            {
                try{Validate(item);}
                catch(ArgumentException ex){throw new ArgumentException("Revisa la red «"+item+"». "+ex.Message);}
            }
            return list;
        }
        public static bool InRange(IPAddress address,string range)
        {
            string[] parts=range.Split('/');IPAddress network;int bits;
            if(parts.Length!=2||!IPAddress.TryParse(parts[0],out network)||!Int32.TryParse(parts[1],out bits))return false;
            byte[] a=address.GetAddressBytes(),n=network.GetAddressBytes();if(a.Length!=n.Length)return false;
            for(int i=0;i<a.Length;i++){int mask=bits>=8?255:bits<=0?0:(255<<(8-bits))&255;if((a[i]&mask)!=(n[i]&mask))return false;bits-=8;}
            return true;
        }
        // Addresses the puestos may use for Jefatura: its computer name, its DNS name when it belongs to a domain, and its private IPs.
        public static List<string> HostSuggestions()
        {
            var result=new List<string>{Environment.MachineName};
            string domain=IPGlobalProperties.GetIPGlobalProperties().DomainName;
            if(!String.IsNullOrWhiteSpace(domain))result.Add(Environment.MachineName+"."+domain.Trim('.'));
            result.AddRange(Detect().Select(n=>n.Address));
            return result.Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        }
        // Redes que Windows clasifica como públicas; se informa sin cambiar su categoría.
        public static List<string> PublicNetworks()
        {
            var result=new List<string>();
            try
            {
                dynamic manager=Activator.CreateInstance(Type.GetTypeFromCLSID(new Guid("DCB00C01-570F-4A9B-8D69-199FDBA5723B")));
                foreach(dynamic network in manager.GetNetworks(1))if((int)network.GetCategory()==0)result.Add((string)network.GetName());
            }
            catch(Exception){} // Only used to warn; the installation does not depend on it.
            return result;
        }
        // Checks that do not block the installation but explain why puestos on other subnets might not connect.
        public static List<string> Warnings(string host,IEnumerable<string> networks)
        {
            var warnings=new List<string>();
            var own=Detect().Select(n=>IPAddress.Parse(n.Address)).ToList();
            var remote=networks.Where(r=>!own.Any(ip=>InRange(ip,r))).ToList();
            IPAddress fixedAddress;bool isAddress=IPAddress.TryParse(host,out fixedAddress);
            if(remote.Count>0 && !isAddress && host.IndexOf('.')<0)
                warnings.Add("Hay puestos en otras subredes ("+String.Join(", ",remote)+"). Desde otra subred el nombre «"+host+"» no se encuentra salvo que el DNS del centro lo conozca. Si no hay DNS interno, elige como dirección la IP fija de este ordenador.");
            if(isAddress && !own.Any(ip=>ip.Equals(fixedAddress)))
                warnings.Add("La dirección "+host+" no pertenece a este ordenador. Los puestos no encontrarán el servidor en ella.");
            if(remote.Count>0)
                warnings.Add("Los routers o cortafuegos que separan las subredes deben permitir conexiones TCP al puerto del servidor hacia este ordenador. Si la red la gestiona otra entidad, pídeselo.");
            foreach(string name in PublicNetworks())
                warnings.Add("Windows clasifica la red «"+name+"» como pública. La regla de Nexo Centro incluye ese perfil, limitada al programa, puerto y redes privadas autorizadas. No es necesario cambiar la categoría de la red.");
            return warnings;
        }
    }
    public abstract class Wizard:Form
    {
        protected readonly Panel body=new Panel{Dock=DockStyle.Fill,AutoScroll=true};
        protected readonly Label heading=new Label{AutoSize=true,Font=new Font("Segoe UI",21,FontStyle.Bold),ForeColor=Color.FromArgb(32,48,68)};
        protected readonly Label intro=new Label{AutoSize=true,MaximumSize=new Size(820,0),ForeColor=Color.FromArgb(99,114,135)};
        protected readonly Button back=new Button{Text="Atrás",Width=100},next=new Button{Text="Siguiente",Width=130},cancel=new Button{Text="Cancelar",Width=100};
        protected readonly List<Panel> pages=new List<Panel>();protected int index;protected bool busy,complete;
        protected readonly TextBox log=new TextBox{Multiline=true,ReadOnly=true,ScrollBars=ScrollBars.Vertical,Dock=DockStyle.Fill,BackColor=Color.White};
        protected Wizard(string title)
        {
            Text=title;Font=new Font("Segoe UI",10);var area=Screen.PrimaryScreen.WorkingArea;ClientSize=new Size(Math.Max(720,Math.Min(920,area.Width-60)),Math.Max(520,Math.Min(740,area.Height-70)));MinimumSize=new Size(720,520);StartPosition=FormStartPosition.CenterScreen;BackColor=Color.FromArgb(245,247,250);AutoScaleMode=AutoScaleMode.Dpi;
            try{using(var stream=Assembly.GetExecutingAssembly().GetManifestResourceStream("AgendaClara.Setup.Icon"))if(stream!=null)Icon=new Icon(stream);}catch{}
            intro.MaximumSize=new Size(Math.Max(580,ClientSize.Width-60),0);
            var header=new FlowLayoutPanel{Dock=DockStyle.Top,FlowDirection=FlowDirection.TopDown,Height=112,Padding=new Padding(24,16,24,0),WrapContents=false};header.Controls.Add(heading);header.Controls.Add(intro);
            var footer=new FlowLayoutPanel{Dock=DockStyle.Bottom,Height=66,Padding=new Padding(16,14,16,12),FlowDirection=FlowDirection.RightToLeft,BackColor=Color.White};
            foreach(var button in new[]{cancel,next,back}){button.Height=36;button.FlatStyle=FlatStyle.Flat;button.FlatAppearance.BorderColor=Color.FromArgb(220,227,235);button.BackColor=Color.White;footer.Controls.Add(button);}next.BackColor=Color.FromArgb(24,110,99);next.ForeColor=Color.White;
            body.Padding=new Padding(24,10,24,18);Controls.Add(body);Controls.Add(header);Controls.Add(footer);
            back.Click+=(s,e)=>ShowPage(index-1);cancel.Click+=(s,e)=>Close();next.Click+=async(s,e)=>await MoveNext();FormClosing+=(s,e)=>{if(busy)e.Cancel=true;};
        }
        protected TableLayoutPanel Page()
        {
            var page=new TableLayoutPanel{ColumnCount=2,AutoSize=true,Dock=DockStyle.Top,Padding=new Padding(0,4,8,16)};page.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,230));page.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));pages.Add(page);return page;
        }
        protected void Field(TableLayoutPanel page,string label,Control control)
        {
            int row=page.RowCount++;page.RowStyles.Add(new RowStyle(SizeType.AutoSize));var l=new Label{Text=label,AutoSize=true,MaximumSize=new Size(210,0),Margin=new Padding(0,8,14,14)};control.Dock=DockStyle.Fill;control.Margin=new Padding(0,4,0,14);control.AccessibleName=label;page.Controls.Add(l,0,row);page.Controls.Add(control,1,row);
        }
        protected void Note(TableLayoutPanel page,string text,bool bold=false)
        {
            var label=new Label{Text=text,AutoSize=true,MaximumSize=new Size(810,0),Margin=new Padding(0,8,0,16),ForeColor=Color.FromArgb(99,114,135),Font=new Font(Font,bold?FontStyle.Bold:FontStyle.Regular)};int row=page.RowCount++;page.Controls.Add(label,0,row);page.SetColumnSpan(label,2);
        }
        protected Panel Pick(TextBox box,Action browse)
        {var panel=new TableLayoutPanel{ColumnCount=2,AutoSize=true};panel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));panel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,98));box.Dock=DockStyle.Fill;var button=new Button{Text="Examinar…",Dock=DockStyle.Fill,Height=30};button.Click+=(s,e)=>browse();Action update=()=>button.Enabled=box.Enabled&&!box.ReadOnly;box.EnabledChanged+=(s,e)=>update();box.ReadOnlyChanged+=(s,e)=>update();update();panel.Controls.Add(box,0,0);panel.Controls.Add(button,1,0);return panel;}
        protected void Folder(TextBox box){using(var dialog=new FolderBrowserDialog{Description="Selecciona la carpeta",SelectedPath=Directory.Exists(box.Text)?box.Text:Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments)})if(dialog.ShowDialog(this)==DialogResult.OK)box.Text=dialog.SelectedPath;}
        protected void Open(TextBox box,string filter){using(var dialog=new OpenFileDialog{Filter=filter,CheckFileExists=true})if(dialog.ShowDialog(this)==DialogResult.OK)box.Text=dialog.FileName;}
        protected void Save(TextBox box,string filter){using(var dialog=new SaveFileDialog{Filter=filter,FileName=Path.GetFileName(box.Text),OverwritePrompt=true})if(dialog.ShowDialog(this)==DialogResult.OK)box.Text=dialog.FileName;}
        protected virtual void ShowPage(int value)
        {index=Math.Max(0,Math.Min(value,pages.Count-1));body.Controls.Clear();body.Controls.Add(pages[index]);back.Enabled=index>0&&!busy&&!complete;next.Text=complete?"Finalizar":index==pages.Count-1?"Instalar":"Siguiente";cancel.Visible=!complete;}
        protected abstract Task MoveNext();
        protected void Error(Exception ex){MessageBox.Show(this,ex.Message,"Nexo Centro · Instalación",MessageBoxButtons.OK,MessageBoxIcon.Warning);}
        protected async Task Work(Func<IProgress<string>,Task> action)
        {
            busy=true;back.Enabled=next.Enabled=cancel.Enabled=false;body.Controls.Clear();body.Controls.Add(log);heading.Text="Instalando Nexo Centro";intro.Text="Espera a que termine la preparación. No se abrirá ninguna consola.";
            var progress=new Progress<string>(text=>{log.AppendText(text+Environment.NewLine);log.SelectionStart=log.TextLength;log.ScrollToCaret();});
            try{await action(progress);complete=true;heading.Text="Instalación completada";intro.Text="Nexo Centro está preparada. Puedes cerrar este asistente.";next.Text="Finalizar";next.Enabled=true;cancel.Visible=false;}
            catch(Exception ex){log.AppendText("\r\nNo se ha completado la instalación.\r\n"+ex.Message);heading.Text="Hay que revisar un paso";intro.Text="Los datos existentes se conservan. Revisa el detalle antes de repetir la operación.";cancel.Text="Cerrar";cancel.Enabled=true;Error(ex);}
            finally{busy=false;}
        }
    }
    public static class Entry
    {
        [STAThread]public static void Main()
        {
            Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);
            using(var framework=Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full")){if(framework==null||Convert.ToInt32(framework.GetValue("Release",0))<528040){MessageBox.Show("Este asistente necesita .NET Framework 4.8, igual que Nexo Centro. Solicita su instalación al responsable del equipo.","Nexo Centro");return;}}
            if(!Environment.Is64BitOperatingSystem){MessageBox.Show("Nexo Centro necesita Windows de 64 bits.","Nexo Centro");return;}
            try
            {
#if SERVER_SETUP
            Application.Run(new ServerWizard());
#else
            Application.Run(new ClientWizard());
#endif
            }catch(Exception ex){MessageBox.Show(ex.Message,"Nexo Centro · Instalación",MessageBoxButtons.OK,MessageBoxIcon.Warning);}
        }
    }
}
