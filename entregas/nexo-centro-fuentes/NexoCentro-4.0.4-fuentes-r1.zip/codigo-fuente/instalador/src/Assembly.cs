using System.Reflection;
using System.Runtime.Versioning;
[assembly:AssemblyTitle("Asistente de instalación de Nexo Centro")]
[assembly:AssemblyProduct("Nexo Centro")]
[assembly:AssemblyVersion("1.2.5.0")]
[assembly:AssemblyFileVersion("1.2.5.0")]
[assembly:TargetFramework(".NETFramework,Version=v4.8")]


[assembly:AssemblyInformationalVersion("1.2.5-nexo-ui-r1")]
