# Continuidad del proyecto: Nexo Centro

## Base actual
Nexo Centro 4.0.4, interfaz r1; instaladores 1.2.5. Antes se denominaba AgendaClara. Este paquete contiene los fuentes del cliente, servidor, instaladores y pruebas. Los archivos principales están en `aplicacion/cliente`, `aplicacion/servidor` e `instalador`.

La interfaz nueva usa calendario despejado, lateral reducido y agenda diaria agrupada. Ocho baterías Windows completaron 552 comprobaciones sin fallos: https://github.com/vygos7/historia/actions/runs/42106266327 . El cliente nuevo mantiene la lógica de agenda, almacenamiento, contratos, TLS, autenticación, sincronización y fallback IPv4/IPv6 de la versión validada. Los nombres internos AgendaClara de ejecutables, namespaces, servicio, datos y registro se conservan para compatibilidad. No renombrarlos globalmente.

## Compilación y comprobación
Leer `INFORME-NEXO-CENTRO.md`, `INFORME-INSTALADOR-COMPLETO.md` y los scripts antes de modificar código. Usar SDK .NET 10; cliente e instaladores se dirigen a .NET Framework 4.8 y Windows x64. Para WPF y SQLite de Windows, las pruebas de ejecución requieren Windows. `aplicacion/pruebas-locales.csproj` incluye regresiones de datos e interfaz. Las pruebas de servicio sólo permiten Windows efímero hospedado por GitHub; no ejecutarlas sobre instalaciones de colegios. `instalador/ci/nexo-centro-ui.yml` documenta la validación de sólo lectura.

Los fuentes no incluyen bin/obj, dependencias restauradas, payloads compilados, datos de colegios, certificados privados o claves. Restaurar paquetes NuGet y compilar según los scripts. Las entregas binarias están en https://github.com/vygos7/historia/tree/entrega-diagnostico-agendaclara-20261105/entregas .

## Estado real y límites
La conexión r2 fue comprobada por el usuario entre Dirección y Jefatura, con creación y borrado sincronizados. La versión de interfaz nueva superó las pruebas Windows sintéticas; la validación física de esa interfaz en los puestos del colegio corresponde al usuario. No modificar ni reinstalar servidores reales para cambiar sólo la interfaz.

## Siguiente cuestión estudiada: Google Forms
Todavía NO está implementada la importación de respuestas. Habrá una respuesta por salida. Las seis preguntas encajan con `ActivityMemory`: valoración general (`Rating`), aspectos positivos (`Positives`), incidencias y dificultades (`Difficulties`), propuestas de mejora (`Improvements`), continuidad Sí/No (`Continuity`) y justificación (`Justification`). Valoración, continuidad y justificación son obligatorias.

Los docentes NO tienen acceso a la agenda. La propuesta pendiente de concretar es que Jefatura copie y envíe un enlace de Google Forms con un código de actividad prerrellenado. Ese código, la generación del enlace y la importación CSV aún no existen. Un campo prerrellenado de Google Forms puede ser editado: validar correspondencia de código, fecha y grupo, mostrar vista previa y confirmar antes de sobrescribir una memoria. No implementar cambios de arquitectura o formatos innecesarios.

El formulario aportado se llama «Evaluación/Memoria actividad complementaria» y pide curso/grupo, fecha y los seis apartados anteriores. El PDF fue compartido en la conversación; no está incluido en este ZIP.
