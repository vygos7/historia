param([Parameter(Mandatory=$true)][string]$Salida,[string]$DotNet='dotnet')
$ErrorActionPreference='Stop'
$env:DOTNET_CLI_TELEMETRY_OPTOUT='1'
$Salida=[IO.Path]::GetFullPath($Salida)
if(Test-Path -LiteralPath $Salida){throw 'Elige una carpeta de salida nueva; no se mezclan compilaciones.'}
New-Item -ItemType Directory -Path $Salida|Out-Null
$payloadRoot=Join-Path $Salida 'payload-root';$payload=Join-Path $Salida 'payload';$installers=Join-Path $Salida 'instaladores'
New-Item -ItemType Directory -Path $payload|Out-Null
& $DotNet publish (Join-Path $PSScriptRoot 'aplicacion/cliente/AgendaClara.Client.csproj') -c Release -p:EnableWindowsTargeting=true -o (Join-Path $payloadRoot 'cliente') --nologo
if($LASTEXITCODE-ne0){throw 'No se ha publicado el cliente.'}
& $DotNet publish (Join-Path $PSScriptRoot 'aplicacion/servidor/AgendaClara.Server.csproj') -c Release -r win-x64 --self-contained true -o (Join-Path $payloadRoot 'servidor') --nologo -m:2
if($LASTEXITCODE-ne0){throw 'No se ha publicado el servidor autocontenido.'}
Add-Type -AssemblyName System.IO.Compression.FileSystem
foreach($role in @('cliente','servidor')) {
 $root=Join-Path $payloadRoot $role
 $files=@(Get-ChildItem -LiteralPath $root -File -Recurse|Sort-Object FullName|ForEach-Object{
  $relative=$_.FullName.Substring($root.Length).TrimStart([IO.Path]::DirectorySeparatorChar).Replace('\','/')
  if($_.Name-match'(?i)(\.pfx$|\.dpapi$|\.key$|^server\.json$|^security\.json$|^TrabajoCompartido\.xml$|^agenda\.sqlite3$)'){throw "Datos o identidades en el payload: $relative"}
  [ordered]@{Path=$relative;Sha256=(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash}
 })
 $manifest=[ordered]@{Format=1;Role=$role;ClientRevision='4.0.4-http-r2';Files=$files}
 $manifest|ConvertTo-Json -Depth 6|Set-Content -LiteralPath (Join-Path $root 'manifiesto.json') -Encoding utf8
 $zip=[IO.Compression.ZipFile]::Open((Join-Path $payload ($role+'.zip')),[IO.Compression.ZipArchiveMode]::Create)
 try {
  Get-ChildItem -LiteralPath $root -File -Recurse|Sort-Object FullName|ForEach-Object{
   $relative=$_.FullName.Substring($root.Length).TrimStart([IO.Path]::DirectorySeparatorChar).Replace('\','/')
   [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$_.FullName,($role+'/'+$relative),[IO.Compression.CompressionLevel]::Optimal)|Out-Null
  }
 }finally{$zip.Dispose()}
}
& (Join-Path $PSScriptRoot 'instalador/Compilar.ps1') -Salida $installers -ClienteZip (Join-Path $payload 'cliente.zip') -ServidorZip (Join-Path $payload 'servidor.zip') -DotNet $DotNet
if($LASTEXITCODE-ne0){throw 'La compilación de instaladores no terminó correctamente.'}
Write-Host "Instaladores preparados en $installers. Falta completar la validación Windows de esta compilación."
