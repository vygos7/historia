# Comprobaciones de la edición 4.1.0 EXPERIMENTAL

- 47 pruebas de correspondencia de actividades, importación, duplicados, edición, recuperación tras corte, aislamiento, servicio y cliente HTTP firmado: correctas.
- 104 comprobaciones de regresión de datos originales: correctas. Interfaz WPF, mensajes del editor/informe WPF y permisos de sólo lectura de Windows no se ejecutan en esta batería Linux. No se usa ninguna agenda real.
- 32 comprobaciones originales de transporte HTTPS/mTLS y alternativa IPv6/IPv4: correctas, en loopback y con datos sintéticos.
- 36 comprobaciones originales de sesiones HTTP: correctas, en loopback y con datos sintéticos.
- 12 pruebas del script Google en simulador JavaScript: correctas.

**Total ejecutado localmente: 231 comprobaciones correctas, 0 fallos.** Los simuladores no son Google real y las pruebas .NET 10/Linux no son Windows/.NET Framework 4.8.

Cliente Windows/net48 y servidor Windows x64 autocontenido: compilados. Prueba nativa de interfaz y regresión WPF: compiladas, **no ejecutadas**. El asistente PowerShell supera el análisis sintáctico; no se ha ejecutado su preparación en Windows.

Se compararon los 107 archivos protegidos de la versión estable: **0 alterados**. Las rutas y huellas se conservan en PRUEBA-AISLAMIENTO.json. No se han modificado instalaciones del colegio, reglas de cortafuegos o servicios reales.

No se desplegó Apps Script, no se modificó el formulario real y no se configuraron credenciales de Google. **Pendiente**: prueba nativa en Windows y ciclo completo con una copia del formulario autorizada por su propietario, incluida recepción, guardado de memoria y duplicados. La edición se mantiene EXPERIMENTAL hasta completar esas pruebas.
