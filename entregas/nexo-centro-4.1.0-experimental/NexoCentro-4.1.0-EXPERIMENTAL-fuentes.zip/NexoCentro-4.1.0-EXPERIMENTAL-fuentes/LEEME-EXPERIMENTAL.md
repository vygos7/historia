# Nexo Centro 4.1.0 EXPERIMENTAL · Google Forms · r1

Esta es una copia de desarrollo independiente de Nexo Centro 4.0.4. La versión estable y sus entregas no se han actualizado ni sobrescrito. No sustituye al programa que ya funciona en el colegio.

## Qué incorpora

- Un único formulario de Google para todas las salidas.
- Enlace por actividad con código aleatorio, nombre, fecha efectiva y grupo prerrellenados.
- El docente recibe el enlace y no necesita acceso a Nexo Centro.
- Recogida periódica desde el servidor experimental, desactivada inicialmente.
- Una respuesta válida puede completar una memoria vacía de una actividad ya realizada.
- Duplicados, modificaciones, datos discordantes, agenda restaurada o memoria existente quedan pendientes de revisión. No se elige la actividad más cercana por fecha.
- Vista previa y confirmación para aplicar respuestas pendientes; segunda confirmación para sustituir una memoria.
- Importación CSV con el mismo control de correspondencia, siempre para revisión.

## Cómo probar sin tocar la instalación del centro

1. Extrae todo el paquete portátil `NexoCentro-4.1.0-EXPERIMENTAL.zip` en una carpeta nueva.
2. Abre `ABRIR-DEMO.cmd`. No ejecutes instaladores ni copies archivos a la carpeta de la versión estable.
3. La demo usa 188 eventos y preparativos ficticios, incluidos ejemplos anteriores y posteriores a noviembre de 2026. La actividad de prueba se llama **PRUEBA GOOGLE · Salida al cine**, fecha **05/11/2026**, grupo **3.º A**.
4. Abre Ajustes → Evaluaciones Google · EXPERIMENTAL. Puedes importar `EJEMPLO-respuesta-FICTICIA.csv` sin configurar Google.
5. La respuesta del CSV quedará pendiente porque su código es ficticio. Selecciona su fila, elige arriba la actividad **PRUEBA GOOGLE · Salida al cine** y pulsa Ver respuesta y aplicar con confirmación. Comprueba la vista previa antes de aceptar. Esto demuestra la revisión manual, no una conexión real con Google.
6. Cierra el panel y abre la ficha de esa salida: aparecerá la memoria ficticia.

La agenda demo y su configuración se guardan en `%LOCALAPPDATA%\NexoCentroExperimental\DemoGoogle`. Al abrirla otra vez se conservan tus pruebas. El archivo de ejemplo no se importa solo.

## Probar los enlaces del formulario

Sigue `Google/CONFIGURAR-GOOGLE.md`. Primero haz **una copia** del formulario real y trabaja con esa copia. El script facilita la plantilla que se pega en Ajustes → Evaluaciones Google.

El formulario del PDF tiene Curso o grupo, Fecha de la salida y las seis preguntas de memoria. El script comprueba esas preguntas y añade Código de la actividad y Nombre de la actividad. Google permite editar los datos prerrellenados; la aplicación comprueba su correspondencia antes de aplicar una respuesta.

No actives «Limitar a 1 respuesta» en el formulario general: impediría que un mismo docente evaluara distintas actividades. La aplicación controla los duplicados por actividad.

## Probar la recogida automática

La demo local permite enlaces y CSV. Para comprobar la recogida automática necesitas **el servidor experimental**, separado del servidor del colegio:

1. En Windows de 64 bits, abre `PREPARAR-SERVIDOR-EXPERIMENTAL.cmd` y sigue sus mensajes (ejecuta el script propio `Preparar-servidor-experimental.ps1`, sin cambiar la política permanente de PowerShell). Crea una contraseña nueva para esta prueba; no uses la del colegio. Si necesitas ayuda para ejecutar el script, revisa su contenido con el responsable técnico antes de continuar.
2. El asistente crea datos ficticios en `%LOCALAPPDATA%\NexoCentroExperimental\ServidorGoogle` y una conexión de prueba en `CompartidoGoogle`. Añade únicamente su certificado de puesto experimental al almacén personal del usuario, sin añadir raíces globales de confianza. No instala servicios ni modifica el cortafuegos.
3. Abre `INICIAR-SERVIDOR-EXPERIMENTAL.cmd` y deja su ventana abierta. Sólo escucha en `127.0.0.1:7444`; no acepta conexiones de otros ordenadores con esta preparación.
4. Abre `ABRIR-CLIENTE-COMPARTIDO.cmd`. Es otra agenda ficticia, distinta de la demo local. No se copian sus pruebas automáticamente de una a otra.
5. Sigue `Google/CONFIGURAR-GOOGLE.md` para autorizar el script en TU copia del formulario y configurar plantilla, URL `/exec` y secreto. No compartas el secreto ni lo pegues en una conversación.
6. Genera el enlace de la salida ficticia, ábrelo, comprueba código/nombre/fecha/grupo y envía una respuesta ficticia.
7. Con la recogida automática inicialmente desactivada, pulsa Consultar Google ahora. Al actualizar, la respuesta debe quedar pendiente para revisión.
8. Para probar la aplicación automática, utiliza otra actividad de prueba ya realizada y con memoria vacía. Activa la casilla automática, genera su enlace y responde. Consultar Google ahora adelanta la comprobación. El intervalo normal es de 15 minutos.
9. Comprueba que la memoria aparece y que repetir la consulta no la cambia ni duplica. Envía una segunda respuesta: debe quedar pendiente y conservar la primera memoria.
10. Cierra la ventana del cliente y detén el servidor experimental con Ctrl+C. La versión estable no necesita reiniciarse.

El servidor necesita salida HTTPS a Google. Si Google Workspace impide el despliegue de Apps Script para este uso, utiliza CSV; no se evita la política del centro. No publiques la hoja de respuestas.

## Separación y límites de esta entrega

- Perfiles, agenda, configuración, caché, nombre de inicio de Windows y mutex propios de la edición experimental.
- Inicio automático desactivado de entrada. No se cambian accesos directos, servicios, reglas ni puerto de la versión estable.
- La aplicación rechaza rutas de escritura ajenas a una carpeta NexoCentroExperimental.
- El cliente exige que el servidor responda como esta edición experimental antes de enviar credenciales o cambios. Conserva la validación TLS y el mecanismo IPv6/IPv4 ya existente.
- El servidor necesita una marca propia de edición; rechaza una carpeta existente que no tenga esa marca.
- Las memorias se incorporan mediante el guardado normal, con revisión, auditoría y control de concurrencia. Preparativos, notas, calendario, categorías y resto de datos se conservan.
- Los enlaces guardan identidad persistente y generación: una restauración o una actividad eliminada no reciben automáticamente respuestas antiguas.
- La configuración y el registro de Google se guardan en dos archivos separados. Las copias normales de la agenda conservan las memorias aplicadas, pero no incluyen aún esos dos archivos. Tras restaurar se revisan los enlaces. No se ha cambiado el formato de copia estable.
- Los antiguos scripts de creación de instaladores se han bloqueado en ESTA copia. Esta revisión se entrega portátil para pruebas, sin un instalador de actualización de producción.

## Validación

Consulta `Evidencias/RESULTADOS.md` en la entrega. Se ha compilado el cliente Windows/.NET Framework 4.8 y el servidor Windows x64 con runtime incluido. Las pruebas locales incluyen regresión de datos, transporte TLS, sesiones, correspondencia de respuestas y simuladores de Apps Script.

**No se ha ejecutado esta revisión en Windows ni contra una cuenta real de Google.** La prueba nativa de interfaz está preparada en `Pruebas-Windows`. No debe presentarse como actualización validada para producción. Primero hay que completar la comprobación de Windows y el ciclo con un formulario autorizado de prueba; después se prepara, por separado, la actualización que proceda.

## Código fuente y continuidad

La carpeta de desarrollo es `/workspace/nexo-centro-4.1.0-experimental`. El ZIP de fuentes contiene una copia completa para abrir en VS Code. No está publicada en GitHub por esta entrega. No hay contraseñas ni respuestas reales en los paquetes.

El código de integración está en `aplicacion/cliente/src/GoogleEvaluations.cs`, `GoogleEvaluationsWindow.cs`, `ExperimentalIsolation.cs`, `aplicacion/servidor/GoogleEvaluationsServer.cs` e `integracion-google/Code.gs`. La configuración de rutas y la comprobación de edición están en los Program.cs, SharedWork.cs y RemoteConnection.cs de esta copia.
