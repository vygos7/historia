﻿param([string]$DotNet='dotnet',[string]$Salida=(Join-Path $PSScriptRoot 'compilado-experimental'),[switch]$ValidarInterfazWindows)
$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$false
$Salida=[IO.Path]::GetFullPath($Salida)
if($Salida-notmatch'(?i)Nexo-?Centro[^/\\]*Experimental'){throw 'La salida debe estar dentro de una carpeta NexoCentroExperimental. No se escribe sobre la versión estable.'}
$marker=Join-Path $Salida 'nexo-compilacion-experimental.marker'
if((Test-Path -LiteralPath $Salida)-and-not(Test-Path -LiteralPath $marker)){throw 'La carpeta de salida ya existe y no pertenece a esta compilación experimental. Elige otra carpeta.'}
New-Item -ItemType Directory -Force -Path $Salida|Out-Null
[IO.File]::WriteAllText($marker,'NexoCentro-4.1.0-experimental-google-r1')
$logs=Join-Path $Salida 'Evidencias';New-Item -ItemType Directory -Force -Path $logs|Out-Null
function Invoke-Check([string]$Name,[scriptblock]$Action){
 & $Action *> (Join-Path $logs ($Name+'.txt'))
 if($LASTEXITCODE-ne0){throw "Ha fallado $Name; consulta Evidencias."}
 Write-Host "Correcto: $Name"
}
foreach($item in @(@('google','pruebas-google/Nexo.Google.Pruebas.csproj'),@('regresion-core','pruebas-core/Nexo.Core.Pruebas.csproj'))){
 $project=Join-Path $PSScriptRoot ('aplicacion/'+$item[1]);Invoke-Check $item[0] {& $DotNet run --project $project -c Release}
}
Invoke-Check 'compilar-cliente' {& $DotNet publish (Join-Path $PSScriptRoot 'aplicacion/cliente/AgendaClara.Client.csproj') -c Release -o (Join-Path $Salida 'Cliente')}
Invoke-Check 'compilar-servidor' {& $DotNet publish (Join-Path $PSScriptRoot 'aplicacion/servidor/AgendaClara.Server.csproj') -c Release -r win-x64 --self-contained true -o (Join-Path $Salida 'Servidor')}
Invoke-Check 'compilar-pruebas-windows' {& $DotNet build (Join-Path $PSScriptRoot 'aplicacion/pruebas-google-ui/Nexo.Google.UI.Pruebas.csproj') -c Release -o (Join-Path $Salida 'Pruebas-Windows')}
if(Get-Command node -ErrorAction SilentlyContinue){Invoke-Check 'script-google-simulado' {& node (Join-Path $PSScriptRoot 'integracion-google/Pruebas-script.cjs')}}
Copy-Item -Path (Join-Path $PSScriptRoot 'distribucion/*') -Destination $Salida -Recurse -Force
New-Item -ItemType Directory -Force -Path (Join-Path $Salida 'Google')|Out-Null
Copy-Item -Path (Join-Path $PSScriptRoot 'integracion-google/*') -Destination (Join-Path $Salida 'Google') -Recurse -Force
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'LEEME-EXPERIMENTAL.md') -Destination (Join-Path $Salida 'MANUAL-EXPERIMENTAL.md') -Force
if($ValidarInterfazWindows){
 if($env:OS-ne'Windows_NT'){throw 'La prueba de interfaz requiere Windows. No se marca como ejecutada desde Linux.'}
 Invoke-Check 'interfaz-windows' {& (Join-Path $Salida 'Pruebas-Windows/AgendaClara.Pruebas.exe')}
}
Write-Host "Entrega experimental: $Salida"
Write-Host 'No se ha creado ningún instalador de actualización. Falta la prueba real con una copia autorizada del formulario.'
