﻿param([string]$Salida=(Join-Path $PSScriptRoot 'compilado'),[string]$DotNet='dotnet',[switch]$Pruebas,[switch]$PruebasRed)
$ErrorActionPreference='Stop'
$env:DOTNET_CLI_TELEMETRY_OPTOUT='1'
& $DotNet publish (Join-Path $PSScriptRoot 'servidor\AgendaClara.Server.csproj') -c Release -r win-x64 --self-contained true -o (Join-Path $Salida 'servidor') --nologo
if($LASTEXITCODE-ne0){throw 'No se ha compilado el servidor.'}
& $DotNet publish (Join-Path $PSScriptRoot 'cliente\AgendaClara.Client.csproj') -c Release -o (Join-Path $Salida 'cliente') --nologo
if($LASTEXITCODE-ne0){throw 'No se ha compilado el cliente.'}
if($Pruebas){
    & $DotNet build (Join-Path $PSScriptRoot 'pruebas-locales.csproj') -c Release --nologo
    if($LASTEXITCODE-ne0){throw 'No se han compilado las pruebas locales.'}
    & (Join-Path $PSScriptRoot 'bin\Release\net48\AgendaClara.Pruebas.exe') (Join-Path $Salida 'verificacion\regresion')
    if($LASTEXITCODE-ne0){throw 'Hay fallos en las pruebas locales.'}
}
if($PruebasRed){
    Write-Host 'Las pruebas utilizan un servidor HTTPS local, puertos temporales y certificados de prueba que se retiran al terminar. No usan una agenda personal.'
    & $DotNet build (Join-Path $PSScriptRoot 'pruebas-interfaz-red\AgendaClara.SharedUI.Tests.csproj') -c Release --nologo
    if($LASTEXITCODE-ne0){throw 'No se han compilado las pruebas WPF de red.'}
    & $DotNet build (Join-Path $PSScriptRoot 'pruebas-red\AgendaClara.NetworkTests.csproj') -c Release --nologo
    if($LASTEXITCODE-ne0){throw 'No se han compilado las pruebas de red.'}
    $run=Join-Path $Salida ('verificacion\red-'+[Guid]::NewGuid().ToString('N'))
    & $DotNet (Join-Path $PSScriptRoot 'pruebas-red\bin\Release\net10.0\AgendaClara.NetworkTests.dll') $run (Join-Path $PSScriptRoot 'pruebas\fixtures\agenda-v4-sintetica.sqlite3') (Join-Path $PSScriptRoot 'pruebas-interfaz-red\bin\Release\net48\AgendaClara.SharedUI.Tests.exe')
    if($LASTEXITCODE-ne0){throw 'Hay fallos en las pruebas multiusuario.'}
}
Write-Host ('Compilación preparada en '+$Salida)
