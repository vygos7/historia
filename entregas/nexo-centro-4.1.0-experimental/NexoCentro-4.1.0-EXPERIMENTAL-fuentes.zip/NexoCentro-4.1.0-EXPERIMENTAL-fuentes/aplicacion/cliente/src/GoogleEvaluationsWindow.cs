using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Data;
using Microsoft.Win32;

namespace AgendaClara
{
    public sealed class GoogleEvaluationsWindow : Window
    {
        readonly Store store;readonly RemoteConnection remote;readonly long initialId;
        readonly ComboBox activity=new ComboBox{MinWidth=320},when=new ComboBox{MinWidth=130,Margin=new Thickness(8,0,0,0)};
        readonly TextBox template=new TextBox{MinHeight=60,AcceptsReturn=true,TextWrapping=TextWrapping.Wrap},endpoint=new TextBox(),minutes=new TextBox{Text="15",Width=70},link=new TextBox{IsReadOnly=true,TextWrapping=TextWrapping.Wrap,MinHeight=55};
        readonly PasswordBox secret=new PasswordBox();readonly CheckBox enabled=new CheckBox{Content="Importar automáticamente respuestas válidas en memorias vacías"};
        readonly TextBlock message=Theme.Text("",13,Theme.AccentDark);readonly DataGrid inbox=new DataGrid{AutoGenerateColumns=false,IsReadOnly=true,CanUserAddRows=false,MinHeight=150,MaxHeight=260};
        GoogleEvaluationSettings config=new GoogleEvaluationSettings();GoogleEvaluationManager local;string localSettings;bool busy;
        sealed class Choice {public AgendaEvent Event;public override string ToString(){return Format.Date(Event.Start)+" · "+Event.Title+" · "+Event.Options.Group;}}
        public GoogleEvaluationsWindow(Store store,long eventId=0)
        {
            this.store=store;initialId=eventId;remote=store.IsShared?SharedRuntime.Connection:null;
            Theme.ApplyWindow(this);Title="Google Forms · EXPERIMENTAL 4.1.0";Width=1050;Height=820;MinWidth=780;MinHeight=560;WindowStartupLocation=WindowStartupLocation.CenterOwner;
            var body=new StackPanel{Margin=new Thickness(22)};
            body.Children.Add(Theme.Text("Evaluaciones de salidas · Google Forms",24,Theme.Ink,true));
            body.Children.Add(Theme.Notice("VERSIÓN EXPERIMENTAL. Usa únicamente datos de prueba. Un solo formulario sirve para todas las actividades. No se vinculan respuestas por proximidad de fechas.",Theme.WarningSoft,Theme.Warning));
            if(store.IsShared&&(remote==null||!remote.IsAdmin)){body.Children.Add(Theme.Text("Esta gestión requiere un usuario administrador de Nexo Centro experimental.",14,Theme.Warning));Content=body;return;}
            if(!store.IsShared)
            {
                localSettings=Path.Combine(Path.GetDirectoryName(store.DatabasePath),"google-formulario.xml");
                if(File.Exists(localSettings))config=XmlData.Read<GoogleEvaluationSettings>(File.ReadAllText(localSettings));
                local=new GoogleEvaluationManager(()=>store,new object(),Path.Combine(Path.GetDirectoryName(store.DatabasePath),"google-evaluations.xml"),SharedConfiguration.Atomic,()=>DateTime.UtcNow,c=>store.Apply(c,GoogleEvaluationManager.Actor,"local-experimental"));
                body.Children.Add(Theme.Text("Modo local: permite enlaces e importación CSV. La recogida automática se realiza en el servidor experimental.",13,Theme.Muted));
            }
            var settings=new StackPanel();Field(settings,"Plantilla prerrellenada exportada por el script de Google",template);
            Field(settings,"Despliegue de Apps Script: URL HTTPS terminada en /exec",endpoint);Field(settings,"Secreto de integración (vacío = conservar el guardado en el servidor)",secret);
            settings.Children.Add(enabled);Field(settings,"Comprobar cada cuántos minutos (5 a 1440)",minutes);
            settings.Children.Add(Theme.Button("Guardar configuración",async()=>await Run(SaveSettings)));
            body.Children.Add(new Expander{Header="Configuración del formulario único",Content=settings,IsExpanded=true,Margin=new Thickness(0,12,0,14)});
            endpoint.IsEnabled=secret.IsEnabled=enabled.IsEnabled=remote!=null;
            body.Children.Add(Theme.Text("1. Selecciona la actividad ya guardada",17,Theme.Ink,true));
            var selector=new WrapPanel();selector.Children.Add(activity);selector.Children.Add(when);body.Children.Add(selector);
            activity.SelectionChanged+=(s,e)=>{var c=activity.SelectedItem as Choice;when.ItemsSource=c==null?new string[0]:Planning.All(c.Event,store.Calendar).Select(o=>Format.Date(o.Date)).ToArray();when.SelectedIndex=0;};
            body.Children.Add(Theme.Text("Nombre, grupo y fecha se toman de la ficha guardada. La memoria es común a todas las fechas de una actividad repetida. Guarda y cierra la ficha antes de generar el enlace.",12,Theme.Muted));
            body.Children.Add(Theme.Button("Generar enlace de evaluación",async()=>await Run(Generate)));
            body.Children.Add(link);body.Children.Add(Theme.Button("Copiar enlace",()=>{if(link.Text.Length>0){Clipboard.SetText(link.Text);message.Text="Enlace copiado. Envíalo al docente por el medio habitual.";}}));
            body.Children.Add(Theme.Text("2. Respuestas recibidas y revisión",17,Theme.Ink,true));
            var tools=new WrapPanel();tools.Children.Add(Theme.Button("Actualizar",async()=>await Run(Refresh)));
            tools.Children.Add(Theme.Button("Consultar Google ahora",async()=>await Run(async()=>{if(remote==null)throw new ArgumentException("La consulta automática sólo funciona en el servidor experimental.");await remote.Admin<GoogleEvaluationStatus>("POST","api/admin/google-evaluations/poll");message.Text="Consulta programada. Pulsa Actualizar dentro de unos segundos.";})));
            tools.Children.Add(Theme.Button("Importar CSV de respuestas…",async()=>await Run(ImportCsv)));body.Children.Add(tools);
            foreach(var column in new[]{new[]{"Estado","Status"},new[]{"Actividad","Response.Title"},new[]{"Fecha","Response.Date"},new[]{"Grupo","Response.Group"},new[]{"Motivo","Reason"}})inbox.Columns.Add(new DataGridTextColumn{Header=column[0],Binding=new Binding(column[1]),Width=new DataGridLength(column[1]=="Reason"?2:1,DataGridLengthUnitType.Star)});
            inbox.SelectionChanged+=(s,e)=>{var selected=inbox.SelectedItem as GoogleEvaluationItem;if(selected!=null&&selected.EventId>0){var choices=activity.ItemsSource as List<Choice>;var target=choices==null?null:choices.FirstOrDefault(c=>c.Event.Id==selected.EventId);if(target!=null)activity.SelectedItem=target;}};
            body.Children.Add(inbox);body.Children.Add(Theme.Button("Ver respuesta y aplicar con confirmación…",async()=>await Run(ApplySelected)));
            body.Children.Add(message);body.Children.Add(Theme.Button("Cerrar",Close));
            Content=new ScrollViewer{Content=body,VerticalScrollBarVisibility=ScrollBarVisibility.Auto,HorizontalScrollBarVisibility=ScrollBarVisibility.Disabled};
            Loaded+=async(s,e)=>await Run(async()=>{await Refresh();FillSettings();});
        }
        static void Field(Panel p,string label,Control c){p.Children.Add(Theme.Label(label));p.Children.Add(c);c.Margin=new Thickness(0,0,0,9);AutomationProperties.SetName(c,label);}
        async Task Run(Func<Task> action){if(busy)return;busy=true;try{await action();}catch(Exception ex){message.Text="No se ha completado: "+ex.Message;}finally{busy=false;}}
        void FillSettings(){template.Text=config.PrefillTemplate;endpoint.Text=config.Endpoint;minutes.Text=config.PollMinutes.ToString();enabled.IsChecked=config.Enabled;secret.Clear();}
        async Task Refresh()
        {
            if(remote!=null){var status=await remote.Admin<GoogleEvaluationStatus>("GET","api/admin/google-evaluations");config=status.Settings;inbox.ItemsSource=status.Items;message.Text=status.LastResult;await remote.SynchronizeAsync();}
            else inbox.ItemsSource=local.Items();
            long selected=activity.SelectedItem is Choice?((Choice)activity.SelectedItem).Event.Id:initialId;
            var choices=store.AllEvents().OrderByDescending(e=>e.Start).Select(e=>new Choice{Event=e}).ToList();activity.ItemsSource=choices;activity.SelectedItem=choices.FirstOrDefault(c=>c.Event.Id==selected)??choices.FirstOrDefault();
        }
        async Task SaveSettings()
        {
            int interval;if(!Int32.TryParse(minutes.Text,out interval)||interval<5||interval>1440)throw new ArgumentException("Revisa el intervalo de consulta.");
            GoogleEvaluationRules.ValidateTemplate(template.Text.Trim());
            var settings=new GoogleEvaluationSettings{PrefillTemplate=template.Text.Trim(),Endpoint=endpoint.Text.Trim(),PollMinutes=interval,Enabled=remote!=null&&enabled.IsChecked==true,Secret=secret.Password};
            if(remote!=null){var status=await remote.Admin<GoogleEvaluationStatus>("POST","api/admin/google-evaluations/settings",settings);config=status.Settings;}
            else{settings.Endpoint="";settings.Secret="";SharedConfiguration.Atomic(localSettings,Encoding.UTF8.GetBytes(XmlData.Write(settings)));config=settings;}
            secret.Clear();message.Text="Configuración experimental guardada.";
        }
        async Task Generate()
        {
            var c=activity.SelectedItem as Choice;if(c==null||when.SelectedItem==null)throw new ArgumentException("Selecciona una actividad y fecha guardadas.");
            var request=new GoogleLinkRequest{EventId=c.Event.Id,Date=(string)when.SelectedItem};
            var result=remote==null?local.Issue(request,config.PrefillTemplate):await remote.Admin<GoogleEvaluationLink>("POST","api/admin/google-evaluations/link",request);
            link.Text=result.Url;message.Text="Código: "+result.Code+" · "+result.Title+" · "+result.Group+". El enlace abre el formulario único con esos datos.";await Refresh();
        }
        async Task ImportCsv()
        {
            var dialog=new OpenFileDialog{Filter="Respuestas CSV|*.csv|Todos los archivos|*.*"};if(dialog.ShowDialog(this)!=true)return;
            if(new FileInfo(dialog.FileName).Length>4000000)throw new ArgumentException("El CSV debe ocupar menos de 4 MB.");
            string text=File.ReadAllText(dialog.FileName);
            if(remote==null){var rows=GoogleEvaluationCsvReader.Parse(text);if(rows.Count>500)throw new ArgumentException("Máximo 500 respuestas por archivo.");foreach(var row in rows)local.Ingest(row,false);}
            else await remote.Admin<GoogleEvaluationStatus>("POST","api/admin/google-evaluations/csv",new GoogleEvaluationCsv{Text=text});
            await Refresh();message.Text="CSV cargado para revisión. No se ha sobrescrito ninguna memoria.";
        }
        async Task ApplySelected()
        {
            var item=inbox.SelectedItem as GoogleEvaluationItem;var choice=activity.SelectedItem as Choice;
            if(item==null)throw new ArgumentException("Selecciona una respuesta.");if(item.Status=="Aplicada"){message.Text="Esa respuesta ya se incorporó.";return;}
            var e=store.Find(choice==null?item.EventId:choice.Event.Id);if(e==null)throw new ArgumentException("Selecciona la actividad de destino en la lista superior.");
            var m=item.Response.Memory??new ActivityMemory();string preview="ACTIVIDAD DE DESTINO: "+e.Title+" · "+Format.Date(e.Start)+" · "+e.Options.Group+"\n\nDATOS DE LA RESPUESTA: "+item.Response.Title+" · "+item.Response.Date+" · "+item.Response.Group+"\n\nValoración: "+m.Rating+"\n\nPositivos: "+m.Positives+"\n\nDificultades: "+m.Difficulties+"\n\nMejoras: "+m.Improvements+"\n\nContinuidad: "+m.Continuity+"\n\nJustificación: "+m.Justification+"\n\nMotivo de revisión: "+item.Reason;
            if(!Dialogs.Confirm(this,"Revisar evaluación de Google",preview,"Confirmar correspondencia y aplicar"))return;
            bool overwrite=e.Options.Memory.HasContent;if(overwrite&&!Dialogs.Confirm(this,"Sustituir memoria existente","Esta actividad ya tiene una memoria. La respuesta seleccionada la sustituirá completa. Comprueba que la actividad y respuesta son correctas.","Sustituir memoria"))return;
            var request=new GoogleEvaluationApply{ItemId=item.Id,EventId=e.Id,ExpectedVersion=e.Version,ConfirmAssignment=true,ConfirmOverwrite=overwrite};
            if(remote==null)local.Apply(request);else await remote.Admin<GoogleEvaluationItem>("POST","api/admin/google-evaluations/apply",request);
            await Refresh();message.Text="Memoria incorporada. Cierra y vuelve a abrir cualquier ficha que estuviera abierta antes de la importación.";
        }
    }
}
