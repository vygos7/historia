﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;

namespace AgendaClara
{
    // Creates an activity, or edits a whole activity or a single date of it.
    public sealed class EventEditor : Window
    {
        internal static Func<Window, string, string, string, bool> Confirm = Dialogs.Confirm;

        sealed class FormState { public string Title, Notes, Location, StartTime, EndTime; public bool AllDay; }

        static readonly int[] reminderDays = { -1, 0, 1, 2, 3, 7, 14, 30 };
        static readonly string[] reminderLabels = { "Sin aviso", "El mismo día", "1 día antes", "2 días antes", "3 días antes", "1 semana antes (7 días)", "2 semanas antes (14 días)", "1 mes antes (30 días)" };

        readonly Store store;
        readonly ActivityPanel activityPanel;
        readonly TextBlock continuityAlert = Theme.Text("", 13, Theme.Warning, true);
        readonly AgendaEvent existing, draft;
        readonly Occurrence occurrence;
        readonly int total;
        bool loadingForm, saving, oneScope, uncertain;
        FormState wholeState, oneState;

        readonly RadioButton scopeAll = new RadioButton { GroupName = "alcance" }, scopeOne = new RadioButton { GroupName = "alcance" };
        readonly TextBox title = new TextBox(), notes = new TextBox(), location = new TextBox(), responsible = new TextBox(), group = new TextBox();
        readonly TextBox startTime = new TextBox(), endTime = new TextBox(), specific = new TextBox(), excluded = new TextBox();
        readonly ComboBox category = new ComboBox { IsEditable = true }, reminder = new ComboBox();
        readonly DatePicker start = new DatePicker(), end = new DatePicker(), moveTo = new DatePicker();
        readonly CheckBox allDay = new CheckBox { Content = "Todo el día" };
        readonly CheckBox nonSchool = new CheckBox { Content = "Permitir excepcionalmente días no lectivos (fines de semana, festivos o vacaciones)" };
        readonly CheckBox moveNonSchool = new CheckBox { Content = "Permitir que la nueva fecha sea un día no lectivo" };
        readonly RadioButton modeInterval = new RadioButton { GroupName = "modo", Content = "Todos los días lectivos entre la fecha de inicio y la de finalización" };
        readonly RadioButton modeWeekdays = new RadioButton { GroupName = "modo", Content = "Solo estos días de la semana dentro del intervalo:" };
        readonly RadioButton modeDates = new RadioButton { GroupName = "modo", Content = "Solo estas fechas concretas:" };
        readonly List<CheckBox> weekdays = new List<CheckBox>();
        readonly TextBlock preview = Theme.Text("", 12.5, Theme.Muted), error = Theme.Text("", 13, Theme.Danger, true);
        readonly Border swatch = Theme.Swatch("#66747B", 18);
        readonly Expander repetition = new Expander { Header = "Repetición, fechas concretas y excepciones" };
        readonly StackPanel moveSection = new StackPanel(), weekdayRow = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(26, 0, 0, 4) };
        readonly Grid datesRow, timesRow;
        readonly Button save, cancel, deleteOne, deleteAll;
        readonly List<FrameworkElement> wholeOnly = new List<FrameworkElement>();

        public bool Changed { get; private set; }
        public string Outcome { get; private set; }

        public EventEditor(Store store, AgendaEvent existing, Occurrence occurrence, DateTime date)
        {
            Theme.ApplyWindow(this);
            this.store = store; this.existing = existing;
            this.occurrence = existing != null ? occurrence : null;
            draft = existing == null ? new AgendaEvent { Start = date.Date, End = date.Date } : existing.Copy();
            if (existing == null) store.StampNew(draft);
            total = existing == null ? 0 : Planning.All(existing, store.Calendar).Count;
            bool offerOne = this.occurrence != null && total > 1;
            Outcome = "";

            Title = existing == null ? "Nueva actividad" : "Actividad · " + existing.Title;
            var area = SystemParameters.WorkArea;
            Width = 700; MinWidth = 560; MinHeight = 460;
            Height = Math.Max(MinHeight, Math.Min(900, area.Height - 40));
            WindowStartupLocation = WindowStartupLocation.CenterOwner; ShowInTaskbar = false;

            var root = new Grid();
            root.RowDefinitions.Add(new RowDefinition());
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            var fields = new StackPanel { Margin = new Thickness(26, 20, 26, 12) };
            root.Children.Add(new ScrollViewer { Content = fields, VerticalScrollBarVisibility = ScrollBarVisibility.Auto, HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled });

            fields.Children.Add(Theme.Text(existing == null ? "Nueva actividad" : "Editar actividad", 24, Theme.Ink, true));
            string intro = existing == null
                ? "Basta con el título y la fecha. Se aplica el calendario escolar: fines de semana, festivos y vacaciones quedan excluidos salvo excepción expresa."
                : this.occurrence != null ? "Abierta desde el " + Format.LongDate(this.occurrence.Date).ToLower(Format.Spanish) + "." : "Abierta desde la búsqueda: los cambios afectan a toda la actividad.";
            var introText = Theme.Text(intro, 12.5, Theme.Muted); introText.Margin = new Thickness(0, 4, 0, 14);
            fields.Children.Add(introText);

            if (offerOne)
            {
                var scope = new StackPanel();
                scope.Children.Add(Theme.Text("¿Qué quieres cambiar?", 13, Theme.Ink, true));
                scopeAll.Content = "Toda la actividad (" + Format.Count(total, "fecha", "fechas") + ")";
                scopeOne.Content = "Solo el " + Format.LongDate(this.occurrence.Date).ToLower(Format.Spanish) + (this.occurrence.Moved ? " (trasladada desde el " + Format.Date(this.occurrence.OriginalDate) + ")" : "") + ": datos, horario o traslado a otro día";
                AutomationProperties.SetName(scopeAll, "Toda la actividad"); AutomationProperties.SetName(scopeOne, "Solo esta fecha");
                scope.Children.Add(scopeAll); scope.Children.Add(scopeOne);
                fields.Children.Add(new Border { Background = Theme.Pale, CornerRadius = new CornerRadius(8), Padding = new Thickness(12, 8, 12, 8), Margin = new Thickness(0, 0, 0, 14), Child = scope });
            }

            fields.Children.Add(continuityAlert);
            Field(fields, "Título *", title);
            var categoryRow = new DockPanel();
            swatch.Margin = new Thickness(0, 0, 8, 0);
            DockPanel.SetDock(swatch, Dock.Left); categoryRow.Children.Add(swatch); categoryRow.Children.Add(category);
            var categoryField = Field(fields, "Categoría (elige una o escribe una nueva)", categoryRow);
            AutomationProperties.SetName(category, "Categoría");
            wholeOnly.Add(categoryField);

            datesRow = Pair(Field(null, "Fecha de inicio", start), Field(null, "Fecha de finalización", end));
            fields.Children.Add(datesRow); wholeOnly.Add(datesRow);
            AutomationProperties.SetName(start, "Fecha de inicio"); AutomationProperties.SetName(end, "Fecha de finalización");

            moveSection.Children.Add(Field(null, "Fecha de esta ocurrencia (cámbiala para trasladarla a otro día)", moveTo));
            moveSection.Children.Add(moveNonSchool);
            moveSection.Margin = new Thickness(0, 0, 0, 10);
            AutomationProperties.SetName(moveTo, "Trasladar a");
            fields.Children.Add(moveSection);

            allDay.Margin = new Thickness(0, 0, 0, 8);
            fields.Children.Add(allDay);
            timesRow = Pair(Field(null, "Hora de inicio (24 h, p. ej. 09:30)", startTime), Field(null, "Hora de finalización (24 h)", endTime));
            fields.Children.Add(timesRow);

            preview.Margin = new Thickness(0, 0, 0, 12);
            fields.Children.Add(preview);

            var people = Pair(Field(null, "Lugar (opcional)", location), Field(null, "Responsable (opcional)", responsible));
            fields.Children.Add(people);
            var groupField = Field(fields, "Grupos o cursos participantes (opcional)", group);
            wholeOnly.Add(groupField); wholeOnly.Add((FrameworkElement)responsible.Parent);
            notes.AcceptsReturn = true; notes.TextWrapping = TextWrapping.Wrap; notes.Height = 78; notes.VerticalContentAlignment = VerticalAlignment.Top; notes.VerticalScrollBarVisibility = ScrollBarVisibility.Auto;
            Field(fields, "Descripción o notas (opcional)", notes);
            var reminderField = Field(fields, "Aviso de proximidad (antelación en días naturales)", reminder);
            wholeOnly.Add(reminderField);

            var rep = new StackPanel { Margin = new Thickness(4, 8, 0, 4) };
            rep.Children.Add(modeInterval); rep.Children.Add(modeWeekdays);
            string[] names = { "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom" };
            for (int i = 0; i < 7; i++)
            {
                var c = new CheckBox { Content = names[i], Margin = new Thickness(0, 2, 12, 2) };
                AutomationProperties.SetName(c, "Repetir " + names[i]);
                weekdays.Add(c); weekdayRow.Children.Add(c);
            }
            rep.Children.Add(new ScrollViewer { Content = weekdayRow, HorizontalScrollBarVisibility = ScrollBarVisibility.Auto, VerticalScrollBarVisibility = ScrollBarVisibility.Disabled });
            rep.Children.Add(modeDates);
            specific.Margin = new Thickness(26, 0, 0, 2);
            AutomationProperties.SetName(specific, "Solo estas fechas");
            rep.Children.Add(specific);
            var specificHint = Theme.Text("Ejemplo: 10/05/2027; 12/05/2027. Las fechas de inicio y finalización se ajustan a la primera y la última.", 11.5, Theme.Muted); specificHint.Margin = new Thickness(26, 0, 0, 10);
            rep.Children.Add(specificHint);
            rep.Children.Add(Theme.Label("Excluir estas fechas (opcional, separadas por punto y coma)"));
            AutomationProperties.SetName(excluded, "Excluir estas fechas");
            rep.Children.Add(excluded);
            nonSchool.Margin = new Thickness(0, 12, 0, 2);
            rep.Children.Add(nonSchool);
            rep.Children.Add(Theme.Text("Desactivada por defecto. Márcala solo para un acto que se celebre conscientemente en un día no lectivo; con ella, el intervalo también incluye esos días.", 11.5, Theme.Muted));
            repetition.Content = rep; repetition.Margin = new Thickness(0, 4, 0, 6);
            fields.Children.Add(repetition); wholeOnly.Add(repetition);

            activityPanel = new ActivityPanel(store, draft, title, start, continuityAlert);
            fields.Children.Add(activityPanel); wholeOnly.Add(activityPanel);

            // Bottom bar: always visible, never scrolled away.
            var bottom = new Grid { Margin = new Thickness(26, 10, 26, 16) };
            bottom.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            bottom.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            bottom.ColumnDefinitions.Add(new ColumnDefinition());
            bottom.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            error.Margin = new Thickness(0, 0, 0, 8); Grid.SetColumnSpan(error, 2);
            AutomationProperties.SetName(error, "Mensaje de error");
            bottom.Children.Add(error);
            var left = new WrapPanel { VerticalAlignment = VerticalAlignment.Center };
            deleteOne = Theme.Button("Eliminar solo esta fecha", DeleteOne, "DangerButton");
            deleteAll = Theme.Button(total > 1 ? "Eliminar toda la actividad" : "Eliminar actividad", DeleteAll, "DangerButton");
            deleteOne.Margin = deleteAll.Margin = new Thickness(0, 0, 8, 4);
            if (offerOne) left.Children.Add(deleteOne);
            if (existing != null) left.Children.Add(deleteAll);
            Grid.SetRow(left, 1); bottom.Children.Add(left);
            var right = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Top };
            cancel = Theme.Button("Cancelar", Close); cancel.Margin = new Thickness(8, 0, 8, 4);
            save = Theme.Button("Guardar", Save, "Primary"); save.Margin = new Thickness(0, 0, 0, 4); save.MinWidth = 100;
            right.Children.Add(cancel); right.Children.Add(save);
            Grid.SetRow(right, 1); Grid.SetColumn(right, 1); bottom.Children.Add(right);
            var bottomBox = new Border { BorderBrush = Theme.Line, BorderThickness = new Thickness(0, 1, 0, 0), Background = Theme.Surface, Child = bottom };
            Grid.SetRow(bottomBox, 1); root.Children.Add(bottomBox);
            Content = root;

            LoadWhole();
            wholeState = Capture();
            if (offerOne)
            {
                oneState = new FormState
                {
                    Title = this.occurrence.View.Title, Notes = this.occurrence.View.Notes, Location = this.occurrence.View.Options.Location,
                    AllDay = this.occurrence.View.AllDay, StartTime = AgendaEvent.Clock(this.occurrence.View.StartMinute), EndTime = AgendaEvent.Clock(this.occurrence.View.EndMinute)
                };
                moveTo.SelectedDate = this.occurrence.Date;
                moveNonSchool.IsChecked = this.occurrence.Change != null && this.occurrence.Change.AllowNonSchool;
                scopeAll.IsChecked = true;
                scopeAll.Checked += (s, e) => SetScope(false);
                scopeOne.Checked += (s, e) => SetScope(true);
            }
            SetScope(false);

            Action refresh = UpdatePreview;
            start.SelectedDateChanged += (s, e) => { if (!loadingForm && start.SelectedDate.HasValue && (!end.SelectedDate.HasValue || end.SelectedDate < start.SelectedDate)) end.SelectedDate = start.SelectedDate; refresh(); };
            end.SelectedDateChanged += (s, e) => refresh();
            foreach (var picker in new[] { start, end, moveTo })
                picker.DateValidationError += (s, e) => { error.Text = "«" + e.Text + "» no es una fecha válida. Escríbela como DD/MM/AAAA o elígela en el calendario."; e.ThrowException = false; };
            allDay.Checked += (s, e) => ToggleTimes(); allDay.Unchecked += (s, e) => ToggleTimes();
            foreach (var r in new[] { modeInterval, modeWeekdays, modeDates }) r.Checked += (s, e) => { ToggleMode(); refresh(); };
            foreach (var c in weekdays.Concat(new[] { nonSchool })) { c.Checked += (s, e) => refresh(); c.Unchecked += (s, e) => refresh(); }
            specific.TextChanged += (s, e) => refresh(); excluded.TextChanged += (s, e) => refresh();
            foreach (var box in new[] { title, startTime, endTime }) box.TextChanged += (s, e) => { if (!loadingForm) error.Text = ""; };
            category.AddHandler(TextBoxBase.TextChangedEvent, new TextChangedEventHandler((s, e) => UpdateSwatch()));
            category.SelectionChanged += (s, e) => Dispatcher.BeginInvoke(new Action(UpdateSwatch));
            PreviewKeyDown += (s, e) => { if (e.Key == Key.Escape) { e.Handled = true; Close(); } };
            Loaded += (s, e) => { title.Focus(); title.SelectAll(); };
            ToggleTimes(); ToggleMode(); UpdateSwatch(); UpdatePreview();
            var connection = Theme.Text("", 12, Theme.Warning); fields.Children.Insert(1, connection);
            Action setConnection = () => { if (!store.IsShared) return; connection.Text = store.ConnectionStatus; activityPanel.RefreshFromServer(); save.IsEnabled = store.CanWrite && !saving && !uncertain; deleteAll.IsEnabled = deleteOne.IsEnabled = store.CanWrite && !saving && !uncertain; SharedUi.ReadOnly(fields, !store.CanWrite || saving || uncertain); };
            Action sharedChanged = () => Dispatcher.BeginInvoke(setConnection);
            store.Changed += sharedChanged; Closed += (s, e) => store.Changed -= sharedChanged;
            Closing += (s, e) => { if (saving) e.Cancel = true; };
            setConnection();
        }

        // ---- layout helpers --------------------------------------------------------------

        static FrameworkElement Field(Panel parent, string label, FrameworkElement control)
        {
            var p = new StackPanel { Margin = new Thickness(0, 0, 0, 12) };
            p.Children.Add(Theme.Label(label));
            p.Children.Add(control);
            if (AutomationProperties.GetName(control).Length == 0) AutomationProperties.SetName(control, label);
            if (parent != null) parent.Children.Add(p);
            return p;
        }
        static Grid Pair(FrameworkElement a, FrameworkElement b)
        {
            var g = new Grid();
            g.ColumnDefinitions.Add(new ColumnDefinition());
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(16) });
            g.ColumnDefinitions.Add(new ColumnDefinition());
            g.Children.Add(a); Grid.SetColumn(b, 2); g.Children.Add(b);
            return g;
        }

        // ---- loading and switching scope -------------------------------------------------

        void LoadWhole()
        {
            loadingForm = true;
            title.Text = draft.Title; notes.Text = draft.Notes; location.Text = draft.Options.Location;
            responsible.Text = draft.Options.Responsible; group.Text = draft.Options.Group;
            var names = store.Categories().Select(c => c.Name).ToList();
            category.ItemsSource = names;
            category.Text = draft.Options.Category;
            start.SelectedDate = draft.Start; end.SelectedDate = draft.End;
            allDay.IsChecked = draft.AllDay;
            startTime.Text = AgendaEvent.Clock(draft.StartMinute); endTime.Text = AgendaEvent.Clock(draft.EndMinute);
            var labels = reminderLabels.ToList(); var values = reminderDays.ToList();
            if (!values.Contains(draft.Options.ReminderDays)) { values.Add(draft.Options.ReminderDays); labels.Add(draft.Options.ReminderDays + " días antes"); }
            reminder.Tag = values; reminder.ItemsSource = labels;
            reminder.SelectedIndex = values.IndexOf(draft.Options.ReminderDays);
            var o = draft.Options;
            for (int i = 0; i < 7; i++) weekdays[i].IsChecked = (o.Weekdays & (1 << i)) != 0;
            int mask = o.Weekdays & 127;
            if (o.SpecificDates.Count > 0) modeDates.IsChecked = true;
            else if (mask == 127 || (mask == 31 && !o.AllowNonSchool)) { modeInterval.IsChecked = true; for (int i = 0; i < 7; i++) weekdays[i].IsChecked = i < 5; }
            else modeWeekdays.IsChecked = true;
            specific.Text = Format.DateList(o.SpecificDates);
            excluded.Text = Format.DateList(o.ExcludedDates);
            nonSchool.IsChecked = o.AllowNonSchool;
            repetition.IsExpanded = modeInterval.IsChecked != true || o.ExcludedDates.Count > 0 || o.AllowNonSchool;
            loadingForm = false;
        }

        FormState Capture() { return new FormState { Title = title.Text, Notes = notes.Text, Location = location.Text, AllDay = allDay.IsChecked == true, StartTime = startTime.Text, EndTime = endTime.Text }; }
        void Apply(FormState s)
        {
            loadingForm = true;
            title.Text = s.Title; notes.Text = s.Notes; location.Text = s.Location; allDay.IsChecked = s.AllDay; startTime.Text = s.StartTime; endTime.Text = s.EndTime;
            loadingForm = false;
        }

        void SetScope(bool one)
        {
            if (one != oneScope)
            {
                if (oneScope) oneState = Capture(); else wholeState = Capture();
                Apply(one ? oneState : wholeState);
            }
            oneScope = one;
            foreach (var e in wholeOnly) e.IsEnabled = !one;
            moveSection.Visibility = one ? Visibility.Visible : Visibility.Collapsed;
            deleteOne.Visibility = one ? Visibility.Visible : Visibility.Collapsed;
            deleteAll.Visibility = one ? Visibility.Collapsed : Visibility.Visible;
            error.Text = "";
            ToggleTimes(); UpdatePreview();
        }

        void ToggleTimes() { timesRow.IsEnabled = allDay.IsChecked != true; }
        void ToggleMode()
        {
            weekdayRow.IsEnabled = modeWeekdays.IsChecked == true;
            specific.IsEnabled = modeDates.IsChecked == true;
            if (!oneScope) datesRow.IsEnabled = modeDates.IsChecked != true;
        }
        void UpdateSwatch()
        {
            string name = (category.Text ?? "").Trim();
            swatch.Background = Theme.Tint(Cards.ColorOf(name), 0);
            swatch.ToolTip = "Color de la categoría «" + name + "»";
        }

        // ---- reading the form ------------------------------------------------------------

        int ReminderValue()
        {
            var values = (List<int>)reminder.Tag;
            return reminder.SelectedIndex >= 0 ? values[reminder.SelectedIndex] : draft.Options.ReminderDays;
        }

        void ReadTimes(out int from, out int to, bool lenient)
        {
            from = draft.StartMinute; to = draft.EndMinute;
            if (allDay.IsChecked == true) return;
            int a, b;
            bool okA = Format.TryParseTime(startTime.Text, out a), okB = Format.TryParseTime(endTime.Text, out b);
            if (lenient) { if (okA) from = a; if (okB) to = b; return; }
            if (!okA) throw new ArgumentException("La hora de inicio «" + startTime.Text.Trim() + "» no es válida. Usa el formato de 24 horas, por ejemplo 09:30.");
            if (!okB) throw new ArgumentException("La hora de finalización «" + endTime.Text.Trim() + "» no es válida. Usa el formato de 24 horas, por ejemplo 14:00.");
            AgendaEvent.ValidateTimes(a, b);
            from = a; to = b;
        }

        AgendaEvent BuildWhole(bool lenient)
        {
            var e = draft.Copy();
            e.Title = title.Text.Trim(); e.Notes = notes.Text;
            e.Options.Category = (category.Text ?? "").Trim();
            e.Options.Location = location.Text.Trim(); e.Options.Responsible = responsible.Text.Trim(); e.Options.Group = group.Text.Trim();
            e.AllDay = allDay.IsChecked == true;
            int from, to; ReadTimes(out from, out to, lenient);
            e.StartMinute = from; e.EndMinute = to;
            e.Options.ReminderDays = ReminderValue();
            e.Options.AllowNonSchool = nonSchool.IsChecked == true;
            if (modeDates.IsChecked == true)
            {
                var list = Format.ParseDateList(specific.Text, "Solo estas fechas");
                if (list.Count == 0) throw new ArgumentException("Escribe al menos una fecha en «Solo estas fechas», o elige otro modo de repetición.");
                e.Options.SpecificDates = list; e.Start = list.First(); e.End = list.Last(); e.Options.Weekdays = 127;
            }
            else
            {
                if (!start.SelectedDate.HasValue) throw new ArgumentException("Indica la fecha de inicio (DD/MM/AAAA).");
                if (!end.SelectedDate.HasValue) throw new ArgumentException("Indica la fecha de finalización (DD/MM/AAAA).");
                e.Start = start.SelectedDate.Value.Date; e.End = end.SelectedDate.Value.Date;
                if (e.End < e.Start) throw new ArgumentException("La fecha de finalización no puede ser anterior a la fecha de inicio.");
                e.Options.SpecificDates.Clear();
                int mask = 0;
                for (int i = 0; i < 7; i++) if (weekdays[i].IsChecked == true) mask |= 1 << i;
                e.Options.Weekdays = modeWeekdays.IsChecked == true ? mask : 127;
                if (modeWeekdays.IsChecked == true && mask == 0) throw new ArgumentException("Marca al menos un día de la semana, o elige «Todos los días lectivos».");
            }
            var excludedDates = Format.ParseDateList(excluded.Text, "Excluir estas fechas");
            var outside = excludedDates.FirstOrDefault(d => d < e.Start || d > e.End);
            if (outside != default(DateTime)) throw new ArgumentException("La fecha excluida " + Format.Date(outside) + " está fuera del intervalo de la actividad (" + e.DateLabel.ToLower(Format.Spanish) + ").");
            e.Options.ExcludedDates = excludedDates;
            // Per-date changes outside the new interval no longer apply.
            e.Options.Changes.RemoveAll(c => c.Date.Date < e.Start || c.Date.Date > e.End);
            return e;
        }

        void UpdatePreview()
        {
            if (loadingForm || datesRow == null) return;
            preview.Foreground = Theme.Muted;
            if (oneScope)
            {
                preview.Text = "Solo cambia la fecha del " + Format.LongDate(occurrence.Date).ToLower(Format.Spanish) + ". Las demás " + (total - 1) + " fechas de la actividad no se modifican.";
                return;
            }
            try
            {
                var e = BuildWhole(true);
                var list = Planning.All(e, store.Calendar);
                IEnumerable<DateTime> candidates = e.Options.SpecificDates.Count > 0 ? e.Options.SpecificDates : Planning.Days(e.Start, e.End).Where(d => (e.Options.Weekdays & (1 << (((int)d.DayOfWeek + 6) % 7))) != 0);
                var skipped = candidates.Where(d => !Planning.RuleOccurs(e, d, store.Calendar)).Select(d => new { Date = d, Why = Planning.SkipReason(e, d, store.Calendar) }).ToList();
                if (list.Count == 0)
                {
                    preview.Foreground = Theme.Danger;
                    preview.Text = "⚠ Con estos datos la actividad no tendría ninguna fecha: todas son no lectivas o están excluidas.";
                    return;
                }
                string text = "Fechas resultantes (" + list.Count + "): " + String.Join(", ", list.Take(10).Select(o => Format.ShortWeekday(o.Date).ToLower(Format.Spanish) + " " + Format.DayMonth(o.Date))) + (list.Count > 10 ? " … y " + (list.Count - 10) + " más" : "") + ".";
                int weekends = skipped.Count(s => s.Why == "Fin de semana");
                var others = skipped.Where(s => s.Why != "Fin de semana").ToList();
                if (others.Count > 0) text += "\nSe omiten " + others.Count + ": " + String.Join(", ", others.Take(4).Select(s => Format.DayMonth(s.Date) + " (" + s.Why + ")")) + (others.Count > 4 ? "…" : "") + ".";
                if (weekends > 0) text += (others.Count > 0 ? " " : "\n") + "Fines de semana excluidos: " + weekends + ".";
                preview.Text = text;
            }
            catch (ArgumentException ex) { preview.Text = "Fechas resultantes: " + ex.Message; }
        }

        // ---- saving and deleting ---------------------------------------------------------

        void ShowError(string message) { error.Text = message; }

        async void Save()
        {
            if (saving || uncertain || !store.CanWrite) return;
            saving = true; save.IsEnabled = false; cancel.IsEnabled = false;
            try
            {
                if (String.IsNullOrWhiteSpace(title.Text)) throw new ArgumentException("Escribe un título para la actividad.");
                string outcome; AgendaEvent e;
                if (oneScope) e = BuildOne(out outcome);
                else { e = BuildWhole(false); activityPanel.Read(e.Options); outcome = existing == null ? "creada" : "actualizada"; }
                if (store.IsShared) await System.Threading.Tasks.Task.Run(() => store.Save(e)); else store.Save(e);
                draft.Id = e.Id; saving = false; Finish(outcome);
            }
            catch (UncertainOperationException ex) { uncertain = true; ShowError(ex.Message); }
            catch (ArgumentException ex) { ShowError(ex.Message); }
            catch (IOException ex) { ShowError(ex.Message + " Los datos escritos siguen en el formulario."); }
            finally { saving = false; save.IsEnabled = !uncertain && store.CanWrite; cancel.IsEnabled = true; }
        }

        void SaveWhole()
        {
            var e = BuildWhole(false);
            activityPanel.Read(e.Options);
            store.Save(e);
            draft.Id = e.Id;
            Finish(existing == null ? "creada" : "actualizada");
        }

        AgendaEvent BuildOne(out string outcome)
        {
            var e = existing.Copy();
            var change = new OccurrenceChange { Date = occurrence.OriginalDate, Title = title.Text.Trim(), Notes = notes.Text, Location = location.Text.Trim(), AllDay = allDay.IsChecked == true };
            int from, to; ReadTimes(out from, out to, false);
            change.StartMinute = from; change.EndMinute = to;
            if (!moveTo.SelectedDate.HasValue) throw new ArgumentException("Indica la fecha de esta ocurrencia (DD/MM/AAAA).");
            DateTime target = moveTo.SelectedDate.Value.Date;
            if (target != occurrence.OriginalDate)
            {
                change.MovedTo = target;
                change.AllowNonSchool = moveNonSchool.IsChecked == true;
                string reason = store.Calendar.Reason(target);
                if (reason.Length > 0 && !change.AllowNonSchool && !e.Options.AllowNonSchool)
                    throw new ArgumentException("El " + Format.LongDate(target).ToLower(Format.Spanish) + " es no lectivo (" + reason + "). Si quieres trasladar la actividad a ese día, marca «Permitir que la nueva fecha sea un día no lectivo».");
            }
            e.Options.Changes.RemoveAll(c => c.Date.Date == occurrence.OriginalDate);
            bool same = change.Title == e.Title && change.Notes == e.Notes && change.Location == e.Options.Location && change.AllDay == e.AllDay
                && (change.AllDay || (change.StartMinute == e.StartMinute && change.EndMinute == e.EndMinute)) && !change.MovedTo.HasValue;
            if (!same) e.Options.Changes.Add(change);
            outcome = change.MovedTo.HasValue ? "trasladada" : "fecha modificada";
            return e;
        }

        void Finish(string outcome) { saving = false; Changed = true; Outcome = outcome; Close(); }

        internal static string DeletionText(string title, bool onlyThisDate, DateTime? date, int total)
        {
            if (onlyThisDate)
            {
                int rest = total - 1;
                return "Se eliminará «" + title + "» solo el " + Format.LongDate(date.Value).ToLower(Format.Spanish) + ".\n\n" +
                    (rest == 1 ? "La otra fecha de la actividad se conservará sin cambios." : "Las otras " + rest + " fechas de la actividad se conservarán sin cambios.") +
                    "\n\nEsta acción no se puede deshacer.";
            }
            if (total > 1) return "Se eliminará «" + title + "» con todas sus fechas (" + total + ").\n\nEsta acción no se puede deshacer.";
            if (total == 1) return "Se eliminará «" + title + "»" + (date.HasValue ? ", cuya única fecha es el " + Format.LongDate(date.Value).ToLower(Format.Spanish) : "") + ".\n\nEsta acción no se puede deshacer.";
            return "Se eliminará «" + title + "». Ahora mismo no tiene fechas visibles con el calendario escolar actual.\n\nEsta acción no se puede deshacer.";
        }

        async void DeleteOne()
        {
            if (!store.CanWrite || saving || uncertain) return;
            try
            {
                if (total <= 1) { DeleteAll(); return; }
                if (!Confirm(this, "Eliminar solo esta fecha", DeletionText(existing.Title, true, occurrence.Date, total), "Eliminar solo esta fecha")) return;
                var e = existing.Copy();
                e.Options.Changes.RemoveAll(c => c.Date.Date == occurrence.OriginalDate);
                if (e.Options.SpecificDates.Count > 0) e.Options.SpecificDates.RemoveAll(d => d.Date == occurrence.OriginalDate);
                else if (!e.Options.ExcludedDates.Contains(occurrence.OriginalDate)) e.Options.ExcludedDates.Add(occurrence.OriginalDate);
                saving = true;
                if (store.IsShared) await System.Threading.Tasks.Task.Run(() => store.Save(e)); else store.Save(e);
                saving = false;
                Finish("fecha eliminada");
            }
            catch (ArgumentException ex) { ShowError(ex.Message); }
            catch (UncertainOperationException ex) { uncertain = true; ShowError(ex.Message); }
            catch (IOException ex) { ShowError("No se ha podido eliminar la fecha. " + ex.Message); }
            finally { saving = false; }
        }

        async void DeleteAll()
        {
            try
            {
                var only = total == 1 ? Planning.All(existing, store.Calendar).Select(o => (DateTime?)o.Date).FirstOrDefault() : null;
                string heading = total > 1 ? "Eliminar toda la actividad" : "Eliminar la actividad";
                if (!Confirm(this, heading, DeletionText(existing.Title, false, only, total), heading)) return;
                saving = true;
                if (store.IsShared) await System.Threading.Tasks.Task.Run(() => store.Delete(existing.Id)); else store.Delete(existing.Id);
                saving = false;
                Finish("eliminada");
            }
            catch (IOException ex) { ShowError("No se ha podido eliminar la actividad. " + ex.Message); }
            finally { saving = false; }
        }
    }
}
