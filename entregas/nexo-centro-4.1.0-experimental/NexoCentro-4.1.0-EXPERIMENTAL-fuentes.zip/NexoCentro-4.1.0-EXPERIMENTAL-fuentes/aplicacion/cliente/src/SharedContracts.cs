﻿using System;
using System.Collections.Generic;
using System.IO;

namespace AgendaClara
{
    public sealed class AgendaSnapshot
    {
        public string Generation = "";
        public long Revision, ConfigVersion;
        public DateTime ServerUtc;
        public List<AgendaEvent> Events = new List<AgendaEvent>();
        public List<Category> Categories = new List<Category>();
        public SchoolCalendar Calendar = new SchoolCalendar();
    }
    public sealed class AgendaCommand
    {
        public string RequestId = Guid.NewGuid().ToString("N"), Operation = "", Generation = "", A = "", B = "";
        public long ConfigVersion;
        public int Number;
        public AgendaEvent Event;
        public SchoolCalendar Calendar;
    }
    public sealed class AgendaReply
    {
        public long ResultId;
        public AgendaSnapshot Snapshot = new AgendaSnapshot();
    }
    public sealed class OperationStatus { public bool Known; public long ResultId; public AgendaSnapshot Snapshot = new AgendaSnapshot(); }
    public sealed class NetworkError { public string Code = "", Message = ""; }
    public sealed class LoginRequest { public bool Automatic; public string UserName = "", Password = "", RefreshToken = ""; }
    public sealed class SessionReply
    {
        public string AccessToken = "", RefreshToken = "", UserName = "", Role = "", ServerId = "";
        public bool Admin;
        public DateTime ExpiresUtc, OfflineUntilUtc;
    }
    public sealed class ServerHealth
    {
        public string ServerId = "", Version = "", BackupError = "", Integrity = "";
        public long Revision;
        public DateTime Utc;
        public DateTime? LastBackupUtc;
        public int ActiveSessions;
    }
    public sealed class BackupRecord { public string Name = "", Hash = ""; public DateTime Utc; public long Size; }
    public sealed class UserChange
    {
        public string UserName = "", Role = "", Password = "";
        public bool Enabled = true, Admin;
    }
    public sealed class UserView { public string UserName = "", Role = ""; public bool Enabled, Admin; }
    public sealed class DeviceView { public string Name = "", Thumbprint = ""; public bool Enabled; }
    public sealed class AuditRow { public long Revision; public string Actor = "", Device = "", Operation = "", Entity = ""; public DateTime Utc; }
    public interface IRemoteAgenda
    {
        AgendaSnapshot Snapshot { get; }
        bool CanWrite { get; }
        bool IsAdmin { get; }
        string Status { get; }
        event Action Changed;
        AgendaReply Execute(AgendaCommand command);
        IRemoteAgenda Fork();
    }
    public sealed class ConflictException : IOException
    {
        public ConflictException(string message) : base(message) { }
    }
}
