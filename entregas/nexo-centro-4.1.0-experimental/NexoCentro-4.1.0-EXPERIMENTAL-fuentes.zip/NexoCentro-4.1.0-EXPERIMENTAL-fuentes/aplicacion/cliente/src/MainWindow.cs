using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;

namespace AgendaClara
{
    public sealed class MainWindow : Window
    {
        // Replaced by the interface tests, which drive the same windows without modal loops.
        internal static Action<Window, Window> ShowModal = (owner, w) => { w.Owner = owner; w.ShowDialog(); };

        readonly Store store;
        SchoolCalendar currentCalendar = new SchoolCalendar();
        readonly Button addActivity, addInDay;
        readonly TextBlock connectionLine = Theme.Text("", 12, Theme.Muted);
        DateTime today = DateTime.Today, selected = DateTime.Today, month;
        string view = "Mes";
        List<AgendaEvent> all = new List<AgendaEvent>();
        readonly Dictionary<long, List<Occurrence>> dates = new Dictionary<long, List<Occurrence>>();
        Dictionary<DateTime, List<Occurrence>> visible = new Dictionary<DateTime, List<Occurrence>>();
        Dictionary<DateTime, List<Occurrence>> everything = new Dictionary<DateTime, List<Occurrence>>();
        List<Category> categories = new List<Category>();
        bool loading;
        double renderedHostHeight = -1;

        readonly TextBlock heading = Theme.Text("", 24, Theme.Ink, true), subheading = Theme.Text("", 12.5, Theme.Muted);
        readonly TextBlock todayLine = Theme.Text("", 13.5, Theme.Ink), statusLine = Theme.Text("", 12, Theme.Muted);
        readonly TextBlock dayTitle = Theme.Text("", 19, Theme.Ink, true), dayInfo = Theme.Text("", 12.5, Theme.Muted), filterNote = Theme.Text("", 12.5, Theme.Warning);
        readonly TextBlock sideLabel = Theme.Text("DÍA SELECCIONADO", 11, Theme.Accent, true);
        internal readonly ContextMenu SettingsMenu = new ContextMenu();
        readonly WrapPanel reminderPanel = new WrapPanel();
        readonly TextBox search = new TextBox { Width = 200 };
        readonly ComboBox categoryFilter = new ComboBox { Width = 175, Margin = new Thickness(6, 0, 6, 0) };
        readonly Dictionary<string, RadioButton> viewButtons = new Dictionary<string, RadioButton>();
        readonly Border host = new Border { Background = Theme.Surface, BorderBrush = Theme.Line, BorderThickness = new Thickness(1), CornerRadius = new CornerRadius(12), Padding = new Thickness(10) };
        readonly StackPanel dayList = new StackPanel();
        readonly ColumnDefinition sideColumn = new ColumnDefinition { Width = new GridLength(310) };
        readonly Button previous, next;
        readonly DatePicker jump = new DatePicker { Width = 130, Margin = new Thickness(6, 0, 0, 0), ToolTip = "Ir a una fecha concreta" };
        readonly Border statusBar = new Border { CornerRadius = new CornerRadius(8), Padding = new Thickness(10, 6, 10, 6), Margin = new Thickness(0, 10, 0, 0) };
        readonly DispatcherTimer timer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(30) };

        public Store Store { get { return store; } }
        public DateTime SelectedDate { get { return selected; } }
        public string CurrentView { get { return view; } }

        public MainWindow(Store store)
        {
            this.store = store;
            Theme.ApplyWindow(this);
            Title = "Nexo Centro EXPERIMENTAL · " + Program.Version;
            month = new DateTime(today.Year, today.Month, 1);
            var area = SystemParameters.WorkArea;
            MinWidth = 960; MinHeight = 560;
            Width = Math.Max(MinWidth, Math.Min(1380, area.Width - 40));
            Height = Math.Max(MinHeight, Math.Min(920, area.Height - 30));
            WindowStartupLocation = WindowStartupLocation.Manual;
            Left = area.Left + Math.Max(0, (area.Width - Width) / 2); Top = area.Top + Math.Max(0, (area.Height - Height) / 2);
            if (area.Width < 1200 || area.Height < 720) WindowState = WindowState.Maximized;

            var root = new Grid { Margin = new Thickness(18, 16, 18, 10) };
            for (int i = 0; i < 5; i++) root.RowDefinitions.Add(new RowDefinition { Height = i == 3 ? new GridLength(1, GridUnitType.Star) : GridLength.Auto });

            // Sólo presentación: se reutilizan los mismos comandos y sesiones de edición.
            var rail = new StackPanel { Margin = new Thickness(12, 24, 12, 16) };
            rail.Children.Add(Theme.Text("Nexo Centro", 21, Theme.AccentDark, true));
            var railCaption = Theme.Text("Agenda del centro", 12, Theme.Muted);
            railCaption.Margin = new Thickness(0, 4, 0, 28); rail.Children.Add(railCaption);
            rail.Children.Add(RailButton("Calendario", () => SetView("Mes")));
            rail.Children.Add(RailButton("Hoy", OpenToday));
            rail.Children.Add(RailButton("Memorias e informes", () => { ShowModal(this, new ReportsWindow(store)); Refresh(); }));
            AddSetting("Trabajo compartido", () => SharedRuntime.ShowSettings(this, store));
            AddSetting("Categorías", OpenCategories);
            AddSetting("Calendario escolar", OpenCalendar);
            AddSetting("Copias de seguridad", OpenBackups);
            AddSetting("Resumen de hoy", OpenTodaySummary);
            AddSetting("Evaluaciones Google · EXPERIMENTAL", () => { ShowModal(this, new GoogleEvaluationsWindow(store)); Refresh(); });
            var settings = RailButton("Ajustes", () => { SettingsMenu.IsOpen = true; });
            SettingsMenu.PlacementTarget = settings; SettingsMenu.Placement = PlacementMode.Right;
            rail.Children.Add(settings);
            var railHelp = Theme.Text("Categorías, calendario escolar, copias y conexión en Ajustes.", 12, Theme.Muted);
            railHelp.Margin = new Thickness(8, 24, 6, 0); rail.Children.Add(railHelp);

            var top = new Grid { Margin = new Thickness(0, 0, 0, 12) };
            top.ColumnDefinitions.Add(new ColumnDefinition());
            top.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            var brand = new StackPanel();
            brand.Children.Add(Theme.Text("EXPERIMENTAL · Google Forms", 23, Theme.Ink, true));
            var brandNote = Theme.Text("Prueba aislada. No utilizar sobre la agenda real.", 13, Theme.Muted);
            brandNote.Margin = new Thickness(0, 4, 0, 0); brand.Children.Add(brandNote);
            brand.Children.Add(connectionLine);
            top.Children.Add(brand);
            var add = addActivity = Theme.Button("＋ Nueva actividad", () => NewActivity(selected), "Primary");
            add.VerticalAlignment = VerticalAlignment.Center;
            Grid.SetColumn(add, 1); top.Children.Add(add);
            root.Children.Add(top);

            // Row 1: today and reminders.
            var banner = new Grid();
            banner.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star), MinWidth = 200 });
            banner.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(2, GridUnitType.Star) });
            var todayButton = new Button { Style = Theme.Style("Quiet"), Content = todayLine, HorizontalContentAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center, ToolTip = "Ver el día de hoy" };
            AutomationProperties.SetName(todayButton, "Resumen de hoy");
            todayButton.Click += (s, e) => GoToday();
            banner.Children.Add(todayButton);
            reminderPanel.VerticalAlignment = VerticalAlignment.Center;
            Grid.SetColumn(reminderPanel, 1); banner.Children.Add(reminderPanel);
            var bannerBox = new Border { Background = Theme.Surface, BorderBrush = Theme.Line, BorderThickness = new Thickness(0, 0, 0, 1), Padding = new Thickness(4, 8, 4, 8), Margin = new Thickness(0, 0, 0, 12), Child = banner };
            Grid.SetRow(bannerBox, 1); root.Children.Add(bannerBox);

            // Date navigation has its own row, separate from view and search controls.
            var tools = new StackPanel { Margin = new Thickness(0, 0, 0, 12) };
            var dateLine = new Grid { Margin = new Thickness(0, 0, 0, 12) };
            dateLine.ColumnDefinitions.Add(new ColumnDefinition());
            dateLine.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            var headingBox = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
            headingBox.Children.Add(heading); headingBox.Children.Add(subheading); dateLine.Children.Add(headingBox);
            var nav = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(10, 0, 0, 0) };
            previous = Theme.Button("‹", () => Move(-1)); previous.Width = 34; previous.FontSize = 18; previous.Padding = new Thickness(0);
            next = Theme.Button("›", () => Move(1)); next.Width = 34; next.FontSize = 18; next.Padding = new Thickness(0);
            AutomationProperties.SetName(previous, "Anterior"); AutomationProperties.SetName(next, "Siguiente");
            var todayNav = Theme.Button("Hoy", GoToday); todayNav.Margin = new Thickness(4, 0, 4, 0);
            nav.Children.Add(previous); nav.Children.Add(todayNav); nav.Children.Add(next); nav.Children.Add(jump);
            AutomationProperties.SetName(jump, "Ir a fecha");
            jump.SelectedDateChanged += (s, e) => { if (!loading && jump.SelectedDate.HasValue) Select(jump.SelectedDate.Value); };
            Grid.SetColumn(nav, 1); dateLine.Children.Add(nav); tools.Children.Add(dateLine);
            var controls = new WrapPanel();
            var views = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 0, 12, 6) };
            foreach (var name in new[] { "Mes", "Semana", "Día", "Próximos", "Resultados" })
            {
                string captured = name;
                var r = new RadioButton { Content = name, Style = Theme.Style("Segment"), GroupName = "vista" };
                AutomationProperties.SetName(r, "Vista " + name);
                r.Checked += (s, e) => { if (!loading) { view = captured; Render(); } };
                viewButtons[name] = r;
                views.Children.Add(r);
            }
            controls.Children.Add(views);
            var find = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 0, 0, 6), VerticalAlignment = VerticalAlignment.Center };
            search.ToolTip = "Buscar en toda la agenda: título, notas, categoría, grupos, responsable y lugar";
            AutomationProperties.SetName(search, "Buscar en toda la agenda");
            AutomationProperties.SetName(categoryFilter, "Filtrar por categoría");
            var searchLabel = Theme.Text("Buscar", 12, Theme.Muted); searchLabel.VerticalAlignment = VerticalAlignment.Center; searchLabel.Margin = new Thickness(0, 0, 8, 0); find.Children.Add(searchLabel);
            find.Children.Add(search); find.Children.Add(categoryFilter); find.Children.Add(Theme.Button("Limpiar", ClearFilters));
            controls.Children.Add(find); tools.Children.Add(controls);
            Grid.SetRow(tools, 2); root.Children.Add(tools);

            // Row 3: current view and the selected day.
            var body = new Grid();
            body.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star), MinWidth = 420 });
            body.ColumnDefinitions.Add(sideColumn);
            var mainArea = new DockPanel { Margin = new Thickness(0, 0, 14, 0) };
            filterNote.Margin = new Thickness(2, 0, 0, 6);
            DockPanel.SetDock(filterNote, Dock.Top); mainArea.Children.Add(filterNote);
            mainArea.Children.Add(host);
            body.Children.Add(mainArea);
            var side = new Grid();
            side.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            side.RowDefinitions.Add(new RowDefinition());
            side.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            var sideHead = new StackPanel { Margin = new Thickness(0, 0, 0, 10) };
            sideHead.Children.Add(sideLabel);
            dayTitle.Margin = new Thickness(0, 4, 0, 2);
            sideHead.Children.Add(dayTitle); sideHead.Children.Add(dayInfo);
            side.Children.Add(sideHead);
            var sideScroll = new ScrollViewer { Content = dayList, VerticalScrollBarVisibility = ScrollBarVisibility.Auto, HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled, Padding = new Thickness(0, 0, 4, 0) };
            Grid.SetRow(sideScroll, 1); side.Children.Add(sideScroll);
            var addHere = addInDay = Theme.Button("＋ Añadir en este día", () => NewActivity(selected));
            addHere.Margin = new Thickness(0, 10, 0, 0);
            Grid.SetRow(addHere, 2); side.Children.Add(addHere);
            var sidePanel = Theme.Panel(side, new Thickness(14));
            Grid.SetColumn(sidePanel, 1); body.Children.Add(sidePanel);
            Grid.SetRow(body, 3); root.Children.Add(body);

            // Row 4: saving and backup status.
            statusLine.TextTrimming = TextTrimming.CharacterEllipsis; statusLine.TextWrapping = TextWrapping.NoWrap;
            statusBar.Child = statusLine;
            Grid.SetRow(statusBar, 4); root.Children.Add(statusBar);
            // In very low windows the whole page scrolls, so the calendar keeps a usable height.
            var page = new ScrollViewer { Content = root, VerticalScrollBarVisibility = ScrollBarVisibility.Auto, HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled };
            root.VerticalAlignment = VerticalAlignment.Top;
            page.SizeChanged += (s, e) => root.Height = Math.Max(MinimumPageHeight, e.NewSize.Height - root.Margin.Top - root.Margin.Bottom);
            var shell = new Grid();
            shell.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(184) });
            shell.ColumnDefinitions.Add(new ColumnDefinition());
            var railSurface = new Border { Background = Theme.Surface, BorderBrush = Theme.Line, BorderThickness = new Thickness(0, 0, 1, 0), Child = new ScrollViewer { Content = rail, VerticalScrollBarVisibility = ScrollBarVisibility.Auto, HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled } };
            shell.Children.Add(railSurface); Grid.SetColumn(page, 1); shell.Children.Add(page); Content = shell;

            search.TextChanged += (s, e) => { if (loading) return; if (search.Text.Trim().Length > 0) SetView("Resultados"); else Render(); };
            categoryFilter.SelectionChanged += (s, e) => { if (!loading) Render(); };
            host.SizeChanged += (s, e) => { if (Math.Abs(e.NewSize.Height - renderedHostHeight) > 3 && view == "Mes") RenderMain(); };
            SizeChanged += (s, e) => sideColumn.Width = new GridLength(ActualWidth < 1180 ? 230 : 290);
            PreviewKeyDown += OnKey;
            timer.Tick += (s, e) => Tick();
            Loaded += (s, e) => timer.Start();
            Closed += (s, e) => timer.Stop();
            loading = true; viewButtons["Mes"].IsChecked = true; loading = false;
            Action sharedChanged = () => Dispatcher.BeginInvoke(new Action(Refresh));
            store.Changed += sharedChanged; Closed += (s, e) => store.Changed -= sharedChanged;
            Refresh();
        }

        const double MinimumPageHeight = 660;

        static Button RailButton(string text, Action action)
        {
            var b = Theme.Button(text, action);
            b.HorizontalContentAlignment = HorizontalAlignment.Left; b.BorderThickness = new Thickness(0);
            b.Background = Brushes.Transparent; b.Padding = new Thickness(8, 12, 6, 12); b.FontSize = 13;
            b.Margin = new Thickness(0, 2, 0, 2); return b;
        }

        void AddSetting(string text, Action action)
        {
            var item = new MenuItem { Header = text, Padding = new Thickness(16, 10, 16, 10) };
            AutomationProperties.SetName(item, text);
            item.Click += (sender, args) => { SettingsMenu.IsOpen = false; action(); };
            SettingsMenu.Items.Add(item);
        }

        static FrameworkElement Spaced(FrameworkElement e) { e.Margin = new Thickness(6, 0, 0, 6); return e; }

        void OnKey(object sender, KeyEventArgs e)
        {
            if (Keyboard.Modifiers == ModifierKeys.Control && e.Key == Key.N) { NewActivity(selected); e.Handled = true; }
            else if (Keyboard.Modifiers == ModifierKeys.Control && e.Key == Key.F) { search.Focus(); search.SelectAll(); e.Handled = true; }
        }

        internal void Tick()
        {
            store.EnsureDailyBackup();
            if (DateTime.Today != today) Refresh(); else UpdateStatus();
        }

        // ---- data ----------------------------------------------------------------------

        public void Refresh()
        {
            connectionLine.Text = store.ConnectionStatus; connectionLine.Visibility = store.IsShared ? Visibility.Visible : Visibility.Collapsed; addActivity.IsEnabled = addInDay.IsEnabled = store.CanWrite;
            today = DateTime.Today;
            var snapshot = store.LoadSnapshot(); currentCalendar = snapshot.Calendar;
            all = snapshot.Events;
            categories = snapshot.Categories;
            Cards.SetCategories(categories);
            Cards.Calendar = currentCalendar;
            dates.Clear();
            foreach (var e in all) dates[e.Id] = Planning.All(e, currentCalendar);
            everything = Planning.Index(dates.Values);
            string current = categoryFilter.SelectedItem as string;
            loading = true;
            var items = new List<string> { "Todas las categorías" };
            items.AddRange(categories.Select(c => c.Name));
            categoryFilter.ItemsSource = items;
            categoryFilter.SelectedItem = current != null && items.Contains(current) ? current : items[0];
            loading = false;
            Render();
        }

        string CategoryFilterValue { get { var c = categoryFilter.SelectedItem as string; return c == null || categoryFilter.SelectedIndex <= 0 ? "" : c; } }
        bool Filtering { get { return search.Text.Trim().Length > 0 || CategoryFilterValue.Length > 0; } }
        List<AgendaEvent> Matching() { return all.Where(e => Planning.Matches(e, search.Text, CategoryFilterValue)).ToList(); }
        List<Occurrence> VisibleOn(DateTime d) { List<Occurrence> l; return visible.TryGetValue(d.Date, out l) ? l : new List<Occurrence>(); }
        List<Occurrence> AllOn(DateTime d) { List<Occurrence> l; return everything.TryGetValue(d.Date, out l) ? l : new List<Occurrence>(); }

        void ClearFilters()
        {
            loading = true; search.Text = ""; categoryFilter.SelectedIndex = 0; loading = false;
            if (view == "Resultados") SetView("Mes"); else Render();
        }

        public void SetView(string name)
        {
            loading = true; viewButtons[name].IsChecked = true; loading = false;
            view = name; Render();
        }

        // ---- navigation ------------------------------------------------------------------

        public void Move(int direction)
        {
            try
            {
                if (view == "Mes")
                {
                    month = month.AddMonths(direction);
                    selected = new DateTime(month.Year, month.Month, Math.Min(selected.Day, DateTime.DaysInMonth(month.Year, month.Month)));
                }
                else
                {
                    selected = selected.AddDays(direction * (view == "Semana" ? 7 : 1));
                    month = new DateTime(selected.Year, selected.Month, 1);
                }
            }
            catch (ArgumentOutOfRangeException) { }
            Render();
        }

        public void GoToday() { selected = DateTime.Today; month = new DateTime(selected.Year, selected.Month, 1); if (view == "Resultados" || view == "Próximos") SetView("Mes"); else Render(); }

        public void Select(DateTime date)
        {
            selected = date.Date; month = new DateTime(date.Year, date.Month, 1);
            if (view == "Resultados" || view == "Próximos") SetView("Día"); else Render();
        }

        void OpenDay(DateTime date) { selected = date.Date; month = new DateTime(date.Year, date.Month, 1); SetView("Día"); }

        // ---- editing ---------------------------------------------------------------------

        public void NewActivity(DateTime date) { if (!store.CanWrite) { Dialogs.Info(this,"Solo consulta","Conecta con el servidor para crear o modificar actividades compartidas."); return; } RunEditor(new EventEditor(store.EditSession(), null, null, date)); }

        public void Open(Occurrence o)
        {
            var session = store.EditSession();
            var fresh = session.Find(o.Source.Id);
            if (fresh == null) { Refresh(); return; }
            var real = Planning.All(fresh, session.Calendar).FirstOrDefault(x => x.OriginalDate == o.OriginalDate);
            RunEditor(new EventEditor(session, fresh, real, o.Date));
        }

        public void OpenWhole(AgendaEvent e)
        {
            var session = store.EditSession();
            var fresh = session.Find(e.Id);
            if (fresh == null) { Refresh(); return; }
            RunEditor(new EventEditor(store, fresh, null, fresh.Start));
        }

        void RunEditor(EventEditor editor)
        {
            ShowModal(this, editor);
            if (editor.Changed) Refresh();
        }

        public void OpenTodaySummary()
        {
            var w = new TodaySummaryWindow(store, DateTime.Today);
            ShowModal(this, w);
            if (w.OpenAgendaRequested) OpenToday();
        }

        public void OpenToday() { OpenDay(DateTime.Today); }

        void OpenCategories() { var w = new CategoryManager(store.EditSession()); ShowModal(this, w); if (w.Changed) Refresh(); }
        void OpenBackups() { if (store.IsShared) { SharedRuntime.ShowSettings(this, store); return; } var w = new BackupWindow(store); ShowModal(this, w); if (w.Restored) Refresh(); else UpdateStatus(); }
        void OpenCalendar()
        {
            var w = new CalendarEditor(store.EditSession()); ShowModal(this, w);
            if (!w.Saved) return;
            Refresh();
            var hidden = store.WithoutVisibleDates();
            Dialogs.Info(this, "Calendario guardado", "El calendario escolar se ha guardado. No se ha borrado ninguna actividad." +
                (hidden.Count > 0 ? "\n\n" + Format.Count(hidden.Count, "actividad no tiene", "actividades no tienen") + " ahora fechas visibles porque todas sus fechas son no lectivas. Puedes encontrarlas con el buscador (vista Resultados) y cambiar sus fechas." : ""));
        }
        void OpenReminders()
        {
            var w = new RemindersWindow(Planning.Reminders(all, today, currentCalendar));
            ShowModal(this, w);
            if (w.Selected != null) Open(w.Selected);
        }

        // ---- rendering -------------------------------------------------------------------

        public void Render()
        {
            if (categoryFilter.ItemsSource == null) return;
            visible = Filtering ? Planning.Index(Matching().Select(e => dates[e.Id])) : everything;
            bool navigable = view == "Mes" || view == "Semana" || view == "Día";
            previous.IsEnabled = next.IsEnabled = navigable;
            loading = true; jump.SelectedDate = selected; loading = false;
            switch (view)
            {
                case "Mes": heading.Text = Format.MonthYear(month); break;
                case "Semana": { var m = Monday(selected); heading.Text = "Semana del " + Format.DayMonth(m) + " al " + Format.Date(m.AddDays(6)); break; }
                case "Día": heading.Text = Format.LongDate(selected); break;
                case "Próximos": heading.Text = "Próximos 30 días"; break;
                default: heading.Text = "Resultados en toda la agenda"; break;
            }
            string term = currentCalendar.Term(selected), year = currentCalendar.YearName(selected);
            subheading.Text = navigable ? (term.Length > 0 ? term : year.Length > 0 ? year : "Fuera del periodo de clases configurado") : view == "Próximos" ? "Desde hoy, " + Format.Date(today) : "Incluye actividades pasadas y las ocultas por el calendario";
            filterNote.Text = Filtering ? "Filtro activo" + (search.Text.Trim().Length > 0 ? " · texto: «" + search.Text.Trim() + "»" : "") + (CategoryFilterValue.Length > 0 ? " · categoría: " + CategoryFilterValue : "") + ". Solo se muestran las actividades que coinciden; pulsa «Limpiar» para verlas todas." : "";
            filterNote.Visibility = Filtering ? Visibility.Visible : Visibility.Collapsed;
            RenderMain();
            RenderSide();
            RenderBanner();
            UpdateStatus();
        }

        void RenderMain()
        {
            renderedHostHeight = host.ActualHeight;
            switch (view)
            {
                case "Mes": host.Child = BuildMonth(); break;
                case "Semana": host.Child = BuildWeek(); break;
                case "Día": host.Child = BuildDay(); break;
                case "Próximos": host.Child = BuildUpcoming(); break;
                default: host.Child = BuildResults(); break;
            }
        }

        static DateTime Monday(DateTime d) { return d.Date.AddDays(-(((int)d.DayOfWeek + 6) % 7)); }

        Brush DayBackground(DateTime d, string reason)
        {
            if (d == selected) return Theme.Selected;
            if (reason.Length == 0) return Theme.Surface;
            return SchoolCalendar.IsWeekend(d) && currentCalendar.BreakFor(d) == null ? Theme.Weekend : Theme.NonSchool;
        }

        UIElement BuildMonth()
        {
            DateTime first = Monday(month);
            int days = DateTime.DaysInMonth(month.Year, month.Month);
            int weeks = ((int)(month - first).TotalDays + days + 6) / 7;
            var outer = new DockPanel();
            var header = new Grid { Margin = new Thickness(0, 0, 0, 4) };
            var legend = Legend(); DockPanel.SetDock(legend, Dock.Bottom); outer.Children.Add(legend);
            legend.Measure(new Size(Math.Max(200, host.ActualWidth - 22), double.PositiveInfinity));
            double available = host.ActualHeight > 0 ? host.ActualHeight - 22 - 22 - legend.DesiredSize.Height - 4 : 520;
            double cellHeight = Math.Max(70, available / weeks);
            DockPanel.SetDock(header, Dock.Top); outer.Children.Add(header);
            var grid = new Grid { Height = cellHeight * weeks };
            string[] names = { "LUN", "MAR", "MIÉ", "JUE", "VIE", "SÁB", "DOM" };
            for (int i = 0; i < 7; i++)
            {
                header.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(i < 5 ? 1 : 0.72, GridUnitType.Star) });
                grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(i < 5 ? 1 : 0.72, GridUnitType.Star) });
                var t = Theme.Text(names[i], 11, i < 5 ? Theme.Muted : Theme.Tint("#566B76", 0.35), true); t.Margin = new Thickness(6, 0, 0, 0);
                Grid.SetColumn(t, i); header.Children.Add(t);
            }
            for (int w = 0; w < weeks; w++) grid.RowDefinitions.Add(new RowDefinition());
            for (int i = 0; i < weeks * 7; i++)
            {
                DateTime date;
                try { date = first.AddDays(i); } catch (ArgumentOutOfRangeException) { break; }
                var cell = MonthCell(date, date.Month == month.Month, cellHeight);
                Grid.SetColumn(cell, i % 7); Grid.SetRow(cell, i / 7); grid.Children.Add(cell);
            }
            outer.Children.Add(new ScrollViewer { Content = grid, VerticalScrollBarVisibility = ScrollBarVisibility.Auto, HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled });
            return outer;
        }

        FrameworkElement MonthCell(DateTime date, bool inMonth, double cellHeight)
        {
            string reason = currentCalendar.Reason(date);
            bool isToday = date == today, isSelected = date == selected;
            var items = VisibleOn(date);
            var panel = new StackPanel();
            var top = new DockPanel { LastChildFill = false, Margin = new Thickness(0, 0, 0, 2) };
            var number = new Button { Style = Theme.Style("Quiet"), Content = Theme.Text(date.Day.ToString(), 13, reason.Length > 0 ? Theme.Muted : Theme.Ink, isToday || isSelected), ToolTip = Format.LongDate(date) + (reason.Length > 0 ? " · " + reason : "") + "\nDoble clic: abrir la vista del día", HorizontalContentAlignment = HorizontalAlignment.Left };
            AutomationProperties.SetName(number, Format.LongDate(date));
            number.Padding = new Thickness(0);
            number.Click += (s, e) => Select(date);
            top.Children.Add(number);
            if (isToday) top.Children.Add(Theme.Pill("HOY", Theme.Accent, Brushes.White));
            panel.Children.Add(top);
            top.Measure(new Size(200, double.PositiveInfinity));
            double room = cellHeight - (isToday || isSelected ? 4 : 2) - 6 - top.DesiredSize.Height;
            if (reason.Length > 0 && reason != "Fin de semana")
            {
                var r = Theme.Text(reason, 10.5, Theme.NonSchoolInk); r.TextWrapping = TextWrapping.NoWrap; r.TextTrimming = TextTrimming.CharacterEllipsis; r.ToolTip = reason;
                panel.Children.Add(r); room -= 15;
            }
            int fitAll = Math.Max(0, (int)(room / 24));
            int show = items.Count <= fitAll ? items.Count : Math.Max(0, (int)((room - 16) / 24));
            foreach (var o in items.Take(show)) { var captured = o; panel.Children.Add(Cards.Compact(o, () => Open(captured))); }
            if (items.Count > show)
            {
                var more = new Button { Style = Theme.Style("Quiet"), Content = Theme.Text("+" + (items.Count - show) + " más", 11.5, Theme.AccentDark, true), HorizontalContentAlignment = HorizontalAlignment.Left, ToolTip = String.Join("\n", items.Select(o => "• " + o.View.Title)) };
                AutomationProperties.SetName(more, "Ver las " + items.Count + " actividades del " + Format.Date(date));
                more.Padding = new Thickness(0);
                more.Click += (s, e) => Select(date);
                panel.Children.Add(more);
            }
            var cell = new Border
            {
                Margin = new Thickness(0), Padding = new Thickness(6, 3, 6, 3), CornerRadius = new CornerRadius(0), ClipToBounds = true,
                BorderThickness = new Thickness(isToday || isSelected ? 2 : 1),
                BorderBrush = isToday ? Theme.Accent : isSelected ? Theme.AccentDark : Theme.Line,
                Background = DayBackground(date, reason), Opacity = inMonth ? 1 : 0.55, Child = panel
            };
            AutomationProperties.SetName(cell, Format.LongDate(date) + ", " + Format.Count(items.Count, "actividad", "actividades") + (reason.Length > 0 ? ", " + reason : ""));
            cell.MouseLeftButtonDown += (s, e) => { if (e.ClickCount == 2) { OpenDay(date); e.Handled = true; } };
            cell.MouseLeftButtonUp += (s, e) => { if (selected != date) Select(date); };
            return cell;
        }

        FrameworkElement Legend()
        {
            var wrap = new WrapPanel { Margin = new Thickness(2, 8, 0, 0) };
            var marks = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 0, 14, 4) };
            marks.Children.Add(new Border { Width = 12, Height = 12, Background = Theme.NonSchool, BorderBrush = Theme.Line, BorderThickness = new Thickness(1) });
            marks.Children.Add(new TextBlock { Text = "No lectivo", FontSize = 11.5, Foreground = Theme.Muted, Margin = new Thickness(5, 0, 10, 0) });
            marks.Children.Add(new TextBlock { Text = "↔ varias fechas", FontSize = 11.5, Foreground = Theme.Muted });
            wrap.Children.Add(marks);
            return wrap;
        }

        UIElement BuildWeek()
        {
            DateTime monday = Monday(selected);
            var outer = new DockPanel();
            var legend = Legend(); DockPanel.SetDock(legend, Dock.Bottom); outer.Children.Add(legend);
            var grid = new Grid();
            for (int i = 0; i < 7; i++)
            {
                DateTime date = monday.AddDays(i);
                grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(i < 5 ? 1 : 0.6, GridUnitType.Star) });
                string reason = currentCalendar.Reason(date);
                bool isToday = date == today;
                var column = new DockPanel();
                var head = new StackPanel { Margin = new Thickness(0, 0, 0, 6) };
                var dayButton = new Button { Content = Format.ShortWeekday(date) + " " + Format.DayMonth(date), FontWeight = isToday ? FontWeights.Bold : FontWeights.Normal, ToolTip = Format.LongDate(date) + "\nDoble clic: abrir la vista del día", Padding = new Thickness(4, 4, 4, 4) };
                AutomationProperties.SetName(dayButton, Format.LongDate(date));
                dayButton.Click += (s, e) => Select(date);
                dayButton.MouseDoubleClick += (s, e) => OpenDay(date);
                head.Children.Add(dayButton);
                if (isToday) { var pill = Theme.Pill("HOY", Theme.Accent, Brushes.White); pill.HorizontalAlignment = HorizontalAlignment.Center; pill.Margin = new Thickness(0, 4, 0, 0); head.Children.Add(pill); }
                if (reason.Length > 0) { var r = Theme.Text(reason, 11, Theme.NonSchoolInk); r.TextAlignment = TextAlignment.Center; r.Margin = new Thickness(0, 3, 0, 0); head.Children.Add(r); }
                DockPanel.SetDock(head, Dock.Top); column.Children.Add(head);
                var list = new StackPanel();
                var items = VisibleOn(date);
                foreach (var o in items) { var captured = o; list.Children.Add(Cards.Full(o, () => Open(captured), false, true)); }
                if (items.Count == 0) list.Children.Add(Theme.Text(reason.Length > 0 ? "" : "Sin actividades", 12, Theme.Muted));
                column.Children.Add(new ScrollViewer { Content = list, VerticalScrollBarVisibility = ScrollBarVisibility.Auto, HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled });
                var box = new Border
                {
                    Child = column, Margin = new Thickness(3), Padding = new Thickness(6), CornerRadius = new CornerRadius(9),
                    Background = DayBackground(date, reason), BorderBrush = isToday ? Theme.Accent : date == selected ? Theme.AccentDark : Theme.Line, BorderThickness = new Thickness(isToday || date == selected ? 2 : 1)
                };
                Grid.SetColumn(box, i); grid.Children.Add(box);
            }
            outer.Children.Add(grid);
            return outer;
        }

        UIElement BuildDay()
        {
            var p = new StackPanel { Margin = new Thickness(6, 4, 6, 4) };
            string reason = currentCalendar.Reason(selected);
            if (reason.Length > 0) p.Children.Add(Theme.Notice("Día no lectivo: " + reason + ". Las actividades ordinarias no aparecen en días no lectivos; solo las que tienen una excepción expresa.", Theme.NonSchool, Theme.NonSchoolInk));
            var items = VisibleOn(selected);
            p.Children.Add(Theme.Text(Format.Count(items.Count, "actividad", "actividades") + (selected == today ? " hoy" : ""), 13, Theme.Muted));
            p.Children.Add(new Border { Height = 8 });
            foreach (string period in new[] { "Todo el día", "Mañana", "Tarde" })
            {
                var group = items.Where(o => (o.View.AllDay ? "Todo el día" : o.View.StartMinute < 12 * 60 ? "Mañana" : "Tarde") == period).ToList();
                if (group.Count == 0) continue;
                var title = Theme.Text(period, 17, Theme.Ink, true); title.Margin = new Thickness(0, 14, 0, 8);
                p.Children.Add(title);
                foreach (var o in group) { var captured = o; p.Children.Add(Cards.Full(o, () => Open(captured), false)); }
            }
            if (items.Count == 0 && reason.Length == 0) p.Children.Add(Theme.Text("No hay actividades este día" + (Filtering ? " con los filtros actuales." : "."), 14, Theme.Muted));
            var add = Theme.Button("＋ Añadir en este día", () => NewActivity(selected)); add.IsEnabled = store.CanWrite; add.HorizontalAlignment = HorizontalAlignment.Left; add.Margin = new Thickness(0, 8, 0, 0);
            p.Children.Add(add);
            return new ScrollViewer { Content = p, VerticalScrollBarVisibility = ScrollBarVisibility.Auto, HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled };
        }

        static string Distance(int days) { return days == 0 ? "Hoy" : days == 1 ? "Mañana" : "Dentro de " + days + " días"; }

        UIElement BuildUpcoming()
        {
            var p = new StackPanel { Margin = new Thickness(6, 4, 6, 4) };
            int shown = 0;
            for (int i = 0; i <= 30; i++)
            {
                DateTime d = today.AddDays(i);
                var items = VisibleOn(d);
                if (items.Count == 0) continue;
                var head = Theme.Text(Distance(i) + " · " + Format.LongDate(d), 14, Theme.AccentDark, true); head.Margin = new Thickness(0, shown == 0 ? 0 : 10, 0, 6);
                p.Children.Add(head);
                foreach (var o in items) { var captured = o; p.Children.Add(Cards.Full(o, () => Open(captured), false)); shown++; }
            }
            if (shown == 0) p.Children.Add(Theme.Text("No hay actividades en los próximos 30 días" + (Filtering ? " con los filtros actuales." : "."), 14, Theme.Muted));
            return new ScrollViewer { Content = p, VerticalScrollBarVisibility = ScrollBarVisibility.Auto, HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled };
        }

        UIElement BuildResults()
        {
            var p = new StackPanel { Margin = new Thickness(6, 4, 6, 4) };
            var found = Matching();
            p.Children.Add(Theme.Text(Format.Count(found.Count, "actividad encontrada", "actividades encontradas") + (Filtering ? "" : " (toda la agenda)") + ". Pulsa una para abrirla y editarla.", 13, Theme.Muted));
            p.Children.Add(new Border { Height = 8 });
            var ordered = found.OrderBy(e => { var d = dates[e.Id]; var n = d.FirstOrDefault(o => o.Date >= today); return n != null ? 0 : d.Count == 0 ? 2 : 1; })
                .ThenBy(e => { var n = dates[e.Id].FirstOrDefault(o => o.Date >= today); return n != null ? n.Date.Ticks : -e.End.Ticks; }).ToList();
            foreach (var e in ordered) { var captured = e; p.Children.Add(Cards.Result(e, dates[e.Id], today, () => OpenWhole(captured))); }
            return new ScrollViewer { Content = p, VerticalScrollBarVisibility = ScrollBarVisibility.Auto, HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled };
        }

        void RenderSide()
        {
            sideLabel.Text = view == "Día" ? "CALENDARIO Y PRÓXIMOS DÍAS" : "DÍA SELECCIONADO";
            if (view == "Día")
            {
                dayTitle.Text = "Agenda de " + (selected == today ? "hoy" : Format.DayMonth(selected));
                dayInfo.Text = "Selecciona una fecha para consultar sus actividades.";
                dayList.Children.Clear();
                var mini = new Calendar { FirstDayOfWeek = DayOfWeek.Monday, DisplayDate = selected, SelectedDate = selected,
                    SelectionMode = CalendarSelectionMode.SingleDate, HorizontalAlignment = HorizontalAlignment.Stretch };
                AutomationProperties.SetName(mini, "Calendario de la agenda diaria");
                mini.SelectedDatesChanged += (sender, args) => { if (mini.SelectedDate.HasValue && mini.SelectedDate.Value.Date != selected) Select(mini.SelectedDate.Value); };
                dayList.Children.Add(mini);
                var upcoming = Theme.Text("Próximos días", 16, Theme.Ink, true); upcoming.Margin = new Thickness(0, 16, 0, 8); dayList.Children.Add(upcoming);
                int shown = 0;
                for (int i = 1; i <= 30 && shown < 4 && selected <= DateTime.MaxValue.Date.AddDays(-i); i++)
                    foreach (var o in VisibleOn(selected.AddDays(i)).Take(4 - shown))
                    { var captured = o; dayList.Children.Add(Cards.Full(o, () => Open(captured), true, true)); shown++; }
                if (shown == 0) dayList.Children.Add(Theme.Text("No hay actividades próximas con los filtros actuales.", 13, Theme.Muted));
                return;
            }
            dayTitle.Text = Format.LongDate(selected);
            string reason = currentCalendar.Reason(selected), term = currentCalendar.Term(selected);
            var items = VisibleOn(selected);
            dayInfo.Text = (reason.Length > 0 ? "No lectivo: " + reason : term.Length > 0 ? term : "Día lectivo") + " · " + Format.Count(items.Count, "actividad", "actividades") + (Filtering ? " (con filtro)" : "");
            dayList.Children.Clear();
            if (reason.Length > 0) dayList.Children.Add(Theme.Notice("Las actividades ordinarias no se muestran en días no lectivos. Solo aparecen las que tienen una excepción expresa.", Theme.NonSchool, Theme.NonSchoolInk));
            foreach (var o in items) { var captured = o; dayList.Children.Add(Cards.Full(o, () => Open(captured), false)); }
            if (items.Count == 0 && reason.Length == 0) dayList.Children.Add(Theme.Text("No hay actividades este día" + (Filtering ? " con los filtros actuales." : "."), 13, Theme.Muted));
        }

        void RenderBanner()
        {
            var todayItems = AllOn(today);
            string reason = currentCalendar.Reason(today);
            string text = "Hoy, " + Format.LongDate(today).ToLower(Format.Spanish) + ": ";
            if (todayItems.Count == 0) text += reason.Length > 0 ? "no lectivo (" + reason + ")" : "sin actividades";
            else text += Format.Count(todayItems.Count, "actividad", "actividades") + " — " + String.Join(", ", todayItems.GroupBy(o => o.View.Options.Category).Select(g => g.Key + " " + g.Count()));
            todayLine.Text = text;
            reminderPanel.Children.Clear();
            var reminders = Planning.Reminders(all, today, currentCalendar);
            var label = Theme.Text("Avisos:", 12.5, Theme.Muted, true); label.VerticalAlignment = VerticalAlignment.Center; label.Margin = new Thickness(0, 0, 8, 0);
            reminderPanel.Children.Add(label);
            if (reminders.Count == 0) reminderPanel.Children.Add(new TextBlock { Text = "no hay avisos próximos", Foreground = Theme.Muted, FontSize = 12.5, VerticalAlignment = VerticalAlignment.Center });
            foreach (var r in reminders.Take(2))
            {
                var captured = r;
                var t = Theme.Text(r.Message, 12.5, r.DaysLeft == 0 ? Theme.AccentDark : Theme.Ink, r.DaysLeft <= 1); t.TextWrapping = TextWrapping.NoWrap; t.TextTrimming = TextTrimming.CharacterEllipsis; t.MaxWidth = 380;
                var b = new Button { Content = t, Padding = new Thickness(8, 3, 8, 3), MinHeight = 28, Margin = new Thickness(0, 2, 6, 2), ToolTip = r.Message, Background = Theme.Surface };
                AutomationProperties.SetName(b, r.Message);
                b.Click += (s, e) => Open(captured.Occurrence);
                reminderPanel.Children.Add(b);
            }
            var seeAll = Theme.Button(reminders.Count > 2 ? "Ver todos (" + reminders.Count + ")" : "Ver avisos", OpenReminders);
            seeAll.MinHeight = 28; seeAll.Padding = new Thickness(8, 3, 8, 3); seeAll.Margin = new Thickness(0, 2, 0, 2);
            reminderPanel.Children.Add(seeAll);
        }

        public void UpdateStatus()
        {
            if (store.IsShared)
            {
                statusBar.Background = store.CanWrite ? Theme.Pale : Theme.WarningSoft;
                statusLine.Foreground = store.CanWrite ? Theme.AccentDark : Theme.Warning;
                statusLine.Text = (store.CanWrite ? "Servidor central · " : "Solo consulta · ") + store.ConnectionStatus + " · Copias gestionadas por el servidor · " + Format.Count(all.Count, "actividad", "actividades") + " · Versión " + Program.Version;
                statusBar.ToolTip = "La base central y las copias se gestionan en Jefatura. Consulta Trabajo compartido para ver su diagnóstico.";
                AutomationProperties.SetName(statusLine, statusLine.Text); return;
            }
            string copy = store.LastBackup.HasValue
                ? (store.LastBackup.Value.Date == DateTime.Today ? "hoy a las " + store.LastBackup.Value.ToString("HH:mm") : "el " + Format.Date(store.LastBackup.Value) + " a las " + store.LastBackup.Value.ToString("HH:mm"))
                : "todavía no hay ninguna";
            if (String.IsNullOrEmpty(store.BackupError))
            {
                statusBar.Background = Theme.Pale;
                statusLine.Foreground = Theme.AccentDark;
                statusLine.Text = "✓ Todos los cambios están guardados en este equipo · Última copia de seguridad: " + copy + " · " + Format.Count(all.Count, "actividad", "actividades") + " · Versión " + Program.Version + " (" + Program.VersionDate + ")";
                statusBar.ToolTip = "Agenda: " + store.DatabasePath + "\nCopias automáticas: " + store.BackupDirectory;
            }
            else
            {
                statusBar.Background = Theme.DangerSoft;
                statusLine.Foreground = Theme.Danger;
                statusLine.Text = "⚠ Los cambios están guardados, pero la copia de seguridad automática ha fallado. Última copia disponible: " + copy + ". Abre «Copias de seguridad» para ver el motivo.";
                statusBar.ToolTip = store.BackupError;
            }
            AutomationProperties.SetName(statusLine, statusLine.Text);
        }
    }
}
