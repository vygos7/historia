using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using AgendaClara;

namespace AgendaClara.Pruebas
{
    // Drives the real windows, handlers and SQLite store of AgendaClara.exe on an isolated database.
    // Modal dialogs are shown non-modally so that the script can operate them.
    public static class UiTests
    {
        static string folder;
        static Application app;
        static MainWindow main;
        static Store store;
        static Action<Window> pending;
        static readonly List<string> confirmations = new List<string>(), infos = new List<string>();
        static readonly Queue<bool> answers = new Queue<bool>();
        static DateTime today = DateTime.Today;

        public static void Run(string dir)
        {
            folder = dir; Directory.CreateDirectory(folder);
            app = new Application { ShutdownMode = ShutdownMode.OnExplicitShutdown };
            Theme.Install(app);
            MainWindow.ShowModal = (owner, w) =>
            {
                w.Owner = owner; w.Show(); Pump();
                var act = pending; pending = null;
                if (act == null) T.Check(false, "Se abrió «" + w.Title + "» sin acción de prueba prevista");
                else { try { act(w); } catch (Exception ex) { T.Check(false, "Acción en «" + w.Title + "»: " + ex.Message); } }
                Pump();
                if (w.IsVisible) w.Close();
            };
            Dialogs.ConfirmImpl = (owner, title, message, label) => { confirmations.Add(title + "|" + message + "|" + label); return answers.Count > 0 && answers.Dequeue(); };
            Dialogs.InfoImpl = (owner, title, message) => infos.Add(title + "|" + message);
            store = new Store(Path.Combine(folder, "interfaz-" + Guid.NewGuid().ToString("N").Substring(0, 8) + ".sqlite3"));
            main = new MainWindow(store);
            main.Width = 1360; main.Height = 900; main.WindowState = WindowState.Normal;
            main.Loaded += (s, e) => app.Dispatcher.BeginInvoke(new Action(Script), DispatcherPriority.ApplicationIdle);
            main.Show();
            app.Run();
            store.Dispose();
        }

        // ---- helpers ---------------------------------------------------------------------

        public static void Pump()
        {
            foreach (Window w in app.Windows) if (w.IsVisible) w.UpdateLayout();
            for (int i = 0; i < 2; i++)
            {
                var frame = new DispatcherFrame();
                Dispatcher.CurrentDispatcher.BeginInvoke(DispatcherPriority.Background, new DispatcherOperationCallback(f => { ((DispatcherFrame)f).Continue = false; return null; }), frame);
                Dispatcher.PushFrame(frame);
            }
            foreach (Window w in app.Windows) if (w.IsVisible) w.UpdateLayout();
        }
        static IEnumerable<DependencyObject> Logical(DependencyObject root)
        {
            yield return root;
            foreach (object child in LogicalTreeHelper.GetChildren(root))
            {
                var d = child as DependencyObject;
                if (d != null) foreach (var x in Logical(d)) yield return x;
            }
        }
        static IEnumerable<DependencyObject> Visual(DependencyObject root)
        {
            yield return root;
            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(root); i++)
                foreach (var x in Visual(VisualTreeHelper.GetChild(root, i))) yield return x;
        }
        static T Named<T>(DependencyObject root, string name) where T : DependencyObject { Pump(); return Logical(root).OfType<T>().FirstOrDefault(x => AutomationProperties.GetName(x) == name); }
        static List<T> AllNamed<T>(DependencyObject root, Func<string, bool> match) where T : DependencyObject { Pump(); return Logical(root).OfType<T>().Where(x => match(AutomationProperties.GetName(x))).ToList(); }
        static Button Btn(DependencyObject root, string text)
        {
            Pump();
            var b = Logical(root).OfType<Button>().FirstOrDefault(x => (x.Content as string) == text || AutomationProperties.GetName(x) == text);
            if (b == null) throw new Exception("No se encuentra el botón «" + text + "»");
            return b;
        }
        static void Click(Button b)
        {
            if (!b.IsEnabled) throw new Exception("El botón «" + AutomationProperties.GetName(b) + "» está desactivado");
            if (!b.IsVisible) throw new Exception("El botón «" + AutomationProperties.GetName(b) + "» no está visible" + (PresentationSource.FromVisual(b) == null ? " (no está conectado a la ventana: " + Chain(b) + ")" : ""));
            b.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent)); Pump();
        }
        static void Click(DependencyObject root, string text)
        {
            if (root == main)
            {
                var item = main.SettingsMenu.Items.OfType<MenuItem>().FirstOrDefault(x => (string)x.Header == text);
                if (item != null)
                {
                    Click(Btn(main, "Ajustes")); Pump();
                    T.Check(item.IsVisible, "La opción «" + text + "» está visible en Ajustes");
                    item.RaiseEvent(new RoutedEventArgs(MenuItem.ClickEvent)); Pump(); return;
                }
            }
            Click(Btn(root, text));
        }
        static string Chain(DependencyObject d)
        {
            var parts = new List<string>();
            while (d != null) { var v = d as Visual; parts.Add(d.GetType().Name + (v != null && PresentationSource.FromVisual(v) != null ? "+" : "-") + (VisualTreeHelper.GetParent(d) == null ? "(sin padre visual)" : "")); d = LogicalTreeHelper.GetParent(d); }
            return String.Join(" < ", parts);
        }
        static bool Has(DependencyObject root, string text) { Pump(); return Logical(root).OfType<TextBlock>().Any(t => t.Text != null && t.Text.Contains(text)); }
        static TextBox Box(DependencyObject root, string name) { var t = Named<TextBox>(root, name); if (t == null) throw new Exception("No se encuentra el campo «" + name + "»"); return t; }
        static string Error(Window w) { var t = Named<TextBlock>(w, "Mensaje de error"); return t == null ? "" : t.Text; }

        static void Capture(Window w, string name)
        {
            w.UpdateLayout(); Pump();
            var root = (FrameworkElement)w.Content;
            var panel = root as Panel; if (panel != null && panel.Background == null) panel.Background = Theme.Background;
            var control = root as Control; if (control != null && control.Background == null) control.Background = Theme.Background;
            w.UpdateLayout(); Pump();
            int width = (int)Math.Ceiling(root.ActualWidth + root.Margin.Left + root.Margin.Right), height = (int)Math.Ceiling(root.ActualHeight + root.Margin.Top + root.Margin.Bottom);
            var bitmap = new RenderTargetBitmap(width, height, 96, 96, PixelFormats.Pbgra32);
            // Render the arranged content directly: a VisualBrush can shift scroll content
            // and crop the heading, producing a misleading screenshot.
            bitmap.Render(root);
            var png = new PngBitmapEncoder(); png.Frames.Add(BitmapFrame.Create(bitmap));
            using (var file = File.Create(Path.Combine(folder, name + ".png"))) png.Save(file);
        }

        // Buttons outside scrolling areas must be fully visible; inside a scrolling area they must not be cut by a cell.
        static List<string> Clipped(Window w)
        {
            w.UpdateLayout(); Pump();
            var root = (FrameworkElement)w.Content;
            var problems = new List<string>();
            var rootRect = new Rect(0, 0, root.ActualWidth, root.ActualHeight);
            foreach (var b in Visual(root).OfType<ButtonBase>().Where(x => x.IsVisible && x.ActualWidth > 0 && x.ActualHeight > 0 && !(x is RepeatButton) && !(x.TemplatedParent is ScrollBar) && !(x is DataGridColumnHeader && x.Content == null)))
            {
                Rect r = b.TransformToAncestor(root).TransformBounds(new Rect(0, 0, b.ActualWidth, b.ActualHeight));
                Rect area = Rect.Empty; bool scrolled = false;
                DependencyObject p = b;
                while (p != null && p != root)
                {
                    if (p is ScrollContentPresenter) { scrolled = true; break; }
                    var fe = p as FrameworkElement;
                    if (fe != null && fe != b)
                    {
                        Geometry clip = LayoutInformation.GetLayoutClip(fe);
                        if (fe.ClipToBounds || clip != null)
                        {
                            Rect local = clip != null ? clip.Bounds : new Rect(0, 0, fe.ActualWidth, fe.ActualHeight);
                            Rect inRoot = fe.TransformToAncestor(root).TransformBounds(local);
                            area = area.IsEmpty ? inRoot : Rect.Intersect(area, inRoot);
                        }
                    }
                    p = VisualTreeHelper.GetParent(p);
                }
                if (!scrolled) area = area.IsEmpty ? rootRect : Rect.Intersect(area, rootRect);
                if (area.IsEmpty) continue; // inside a scrolling area, not cut by any cell
                Rect inter = Rect.Intersect(r, area);
                if (inter.IsEmpty || inter.Width < r.Width - 1.5 || inter.Height < r.Height - 1.5) problems.Add(Describe(b) + " " + r.ToString(System.Globalization.CultureInfo.InvariantCulture));
            }
            return problems;
        }
        static string Describe(ButtonBase b) { string n = AutomationProperties.GetName(b); return "«" + (n.Length > 0 ? n : b.Content as string ?? b.GetType().Name) + "»"; }

        static void CheckLayout(Window w, string name)
        {
            var problems = Clipped(w);
            T.Check(problems.Count == 0, name + (problems.Count == 0 ? "" : ": " + String.Join(", ", problems.Take(6))));
        }

        static DateTime SchoolDayFrom(DateTime d) { while (!store.Calendar.IsSchoolDay(d)) d = d.AddDays(1); return d; }
        static AgendaEvent Save(string title, string start, string end, string category, Action<AgendaEvent> setup = null)
        {
            var e = new AgendaEvent { Title = title, Start = T.D(start), End = T.D(end), AllDay = false, StartMinute = 600, EndMinute = 660 };
            e.Options.Category = category;
            if (setup != null) setup(e);
            store.Save(e); return e;
        }
        static string Dates(long id) { return T.Dates(Planning.All(store.Find(id), store.Calendar)); }
        static Button CardOn(string prefix) { return AllNamed<Button>(main, n => n.StartsWith(prefix)).FirstOrDefault(); }
        static void Edit(Button opener, Action<EventEditor> work) { pending = w => work((EventEditor)w); Click(opener); }

        // ---- script ----------------------------------------------------------------------

        static void Script()
        {
            try
            {
                T.Section("Interfaz · arranque y creación");
                T.Run("Arranque", Startup);
                T.Run("Crear con el formulario", Create);
                T.Section("Interfaz · navegación");
                T.Run("Navegación", Navigation);
                T.Section("Interfaz · vistas, varias actividades y calendario escolar");
                T.Run("Vistas", Views);
                T.Section("Interfaz · editar, trasladar y eliminar fechas");
                T.Run("Ocurrencias", OccurrenceEditing);
                T.Section("Interfaz · búsqueda y filtros");
                T.Run("Búsqueda", Search);
                T.Run("Navegación lateral", Sidebar);
                T.Section("Interfaz · calendario escolar");
                T.Run("Calendario", CalendarWindow);
                T.Section("Interfaz · categorías");
                T.Run("Categorías", Categories);
                T.Section("Interfaz · avisos");
                T.Run("Avisos", Reminders);
                T.Section("Interfaz · copias de seguridad");
                T.Run("Copias", Backups);
                T.Section("Interfaz · resumen «Tu agenda de hoy»");
                T.Run("Seguimiento, memorias e informes", () => LifecycleTests.UI(folder));
                T.Run("Resumen de hoy", Summary);
                T.Run("Mostrar al iniciar Windows", SignInOption);
                T.Section("Interfaz · tamaño de ventana y legibilidad");
                T.Run("Tamaños", Sizes);
                T.Section("Interfaz · cerrar y reabrir");
                T.Run("Reabrir", Reopen);
            }
            finally { app.Shutdown(); }
        }

        static void Sidebar()
        {
            Click(main, "Limpiar");
            var filter = Named<ComboBox>(main, "Filtrar por categoría");
            filter.SelectedItem = "Charla"; Pump();
            T.Check((filter.SelectedItem as string) == "Charla" && Has(main, "Filtro activo"), "Categorías accesibles desde un único filtro desplegable");
            T.Check(!AllNamed<Button>(main, n => n.StartsWith("Filtrar: ")).Any(), "El lateral no repite la lista de categorías");
            filter.SelectedIndex = 0; Pump();
            T.Check(filter.SelectedIndex == 0, "Todas las categorías retira el filtro");
            main.SetView("Próximos"); Pump(); Click(main, "Calendario");
            T.Check(main.CurrentView == "Mes", "Calendario lateral vuelve a la vista mensual");
            T.Check(new[] { "Categorías", "Calendario escolar", "Copias de seguridad", "Trabajo compartido", "Resumen de hoy" }.All(name => main.SettingsMenu.Items.OfType<MenuItem>().Any(item => (string)item.Header == name)), "Ajustes conserva todas las herramientas existentes");
            T.Check(main.Title.StartsWith("Nexo Centro") && Has(main, "Nexo Centro"), "Nombre Nexo Centro visible en la ventana y el lateral");
            var date = main.SelectedDate;
            Click(main, "Hoy");
            T.Check(main.CurrentView == "Día" && main.SelectedDate == DateTime.Today && Named<Calendar>(main, "Calendario de la agenda diaria") != null, "Hoy abre la agenda diaria con calendario auxiliar");
            CheckLayout(main, "Agenda diaria Nexo Centro sin controles recortados");
            Capture(main, "nexo-centro-hoy");
            main.Select(date); main.SetView("Mes"); Pump();
            Capture(main, "nexo-centro-calendario");
        }

        static void Startup()
        {
            Pump();
            T.Check(main.CurrentView == "Mes" && Has(main, Format.MonthYear(today)), "Arranca en la vista mensual del mes actual");
            T.Check(Logical(main).OfType<TextBlock>().Any(t => t.Text == "HOY"), "El día actual está marcado como HOY");
            T.Check(Has(main, "Todos los cambios están guardados") && Has(main, "Última copia de seguridad: hoy"), "Indicador visible de guardado y última copia");
            Capture(main, "01-arranque");
        }

        static void Create()
        {
            DateTime day = SchoolDayFrom(today);
            main.Select(day);
            bool sawTitleError = false, keptText = false, sawTimeError = false;
            Edit(Btn(main, "＋ Nueva actividad"), e =>
            {
                Click(e, "Guardar");
                sawTitleError = e.IsVisible && Error(e).Contains("título");
                Box(e, "Título *").Text = "Claustro de inicio";
                Box(e, "Hora de inicio (24 h, p. ej. 09:30)").Text = "25:99";
                Click(e, "Guardar");
                sawTimeError = e.IsVisible && Error(e).Contains("no es válida");
                keptText = Box(e, "Título *").Text == "Claustro de inicio";
                Box(e, "Hora de inicio (24 h, p. ej. 09:30)").Text = "16:00";
                Box(e, "Hora de finalización (24 h)").Text = "15:00";
                Click(e, "Guardar");
                T.Check(e.IsVisible && Error(e).Contains("posterior"), "La hora final anterior a la inicial se rechaza en el formulario");
                Box(e, "Hora de finalización (24 h)").Text = "17:30";
                Capture(e, "02-editor-nueva");
                Click(e, "Guardar");
                T.Check(!e.IsVisible, "Guardar cierra el formulario");
            });
            T.Check(sawTitleError, "Sin título: aviso visible y el formulario sigue abierto");
            T.Check(sawTimeError && keptText, "Hora incorrecta: aviso visible sin perder lo escrito");
            var all = store.AllEvents();
            T.Check(all.Count == 1 && all[0].Title == "Claustro de inicio" && all[0].TimeLabel == "16:00–17:30" && all[0].Start == day, "Se crea un único registro real con los datos del formulario");
            T.Check(CardOn("Claustro de inicio") != null, "La actividad nueva aparece en la agenda");
            Edit(Btn(main, "＋ Añadir en este día"), e => { Box(e, "Título *").Text = "Borrador que se descarta"; Click(e, "Cancelar"); });
            T.Check(store.AllEvents().Count == 1, "Cancelar descarta el borrador");
            var created = store.AllEvents()[0];
            Edit(CardOn("Claustro de inicio"), e => { Box(e, "Título *").Text = "Cambio sin guardar"; Click(e, "Cancelar"); });
            T.Check(store.Find(created.Id).Title == "Claustro de inicio", "Cancelar descarta los cambios de una actividad existente");
        }

        static void Navigation()
        {
            main.Select(T.D("15/12/2026")); main.SetView("Mes");
            Click(main, "Siguiente");
            T.Check(Has(main, "Enero 2027"), "Mes siguiente cruzando de año (diciembre → enero)");
            Click(main, "Siguiente");
            T.Check(Has(main, "Febrero 2027"), "Mes siguiente (febrero)");
            Click(main, "Anterior"); Click(main, "Anterior"); Click(main, "Anterior");
            T.Check(Has(main, "Noviembre 2026") && main.SelectedDate.Month == 11 && main.SelectedDate.Year == 2026, "Mes anterior cruzando de año");
            main.Select(T.D("28/12/2026")); main.SetView("Semana");
            T.Check(Has(main, "Semana del 28/12 al 03/01/2027"), "Vista semanal que cruza de año");
            Click(main, "Siguiente");
            T.Check(Has(main, "Semana del 04/01 al 10/01/2027"), "Semana siguiente");
            Click(main, "Anterior"); Click(main, "Anterior");
            T.Check(Has(main, "Semana del 21/12 al 27/12/2026"), "Semana anterior");
            main.Select(T.D("31/12/2026")); main.SetView("Día");
            Click(main, "Siguiente");
            T.Check(Has(main, "Viernes, 01/01/2027") && Has(main, "Día de Año Nuevo"), "Día siguiente cruzando de año, con su motivo no lectivo");
            Click(main, "Anterior");
            T.Check(Has(main, "Jueves, 31/12/2026"), "Día anterior");
            Click(main, "Hoy");
            T.Check(main.SelectedDate == today, "«Hoy» vuelve a la fecha actual");
        }

        static void Views()
        {
            for (int i = 0; i < 8; i++) Save("Reunión " + (i + 1) + " con un título largo que debe recortarse sin invadir otras citas", "10/05/2027", "10/05/2027", "Reunión", e => { e.StartMinute = 480 + i * 30; e.EndMinute = 500 + i * 30; e.Notes = "Notas para comprobar el desplazamiento del panel."; });
            Save("Semana cultural", "10/05/2027", "18/05/2027", "Celebración", e => e.AllDay = true);
            Save("Jornadas de puertas abiertas", "07/05/2027", "11/05/2027", "Otros");
            main.Refresh(); main.Select(T.D("10/05/2027")); main.SetView("Mes");
            var more = Named<Button>(main, "Ver las 10 actividades del 10/05/2027");
            T.Check(more != null && more.IsVisible, "Indicador «+N más» cuando no caben en la casilla");
            if (more != null) T.Check(((TextBlock)more.Content).Text.StartsWith("+") && ((TextBlock)more.Content).Text.EndsWith(" más"), "El indicador dice «+N más»");
            if (more != null) Click(more);
            T.Check(Has(main, "10 actividades") && AllNamed<Button>(main, n => n.StartsWith("Reunión ")).Count >= 8, "Pulsar «+N más» muestra todas las actividades del día en el panel");
            T.Check(Named<Border>(main, "Sábado, 08/05/2027, 0 actividades, Fin de semana") != null && Named<Border>(main, "Domingo, 09/05/2027, 0 actividades, Fin de semana") != null, "Fin de semana sin actividades ordinarias (intervalo 07–11/05)");
            T.Check(Named<Border>(main, "Jueves, 13/05/2027, 0 actividades, Día no lectivo local") != null && Named<Border>(main, "Lunes, 17/05/2027, 0 actividades, Día no lectivo local") != null, "Días no lectivos locales sin actividades");
            T.Check(Named<Border>(main, "Martes, 18/05/2027, 1 actividad") != null && Named<Border>(main, "Miércoles, 12/05/2027, 1 actividad") != null && Named<Border>(main, "Martes, 11/05/2027, 2 actividades") != null, "Semana cultural (10–18/05) solo en 10, 11, 12 y 18");
            CheckLayout(main, "Vista mensual: casillas e indicadores sin recortes");
            Capture(main, "03-mes-mayo-2027");
            main.SetView("Semana");
            T.Check(Has(main, "Semana del 10/05 al 16/05/2027") && Has(main, "Día no lectivo local"), "Vista semanal con días no lectivos señalados");
            CheckLayout(main, "Vista semanal sin recortes");
            Capture(main, "04-semana");
            main.SetView("Día");
            T.Check(Has(main, "Lunes, 10/05/2027") && Has(main, "10 actividades"), "Vista diaria con todas las actividades");
            T.Check(Logical(main).OfType<ScrollViewer>().Any(s => s.ScrollableHeight > 0), "La vista diaria se desplaza cuando el contenido no cabe");
            Capture(main, "05-dia");
            main.SetView("Próximos");
            T.Check(Has(main, "Próximos 30 días"), "Consulta de próximos eventos");
            main.SetView("Mes");
        }

        static void OccurrenceEditing()
        {
            var week = store.AllEvents().Single(e => e.Title == "Semana cultural");
            main.Select(T.D("11/05/2027")); main.SetView("Día");
            Edit(CardOn("Semana cultural"), e =>
            {
                var one = Named<RadioButton>(e, "Solo esta fecha");
                T.Check(one != null && Named<RadioButton>(e, "Toda la actividad") != null, "Al abrir una fecha se ofrece elegir: toda la actividad o solo esta fecha");
                T.Check(Btn(e, "Eliminar toda la actividad").IsVisible && !Btn(e, "Eliminar solo esta fecha").IsVisible, "Con «toda la actividad» el botón dice «Eliminar toda la actividad»");
                one.IsChecked = true; Pump();
                T.Check(Btn(e, "Eliminar solo esta fecha").IsVisible && !Btn(e, "Eliminar toda la actividad").IsVisible, "Con «solo esta fecha» el botón dice «Eliminar solo esta fecha»");
                Box(e, "Título *").Text = "Semana cultural: teatro";
                Capture(e, "06-editor-una-fecha");
                Click(e, "Guardar");
            });
            var after = Planning.All(store.Find(week.Id), store.Calendar);
            T.Check(after.Single(o => o.Date == T.D("11/05/2027")).View.Title == "Semana cultural: teatro" && after.Where(o => o.Date != T.D("11/05/2027")).All(o => o.View.Title == "Semana cultural"), "Editar una fecha desde la interfaz no altera las demás");

            main.Select(T.D("12/05/2027"));
            Edit(CardOn("Semana cultural"), e =>
            {
                Named<RadioButton>(e, "Solo esta fecha").IsChecked = true; Pump();
                Named<DatePicker>(e, "Trasladar a").SelectedDate = T.D("15/05/2027"); Pump();
                Click(e, "Guardar");
                T.Check(e.IsVisible && Error(e).Contains("no lectivo"), "Trasladar a sábado exige la excepción expresa");
                Logical(e).OfType<CheckBox>().Single(c => (c.Content as string) == "Permitir que la nueva fecha sea un día no lectivo").IsChecked = true;
                Click(e, "Guardar");
            });
            T.Check(Dates(week.Id) == "10/05,11/05,15/05,18/05", "Trasladar una sola fecha (12/05 → sábado 15/05 con excepción)");
            main.Select(T.D("15/05/2027"));
            Edit(CardOn("Semana cultural"), e =>
            {
                Named<RadioButton>(e, "Solo esta fecha").IsChecked = true; Pump();
                Named<DatePicker>(e, "Trasladar a").SelectedDate = T.D("19/05/2027"); Pump();
                Click(e, "Guardar");
            });
            T.Check(Dates(week.Id) == "10/05,11/05,18/05,19/05", "Volver a trasladar la fecha (15/05 → 19/05) sin tocar el resto");

            main.Select(T.D("18/05/2027"));
            Edit(CardOn("Semana cultural"), e =>
            {
                Named<RadioButton>(e, "Solo esta fecha").IsChecked = true; Pump();
                answers.Enqueue(false);
                Click(e, "Eliminar solo esta fecha");
                T.Check(e.IsVisible && Dates(week.Id).Contains("18/05"), "Cancelar la confirmación no elimina nada");
                answers.Enqueue(true);
                Click(e, "Eliminar solo esta fecha");
            });
            string last = confirmations.Last();
            T.Check(last.StartsWith("Eliminar solo esta fecha|") && last.Contains("solo el martes, 18/05/2027") && last.Contains("Las otras 3 fechas") && !last.Contains("todas sus fechas"), "La confirmación explica que solo se elimina esa fecha");
            T.Check(Dates(week.Id) == "10/05,11/05,19/05", "Eliminar solo una fecha conserva las demás");

            main.Select(T.D("10/05/2027"));
            Edit(CardOn("Semana cultural"), e => { answers.Enqueue(true); Click(e, "Eliminar toda la actividad"); });
            last = confirmations.Last();
            T.Check(last.StartsWith("Eliminar toda la actividad|") && last.Contains("con todas sus fechas (3)"), "La confirmación de borrar toda la actividad indica su alcance");
            T.Check(store.Find(week.Id) == null, "Eliminar toda la actividad");

            var pair = Save("Visita del alumnado de Infantil", "25/05/2027", "26/05/2027", "Salida / excursión");
            main.Refresh(); main.Select(T.D("25/05/2027"));
            Edit(CardOn("Visita del alumnado"), e => { Named<RadioButton>(e, "Solo esta fecha").IsChecked = true; Pump(); answers.Enqueue(true); Click(e, "Eliminar solo esta fecha"); });
            T.Check(Dates(pair.Id) == "26/05", "Queda una sola fecha");
            main.Select(T.D("26/05/2027"));
            Edit(CardOn("Visita del alumnado"), e =>
            {
                T.Check(Named<RadioButton>(e, "Solo esta fecha") == null && !Logical(e).OfType<Button>().Any(b => (b.Content as string) == "Eliminar solo esta fecha" && b.IsVisible), "Con una sola fecha no se ofrece «solo esta fecha»");
                answers.Enqueue(false);
                Click(e, "Eliminar actividad");
            });
            T.Check(confirmations.Last().Contains("única fecha es el miércoles, 26/05/2027") && store.Find(pair.Id) != null, "La última fecha se explica con claridad (y cancelar la conserva)");
        }

        static void Search()
        {
            Save("Excursión a Doñana", "17/11/2026", "17/11/2026", "Salida / excursión", e => e.Options.Responsible = "María");
            Save("Charla sobre el parque de Doñana", "18/11/2026", "18/11/2026", "Charla");
            Save("Charla antigua de Doñana", "20/10/2025", "20/10/2025", "Charla", e => e.Options.AllowNonSchool = true);
            main.Refresh();
            var search = Box(main, "Buscar en toda la agenda");
            search.Text = "donana"; Pump();
            T.Check(main.CurrentView == "Resultados" && Has(main, "3 actividades encontradas"), "Buscar «donana» sin tilde encuentra «Doñana», incluida una actividad pasada");
            search.Text = "DOÑANA maría"; Pump();
            T.Check(Has(main, "1 actividad encontrada"), "Mayúsculas, tildes y varias palabras");
            search.Text = "doñana"; Pump();
            Named<ComboBox>(main, "Filtrar por categoría").SelectedItem = "Charla"; Pump();
            T.Check(Has(main, "2 actividades encontradas") && Has(main, "categoría: Charla"), "Búsqueda combinada con categoría");
            T.Check(Has(main, "Pasada · última fecha 20/10/2025"), "Los resultados incluyen actividades pasadas");
            Capture(main, "07-resultados");
            Edit(AllNamed<Button>(main, n => n.StartsWith("Charla sobre el parque")).First(), e =>
            {
                T.Check(Named<RadioButton>(e, "Solo esta fecha") == null, "Desde los resultados se edita la actividad completa (no una fecha inexistente)");
                Box(e, "Lugar (opcional)").Text = "Salón de actos"; Click(e, "Guardar");
            });
            T.Check(store.AllEvents().Single(x => x.Title.StartsWith("Charla sobre el parque")).Options.Location == "Salón de actos", "Abrir y editar desde los resultados");
            main.SetView("Mes"); Pump();
            T.Check(Has(main, "Filtro activo"), "El filtro activo se indica también en el calendario");
            Click(main, "Limpiar");
            T.Check(search.Text == "" && Named<ComboBox>(main, "Filtrar por categoría").SelectedIndex == 0 && !Has(main, "Filtro activo"), "«Limpiar» borra búsqueda y filtro");
        }

        static void CalendarWindow()
        {
            var original = store.Calendar.Copy();
            pending = w =>
            {
                Click(w, "＋ Añadir día o periodo no lectivo");
                Named<TextBox>(w, "Nombre del periodo");
                var names = AllNamed<TextBox>(w, n => n == "Nombre del periodo"); names.Last().Text = "Jornada del centro";
                AllNamed<DatePicker>(w, n => n == "Desde").Last().SelectedDate = T.D("17/11/2026");
                AllNamed<DatePicker>(w, n => n == "Hasta").Last().SelectedDate = T.D("17/11/2026");
                CheckLayout(w, "Editor del calendario sin recortes");
                Capture(w, "08-calendario-escolar");
                Click(w, "Guardar calendario");
            };
            Click(main, "Calendario escolar");
            T.Check(store.Calendar.Breaks.Any(b => b.Name == "Jornada del centro" && b.Start == T.D("17/11/2026")) && !store.Calendar.IsSchoolDay(T.D("17/11/2026")), "Añadir un día no lectivo desde la aplicación");
            T.Check(infos.Count > 0 && infos.Last().Contains("No se ha borrado ninguna actividad") && infos.Last().Contains("1 actividad no tiene"), "Aviso: ninguna actividad borrada y cuántas quedan ocultas");
            var search = Box(main, "Buscar en toda la agenda");
            search.Text = "excursion doñana"; Pump();
            T.Check(Has(main, "Sin fechas visibles con el calendario actual"), "La actividad oculta sigue en los resultados de búsqueda");
            Click(main, "Limpiar");
            store.SaveCalendar(original); main.Refresh();
        }

        static void Categories()
        {
            var taller = Save("Taller de reciclaje", "19/11/2026", "19/11/2026", "Taller");
            var concurso = Save("Concurso de ortografía", "20/11/2026", "20/11/2026", "Concurso");
            main.Refresh();
            CategoryManager.ChooseTarget = (o, c, l) => "Otros";
            CategoryManager.ChooseColor = (o, c) => "#A33A3A";
            pending = w =>
            {
                Click(w, "Cambiar nombre de Taller");
                Box(w, "Nuevo nombre para Taller").Text = "Taller de familias";
                Click(w, "Guardar nombre");
                T.Check(Has(w, "renombrada"), "Renombrar desde la gestión de categorías");
                Click(w, "Eliminar Concurso");
                T.Check(Has(w, "pasado a «Otros»"), "Eliminar una categoría informa de adónde van sus actividades");
                Click(w, "Cambiar color de Charla");
                Box(w, "Nombre de la nueva categoría").Text = "Claustro";
                Click(w, "Añadir categoría");
                Box(w, "Nombre de la nueva categoría").Text = "claustro";
                Click(w, "Añadir categoría");
                T.Check(Has(w, "Ya existe"), "No se duplica una categoría (aviso visible)");
                w.Width = w.MinWidth; w.Height = w.MinHeight;
                CheckLayout(w, "Gestión de categorías sin recortes en tamaño mínimo");
                Capture(w, "09-categorias");
            };
            Click(main, "Categorías");
            T.Check(store.Find(taller.Id).Options.Category == "Taller de familias" && store.Find(concurso.Id).Options.Category == "Otros", "Las actividades siguen a su categoría renombrada o reasignada");
            var cats = store.Categories();
            T.Check(cats.Any(c => c.Name == "Claustro") && cats.First(c => c.Name == "Charla").Color == "#A33A3A" && !cats.Any(c => c.Name == "Concurso"), "Categoría nueva, color cambiado y categoría eliminada");
            T.Check(Named<ComboBox>(main, "Filtrar por categoría").Items.Cast<string>().Contains("Taller de familias"), "El filtro de la ventana principal refleja los cambios");
        }

        static void Reminders()
        {
            DateTime day = SchoolDayFrom(today.AddDays(5));
            int days = (int)(day - today).TotalDays;
            var e = new AgendaEvent { Title = "Excursión al museo", Start = day, End = day, AllDay = true };
            e.Options.Category = "Salida / excursión"; e.Options.ReminderDays = 10;
            store.Save(e); main.Refresh();
            string expected = "Faltan " + days + " días para «Excursión al museo»";
            T.Check(Has(main, expected), "Aviso visible en la ventana principal: " + expected);
            pending = w => { T.Check(Has(w, expected) && Has(w, "días naturales"), "La ventana de avisos lo muestra e indica que son días naturales"); Capture(w, "10-avisos"); };
            Click(AllNamed<Button>(main, n => n == "Ver avisos" || n.StartsWith("Ver todos")).First());
            var stored = store.Find(e.Id); stored.Options.ReminderDays = -1; store.Save(stored); main.Refresh();
            T.Check(!Has(main, expected), "Al desactivar el aviso desaparece");
        }

        static void Backups()
        {
            string manual = Path.Combine(folder, "usb", "copia-manual.sqlite3");
            BackupWindow.ChooseSavePath = o => manual;
            BackupWindow.ChooseOpenPath = (o, f) => manual;
            int count = store.AllEvents().Count;
            pending = w =>
            {
                Click(w, "Guardar una copia en otra carpeta o USB…");
                T.Check(File.Exists(manual) && Has(w, "Copia guardada"), "Copia manual en otra carpeta desde la interfaz");
                Capture(w, "11-copias");
            };
            Click(main, "Copias de seguridad");
            var extra = Save("Actividad posterior a la copia", "19/11/2026", "19/11/2026", "Otros");
            main.Refresh();
            pending = w =>
            {
                answers.Enqueue(true);
                Click(w, "Restaurar desde un archivo…");
                T.Check(((BackupWindow)w).Restored, "Restaurar desde la interfaz");
            };
            Click(main, "Copias de seguridad");
            T.Check(store.AllEvents().Count == count && store.Find(extra.Id) == null, "La agenda vuelve al estado de la copia");
            T.Check(confirmations.Last().Contains("Antes de hacerlo, la agenda actual se guardará") && infos.Last().StartsWith("Copia restaurada"), "La restauración avisa de la copia previa y confirma el resultado");
            var safety = store.ListBackups().FirstOrDefault(b => Path.GetFileName(b.Path).StartsWith("Antes-de-restaurar"));
            T.Check(safety != null && Store.Inspect(safety.Path).Events == count + 1, "La copia previa a la restauración conserva la actividad posterior");

            Directory.Delete(store.BackupDirectory, true);
            File.WriteAllText(store.BackupDirectory, "bloqueo");
            Save("Actividad con la copia bloqueada", "20/11/2026", "20/11/2026", "Otros");
            main.Refresh();
            T.Check(Has(main, "Los cambios están guardados, pero la copia de seguridad automática ha fallado"), "El fallo de la copia se muestra sin decir que ha fallado el guardado");
            Capture(main, "12-fallo-copia");
            File.Delete(store.BackupDirectory);
            main.Tick();
            T.Check(Has(main, "Todos los cambios están guardados"), "Al recuperarse, el indicador vuelve a la normalidad");
        }

        static string Snapshot()
        {
            return String.Join("|", store.AllEvents().Select(e => e.Id + e.Title + e.Start.Ticks + e.End.Ticks + e.StartMinute + e.EndMinute + XmlData.Write(e.Options)))
                + String.Join("|", store.Categories().Select(c => c.Name + c.Color + c.Position)) + XmlData.Write(store.Calendar);
        }

        static TodaySummaryWindow ShowSummary(string date, string capture = null)
        {
            var w = new TodaySummaryWindow(store, T.D(date)) { Owner = main };
            w.Show(); Pump();
            if (capture != null) Capture(w, capture);
            return w;
        }
        static List<string> SummaryItems(Window w) { return AllNamed<Border>(w, n => n.StartsWith("Resumen: ")).Select(b => AutomationProperties.GetName(b).Substring(9)).ToList(); }

        static void Summary()
        {
            Save("Ausencia: tutora de 4º B", "24/11/2026", "24/11/2026", "Ausencia de profesorado", e => e.AllDay = true);
            Save("Reunión de equipo directivo", "24/11/2026", "24/11/2026", "Reunión", e => { e.StartMinute = 570; e.EndMinute = 630; e.Options.Group = "Equipo directivo"; e.Options.Location = "Despacho"; e.Options.Responsible = "Dirección"; });
            var taller = Save("Taller de huerto", "23/11/2026", "27/11/2026", "Charla", e =>
            {
                e.StartMinute = 720; e.EndMinute = 780;
                e.Options.ExcludedDates.Add(T.D("26/11/2026"));
                e.Options.Changes.Add(new OccurrenceChange { Date = T.D("25/11/2026"), Title = "Taller de huerto (invernadero)", Notes = "", StartMinute = 720, EndMinute = 780 });
                e.Options.Changes.Add(new OccurrenceChange { Date = T.D("27/11/2026"), Title = "Taller de huerto", Notes = "", StartMinute = 720, EndMinute = 780, MovedTo = T.D("01/12/2026") });
            });
            Save("Semana de la lectura", "11/12/2026", "14/12/2026", "Celebración", e => e.AllDay = true);
            Save("Mercadillo solidario", "12/12/2026", "12/12/2026", "Celebración", e => { e.Options.AllowNonSchool = true; e.StartMinute = 600; e.EndMinute = 780; });
            for (int i = 0; i < 12; i++) Save("Entrevista con familias " + (i + 1), "30/11/2026", "30/11/2026", "Reunión", e => { e.StartMinute = 900 + i * 15; e.EndMinute = 910 + i * 15; e.Options.Location = "Tutoría"; });
            main.Refresh();
            string before = Snapshot();

            var w = ShowSummary("24/11/2026", "17-resumen-con-actividades");
            var items = SummaryItems(w);
            T.Check(Has(w, "Tu agenda de hoy") && Has(w, "Martes, 24/11/2026"), "Encabezado «Tu agenda de hoy» con día de la semana y fecha en español");
            T.Check(items.Count == 3 && items[0] == "Todo el día, Ausencia: tutora de 4º B, Ausencia de profesorado" && items[1].StartsWith("09:30–10:30, Reunión de equipo directivo") && items[2].StartsWith("12:00–13:00, Taller de huerto"), "Orden: primero todo el día y después por hora, con horario y título");
            T.Check(Has(w, "Grupos: Equipo directivo · Lugar: Despacho · Responsable: Dirección"), "Grupo, lugar y responsable en una sola línea cuando están registrados");
            var card = AllNamed<Border>(w, n => n.Contains("Taller de huerto")).First();
            var swatch = Logical(card).OfType<Border>().FirstOrDefault(b => b.Width == 11);
            string charla = store.Categories().First(c => c.Name == "Charla").Color;
            T.Check(swatch != null && ((SolidColorBrush)swatch.Background).Color == Theme.Tint(charla, 0).Color && Has(card, "Charla"), "Categoría con su nombre y el mismo color que en la agenda");
            T.Check(!w.Topmost && w.WindowState == WindowState.Normal && w.ActualWidth <= 520 && w.ActualHeight <= 640, "Ventana compacta, no queda siempre encima y no ocupa toda la pantalla");
            CheckLayout(w, "Resumen sin botones recortados");
            w.Close();

            w = ShowSummary("25/11/2026");
            T.Check(SummaryItems(w).Any(n => n.Contains("Taller de huerto (invernadero)")) && Has(w, "Cambios solo en esta fecha"), "Respeta la modificación de una sola fecha");
            w.Close();
            w = ShowSummary("26/11/2026", "18-resumen-sin-actividades");
            T.Check(SummaryItems(w).Count == 0 && Has(w, "Hoy no tienes actividades programadas") && !Has(w, "No se han podido leer"), "Fecha excluida: «Hoy no tienes actividades programadas»");
            w.Close();
            w = ShowSummary("27/11/2026");
            T.Check(SummaryItems(w).Count == 0, "La fecha trasladada no aparece en su día original");
            w.Close();
            w = ShowSummary("01/12/2026");
            T.Check(SummaryItems(w).Any(n => n.Contains("Taller de huerto")) && Has(w, "Trasladada desde el 27/11/2026"), "La fecha trasladada aparece en su nuevo día");
            w.Close();
            w = ShowSummary("28/11/2026");
            T.Check(Has(w, "Día no lectivo: Fin de semana") && Has(w, "Hoy no tienes actividades programadas"), "Sábado: motivo no lectivo y sin actividades ordinarias");
            w.Close();
            w = ShowSummary("08/12/2026");
            T.Check(Has(w, "Día no lectivo: Día de la Inmaculada Concepción"), "Festivo: indica el motivo");
            w.Close();
            w = ShowSummary("12/12/2026", "19-resumen-excepcion-sabado");
            items = SummaryItems(w);
            T.Check(items.Count == 1 && items[0].Contains("Mercadillo solidario") && Has(w, "Excepción: día no lectivo"), "Sábado con excepción expresa: solo la actividad autorizada (no la del intervalo)");
            w.Close();
            w = ShowSummary("13/12/2026");
            T.Check(SummaryItems(w).Count == 0, "Domingo dentro de un intervalo: sin actividades");
            w.Close();
            w = ShowSummary("14/12/2026");
            T.Check(SummaryItems(w).Any(n => n.Contains("Semana de la lectura")), "El intervalo continúa el lunes siguiente");
            w.Close();

            w = ShowSummary("30/11/2026");
            w.Width = w.MinWidth; w.Height = w.MinHeight; Pump();
            T.Check(SummaryItems(w).Count == 12 && Logical(w).OfType<ScrollViewer>().Any(s => s.ScrollableHeight > 0), "Con muchas actividades se puede desplazar para verlas todas");
            CheckLayout(w, "Resumen en tamaño mínimo: botones visibles");
            Capture(w, "20-resumen-muchas-minimo");
            w.Close();

            var failing = new TodaySummaryWindow(() => { throw new StoreException(10, "No se pudo leer la agenda. Error de lectura o escritura en el disco."); }, T.D("24/11/2026")) { Owner = main };
            failing.Show(); Pump();
            T.Check(failing.LoadFailed && Has(failing, "No se han podido leer los datos de la agenda") && Has(failing, "no significa que no haya actividades") && !Has(failing, "Hoy no tienes actividades programadas"), "Error de lectura: mensaje comprensible, no se confunde con «no hay actividades»");
            Capture(failing, "21-resumen-error");
            failing.Close();

            T.Check(Snapshot() == before && store.AllEvents().Count > 0, "Mostrar el resumen no modifica ninguna actividad, categoría ni calendario");

            main.Select(T.D("10/05/2027")); main.SetView("Mes");
            pending = x =>
            {
                T.Check(x is TodaySummaryWindow && Has(x, Format.LongDate(DateTime.Today)) && app.Windows.OfType<TodaySummaryWindow>().Count() == 1, "El botón «Resumen de hoy» abre un único resumen del día actual");
                Click(x, "Cerrar");
            };
            Click(main, "Resumen de hoy");
            T.Check(main.CurrentView == "Mes" && main.SelectedDate == T.D("10/05/2027"), "«Cerrar» cierra solo el resumen y deja la agenda como estaba");
            pending = x => Click(x, "Abrir agenda");
            Click(main, "Resumen de hoy");
            T.Check(main.CurrentView == "Día" && main.SelectedDate == DateTime.Today, "«Abrir agenda» lleva a la agenda en el día actual");
            pending = x => { };
            Click(main, "Resumen de hoy");
            T.Check(Snapshot() == before, "Consultarlo varias veces sigue sin modificar datos");
        }

        // Uses a key of its own instead of the real Run key, and checks that the real one is left as it was.
        static void SignInOption()
        {
            const string realKey = @"Software\Microsoft\Windows\CurrentVersion\Run", testRoot = @"Software\AgendaClara.Pruebas";
            Func<string> real = () =>
            {
                using (var k = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(realKey))
                using (var s = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(@"Software\AgendaClara"))
                    return (k == null ? null : k.GetValue("AgendaClara") as string) + "|" + (s == null ? "" : String.Join(",", s.GetValueNames()));
            };
            string realBefore = real();
            string saved = global::AgendaClara.Startup.KeyPath, savedSettings = global::AgendaClara.Startup.SettingsPath;
            global::AgendaClara.Startup.KeyPath = testRoot + @"\Run";
            global::AgendaClara.Startup.SettingsPath = testRoot + @"\Ajustes";
            try
            {
                Microsoft.Win32.Registry.CurrentUser.DeleteSubKeyTree(testRoot, false);
                var w = ShowSummary("24/11/2026");
                var check = Named<CheckBox>(w, "Mostrar al iniciar Windows");
                T.Check(check != null && check.IsChecked == false, "El resumen ofrece «Mostrar al iniciar Windows», desmarcado si no está activado");
                CheckLayout(w, "Resumen con la casilla: botones sin recortes");
                check.IsChecked = true; Pump();
                string exe = typeof(Store).Assembly.Location;
                string expected = "\"" + exe + "\" --resumen --agenda \"" + store.DatabasePath + "\"";
                T.Check(global::AgendaClara.Startup.Registered() == expected, "Al marcarla, Windows abrirá el resumen de esta agenda al iniciar sesión");
                T.Check(File.Exists(exe), "La orden apunta al ejecutable de Agenda Clara");
                Capture(w, "23-resumen-inicio-windows");
                w.Close();
                w = ShowSummary("24/11/2026");
                T.Check(Named<CheckBox>(w, "Mostrar al iniciar Windows").IsChecked == true, "Al volver a abrir el resumen, la casilla aparece marcada");
                Named<CheckBox>(w, "Mostrar al iniciar Windows").IsChecked = false; Pump();
                T.Check(!global::AgendaClara.Startup.IsEnabled, "Al desmarcarla, deja de abrirse al iniciar sesión");
                w.Close();
                T.Check(global::AgendaClara.Startup.Command(global::AgendaClara.Program.DefaultDatabasePath()) == "\"" + exe + "\" --resumen", "Con la agenda personal la orden no lleva ruta de archivo");
                var failing = new TodaySummaryWindow(() => { throw new StoreException(10, "Error simulado"); }, T.D("24/11/2026"), store.DatabasePath) { Owner = main };
                failing.Show(); Pump();
                T.Check(Named<CheckBox>(failing, "Mostrar al iniciar Windows") != null, "Con error de lectura se puede desactivar igualmente");
                failing.Close();

                // On by default: opening the personal agenda turns it on unless the user unticked it.
                Microsoft.Win32.Registry.CurrentUser.DeleteSubKeyTree(testRoot, false);
                global::AgendaClara.Startup.ApplyDefault(store.DatabasePath);
                T.Check(global::AgendaClara.Startup.Registered() == expected, "Activado por defecto sin que el usuario marque nada");
                w = ShowSummary("24/11/2026");
                T.Check(Named<CheckBox>(w, "Mostrar al iniciar Windows").IsChecked == true, "La casilla aparece marcada de serie");
                Named<CheckBox>(w, "Mostrar al iniciar Windows").IsChecked = false; Pump();
                w.Close();
                global::AgendaClara.Startup.ApplyDefault(store.DatabasePath);
                T.Check(!global::AgendaClara.Startup.IsEnabled && global::AgendaClara.Startup.OptedOut, "Si el usuario la desmarca, no se vuelve a activar sola al abrir la agenda");
                w = ShowSummary("24/11/2026");
                Named<CheckBox>(w, "Mostrar al iniciar Windows").IsChecked = true; Pump();
                w.Close();
                T.Check(global::AgendaClara.Startup.IsEnabled && !global::AgendaClara.Startup.OptedOut, "Al volver a marcarla se activa de nuevo");
                using (var k = Microsoft.Win32.Registry.CurrentUser.CreateSubKey(global::AgendaClara.Startup.KeyPath)) k.SetValue("NexoCentroExperimental", "\"C:\\Antigua\\AgendaClara.exe\" --resumen");
                global::AgendaClara.Startup.ApplyDefault(store.DatabasePath);
                T.Check(global::AgendaClara.Startup.Registered() == expected, "Tras instalar otra versión, apunta sola al programa que se abre");
            }
            finally
            {
                global::AgendaClara.Startup.KeyPath = saved;
                global::AgendaClara.Startup.SettingsPath = savedSettings;
                Microsoft.Win32.Registry.CurrentUser.DeleteSubKeyTree(testRoot, false);
            }
            T.Check(real() == realBefore, "Las pruebas no modifican el inicio de Windows real");
        }

        static void Sizes()
        {
            main.Select(T.D("10/05/2027")); main.SetView("Mes");
            foreach (var size in new[] { new Size(960, 560), new Size(1100, 700), new Size(1280, 800) })
            {
                main.WindowState = WindowState.Normal; main.Width = size.Width; main.Height = size.Height; Pump();
                string label = (int)size.Width + "×" + (int)size.Height;
                CheckLayout(main, "Ventana principal a " + label + ": botones e indicadores sin recortes (vista mensual)");
                Capture(main, "13-principal-" + label);
                main.SetView("Semana"); CheckLayout(main, "Ventana principal a " + label + " (vista semanal)");
                main.SetView("Mes");
            }
            T.Check(main.MinWidth <= 960 && main.MinHeight <= 560 && main.ResizeMode == ResizeMode.CanResize, "Ventana redimensionable con tamaño mínimo apto para portátiles");
            main.WindowState = WindowState.Maximized; Pump();
            T.Check(main.WindowState == WindowState.Maximized, "Maximizar");
            main.WindowState = WindowState.Minimized; Pump();
            T.Check(main.WindowState == WindowState.Minimized, "Minimizar");
            main.WindowState = WindowState.Normal; main.Width = 1360; main.Height = 900; Pump();
            main.Select(T.D("10/05/2027"));
            Edit(CardOn("Reunión 1"), e =>
            {
                e.Width = e.MinWidth; e.Height = e.MinHeight; Pump();
                CheckLayout(e, "Formulario en tamaño mínimo: botones visibles");
                Capture(e, "14-editor-minimo");
                Click(e, "Cancelar");
            });
            pending = w => { w.Width = w.MinWidth; w.Height = w.MinHeight; Pump(); CheckLayout(w, "Copias de seguridad en tamaño mínimo"); };
            Click(main, "Copias de seguridad");
            pending = w => { w.Width = w.MinWidth; w.Height = w.MinHeight; Pump(); CheckLayout(w, "Calendario escolar en tamaño mínimo"); Capture(w, "15-calendario-minimo"); };
            Click(main, "Calendario escolar");
        }

        static void Reopen()
        {
            int count = store.AllEvents().Count;
            main.Close();
            var again = new MainWindow(store); again.Show(); Pump();
            T.Check(Has(again, Format.Count(count, "actividad", "actividades")), "Cerrar y reabrir la ventana conserva la agenda");
            again.Close();
        }
    }
}
