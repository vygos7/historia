@echo off
powershell.exe -NoProfile -File "%~dp0Compilar.ps1" %*
pause
