using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Automation;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using AgendaClara;
static class GoogleUiTests
{
    static int checks;
    static void Check(bool value,string text){if(!value)throw new Exception(text);checks++;Console.WriteLine("OK · "+text);}
    static IEnumerable<DependencyObject> Tree(DependencyObject root){yield return root;foreach(var x in LogicalTreeHelper.GetChildren(root)){var d=x as DependencyObject;if(d!=null)foreach(var child in Tree(d))yield return child;}}
    static void Pump(Window window){for(int i=0;i<5;i++){window.UpdateLayout();var frame=new DispatcherFrame();window.Dispatcher.BeginInvoke(DispatcherPriority.Background,new Action(()=>frame.Continue=false));Dispatcher.PushFrame(frame);}}
    static void Click(Window window,string label){Tree(window).OfType<Button>().Single(b=>b.Content as string==label).RaiseEvent(new RoutedEventArgs(Button.ClickEvent));Pump(window);}
    [STAThread] static int Main(string[] args)
    {
        string root=Path.Combine(Path.GetTempPath(),"NexoCentroExperimental","validacion-ui-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(root);
        try
        {
            Format.ApplyCulture();ExperimentalIsolation.PathForWrite(root);
            var app=new Application{ShutdownMode=ShutdownMode.OnExplicitShutdown};Theme.Install(app);
            const string template="https://docs.google.com/forms/d/e/TEST/viewform?entry.1=__NEXO_CODE__&entry.2=__NEXO_TITLE__&entry.3=__NEXO_DATE__&entry.4=__NEXO_GROUP__";
            File.WriteAllText(Path.Combine(root,"google-formulario.xml"),XmlData.Write(new GoogleEvaluationSettings{PrefillTemplate=template}));
            using(var store=new Store(Path.Combine(root,"agenda.sqlite3"),false))
            {
                var e=new AgendaEvent{Title="Salida sintética al cine & teatro",Start=new DateTime(2026,11,5),End=new DateTime(2026,11,5),AllDay=true};e.Options.Group="3.º A";e.Options.AllowNonSchool=true;store.StampNew(e);store.Save(e);
                var main=new MainWindow(store);main.Show();Pump(main);Check(main.Title.Contains("EXPERIMENTAL"),"La ventana principal identifica la edición experimental");
                var window=new GoogleEvaluationsWindow(store,e.Id){Owner=main};window.Show();Pump(window);
                Check(window.Title.Contains("EXPERIMENTAL"),"El panel de Google muestra EXPERIMENTAL");
                Check(Tree(window).OfType<TextBlock>().Any(t=>t.Text.Contains("Modo local")),"Explica que la recogida automática necesita el servidor experimental");
                Check(Tree(window).OfType<ComboBox>().First().SelectedItem!=null,"Selecciona la actividad guardada");
                Click(window,"Generar enlace de evaluación");
                var link=Tree(window).OfType<TextBox>().Single(t=>t.IsReadOnly&&t.Text.StartsWith("https://docs.google.com/"));
                Check(link.Text.Contains("NCX-"),"Genera un código de actividad");Check(link.Text.Contains("%26"),"Escapa caracteres especiales del título");Check(link.Text.Contains("2026-11-05"),"Incluye la fecha guardada");
                string originalLink=link.Text;Click(window,"Generar enlace de evaluación");Check(link.Text==originalLink,"El enlace no cambia al volver a generarlo");
                Check(!store.Find(e.Id).Options.Memory.HasContent,"Generar el enlace no inventa ni rellena una memoria");
                Click(window,"Consultar Google ahora");Check(Tree(window).OfType<TextBlock>().Any(t=>t.Text.Contains("sólo funciona en el servidor experimental")),"La demo local informa del requisito sin intentar conectarse a Google");
                Check(!Tree(window).OfType<PasswordBox>().Single().IsEnabled,"La demo no guarda secretos de Google");
                var content=(FrameworkElement)window.Content;Pump(window);var image=new RenderTargetBitmap((int)Math.Ceiling(content.ActualWidth),(int)Math.Ceiling(content.ActualHeight),96,96,PixelFormats.Pbgra32);image.Render(content);var png=new PngBitmapEncoder();png.Frames.Add(BitmapFrame.Create(image));using(var file=File.Create(Path.Combine(root,"google-panel.png")))png.Save(file);
                window.Close();main.Close();Check(store.IntegrityCheck()=="ok","La agenda ficticia sigue íntegra");
            }
            app.Shutdown();Console.WriteLine("RESUMEN: "+checks+" comprobaciones Windows correctas; 0 fallos.");Console.WriteLine("Resultados y captura: "+root);return 0;
        }
        catch(Exception ex){Console.Error.WriteLine("FALLO: "+ex);Console.Error.WriteLine("Datos sintéticos de prueba: "+root);return 1;}
    }
}
