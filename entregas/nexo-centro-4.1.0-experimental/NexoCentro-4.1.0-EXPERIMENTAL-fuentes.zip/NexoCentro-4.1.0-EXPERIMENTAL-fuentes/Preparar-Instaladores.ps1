throw "Esta edición experimental se entrega portátil y en código fuente. No ejecutes el empaquetado del instalador estable. Consulta LEEME-EXPERIMENTAL.md."
