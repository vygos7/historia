# Fuentes AgendaClara 4.0.1 / instalador 1.2.0

Consulta INFORME-HTTPS.md y LEEME-PRIMERO.md en la raíz del paquete. El código de esta entrega repara confianza HTTPS, conservación de configuración y diagnóstico. Los paquetes nuevos se cifran y su clave se comunica por separado.

Desarrollo: SDK .NET 10, .NET Framework 4.8, Windows x64 y paquetes NuGet de los proyectos. aplicacion/Compilar.ps1 publica cliente y servidor. instalador/Compilar.ps1 recompila asistentes; si faltan los ZIP de payload, los recupera de ../../Instalar-AgendaClara.exe distribuido junto a estas fuentes. Para incorporar cambios nuevos de aplicación, publica los proyectos, crea ZIP que contengan las carpetas raíz cliente y servidor y pásalos con -ClienteZip y -ServidorZip. No uses payloads antiguos para comprobar código nuevo.

Pruebas: aplicacion/pruebas-locales.csproj; aplicacion/pruebas-tls/AgendaClara.TlsTests.csproj; instalador/pruebas/SimpleTests.cs con instalador/Compilar-Pruebas.ps1. Este último necesita los payloads, cliente publicado en payload-root/cliente y el instalador cliente compilado. Las pruebas de instalación añaden una raíz sintética y certificados personales; Windows puede pedir intervención tanto al añadir como al retirar la raíz. Solo deben ejecutarse en un entorno de desarrollo. Usa rutas cortas para las pruebas SQLite.

La batería TLS recibe una carpeta nueva de pruebas. La batería de integración recibe carpeta nueva y ruta de pruebas/fixtures/agenda-v4-sintetica.sqlite3. Ninguna necesita la agenda real. Los scripts son herramientas de desarrollo, no instrucciones para los usuarios del colegio.

Los resultados de esta entrega y sus límites constan en el informe. No se distribuyen los certificados, claves ni instaladores de puesto generados por las pruebas.
