# Continuidad de la edición experimental

Objetivo autorizado: copiar la versión estable e incorporar enlaces prerrellenados y recogida de evaluaciones de un formulario único de Google, sin modificar la versión estable ni la instalación del colegio.

Base estable: `/workspace/nexo-centro`, versión 4.0.4 interfaz r1. Entrega y fuentes estables conservadas. Nueva copia: `/workspace/nexo-centro-4.1.0-experimental`, versión 4.1.0 experimental-google-r1.

Estado: código implementado, cliente y servidor compilados desde Linux. Pruebas locales en Evidencias de la entrega. Pendiente ejecución Windows nativa (incluido asistente PowerShell), despliegue por el propietario de una COPIA del formulario y prueba de ida/vuelta real con Google. No hay integración desplegada ni credenciales Google guardadas en el proyecto.

No publicar esta versión en GitHub sin autorización específica. No ejecutar Preparar-Instaladores.ps1 ni instalador/Compilar.ps1: se bloquean expresamente para evitar reutilizar el servidor estable congelado. Distribución de pruebas portátil; el servidor experimental utiliza loopback 7444 y datos nuevos.

Las memorias se aplican con Store.Apply y actor integracion-google; no se asignan por cercanía de fecha. Un código y una identidad persistente vinculan actividad, generación, nombre, fecha efectiva y grupo. Los casos ambiguos son pendientes y requieren confirmación. La restauración cambia generación e invalida la aplicación automática de enlaces anteriores.

No cambiar AddressFallbackHandler.cs, ServerTlsTrust.cs, HttpRequestTiming.cs, Store.cs, StoreNetwork.cs, Planning.cs o ActivityData.cs sin una necesidad demostrada. Se mantienen iguales a la base estable. Google usa un cliente HTTP propio y no cambia el timeout de la API de la agenda.

El archivo VERSION-ESTABLE-PROTEGIDA.json permite volver a comprobar los 107 archivos protegidos del entorno original. No asumir que una compilación correcta equivale a una prueba real en Windows o con Google.
