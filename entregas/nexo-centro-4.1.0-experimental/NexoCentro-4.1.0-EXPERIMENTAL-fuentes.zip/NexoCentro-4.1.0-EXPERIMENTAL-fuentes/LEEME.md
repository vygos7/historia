# Edición EXPERIMENTAL 4.1.0: empezar aquí

Esta carpeta es una copia nueva para la integración de evaluaciones con Google Forms. Consulta **LEEME-EXPERIMENTAL.md** y utiliza **Compilar-Experimental.ps1**.

No ejecutes los procedimientos antiguos de actualización ni sustituyas la aplicación estable. Los informes 4.0.x se conservan como antecedentes técnicos; no son instrucciones de instalación de esta edición experimental.
