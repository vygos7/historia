@echo off
setlocal
if not exist "%LOCALAPPDATA%\NexoCentroExperimental\CompartidoGoogle\TrabajoCompartido.xml" (
 echo Primero ejecuta Preparar-servidor-experimental.ps1 siguiendo el manual.
 pause
 exit /b 1
)
start "" "%~dp0Cliente\AgendaClara.exe" --agenda "%LOCALAPPDATA%\NexoCentroExperimental\CompartidoGoogle\agenda-local-no-utilizada.sqlite3" --config "%LOCALAPPDATA%\NexoCentroExperimental\CompartidoGoogle\TrabajoCompartido.xml"
