@echo off
setlocal
rem La politica se aplica solo a este proceso; no cambia la configuracion permanente de Windows.
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Preparar-servidor-experimental.ps1"
set "SETUP_RESULT=%ERRORLEVEL%"
pause
exit /b %SETUP_RESULT%
