@echo off
setlocal
if not exist "%LOCALAPPDATA%\NexoCentroExperimental\ServidorGoogle\nexo-experimental.marker" (
 echo Primero ejecuta Preparar-servidor-experimental.ps1 siguiendo el manual.
 pause
 exit /b 1
)
"%~dp0Servidor\AgendaClara.Server.exe" --data "%LOCALAPPDATA%\NexoCentroExperimental\ServidorGoogle"
pause
