@echo off
setlocal
"%~dp0Pruebas-Windows\AgendaClara.Pruebas.exe"
set "TEST_RESULT=%ERRORLEVEL%"
pause
exit /b %TEST_RESULT%
