﻿# Sólo crea un entorno sintético en el perfil del usuario. No crea servicios ni reglas de firewall.
$ErrorActionPreference='Stop'
$edition='NexoCentro-4.1.0-experimental-google-r1'
$profileRoot=Join-Path $env:LOCALAPPDATA 'NexoCentroExperimental'
$data=Join-Path $profileRoot 'ServidorGoogle'
$client=Join-Path $profileRoot 'CompartidoGoogle'
$config=Join-Path $client 'TrabajoCompartido.xml'
$exe=Join-Path $PSScriptRoot 'Servidor/AgendaClara.Server.exe'
$seed=Join-Path $PSScriptRoot 'Datos-iniciales/Agenda-ficticia.sqlite3'
if(-not(Test-Path -LiteralPath $exe)){throw 'Extrae todo el paquete experimental antes de ejecutar este asistente.'}
if(Test-Path -LiteralPath $config){Write-Host 'Ya está preparado. Abre INICIAR-SERVIDOR-EXPERIMENTAL.cmd y después ABRIR-CLIENTE-COMPARTIDO.cmd.';return}
if(Test-Path -LiteralPath $data){throw 'Ya existe una preparación anterior. No se ha borrado ni sustituido. Conserva esa carpeta y revisa la instalación de prueba.'}
Write-Host 'NEXO CENTRO EXPERIMENTAL: prueba en este ordenador, puerto 7444 y escucha sólo en 127.0.0.1.'
Write-Host 'No se actualiza el programa estable, no se instala ningún servicio y no se cambia el cortafuegos.'
Write-Host 'Crea una contraseña NUEVA para el administrador de esta prueba (mínimo 12 caracteres).'
$secure=Read-Host 'Contraseña experimental' -AsSecureString
$pointer=[Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
try{$password=[Runtime.InteropServices.Marshal]::PtrToStringBSTR($pointer)}finally{[Runtime.InteropServices.Marshal]::ZeroFreeBSTR($pointer)}
if($password.Length-lt12-or$password.Length-gt256){throw 'La contraseña debe tener entre 12 y 256 caracteres.'}
$random=New-Object byte[] 32
$rng=[Security.Cryptography.RandomNumberGenerator]::Create()
try{$rng.GetBytes($random)}finally{$rng.Dispose()}
$packagePassword=[Convert]::ToBase64String($random)
function Invoke-Experimental([string[]]$Arguments,[string]$InputPassword){
 $start=New-Object Diagnostics.ProcessStartInfo
 $start.FileName=$exe;$start.UseShellExecute=$false;$start.CreateNoWindow=$true
 $start.RedirectStandardInput=$true;$start.RedirectStandardOutput=$true;$start.RedirectStandardError=$true
 $start.StandardInputEncoding=New-Object Text.UTF8Encoding($false)
 # Las rutas de Windows no contienen comillas. Escapar las barras finales antes del cierre.
 $start.Arguments=($Arguments|ForEach-Object{'"'+([regex]::Replace($_,'(\\*)"','$1$1\"')-replace '(\\+)$','$1$1')+'"'})-join' '
 $process=New-Object Diagnostics.Process
 $process.StartInfo=$start
 try{
  [void]$process.Start();$process.StandardInput.WriteLine($InputPassword);$process.StandardInput.Close()
  $output=$process.StandardOutput.ReadToEndAsync();$errorText=$process.StandardError.ReadToEndAsync();$process.WaitForExit()
  if($process.ExitCode-ne0){throw ($errorText.Result+' '+$output.Result)}
 }finally{$process.Dispose()}
}
try{
 Invoke-Experimental @('init','--data',$data,'--host','127.0.0.1','--network','127.0.0.1/32','--port','7444','--user','AdministradorExperimental','--import',$seed) $password
 # La escucha de esta prueba queda limitada expresamente a este ordenador.
 $serverFile=Join-Path $data 'server.json'
 $settings=Get-Content -LiteralPath $serverFile -Raw|ConvertFrom-Json
 $settings.ListenHost='127.0.0.1'
 [IO.File]::WriteAllText($serverFile,($settings|ConvertTo-Json -Depth 8),(New-Object Text.UTF8Encoding($false)))
 $package=Join-Path $profileRoot ('AccesoTemporal-'+[Guid]::NewGuid().ToString('N'))
 Invoke-Experimental @('enroll','--data',$data,'--name','JefaturaExperimental','--output',$package,'--automatic-role','Jefatura') $packagePassword
 $flags=[Security.Cryptography.X509Certificates.X509KeyStorageFlags]::UserKeySet-bor[Security.Cryptography.X509Certificates.X509KeyStorageFlags]::PersistKeySet
 $certificate=New-Object Security.Cryptography.X509Certificates.X509Certificate2 -ArgumentList @((Join-Path $package 'equipo.pfx'),$packagePassword,$flags)
 $personal=New-Object Security.Cryptography.X509Certificates.X509Store -ArgumentList @('My','CurrentUser')
 try{
  $personal.Open([Security.Cryptography.X509Certificates.OpenFlags]::ReadWrite);$personal.Add($certificate)
  New-Item -ItemType Directory -Path $client|Out-Null
  $document=New-Object Xml.XmlDocument;$element=$document.CreateElement('SharedConfiguration');[void]$document.AppendChild($element)
  $values=[ordered]@{Shared='true';AllowOffline='false';AutomaticAccess='true';ServerUrl='https://127.0.0.1:7444';UserName=([IO.File]::ReadAllText((Join-Path $package 'usuario.txt')).Trim());ClientThumbprint=$certificate.Thumbprint;IndividualDatabase='';ServerAuthority=[Convert]::ToBase64String([IO.File]::ReadAllBytes((Join-Path $package 'servidor-raiz.cer')))}
  foreach($entry in $values.GetEnumerator()){$item=$document.CreateElement($entry.Key);$item.InnerText=$entry.Value;[void]$element.AppendChild($item)}
  $document.Save($config)
 }finally{$personal.Dispose();$certificate.Dispose()}
 # Sólo se retiran los ficheros temporales recién generados por este asistente.
 Remove-Item -LiteralPath $package -Recurse
 Write-Host 'Preparación terminada. No se ha añadido ninguna raíz de confianza global a Windows.'
 Write-Host '1. Abre INICIAR-SERVIDOR-EXPERIMENTAL.cmd y deja esa ventana abierta.'
 Write-Host '2. Abre ABRIR-CLIENTE-COMPARTIDO.cmd.'
 Write-Host '3. En Ajustes > Evaluaciones Google, configura la COPIA de tu formulario.'
}finally{$password=$null;$packagePassword=$null;$secure.Dispose();[Array]::Clear($random,0,$random.Length)}
