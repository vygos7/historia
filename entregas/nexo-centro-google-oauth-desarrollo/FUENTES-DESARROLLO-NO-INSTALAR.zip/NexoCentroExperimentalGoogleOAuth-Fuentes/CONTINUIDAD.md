# Continuidad 4.2.0 Google oficial

Requisito del usuario: uso por personas totalmente principiantes, con cuatro pasos — conectar Google/consentir, elegir formulario, copiar enlace de salida y recibir automáticamente la memoria. No pedir scripts, proyectos, secretos ni plantillas al usuario.

Base estable protegida: /workspace/nexo-centro. Copia 4.1.0 protegida: /workspace/nexo-centro-4.1.0-experimental. Trabajo actual independiente: /workspace/nexo-centro-4.2.0-google.

Implementación: GoogleOfficial.cs (contratos y REST), GoogleOfficialCoordinator.cs (estado y recogida), GoogleDesktopConnect.cs (SDK OAuth PKCE y almacén cifrado), GoogleFormPicker.cs (selector oficial), GoogleLocalRuntime.cs, GoogleEvaluationsWindow.cs y servidor/GoogleOfficialService.cs. Se reutiliza GoogleEvaluationManager para guardar con auditoría y control de concurrencia. El puente Apps Script antiguo ya no se registra en DI ni se expone en la interfaz.

Bloqueo externo real: no hay registro OAuth propio ni acceso administrativo Google Cloud. Assets/GoogleApp.json está vacío deliberadamente. No crear paquetes supuestamente listos ni devolver al usuario una configuración técnica. Consultar ESTADO-GOOGLE.md. No declarar completado el flujo sin probarlo en Google real.

Pruebas: pruebas-google-oficial incluye simuladores REST y selector loopback. pruebas-google conserva la regresión del gestor y puente anterior, sin activar éste en producción. pruebas-core ejecuta las pruebas de datos históricas. pruebas-google-ui compila una prueba WPF específica; ejecución Windows debe documentarse aparte.

No modificar Store.cs, StoreNetwork.cs, AddressFallbackHandler.cs, ServerTlsTrust.cs, HttpRequestTiming.cs, Planning.cs ni ActivityData.cs. Verificar VERSION-ESTABLE-PROTEGIDA.json y BASE-4.1.0-PROTEGIDA.json antes de terminar. Nunca añadir credenciales reales a Git.
