using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using AgendaClara;
public static class Probe
{
    static readonly List<string> log=new List<string>();static string folder;static Application app;
    static void Check(bool ok,string text){log.Add((ok?"CORRECTO: ":"FALLO: ")+text);Console.WriteLine(log.Last());if(!ok)throw new Exception(text);}
    static IEnumerable<DependencyObject> Tree(DependencyObject d){yield return d;foreach(var x in LogicalTreeHelper.GetChildren(d)){var child=x as DependencyObject;if(child!=null)foreach(var y in Tree(child))yield return y;}}
    static void Pump(){foreach(Window w in app.Windows)if(w.IsVisible)w.UpdateLayout();var f=new DispatcherFrame();Dispatcher.CurrentDispatcher.BeginInvoke(DispatcherPriority.Background,new Action(()=>f.Continue=false));Dispatcher.PushFrame(f);}
    static void Wait(Func<bool> done,int seconds=40){var until=DateTime.UtcNow.AddSeconds(seconds);while(!done()&&DateTime.UtcNow<until){Pump();Thread.Sleep(30);}if(!done())throw new Exception("Tiempo agotado esperando un cambio en la interfaz");Pump();}
    static void Click(Window w,string text){var b=Tree(w).OfType<Button>().First(x=>(x.Content as string)==text);if(!b.IsEnabled)throw new Exception("Botón desactivado: "+text);b.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));Pump();}
    static TextBox Title(Window w){return Tree(w).OfType<TextBox>().First(x=>AutomationProperties.GetName(x)=="Título *");}
    static void Capture(Window w,string name)
    {
        var root=(FrameworkElement)w.Content;Pump();int width=(int)(root.ActualWidth+root.Margin.Left+root.Margin.Right),height=(int)(root.ActualHeight+root.Margin.Top+root.Margin.Bottom);
        var image=new RenderTargetBitmap(width,height,96,96,PixelFormats.Pbgra32);var bg=new DrawingVisual();using(var dc=bg.RenderOpen())dc.DrawRectangle(Theme.Background,null,new Rect(0,0,width,height));image.Render(bg);image.Render(root);var enc=new PngBitmapEncoder();enc.Frames.Add(BitmapFrame.Create(image));using(var f=File.Create(Path.Combine(folder,name)))enc.Save(f);
    }
    [STAThread]public static int Main(string[] args)
    {
        folder=Path.GetFullPath(args[0]);Directory.CreateDirectory(folder);app=new Application{ShutdownMode=ShutdownMode.OnExplicitShutdown};Theme.Install(app);Format.ApplyCulture();SynchronizationContext.SetSynchronizationContext(new DispatcherSynchronizationContext(app.Dispatcher));app.DispatcherUnhandledException+=(sender,error)=>{log.Add("ERROR ASINCRONO: "+error.Exception);Console.WriteLine(error.Exception);error.Handled=true;};
        RemoteConnection a=null,b=null;MainWindow main=null;
        try
        {
            if(args.Length>3){bool rejected=false;try{using(var forbidden=new Store(args[3],false)){} }catch(IOException){rejected=true;}Check(rejected,"El cliente no puede abrir la base central en modo individual");}
            var first=SharedConfiguration.Load(args[1]);var second=SharedConfiguration.Load(args[2]);
            string password1=Console.ReadLine(),password2=Console.ReadLine();
            a=new RemoteConnection(first,Path.Combine(folder,"client-a.xml"));b=new RemoteConnection(second,Path.Combine(folder,"client-b.xml"));
            a.ConnectAsync(password1).GetAwaiter().GetResult();b.ConnectAsync(password2).GetAwaiter().GetResult();a.Start();b.Start();
            var store=new Store(a);var other=new Store(b);main=new MainWindow(store);main.Show();Pump();main.SetView("Resultados");
            Check(Tree(main).OfType<TextBlock>().Any(t=>t.Text.Contains("Conectado y sincronizado")),"El cliente WPF muestra conexión y última sincronización");
            var editor=new EventEditor(store.EditSession(),null,null,new DateTime(2026,10,29));editor.Show();Pump();Title(editor).Text="Prueba visual compartida";Click(editor,"Guardar");Wait(()=>editor.Changed);Wait(()=>other.AllEvents().Any(e=>e.Title=="Prueba visual compartida"));
            Check(true,"El formulario WPF guarda por HTTPS y el segundo cliente lo recibe");
            var activity=store.AllEvents().Single(e=>e.Title=="Prueba visual compartida");editor=new EventEditor(store.EditSession(),activity,null,activity.Start);editor.Show();Pump();Title(editor).Text="Borrador que debe conservarse";
            var actual=other.Find(activity.Id);actual.Title="Cambio desde otro ordenador";other.Save(actual);Wait(()=>store.Find(activity.Id).Title==actual.Title);Click(editor,"Guardar");
            Wait(()=>Tree(editor).OfType<TextBlock>().Any(t=>t.Text.Contains("Otra persona")));
            Check(!editor.Changed&&Title(editor).Text=="Borrador que debe conservarse","El conflicto se informa en el editor y conserva lo escrito");Capture(editor,"conflicto-wpf.png");editor.Close();
            Wait(()=>Tree(main).OfType<TextBlock>().Any(t=>t.Text.Contains("Cambio desde otro ordenador")));Check(true,"La ventana principal se actualiza automáticamente ante cambios remotos");Capture(main,"cliente-conectado.png");
            File.WriteAllText(Path.Combine(folder,"ready"),"ok");
            Wait(()=>!a.CanWrite,60);Pump();editor=new EventEditor(store.EditSession(),store.Find(activity.Id),null,activity.Start);editor.Show();Pump();
            var save=Tree(editor).OfType<Button>().Single(x=>(x.Content as string)=="Guardar");
            Check(!save.IsEnabled&&Title(editor).IsReadOnly,"Sin servidor el formulario permite consultar y bloquea edición y guardado");Capture(editor,"cliente-desconectado.png");editor.Close();
            var report=ActivityReports.Build(store.AllEvents(),"Informe generado sin conexión · datos locales");ActivityReports.ExportPdf(((IDocumentPaginatorSource)report).DocumentPaginator,Path.Combine(folder,"informe-desconectado.pdf"));
            Check(new FileInfo(Path.Combine(folder,"informe-desconectado.pdf")).Length>10000,"El cliente WPF genera PDF desde los datos cifrados de consulta sin servidor");
            File.WriteAllText(Path.Combine(folder,"offline"),"ok");Wait(()=>a.CanWrite,60);Pump();Check(Tree(main).OfType<TextBlock>().Any(t=>t.Text.Contains("Conectado y sincronizado")),"La interfaz recupera conexión y edición automáticamente tras reiniciar el servidor");
            log.Add("RESUMEN: 8 comprobaciones de interfaz compartida correctas, 0 fallos.");return 0;
        }
        catch(Exception ex){log.Add("FALLO: "+ex);Console.WriteLine(ex);return 1;}
        finally { if(main!=null)main.Close();if(a!=null)a.Dispose();if(b!=null)b.Dispose();File.WriteAllLines(Path.Combine(folder,"resultado-interfaz-red.txt"),log);app.Shutdown(); }
    }
}

