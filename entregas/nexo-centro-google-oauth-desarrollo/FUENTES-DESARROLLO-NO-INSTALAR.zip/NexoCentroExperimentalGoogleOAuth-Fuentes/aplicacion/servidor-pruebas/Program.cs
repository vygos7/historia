using System.Net;
using System.Net.Sockets;
using System.Text.Json;
using System.Security.Cryptography.X509Certificates;
using AgendaClara;
using AgendaClara.Server;
[assembly:System.Runtime.Versioning.SupportedOSPlatform("windows")]
// Host exclusivo de integración: datos sintéticos y escucha sólo en loopback.
string root=Path.GetFullPath(args[0]);ExperimentalIsolation.Server(root,true);
if(!File.Exists(Path.Combine(root,"server.json")))
{
    var listener=new TcpListener(IPAddress.Loopback,0);listener.Start();int port=((IPEndPoint)listener.LocalEndpoint).Port;listener.Stop();
    var settings=new ServerSettings{ListenHost="127.0.0.1",PublicHost="localhost",Port=port,AllowedNetworks=["127.0.0.1/32"],BackupDirectory=Path.Combine(root,"copias")};
    File.WriteAllText(Path.Combine(root,"server.json"),JsonSerializer.Serialize(settings));
    Certificates.Initialize(root,"127.0.0.1");
    using(var ca=Certificates.Load(root,"authority.pfx"))
    {
        // El certificado del servidor debe permitir nombre e IP sin depender del DNS del colegio.
        using var key=System.Security.Cryptography.RSA.Create(2048);
        var req=new System.Security.Cryptography.X509Certificates.CertificateRequest("CN=localhost",key,System.Security.Cryptography.HashAlgorithmName.SHA256,System.Security.Cryptography.RSASignaturePadding.Pkcs1);
        req.CertificateExtensions.Add(new System.Security.Cryptography.X509Certificates.X509BasicConstraintsExtension(false,false,0,true));
        req.CertificateExtensions.Add(new System.Security.Cryptography.X509Certificates.X509EnhancedKeyUsageExtension(new System.Security.Cryptography.OidCollection{new("1.3.6.1.5.5.7.3.1")},true));
        var san=new System.Security.Cryptography.X509Certificates.SubjectAlternativeNameBuilder();san.AddDnsName("localhost");san.AddIpAddress(IPAddress.Loopback);req.CertificateExtensions.Add(san.Build());
        using var leaf=req.Create(ca,DateTimeOffset.UtcNow.AddMinutes(-1),DateTimeOffset.UtcNow.AddDays(1),System.Security.Cryptography.RandomNumberGenerator.GetBytes(16));using var cert=leaf.CopyWithPrivateKey(key);
        string password=System.Text.Encoding.UTF8.GetString(Certificates.Unprotect(File.ReadAllBytes(Path.Combine(root,"certificate-password.dpapi"))));
        File.WriteAllBytes(Path.Combine(root,"server.pfx"),cert.Export(System.Security.Cryptography.X509Certificates.X509ContentType.Pfx,password));
    }
    SecurityState.Initialize(root,"pruebas","Prueba-Usuario-2026!");
    Certificates.Enroll(root,"diagnostico-prueba","Prueba-Paquete-2026!",Path.Combine(root,"puesto"));
    Certificates.Enroll(root,"revocado-prueba","Prueba-Paquete-2026!",Path.Combine(root,"revocado"));
    using(var cert=System.Security.Cryptography.X509Certificates.X509CertificateLoader.LoadPkcs12FromFile(Path.Combine(root,"revocado","equipo.pfx"),"Prueba-Paquete-2026!"))new SecurityState(root).SetDevice(SecurityState.CertificateId(cert),false);
    string other=Path.Combine(root,"otra-ca");Directory.CreateDirectory(other);Certificates.Initialize(other,"localhost");
    File.WriteAllText(Path.Combine(other,"server.json"),JsonSerializer.Serialize(settings));SecurityState.Initialize(other,"pruebas","Prueba-Usuario-2026!");
    Certificates.Enroll(other,"puesto-ajeno","Prueba-Paquete-2026!",Path.Combine(other,"puesto"));
}
var app=ServerHost.Create(root,[]);
app.Use(async(ctx,next)=>
{
    string fault=File.Exists(Path.Combine(root,"fallo.txt"))?File.ReadAllText(Path.Combine(root,"fallo.txt")):"";
    if((fault=="slow-session" && ctx.Request.Path=="/api/session")||(fault=="slow-snapshot" && ctx.Request.Path=="/api/snapshot"))await Task.Delay(12000,ctx.RequestAborted);
    if(fault=="broken-signalr" && ctx.Request.Path.StartsWithSegments("/changes")){ctx.Response.StatusCode=503;return;}
    if(fault=="slow-signalr" && ctx.Request.Path.StartsWithSegments("/changes"))await Task.Delay(60000,ctx.RequestAborted);
    await next();
});
await app.StartAsync();File.WriteAllText(Path.Combine(root,"listo.txt"),"listo");await app.WaitForShutdownAsync();
