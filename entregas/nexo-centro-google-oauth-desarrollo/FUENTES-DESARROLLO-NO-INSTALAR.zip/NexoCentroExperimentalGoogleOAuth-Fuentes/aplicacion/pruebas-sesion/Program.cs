// La asamblea del servidor está marcada Windows. Esta batería ejercita sólo seguridad,
// XML y middleware portables; no llama a DPAPI, SQLite de Windows ni instala servicios.
#pragma warning disable CA1416
using System.Diagnostics;
using System.Net;
using System.Net.Http.Headers;
using System.Net.Security;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Security.AccessControl;
using System.Security.Principal;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.Json;
using AgendaClara;
using AgendaClara.Server;
using Microsoft.AspNetCore.Hosting.Server;
using Microsoft.AspNetCore.Hosting.Server.Features;
using Microsoft.AspNetCore.Server.Kestrel.Https;

static class SessionTests
{
    static int checks;
    const string Password="Sintetica-Sesion-2026!";
    static void Check(bool value,string text){if(!value)throw new Exception(text);Console.WriteLine("CORRECTO: "+text);checks++;}
    static void Put(byte[] b,int offset,uint value)=>BitConverter.GetBytes(value).CopyTo(b,offset);
    static void Port(byte[] b,int offset,int value){b[offset]=(byte)(value>>8);b[offset+1]=(byte)value;}
    static void Tables()
    {
        Check(DiagnosticTarget.WithIPv4("https://jefatura:7443/","192.168.6.135")=="https://192.168.6.135:7443/","La comparación IPv4 mantiene HTTPS y el puerto 7443");
        bool targetDenied=false;try{DiagnosticTarget.WithIPv4("https://jefatura:7443/","8.8.8.8");}catch(ArgumentException){targetDenied=true;}
        Check(targetDenied,"La comparación no envía credenciales a una IPv4 pública");
        targetDenied=false;try{DiagnosticTarget.WithIPv4("http://jefatura:7443/","192.168.6.135");}catch(ArgumentException){targetDenied=true;}
        Check(targetDenied,"La comparación no admite HTTP sin TLS");
        byte[] v4=new byte[28];Put(v4,0,1);Put(v4,4,3);
        IPAddress.Parse("192.168.4.153").GetAddressBytes().CopyTo(v4,8);Port(v4,12,51234);
        IPAddress.Parse("192.168.6.135").GetAddressBytes().CopyTo(v4,16);Port(v4,20,7443);Put(v4,24,1234);
        var rows=HttpSocketObservation.Parse(v4,2,1234,7443);
        Check(rows.Count==1 && rows[0].Contains("local=192.168.4.153:51234") && rows[0].Contains("remoto=192.168.6.135:7443 SYN_SENT"),"Tabla IPv4: dirección local/remota, puerto de red y SYN_SENT");
        Check(HttpSocketObservation.Parse(v4,2,9999,7443).Count==0 && HttpSocketObservation.Parse(v4,2,1234,443).Count==0,"No se atribuyen sockets de otro PID o puerto");
        byte[] v6=new byte[60];Put(v6,0,1);IPAddress.IPv6Loopback.GetAddressBytes().CopyTo(v6,4);Port(v6,24,51235);
        IPAddress.Parse("fe80::b9a4:e0bd:ea6e:f226").GetAddressBytes().CopyTo(v6,28);Put(v6,44,10);Port(v6,48,7443);Put(v6,52,5);Put(v6,56,1234);
        rows=HttpSocketObservation.Parse(v6,23,1234,7443);
        Check(rows.Count==1 && rows[0].Contains("[fe80::b9a4:e0bd:ea6e:f226%10]:7443 ESTABLISHED"),"Tabla IPv6: se conserva el ámbito de enlace y el estado");
        bool invalid=false;try{HttpSocketObservation.Parse(new byte[]{2,0,0,0},2,1234,7443);}catch(InvalidOperationException){invalid=true;}
        Check(invalid,"Una tabla TCP truncada no se interpreta como ausencia de conexiones");
        string id=SessionDiagnostics.RequestId("\r\nBearer secreto");Check(Guid.TryParseExact(id,"N",out _) && !id.Contains("secreto"),"El identificador HTTP no permite inyectar texto en el registro");
    }
    static async Task Security(string root)
    {
        Directory.CreateDirectory(root);SecurityState.Initialize(root,"prueba",Password);var security=new SecurityState(root);
        security.Enroll(new TrustedDevice{Name="puesto-sintetico",Thumbprint="synthetic",AutomaticUser="prueba"});
        List<string> phases=[];var session=security.Login(new LoginRequest{UserName="prueba",Password=Password},"synthetic",phases.Add);
        Check(phases.SequenceEqual(new[]{"security_lock_wait","security_lock_acquired","password_check_start","password_check_end","credentials_accepted","session_save_start","session_save_end"}),"La autenticación informa de bloqueo, contraseña y persistencia por separado");
        Check(security.Authenticate(session.AccessToken,"synthetic")?.Admin==true,"Instrumentar no cambia permisos ni autorización");
        var renewed=security.Login(new LoginRequest{UserName="prueba",RefreshToken=session.RefreshToken},"synthetic");
        Check(security.Authenticate(renewed.AccessToken,"synthetic")!=null,"La renovación de sesión sigue funcionando");
        bool expired=false;try{security.Login(new LoginRequest{UserName="prueba",RefreshToken=session.RefreshToken},"synthetic");}catch(UnauthorizedAccessException){expired=true;}
        Check(expired,"El token de renovación consumido no se puede reutilizar");
        var automatic=security.Login(new LoginRequest{UserName="prueba",Automatic=true},"synthetic",_=>throw new IOException("Observador averiado"));
        Check(security.Authenticate(automatic.AccessToken,"synthetic")!=null,"Un observador averiado no rompe el acceso automático");
        using var entered=new ManualResetEventSlim();using var release=new ManualResetEventSlim();using var waiting=new ManualResetEventSlim();
        bool acquired=false;
        var first=Task.Run(()=>security.Login(new LoginRequest{UserName="prueba",Automatic=true},"synthetic",p=>{if(p=="security_lock_acquired"){entered.Set();if(!release.Wait(TimeSpan.FromSeconds(5)))throw new Exception("Barrera");}}));
        Check(entered.Wait(TimeSpan.FromSeconds(5)),"Primera autenticación entra en el bloqueo de seguridad");
        var second=Task.Run(()=>security.Login(new LoginRequest{UserName="prueba",Automatic=true},"synthetic",p=>{if(p=="security_lock_wait")waiting.Set();if(p=="security_lock_acquired")acquired=true;}));
        try{Check(waiting.Wait(TimeSpan.FromSeconds(5)) && !acquired,"Una segunda autenticación registra la espera antes de obtener el bloqueo");}
        finally{release.Set();}
        await Task.WhenAll(first,second);Check(acquired,"La espera se resuelve al liberar el bloqueo; sin interbloqueo");
        security.SetDevice("synthetic",false);bool denied=false;try{security.Login(new LoginRequest{UserName="prueba",Automatic=true},"synthetic");}catch(UnauthorizedAccessException){denied=true;}
        Check(denied,"Un puesto revocado sigue siendo rechazado");
    }
    static X509Certificate2 Certificate(string name,bool server)
    {
        using var key=RSA.Create(2048);var request=new CertificateRequest("CN="+name,key,HashAlgorithmName.SHA256,RSASignaturePadding.Pkcs1);
        request.CertificateExtensions.Add(new X509BasicConstraintsExtension(false,false,0,true));
        request.CertificateExtensions.Add(new X509EnhancedKeyUsageExtension(new OidCollection{new(server?"1.3.6.1.5.5.7.3.1":"1.3.6.1.5.5.7.3.2")},true));
        if(server){var san=new SubjectAlternativeNameBuilder();san.AddDnsName("localhost");request.CertificateExtensions.Add(san.Build());}
        return TlsFixtureKeys.ForTls(request.CreateSelfSigned(DateTimeOffset.UtcNow.AddMinutes(-1),DateTimeOffset.UtcNow.AddDays(1)));
    }
    static async Task Http(string root)
    {
        Directory.CreateDirectory(root);SecurityState.Initialize(root,"prueba",Password);var security=new SecurityState(root);
        using var serverCert=Certificate("localhost",true);using var clientCert=Certificate("puesto-sintetico",false);
        string device=SecurityState.CertificateId(clientCert);security.Enroll(new TrustedDevice{Name="puesto-sintetico",Thumbprint=device});
        await using var diagnostics=new SessionDiagnostics(root);
        var builder=WebApplication.CreateSlimBuilder();builder.Logging.ClearProviders();builder.Logging.AddConsole().SetMinimumLevel(LogLevel.Warning).AddFilter("Microsoft.AspNetCore.Server.Kestrel.Https",LogLevel.Debug);
        builder.WebHost.ConfigureKestrel(k=>k.Listen(IPAddress.Loopback,0,l=>l.UseHttps(new HttpsConnectionAdapterOptions{
            ServerCertificate=serverCert,ClientCertificateMode=ClientCertificateMode.RequireCertificate,
            ClientCertificateValidation=(cert,chain,errors)=>cert.RawData.SequenceEqual(clientCert.RawData)})));
        await using var app=builder.Build();
        app.Use((HttpContext ctx,RequestDelegate next)=>diagnostics.InvokeAsync(ctx,next));
        app.MapPost("/api/session",async context=>
        {
            var trace=SessionTrace.From(context);trace.Mark("body_read_start");
            using var reader=new StreamReader(context.Request.Body);var input=XmlData.Read<LoginRequest>(await reader.ReadToEndAsync());trace.Mark("body_read_end");
            try
            {
                var cert=await context.Connection.GetClientCertificateAsync();
                var session=security.Login(input,SecurityState.CertificateId(cert),trace.Mark);
                context.Response.ContentType="application/xml";await context.Response.WriteAsync(XmlData.Write(session));
            }
            catch(UnauthorizedAccessException){context.Response.StatusCode=401;await context.Response.WriteAsync("rechazado");}
        });
        app.MapGet("/ready",()=>"listo");
        app.MapGet("/slow-headers",async context=>{await Task.Delay(1500,context.RequestAborted);await context.Response.WriteAsync("tardio");});
        app.MapGet("/slow-default",async context=>{await Task.Delay(12000,context.RequestAborted);await context.Response.WriteAsync("tardio");});
        app.MapGet("/slow-body",async context=>{await context.Response.WriteAsync("inicio");await context.Response.Body.FlushAsync();await Task.Delay(5000,context.RequestAborted);await context.Response.WriteAsync("tardio");});
        await app.StartAsync();int port=new Uri(app.Services.GetRequiredService<IServer>().Features.Get<IServerAddressesFeature>().Addresses.Single()).Port;
        using var handler=new HttpClientHandler{UseProxy=false};handler.ClientCertificates.Add(clientCert);
        // Confianza exclusiva en el certificado sintético, conservando la comprobación del nombre.
        handler.ServerCertificateCustomValidationCallback=(message,cert,chain,errors)=>
            (errors&SslPolicyErrors.RemoteCertificateNameMismatch)==0 && cert.RawData.SequenceEqual(serverCert.RawData);
        using var http=new HttpClient(handler){BaseAddress=new Uri("https://localhost:"+port),Timeout=TimeSpan.FromSeconds(10)};
        string id=Guid.NewGuid().ToString("N");List<string> timing=[];string access,refresh;
        using(var request=new HttpRequestMessage(HttpMethod.Post,"api/session"))
        {
            request.Headers.Add("X-Agenda-Request-Id",id);request.Content=new StringContent(XmlData.Write(new LoginRequest{UserName="prueba",Password=Password}),Encoding.UTF8,"application/xml");
            using var response=await HttpRequestTiming.SendAsync(http,request,timing.Add,CancellationToken.None);
            var session=XmlData.Read<SessionReply>(await response.Content.ReadAsStringAsync());access=session.AccessToken;refresh=session.RefreshToken;
            Check(response.StatusCode==HttpStatusCode.OK && security.Authenticate(access,device)!=null,"HTTPS loopback: certificado de cliente, POST real y sesión válida");
            Check(response.Headers.GetValues("X-Agenda-Request-Id").Single()==id,"El cliente y el servidor comparten el identificador de la petición");
        }
        Check(timing.Count==2 && timing[0].Contains("cabeceras recibidas") && timing[1].Contains("cuerpo recibido"),"El transporte registra cabeceras y cuerpo por separado");
        using(var request=new HttpRequestMessage(HttpMethod.Post,"api/session"))
        {
            request.Content=new StringContent(XmlData.Write(new LoginRequest{UserName="prueba",Password="Clave-Incorrecta-Sintetica"}),Encoding.UTF8,"application/xml");
            using var response=await HttpRequestTiming.SendAsync(http,request,_=>{},CancellationToken.None);
            Check(response.StatusCode==HttpStatusCode.Unauthorized,"Una contraseña incorrecta sigue devolviendo HTTP 401, sin confundirse con timeout");
        }

        foreach(string route in new[]{"slow-headers","slow-body"})
        {
            // Aislar las fases HTTP del coste de abrir un canal TLS nuevo en Windows.
            using(var warmRequest=new HttpRequestMessage(HttpMethod.Get,"ready"))
            using(var warmResponse=await HttpRequestTiming.SendAsync(http,warmRequest,_=>{},CancellationToken.None))warmResponse.EnsureSuccessStatusCode();
            timing=[];var watch=Stopwatch.StartNew();bool timedOut=false;
            using var request=new HttpRequestMessage(HttpMethod.Get,route);
            try{using var response=await HttpRequestTiming.SendAsync(http,request,timing.Add,CancellationToken.None,route=="slow-body"?TimeSpan.FromSeconds(1):TimeSpan.FromMilliseconds(300));}catch(OperationCanceledException){timedOut=true;}
            Check(timedOut && watch.Elapsed<TimeSpan.FromSeconds(3),"Se respeta el plazo global en "+route);
            Check((route=="slow-body")==timing.Any(x=>x.Contains("cabeceras recibidas")),"Se identifica si el timeout fue anterior o posterior a las cabeceras: "+route);
        }
        {
            var watch=Stopwatch.StartNew();bool timedOut=false;using var request=new HttpRequestMessage(HttpMethod.Get,"slow-default");
            try{using var response=await HttpRequestTiming.SendAsync(http,request,_=>{},CancellationToken.None);}catch(OperationCanceledException){timedOut=true;}
            Check(timedOut && watch.Elapsed>=TimeSpan.FromSeconds(9) && watch.Elapsed<TimeSpan.FromSeconds(12),"El plazo predeterminado sigue siendo 10 segundos, sin ampliarlo");
        }
        using(var cancelled=new CancellationTokenSource())
        {
            cancelled.Cancel();bool rejected=false;using var request=new HttpRequestMessage(HttpMethod.Get,"slow-headers");
            try{using var response=await HttpRequestTiming.SendAsync(http,request,_=>{},cancelled.Token);}catch(OperationCanceledException){rejected=true;}
            Check(rejected,"La cancelación solicitada por el usuario se conserva");
        }
        foreach(string host in new[]{"127.0.0.1","localhost"})
        {
            using var badHandler=new HttpClientHandler{UseProxy=false};badHandler.ClientCertificates.Add(clientCert);
            badHandler.ServerCertificateCustomValidationCallback=(message,cert,chain,errors)=>host=="127.0.0.1"?(errors&SslPolicyErrors.RemoteCertificateNameMismatch)==0:false;
            using var badHttp=new HttpClient(badHandler);using var request=new HttpRequestMessage(HttpMethod.Get,"https://"+host+":"+port+"/slow-headers");
            bool denied=false;try{using var response=await HttpRequestTiming.SendAsync(badHttp,request,_=>{},CancellationToken.None);}catch(HttpRequestException){denied=true;}
            Check(denied,host=="127.0.0.1"?"La prueba rechaza el nombre TLS incorrecto":"La prueba rechaza un servidor sin confianza");
        }
        var failureContext=new DefaultHttpContext();failureContext.Request.Path="/api/session";
        diagnostics.StorageFailure(failureContext,new IOException("SECRETO-NO-REGISTRAR",new IOException("OTRO-SECRETO")));
        await app.StopAsync();await diagnostics.DisposeAsync();
        string text=File.ReadAllText(Path.Combine(root,"diagnostico","sesiones.jsonl"));
        var lines=text.Split('\n',StringSplitOptions.RemoveEmptyEntries).Select(x=>JsonDocument.Parse(x)).ToList();
        Check(lines.Any(d=>d.RootElement.GetProperty("request").GetString()==id && d.RootElement.GetProperty("phase").GetString()=="http_received" && d.RootElement.GetProperty("remote").GetString()=="127.0.0.1"),"El servidor registra la IP real del POST y su ID");
        Check(lines.Any(d=>d.RootElement.GetProperty("phase").GetString()=="session_save_end") && lines.Any(d=>d.RootElement.GetProperty("phase").GetString()=="response_completed"),"El registro confirma persistencia y finalización de la respuesta");
        Check(!text.Contains(Password) && !text.Contains("Clave-Incorrecta-Sintetica") && !text.Contains(access) && !text.Contains(refresh) && !text.Contains("Bearer") && !text.Contains("prueba"),"Los registros excluyen contraseñas, tokens, cuerpos y nombres de usuario");
        Check(lines.Any(d=>d.RootElement.GetProperty("phase").GetString()=="storage_exception" && d.RootElement.GetProperty("causes").GetArrayLength()==2) && !text.Contains("SECRETO"),"El error de almacenamiento registra causas técnicas sin copiar mensajes privados");
        Check(!diagnostics.WriteFailed && diagnostics.Dropped==0,"El diagnóstico se escribe y no pierde eventos durante la prueba");
        foreach(var line in lines)line.Dispose();
    }
    static string AccessRules(FileSecurity security)=>string.Join("|",security.GetAccessRules(true,true,typeof(SecurityIdentifier)).Cast<FileSystemAccessRule>()
        .Select(rule=>rule.IdentityReference.Value+":"+rule.AccessControlType+":"+(int)rule.FileSystemRights+":"+rule.InheritanceFlags+":"+rule.PropagationFlags+":"+rule.IsInherited).OrderBy(x=>x));
    static void AtomicPersistence(string root)
    {
        Directory.CreateDirectory(root);string path=Path.Combine(root,"security-sintetica.json");
        AgendaClara.Server.Files.Atomic(path,Encoding.UTF8.GetBytes("anterior"));
        string expectedAcl=null,expectedRules=null;bool expectedProtection=false;
        if(OperatingSystem.IsWindows())
        {
            var acl=new FileSecurity();acl.SetAccessRuleProtection(true,false);
            acl.AddAccessRule(new FileSystemAccessRule(WindowsIdentity.GetCurrent().User!,FileSystemRights.FullControl,AccessControlType.Allow));
            new FileInfo(path).SetAccessControl(acl);
            var expected=new FileInfo(path).GetAccessControl(AccessControlSections.Access);
            expectedAcl=expected.GetSecurityDescriptorSddlForm(AccessControlSections.Access);
            expectedRules=AccessRules(expected);expectedProtection=expected.AreAccessRulesProtected;
        }
        AgendaClara.Server.Files.Atomic(path,Encoding.UTF8.GetBytes("nuevo"));
        Check(File.ReadAllText(path)=="nuevo","La escritura atómica sustituye la configuración completa");
        if(OperatingSystem.IsWindows())
        {
            var actual=new FileInfo(path).GetAccessControl(AccessControlSections.Access);
            string actualAcl=actual.GetSecurityDescriptorSddlForm(AccessControlSections.Access);
            Console.WriteLine("DACL_SINTETICA antes="+expectedAcl+" despues="+actualAcl);
            Check(AccessRules(actual)==expectedRules && actual.AreAccessRulesProtected==expectedProtection,"La escritura atómica conserva todas las reglas y protección de la DACL; antes="+expectedAcl+" después="+actualAcl);
            bool failed=false;
            using(var lease=new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.None))
                try{AgendaClara.Server.Files.Atomic(path,Encoding.UTF8.GetBytes("no-confirmado"));}catch(Exception ex)when(ex is IOException || ex is UnauthorizedAccessException){failed=true;Console.WriteLine("BLOQUEO_SINTETICO "+ex.GetType().Name+" HRESULT="+ex.HResult.ToString("X8"));}
            Check(failed && File.ReadAllText(path)=="nuevo","Un destino bloqueado conserva el archivo anterior y no confirma el guardado");
        }
        Check(Directory.GetFiles(root,"*.tmp").Length==0,"La escritura atómica limpia temporales después del éxito o del fallo");
    }
    public static async Task<int> Main(string[] args)
    {
        try
        {
            string root=Path.GetFullPath(args[0]);if(Directory.Exists(root))throw new Exception("Usa una carpeta nueva de pruebas.");Directory.CreateDirectory(root);
            AtomicPersistence(Path.Combine(root,"atomico"));Tables();await Security(Path.Combine(root,"seguridad"));await Http(Path.Combine(root,"http"));
            Console.WriteLine("RESUMEN: "+checks+" comprobaciones correctas; 0 fallos. No es ejecución Windows/net48 ni conexión al colegio.");return 0;
        }
        catch(Exception ex){Console.Error.WriteLine(ex);return 1;}
        finally{TlsFixtureKeys.Cleanup();}
    }
}
