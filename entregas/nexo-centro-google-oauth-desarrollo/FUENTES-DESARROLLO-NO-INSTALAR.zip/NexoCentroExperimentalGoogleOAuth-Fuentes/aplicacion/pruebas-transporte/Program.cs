// El servidor marca toda su asamblea como Windows. Sólo se usan seguridad y XML
// portables; no se llama a DPAPI, winsqlite3, registro ni servicios de Windows.
#pragma warning disable CA1416
using System.Diagnostics;
using System.Net;
using System.Net.Http.Headers;
using System.Net.Security;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using AgendaClara;
using AgendaClara.Server;
using Microsoft.AspNetCore.Hosting.Server;
using Microsoft.AspNetCore.Hosting.Server.Features;
using Microsoft.AspNetCore.Server.Kestrel.Https;
using Microsoft.AspNetCore.SignalR;
using Microsoft.AspNetCore.SignalR.Client;

public sealed class SyntheticChanges:Hub { }
static class TransportTests
{
    static int checks;
    static void Check(bool value,string name){if(!value)throw new Exception(name);checks++;Console.WriteLine("CORRECTO: "+name);}
    static X509Certificate2 Authority()
    {
        using var key=RSA.Create(2048);var request=new CertificateRequest("CN=CA-Sintetica-Transporte",key,HashAlgorithmName.SHA256,RSASignaturePadding.Pkcs1);
        request.CertificateExtensions.Add(new X509BasicConstraintsExtension(true,false,0,true));
        request.CertificateExtensions.Add(new X509KeyUsageExtension(X509KeyUsageFlags.KeyCertSign|X509KeyUsageFlags.CrlSign,true));
        return TlsFixtureKeys.ForTls(request.CreateSelfSigned(DateTimeOffset.UtcNow.AddDays(-3),DateTimeOffset.UtcNow.AddDays(3)));
    }
    static X509Certificate2 Leaf(X509Certificate2 ca,string name,string usage,bool expired=false)
    {
        using var key=RSA.Create(2048);var request=new CertificateRequest("CN="+name,key,HashAlgorithmName.SHA256,RSASignaturePadding.Pkcs1);
        request.CertificateExtensions.Add(new X509BasicConstraintsExtension(false,false,0,true));
        request.CertificateExtensions.Add(new X509KeyUsageExtension(X509KeyUsageFlags.DigitalSignature|X509KeyUsageFlags.KeyEncipherment,true));
        request.CertificateExtensions.Add(new X509EnhancedKeyUsageExtension(new OidCollection{new(usage)},true));
        var san=new SubjectAlternativeNameBuilder();san.AddDnsName(name);request.CertificateExtensions.Add(san.Build());
        using var signed=request.Create(ca,DateTimeOffset.UtcNow.AddDays(expired?-2:-1),DateTimeOffset.UtcNow.AddDays(expired?-1:1),RandomNumberGenerator.GetBytes(16));
        return TlsFixtureKeys.ForTls(signed.CopyWithPrivateKey(key));
    }
    static async Task Races()
    {
        var v6=IPAddress.Parse("fe80::1%10");var v62=IPAddress.Parse("fe80::2%10");var v4=IPAddress.Parse("192.168.6.135");var v42=IPAddress.Parse("192.168.6.136");
        Check(EndpointRouter.Interleave(new[]{v6,v62,v4,v42,v6}).SequenceEqual(new[]{v6,v4,v62,v42}),"Se alternan familias y eliminan duplicados, sin desactivar IPv6");
        var watch=Stopwatch.StartNew();bool cancelled=false;List<string> trace=[];
        Task<ValidatedEndpoint> Connect(IPAddress ip,CancellationToken token)
        {
            if(ip.Equals(v6)){token.Register(()=>cancelled=true);return new TaskCompletionSource<ValidatedEndpoint>().Task;}
            return Task.FromResult(new ValidatedEndpoint(ip,new byte[]{1}));
        }
        var winner=await EndpointRouter.RaceAsync(new[]{v6,v4},Connect,trace.Add,CancellationToken.None);
        Check(winner.Address.Equals(v4) && watch.Elapsed>=TimeSpan.FromMilliseconds(200) && watch.Elapsed<TimeSpan.FromSeconds(2),"IPv6 que no responde no consume 10 s: IPv4 comienza tras 250 ms");
        Check(cancelled,"Se cancela la conexión perdedora al elegir una dirección válida");
        winner=await EndpointRouter.RaceAsync(new[]{v6},(ip,t)=>Task.FromResult(new ValidatedEndpoint(ip,new byte[]{1})),_=>{},CancellationToken.None);
        Check(winner.Address.Equals(v6),"Una red que sólo dispone de IPv6 sigue funcionando");
        using(var limit=new CancellationTokenSource(150))
        {
            bool stopped=false;
            try{await EndpointRouter.RaceAsync(new[]{v6,v4},(ip,t)=>new TaskCompletionSource<ValidatedEndpoint>().Task,_=>{},limit.Token);}catch(OperationCanceledException){stopped=true;}
            Check(stopped,"El plazo global cancela todos los intentos, incluso uno que no responde");
        }
        int selections=0;var origin=new Uri("https://jefatura:7443");
        var router=new EndpointRouter(origin,null,"",_=>Task.FromResult(new[]{v4}),async(ip,t)=>{Interlocked.Increment(ref selections);await Task.Delay(30,t);return new ValidatedEndpoint(ip,new byte[]{1});});
        var concurrent=await Task.WhenAll(Enumerable.Range(0,8).Select(_=>router.SelectAsync(_=>{},CancellationToken.None)));
        Check(selections==1 && concurrent.All(e=>ReferenceEquals(e,concurrent[0])),"Las peticiones simultáneas comparten una selección TLS y su caché acotada");
        using var request=new HttpRequestMessage(HttpMethod.Post,"https://jefatura:7443/api/session");router.Bind(request,concurrent[0]);
        Check(request.RequestUri.Host=="192.168.6.135" && request.Headers.Host=="jefatura:7443","Se fija el destino de transporte y se conserva Host del servidor original");
        bool refused=false;using var foreign=new HttpRequestMessage(HttpMethod.Post,"https://otro:7443/api/session");
        try{router.Bind(foreign,concurrent[0]);}catch(HttpRequestException){refused=true;}
        Check(refused,"La ruta no permite enviar credenciales a otro origen");
        var counter=new FailedSend();using var client=new HttpClient(new AddressFallbackHandler(router,counter,_=>{}));
        using var write=new HttpRequestMessage(HttpMethod.Post,"https://jefatura:7443/api/session");
        try{await client.SendAsync(write);}catch(HttpRequestException){}
        Check(counter.Count==1,"Un fallo HTTP no repite el POST tras haberlo enviado");
        await router.SelectAsync(_=>{},CancellationToken.None);
        Check(selections==2,"El siguiente intento puede resolver de nuevo tras invalidar la ruta fallida");
        var pendingDns=new EndpointRouter(origin,null,"",_=>new TaskCompletionSource<IPAddress[]>().Task);
        using var dnsClient=new HttpClient(new AddressFallbackHandler(pendingDns,new FailedSend(),_=>{}));
        using var dnsRequest=new HttpRequestMessage(HttpMethod.Post,"https://jefatura:7443/api/session");bool dnsStopped=false;
        try{using var response=await HttpRequestTiming.SendAsync(dnsClient,dnsRequest,_=>{},CancellationToken.None,TimeSpan.FromMilliseconds(150));}catch(OperationCanceledException){dnsStopped=true;}
        Check(dnsStopped,"El presupuesto incluye la resolución DNS, sin esperar indefinidamente");
        var badDns=new EndpointRouter(origin,null,"",_=>Task.FromException<IPAddress[]>(new System.Net.Sockets.SocketException((int)System.Net.Sockets.SocketError.HostNotFound)));
        var neverSend=new FailedSend();using var badDnsHttp=new HttpClient(new AddressFallbackHandler(badDns,neverSend,_=>{}));
        using var badDnsRequest=new HttpRequestMessage(HttpMethod.Post,"https://jefatura:7443/api/session");bool dnsClassified=false;
        try{await badDnsHttp.SendAsync(badDnsRequest);}catch(HttpRequestException ex){dnsClassified=ex.InnerException is System.Net.Sockets.SocketException;}
        Check(dnsClassified && neverSend.Count==0,"El fallo DNS conserva su causa y no envía una petición HTTP");

    }
    sealed class FailedSend:HttpMessageHandler
    {
        internal int Count;
        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request,CancellationToken token){Count++;throw new HttpRequestException("Fallo sintético tras enviar.");}
    }
    static HttpMessageHandler Handler(EndpointRouter router,X509Certificate2 certificate,Action<string> report=null)
    {
        var handler=new HttpClientHandler{AllowAutoRedirect=false,UseCookies=false,UseProxy=false};handler.ClientCertificates.Add(certificate);
        handler.ServerCertificateCustomValidationCallback=(request,cert,chain,errors)=>router.ValidateHttp(request,cert,errors).Length==0;
        return new AddressFallbackHandler(router,handler,report??(_=>{}));
    }
    static async Task Https(string folder)
    {
        Directory.CreateDirectory(folder);
        using var ca=Authority();using var otherCa=Authority();
        using var server=Leaf(ca,"localhost","1.3.6.1.5.5.7.3.1");
        using var alternate=Leaf(ca,"localhost","1.3.6.1.5.5.7.3.1");
        using var clientCert=Leaf(ca,"puesto-sintetico","1.3.6.1.5.5.7.3.2");
        using var expired=Leaf(ca,"localhost","1.3.6.1.5.5.7.3.1",true);
        string authority=Convert.ToBase64String(ca.RawData);string password="Sintetica-Fallback-2026!";
        SecurityState.Initialize(folder,"pruebas",password);var security=new SecurityState(folder);var device=SecurityState.CertificateId(clientCert);
        security.Enroll(new TrustedDevice{Name="puesto-sintetico",Thumbprint=device});
        int posts=0;string receivedHost="";IPAddress receivedIp=null;
        var builder=WebApplication.CreateSlimBuilder();builder.Logging.ClearProviders();builder.Logging.AddConsole().SetMinimumLevel(LogLevel.Warning).AddFilter("Microsoft.AspNetCore.Server.Kestrel.Https",LogLevel.Debug);builder.Services.AddSignalR();
        builder.WebHost.ConfigureKestrel(k=>k.Listen(IPAddress.Loopback,0,l=>l.UseHttps(new HttpsConnectionAdapterOptions{
            ServerCertificate=server,ClientCertificateMode=ClientCertificateMode.RequireCertificate,
            ClientCertificateValidation=(cert,chain,errors)=>cert.RawData.SequenceEqual(clientCert.RawData)})));
        await using var app=builder.Build();
        app.Use(async(context,next)=>
        {
            if(context.Request.Path.StartsWithSegments("/changes"))
            {
                string auth=context.Request.Headers.Authorization.ToString();var cert=await context.Connection.GetClientCertificateAsync();
                if(cert==null || !auth.StartsWith("Bearer ") || security.Authenticate(auth.Substring(7),SecurityState.CertificateId(cert))==null){context.Response.StatusCode=401;return;}
            }
            await next();
        });
        app.MapPost("/api/session",async context=>
        {
            Interlocked.Increment(ref posts);receivedHost=context.Request.Host.Value;receivedIp=context.Connection.RemoteIpAddress;
            using var reader=new StreamReader(context.Request.Body);var input=XmlData.Read<LoginRequest>(await reader.ReadToEndAsync());
            var cert=await context.Connection.GetClientCertificateAsync();var reply=security.Login(input,SecurityState.CertificateId(cert));
            await context.Response.WriteAsync(XmlData.Write(reply));
        });
        app.MapGet("/api/snapshot",async context=>
        {
            string auth=context.Request.Headers.Authorization.ToString();var cert=await context.Connection.GetClientCertificateAsync();
            if(!auth.StartsWith("Bearer ") || security.Authenticate(auth.Substring(7),SecurityState.CertificateId(cert))==null){context.Response.StatusCode=401;return;}
            await context.Response.WriteAsync(XmlData.Write(new AgendaSnapshot{Generation="sintetica",Revision=5}));
        });
        app.MapHub<SyntheticChanges>("/changes");await app.StartAsync();
        int port=new Uri(app.Services.GetRequiredService<IServer>().Features.Get<IServerAddressesFeature>().Addresses.Single()).Port;
        var origin=new Uri("https://localhost:"+port);
        var network=new EndpointRouter(origin,clientCert,authority);bool v6Cancelled=false;List<string> details=[];
        Task<ValidatedEndpoint> Connect(IPAddress ip,CancellationToken token)
        {
            if(ip.AddressFamily==System.Net.Sockets.AddressFamily.InterNetworkV6){token.Register(()=>v6Cancelled=true);return new TaskCompletionSource<ValidatedEndpoint>().Task;}
            return network.ConnectAsync(ip,token);
        }
        var router=new EndpointRouter(origin,clientCert,authority,_=>Task.FromResult(new[]{IPAddress.IPv6Loopback,IPAddress.Loopback}),Connect);
        using var http=new HttpClient(Handler(router,clientCert,details.Add)){BaseAddress=origin,Timeout=TimeSpan.FromSeconds(10)};
        SessionReply session;
        using(var request=new HttpRequestMessage(HttpMethod.Post,"api/session"))
        {
            request.Content=new StringContent(XmlData.Write(new LoginRequest{UserName="pruebas",Password=password}),Encoding.UTF8,"application/xml");
            var watch=Stopwatch.StartNew();using var response=await HttpRequestTiming.SendAsync(http,request,_=>{},CancellationToken.None);
            session=XmlData.Read<SessionReply>(await response.Content.ReadAsStringAsync());
            Check(response.StatusCode==HttpStatusCode.OK && watch.Elapsed<TimeSpan.FromSeconds(5),"IPv6 silenciosa simulada e IPv4 HTTPS real: autenticación sin agotar 10 s");
        }
        Check(posts==1 && v6Cancelled,"Sólo se envía un POST; se cancela el intento IPv6 sin enviar credenciales");
        Check(receivedHost==origin.Authority && receivedIp.Equals(IPAddress.Loopback),"El servidor recibe Host original por IPv4, sin cambiar la URL configurada");
        var san=new X509SubjectAlternativeNameExtension(server.Extensions["2.5.29.17"].RawData);
        Check(!san.EnumerateIPAddresses().Any(),"La prueba usa un certificado con SAN DNS, sin SAN de IP");
        Check(security.Authenticate(session.AccessToken,device)!=null,"El certificado de puesto y la sesión emitida siguen siendo válidos");
        using(var request=new HttpRequestMessage(HttpMethod.Get,"api/snapshot"))
        {
            request.Headers.Authorization=new AuthenticationHeaderValue("Bearer",session.AccessToken);
            using var response=await HttpRequestTiming.SendAsync(http,request,_=>{},CancellationToken.None);
            Check(response.StatusCode==HttpStatusCode.OK && XmlData.Read<AgendaSnapshot>(await response.Content.ReadAsStringAsync()).Revision==5,"La ruta sirve también para recuperar los datos iniciales autenticados");
        }
        using(var bound=new HttpRequestMessage(HttpMethod.Get,new Uri(origin,"api/snapshot")))
        {
            var endpoint=await router.SelectAsync(_=>{},CancellationToken.None);router.Bind(bound,endpoint);
            Check(router.ValidateHttp(bound,server,SslPolicyErrors.RemoteCertificateNameMismatch|SslPolicyErrors.RemoteCertificateChainErrors)=="","La IP se vincula al certificado ya validado para localhost, conservando CA y fecha");
            Check(router.ValidateHttp(bound,alternate,SslPolicyErrors.RemoteCertificateNameMismatch|SslPolicyErrors.RemoteCertificateChainErrors)!="","Otra hoja de la misma CA no puede sustituir el certificado prevalidado");
            Check(router.ValidateHttp(bound,expired,SslPolicyErrors.None)!="","Un certificado distinto o caducado no se acepta en el enlace HTTP");
        }
        Check(ServerTlsTrust.Check(authority,expired,SslPolicyErrors.RemoteCertificateChainErrors)=="expired","La comprobación TLS de producción rechaza fechas caducadas");
        Check(ServerTlsTrust.Check(authority,clientCert,SslPolicyErrors.RemoteCertificateChainErrors)!="","Un certificado clientAuth no sustituye un certificado serverAuth");
        Check(ServerTlsTrust.Check("",server,SslPolicyErrors.RemoteCertificateChainErrors)!="","Sin CA configurada se conserva la exigencia de confianza del sistema");
        async Task Rejected(EndpointRouter invalid,string code,string text)
        {
            bool rejected=false;using var limit=new CancellationTokenSource(TimeSpan.FromSeconds(5));
            try{await invalid.SelectAsync(_=>{},limit.Token);}catch(EndpointTlsException ex){rejected=ex.Code==code;}
            Check(rejected,text);
        }
        await Rejected(new EndpointRouter(new Uri("https://nombre-incorrecto.invalid:"+port),clientCert,authority,_=>Task.FromResult(new[]{IPAddress.Loopback})),"name","Resolver una IP accesible no permite aceptar un nombre TLS incorrecto");
        await Rejected(new EndpointRouter(origin,clientCert,Convert.ToBase64String(otherCa.RawData),_=>Task.FromResult(new[]{IPAddress.Loopback})),"untrusted","Una CA distinta sigue siendo rechazada durante la selección");
        await Rejected(new EndpointRouter(new Uri("https://127.0.0.1:"+port),clientCert,authority),"name","Una URL configurada por IP exige SAN de IP; no se transforma en otra identidad");
        Check(posts==1,"Las pruebas TLS rechazadas no envían peticiones de autenticación");
        var received=new TaskCompletionSource<string>(TaskCreationOptions.RunContinuationsAsynchronously);
        await using(var hub=new HubConnectionBuilder().WithUrl(new Uri(origin,"changes"),options=>
        {
            options.Transports=Microsoft.AspNetCore.Http.Connections.HttpTransportType.LongPolling;
            options.AccessTokenProvider=()=>Task.FromResult(session.AccessToken);
            options.HttpMessageHandlerFactory=inner=>
            {
                var native=(HttpClientHandler)inner;native.AllowAutoRedirect=false;native.UseCookies=false;native.UseProxy=false;native.ClientCertificates.Add(clientCert);
                native.ServerCertificateCustomValidationCallback=(request,cert,chain,errors)=>router.ValidateHttp(request,cert,errors).Length==0;
                return new AddressFallbackHandler(router,native,_=>{});
            };
        }).Build())
        {
            hub.On<string>("Aviso",value=>received.TrySetResult(value));
            await hub.StartAsync();Check(hub.State==HubConnectionState.Connected,"SignalR conecta por el mismo transporte con identidad original y mTLS");
            await app.Services.GetRequiredService<IHubContext<SyntheticChanges>>().Clients.All.SendAsync("Aviso","sintetico");
            using var limit=new CancellationTokenSource(TimeSpan.FromSeconds(5));
            Check(await EndpointRouter.Cancellable(received.Task,limit.Token)=="sintetico","SignalR entrega un aviso real después del fallback IPv4");
            await hub.StopAsync();
        }
        if(System.Net.Sockets.Socket.OSSupportsIPv6)
        {
            var builder6=WebApplication.CreateSlimBuilder();builder6.Logging.ClearProviders();builder6.Logging.AddConsole().SetMinimumLevel(LogLevel.Warning).AddFilter("Microsoft.AspNetCore.Server.Kestrel.Https",LogLevel.Debug);
            builder6.WebHost.ConfigureKestrel(k=>k.Listen(IPAddress.IPv6Loopback,0,l=>l.UseHttps(new HttpsConnectionAdapterOptions{
                ServerCertificate=server,ClientCertificateMode=ClientCertificateMode.RequireCertificate,
                ClientCertificateValidation=(cert,chain,errors)=>cert.RawData.SequenceEqual(clientCert.RawData)})));
            await using var ipv6Server=builder6.Build();ipv6Server.MapGet("/ipv6",()=>"IPv6-correcta");await ipv6Server.StartAsync();
            int port6=new Uri(ipv6Server.Services.GetRequiredService<IServer>().Features.Get<IServerAddressesFeature>().Addresses.Single()).Port;
            var origin6=new Uri("https://localhost:"+port6);
            var router6=new EndpointRouter(origin6,clientCert,authority,_=>Task.FromResult(new[]{IPAddress.IPv6Loopback}));
            using var http6=new HttpClient(Handler(router6,clientCert));using var req6=new HttpRequestMessage(HttpMethod.Get,new Uri(origin6,"ipv6"));
            using var response6=await HttpRequestTiming.SendAsync(http6,req6,_=>{},CancellationToken.None);
            Check(response6.StatusCode==HttpStatusCode.OK && await response6.Content.ReadAsStringAsync()=="IPv6-correcta","Una conexión HTTPS IPv6 real con mTLS funciona sin disponer de IPv4");
            await ipv6Server.StopAsync();
        }
        else Console.WriteLine("OMITIDO: conexión HTTPS IPv6 real, no disponible en este sistema.");
        Check(details.All(d=>!d.Contains(password) && !d.Contains(session.AccessToken) && !d.Contains(session.RefreshToken)),"Los registros de selección no contienen credenciales ni tokens");
        File.WriteAllLines(Path.Combine(folder,"rutas.txt"),details);await app.StopAsync();
    }
    static async Task<int> Main(string[] args)
    {
        try
        {
            string root=Path.GetFullPath(args[0]);if(Directory.Exists(root))throw new ArgumentException("Usa una carpeta de prueba nueva.");Directory.CreateDirectory(root);
            await Races();await Https(Path.Combine(root,"https"));
            Console.WriteLine("RESUMEN: "+checks+" comprobaciones correctas; 0 fallos. Ejecución .NET 10/Linux; Windows/net48 y colegio pendientes.");return 0;
        }
        catch(Exception ex){Console.Error.WriteLine(ex);return 1;}
        finally{TlsFixtureKeys.Cleanup();}
    }
}
