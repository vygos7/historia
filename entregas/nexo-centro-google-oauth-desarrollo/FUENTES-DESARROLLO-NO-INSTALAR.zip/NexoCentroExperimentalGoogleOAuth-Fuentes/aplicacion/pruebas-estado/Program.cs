using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using AgendaClara;
public sealed class Feed:IRemoteAgenda
{
    public AgendaSnapshot Data;public bool Connected=true;public AgendaSnapshot Snapshot{get{return XmlData.Read<AgendaSnapshot>(XmlData.Write(Data));}}public bool CanWrite{get{return Connected;}}public bool IsAdmin{get{return Connected;}}public string Status{get{return (Connected?"Conectado y sincronizado":"Sin conexión")+" · última sincronización "+Data.ServerUtc.ToLocalTime().ToString("dd/MM/yyyy HH:mm:ss");}}public event Action Changed;
    public AgendaReply Execute(AgendaCommand command){throw new IOException("Solo se usa para pruebas de presentación");}public IRemoteAgenda Fork(){return this;}public void Offline(){Connected=false;if(Changed!=null)Changed();}
}
public static class StatusTests
{
    static IEnumerable<DependencyObject> Tree(DependencyObject d){yield return d;foreach(var c in LogicalTreeHelper.GetChildren(d)){var item=c as DependencyObject;if(item!=null)foreach(var child in Tree(item))yield return child;}}
    static void Pump(Window w){w.UpdateLayout();var f=new DispatcherFrame();Dispatcher.CurrentDispatcher.BeginInvoke(DispatcherPriority.Background,new Action(()=>f.Continue=false));Dispatcher.PushFrame(f);w.UpdateLayout();}
    static void Screenshot(Window w,string path){var root=(FrameworkElement)w.Content;var bitmap=new RenderTargetBitmap((int)root.ActualWidth,(int)root.ActualHeight,96,96,PixelFormats.Pbgra32);var bg=new DrawingVisual();using(var dc=bg.RenderOpen())dc.DrawRectangle(Theme.Background,null,new Rect(0,0,bitmap.PixelWidth,bitmap.PixelHeight));bitmap.Render(bg);bitmap.Render(root);var encoder=new PngBitmapEncoder();encoder.Frames.Add(BitmapFrame.Create(bitmap));using(var file=File.Create(path))encoder.Save(file);}
    [STAThread]public static int Main(string[] args)
    {
        string folder=Path.GetFullPath(args[0]);Directory.CreateDirectory(folder);var app=new Application{ShutdownMode=ShutdownMode.OnExplicitShutdown};Theme.Install(app);Format.ApplyCulture();
        Store.CopyReadOnly(args[1],Path.Combine(folder,"presentacion.sqlite3"));AgendaSnapshot snapshot;using(var s=new Store(Path.Combine(folder,"presentacion.sqlite3"),false))snapshot=s.LoadSnapshot();snapshot.ServerUtc=DateTime.UtcNow;
        var feed=new Feed{Data=snapshot};var main=new MainWindow(new Store(feed));main.Show();Pump(main);main.SetView("Resultados");Pump(main);
        bool connected=Tree(main).OfType<TextBlock>().Any(t=>t.Text.StartsWith("Servidor central ·")&&t.Text.Contains("Copias gestionadas por el servidor"));Screenshot(main,Path.Combine(folder,"estado-conectado.png"));
        feed.Offline();Pump(main);bool offline=Tree(main).OfType<TextBlock>().Any(t=>t.Text.StartsWith("Solo consulta ·")&&t.Text.Contains("Sin conexión"));Screenshot(main,Path.Combine(folder,"estado-desconectado.png"));
        main.Close();app.Shutdown();File.WriteAllLines(Path.Combine(folder,"resultado-estado.txt"),new[]{(connected?"CORRECTO: ":"FALLO: ")+"El estado conectado identifica el almacenamiento y las copias centrales",(offline?"CORRECTO: ":"FALLO: ")+"El estado desconectado identifica expresamente la consulta local"});return connected&&offline?0:1;
    }
}

