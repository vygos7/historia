using AgendaClara;
using Microsoft.AspNetCore.SignalR;

namespace AgendaClara.Server;
public sealed class GoogleOfficialService:IDisposable
{
    public GoogleOfficialCoordinator Controller {get;}
    readonly HttpClient http;
    public GoogleOfficialService(ServerEngine engine,IHubContext<ChangesHub> hub,ILogger<GoogleOfficialService> logger)
    {
        var app=GoogleAppRegistration.Load();http=new HttpClient(new HttpClientHandler{AllowAutoRedirect=false});
        async Task Notify(){try{var snapshot=engine.Snapshot();await hub.Clients.All.SendAsync("Changed",snapshot.Generation,snapshot.Revision);}catch(Exception ex){logger.LogWarning("Aviso Google pendiente: {Tipo}",ex.GetType().Name);}}
        Controller=new GoogleOfficialCoordinator(engine.Root,app,new GoogleOfficialApi(http,app),new GoogleEncryptedTokenVault(engine.Root,Certificates.Protect,Certificates.Unprotect,Files.Atomic),()=>engine.Store,engine.Gate,c=>engine.Apply(c,new Principal(GoogleEvaluationManager.Actor,"google-oficial","Jefatura",true,DateTime.UtcNow.AddMinutes(5))),Files.Atomic,action=>{lock(engine.Gate)return Task.FromResult(action());},()=>{_ = Notify();});
    }
    public void Dispose(){Controller.Dispose();http.Dispose();}
}
public sealed class GoogleOfficialWorker(GoogleOfficialService service):BackgroundService
{protected override Task ExecuteAsync(CancellationToken stoppingToken)=>service.Controller.Run(stoppingToken);}
