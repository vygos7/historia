#nullable enable
using System.IO.Compression;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using AgendaClara;

namespace AgendaClara.Server;
public sealed class ServerEngine : IDisposable
{
    public readonly object Gate=new();
    public Store Store { get; private set; }
    public SecurityState Security { get; }
    public ServerSettings Settings { get; }
    public string Root { get; }
    public DateTime? LastBackupUtc { get; private set; }
    public string BackupError { get; private set; }="";
    public bool Healthy { get; private set; }=true;
    public ServerEngine(string root,ServerSettings settings)
    {
        Root=root;Settings=settings;Security=new SecurityState(root);Store=new Store(Path.Combine(root,"agenda.sqlite3"),false);
        Store.ClaimForServer(Security.ServerId);
        Store.SetBackupDirectory(Path.Combine(root,"safety"));
        if(Store.IntegrityCheck()!="ok")throw new IOException("La agenda no supera la comprobación de integridad.");
    }
    public AgendaSnapshot Snapshot() { lock(Gate)return Store.LoadSnapshot(); }
    public AgendaReply Apply(AgendaCommand command,Principal person)
    { lock(Gate) { if(!Healthy)throw new IOException("El servidor está en mantenimiento por un error de restauración."); return Store.Apply(command,person.UserName,person.Device); } }
    public ServerHealth Health() { lock(Gate) return new ServerHealth { ServerId=Security.ServerId,Version=typeof(ServerEngine).Assembly.GetName().Version!.ToString(3),Utc=DateTime.UtcNow,Revision=Store.LoadSnapshot().Revision,LastBackupUtc=LastBackupUtc,BackupError=BackupError,Integrity=Healthy?"ok":"mantenimiento",ActiveSessions=Security.ActiveSessions }; }
    byte[] Key()=>Certificates.Unprotect(File.ReadAllBytes(Path.Combine(Root,"backup-key.dpapi")));
    static string Digest(byte[] bytes)=>Convert.ToHexString(SHA256.HashData(bytes));
    static void Entry(ZipArchive zip,string name,byte[] bytes) { using var s=zip.CreateEntry(name,CompressionLevel.Optimal).Open();s.Write(bytes); }
    public BackupRecord Backup()
    {
        lock(Gate)
        {
            string temporary=Path.Combine(Root,"snapshot-"+Guid.NewGuid().ToString("N")+".sqlite3");
            try
            {
                Directory.CreateDirectory(Settings.BackupDirectory); Store.BackupTo(temporary);
                var info=Store.Inspect(temporary);if(info.Error.Length!=0)throw new IOException(info.Error);
                byte[] database=File.ReadAllBytes(temporary), security=Security.ExportForBackup(), archive;
                var infrastructure = new Dictionary<string,byte[]> { ["authority.pfx"]=File.ReadAllBytes(Path.Combine(Root,"authority.pfx")), ["server.pfx"]=File.ReadAllBytes(Path.Combine(Root,"server.pfx")), ["authority.cer"]=File.ReadAllBytes(Path.Combine(Root,"authority.cer")), ["certificate-password.txt"]=Certificates.Unprotect(File.ReadAllBytes(Path.Combine(Root,"certificate-password.dpapi"))), ["server-config.json"]=File.ReadAllBytes(Path.Combine(Root,"server.json")) };
                using(var stream=new MemoryStream())
                {
                    using(var zip=new ZipArchive(stream,ZipArchiveMode.Create,true))
                    {
                        Entry(zip,"agenda.sqlite3",database); Entry(zip,"security.json",security);
                        var manifest = new Dictionary<string,string>{{"database",Digest(database)},{"security",Digest(security)},{"format","2"}};
                        foreach(var item in infrastructure) { Entry(zip,item.Key,item.Value); manifest[item.Key]=Digest(item.Value); }
                        Entry(zip,"manifest.json",JsonSerializer.SerializeToUtf8Bytes(manifest));
                    }
                    archive=stream.ToArray();
                }
                byte[] nonce=RandomNumberGenerator.GetBytes(12), tag=new byte[16],cipher=new byte[archive.Length];
                byte[] key=Key();try{using var aes=new AesGcm(key,16);aes.Encrypt(nonce,archive,cipher,tag,Encoding.ASCII.GetBytes("ACB1"));}finally{CryptographicOperations.ZeroMemory(key);}
                byte[] output=new byte[32+cipher.Length];Encoding.ASCII.GetBytes("ACB1").CopyTo(output,0);nonce.CopyTo(output,4);tag.CopyTo(output,16);cipher.CopyTo(output,32);
                string name="AgendaClara-"+DateTime.UtcNow.ToString("yyyyMMdd-HHmmss-fff")+"-"+Guid.NewGuid().ToString("N").Substring(0,6)+".acbackup";
                var record=new BackupRecord{Name=name,Hash=Digest(output),Utc=DateTime.UtcNow,Size=output.Length};
                // Authenticate and verify the complete archive before publishing it.
                Decode(output);
                Files.Atomic(Path.Combine(Settings.BackupDirectory,name),output);
                if(!string.IsNullOrWhiteSpace(Settings.ExternalBackupDirectory)) { Directory.CreateDirectory(Settings.ExternalBackupDirectory);Files.Atomic(Path.Combine(Settings.ExternalBackupDirectory,name),output); }
                LastBackupUtc=DateTime.UtcNow; BackupError="";
                foreach(var file in new DirectoryInfo(Settings.BackupDirectory).GetFiles("AgendaClara-*.acbackup").Where(f=>f.LastWriteTimeUtc<DateTime.UtcNow.AddDays(-Settings.RetentionDays)))file.Delete();
                return record;
            }
            catch(Exception ex) { BackupError=ex.Message;throw; }
            finally { if(File.Exists(temporary))File.Delete(temporary); }
        }
    }
    (byte[] Database,byte[] Security,Dictionary<string,byte[]> Infrastructure) Decode(byte[] data)
    { byte[] key=Key(); try{return Unpack(data,key);}finally{CryptographicOperations.ZeroMemory(key);} }
    static (byte[] Database,byte[] Security,Dictionary<string,byte[]> Infrastructure) Unpack(byte[] data,byte[] recoveryKey)
    {
        if(data.Length<33 || data.Length>268435456 || Encoding.ASCII.GetString(data,0,4)!="ACB1")throw new IOException("El archivo no es una copia cifrada de AgendaClara.");
        byte[] plaintext=new byte[data.Length-32],key=(byte[])recoveryKey.Clone();
        try{using var aes=new AesGcm(key,16);aes.Decrypt(data.AsSpan(4,12),data.AsSpan(32),data.AsSpan(16,16),plaintext,Encoding.ASCII.GetBytes("ACB1"));}finally{CryptographicOperations.ZeroMemory(key);}
        using var stream=new MemoryStream(plaintext);using var zip=new ZipArchive(stream,ZipArchiveMode.Read);
        byte[] Read(string name)
        {
            var e=zip.GetEntry(name)??throw new IOException("La copia no contiene "+name); if(e.Length>268435456)throw new IOException("La copia es demasiado grande.");
            using var input=e.Open();using var output=new MemoryStream();input.CopyTo(output);return output.ToArray();
        }
        var database=Read("agenda.sqlite3");var security=Read("security.json");var manifest=JsonSerializer.Deserialize<Dictionary<string,string>>(Read("manifest.json"))??throw new IOException("Falta el manifiesto.");
        if(manifest["format"]!="2" || manifest["database"]!=Digest(database)||manifest["security"]!=Digest(security))throw new IOException("Las huellas de la copia no coinciden.");
        SecurityState.ValidateExport(security);
        var infrastructure = new Dictionary<string,byte[]>();
        foreach(var name in new[]{"authority.pfx","server.pfx","authority.cer","certificate-password.txt","server-config.json"}) { var item=Read(name); if(item.Length>8388608 || !manifest.TryGetValue(name,out var digest) || digest!=Digest(item))throw new IOException("La copia de certificados o configuración no es válida."); infrastructure[name]=item; }
        return(database,security,infrastructure);
    }
    public List<BackupRecord> ListBackups()
    {
        lock(Gate) { if(!Directory.Exists(Settings.BackupDirectory))return [];return new DirectoryInfo(Settings.BackupDirectory).GetFiles("AgendaClara-*.acbackup").OrderByDescending(f=>f.LastWriteTimeUtc).Select(f=>new BackupRecord{Name=f.Name,Utc=f.LastWriteTimeUtc,Size=f.Length}).ToList(); }
    }
    public byte[] Download(string name)
    { lock(Gate) { if(name!=Path.GetFileName(name)||!name.StartsWith("AgendaClara-")||!name.EndsWith(".acbackup"))throw new ArgumentException("Nombre de copia no válido.");return File.ReadAllBytes(Path.Combine(Settings.BackupDirectory,name)); } }
    public void Restore(byte[] data,string generation,long revision,Principal actor)
    {
        lock(Gate)
        {
            var current=Store.LoadSnapshot();if(current.Generation!=generation||current.Revision!=revision)throw new ConflictException("La agenda ha cambiado desde la comprobación previa. Revisa la restauración.");
            var decoded=Decode(data);
            if(Digest(decoded.Infrastructure["authority.cer"])!=Digest(File.ReadAllBytes(Path.Combine(Root,"authority.cer"))))throw new ArgumentException("Esta copia pertenece a otra instalación. Usa la recuperación local con su clave externa para recuperar también los certificados.");
            string stage=Path.Combine(Root,"restore-"+Guid.NewGuid().ToString("N")+".sqlite3");
            string safety=Path.Combine(Root,"safety","Antes-de-restaurar-central-"+DateTime.UtcNow.ToString("yyyyMMdd-HHmmss-fff")+".sqlite3");
            byte[] oldSecurity=Security.ExportForBackup();
            try
            {
                File.WriteAllBytes(stage,decoded.Database);var check=Store.Inspect(stage);if(check.Error.Length!=0)throw new IOException(check.Error);
                // Opening a staging copy validates every XML field before the live agenda changes.
                using(var staged=new Store(stage,false)){if(staged.IntegrityCheck()!="ok")throw new IOException("La copia no es íntegra.");staged.LoadSnapshot();}
                Backup(); Store.BackupTo(safety);
                try { Store.RestoreFrom(stage); Security.Restore(decoded.Security);Store.NewGeneration(actor.UserName,actor.Device);Healthy=true; }
                catch
                {
                    try { Store.RestoreFrom(safety);Security.Restore(oldSecurity);Store.NewGeneration("recuperacion",actor.Device); }catch{Healthy=false;}
                    throw;
                }
            }
            finally { if(File.Exists(stage))File.Delete(stage); }
        }
    }
    public static void Recover(string root,string archive,string keyFile,string host,string network,int port)
    {
        var networks=Certificates.ParseNetworks(network);if(Uri.CheckHostName(host)==UriHostNameType.Unknown||port<1024||port>65535)throw new ArgumentException("Nombre o puerto de recuperación no válido.");
        if(File.Exists(Path.Combine(root,"server.json")) || File.Exists(Path.Combine(root,"agenda.sqlite3")))throw new IOException("La recuperación necesita una carpeta de datos nueva.");
        byte[] key=Convert.FromBase64String(File.ReadAllText(keyFile).Trim());if(key.Length!=32)throw new ArgumentException("Clave de recuperación no válida.");
        var recovered=Unpack(File.ReadAllBytes(archive),key);
        // Verify the private authority before publishing any restored configuration.
        string password=Encoding.UTF8.GetString(recovered.Infrastructure["certificate-password.txt"]);
        using(var authority=System.Security.Cryptography.X509Certificates.X509CertificateLoader.LoadPkcs12(recovered.Infrastructure["authority.pfx"],password,System.Security.Cryptography.X509Certificates.X509KeyStorageFlags.EphemeralKeySet))
        { if(!authority.HasPrivateKey)throw new IOException("La copia no conserva la autoridad de certificados."); }
        Directory.CreateDirectory(root);string staging=Path.Combine(root,"validar.sqlite3");File.WriteAllBytes(staging,recovered.Database);
        using(var check=new Store(staging,false)){if(check.IntegrityCheck()!="ok")throw new IOException("La agenda recuperada no supera integridad.");check.LoadSnapshot();check.NewGeneration("recuperacion-local","administrador-windows");}
        File.Move(staging,Path.Combine(root,"agenda.sqlite3"));
        Files.Atomic(Path.Combine(root,"security.json"),recovered.Security);
        foreach(var name in new[]{"authority.pfx","server.pfx","authority.cer"})Files.Atomic(Path.Combine(root,name),recovered.Infrastructure[name]);
        Files.Atomic(Path.Combine(root,"certificate-password.dpapi"),Certificates.Protect(recovered.Infrastructure["certificate-password.txt"]));
        Files.Atomic(Path.Combine(root,"backup-key.dpapi"),Certificates.Protect(key));CryptographicOperations.ZeroMemory(key);
        var config=JsonSerializer.Deserialize<ServerSettings>(recovered.Infrastructure["server-config.json"])??throw new IOException("Configuración recuperada no válida.");
        config.PublicHost=host;config.AllowedNetworks=networks;config.Port=port;config.BackupDirectory=Path.Combine(root,"copias");config.ExternalBackupDirectory="";
        Certificates.RenewServer(root,host);
        Files.Atomic(Path.Combine(root,"server.json"),JsonSerializer.SerializeToUtf8Bytes(config,new JsonSerializerOptions{WriteIndented=true}));
    }
    public void Dispose()=>Store.Dispose();
}
public sealed class BackupWorker(ServerEngine engine,ILogger<BackupWorker> logger):BackgroundService
{
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        while(!stoppingToken.IsCancellationRequested)
        {
            try { await Task.Run(()=>engine.Backup(),stoppingToken); }catch(OperationCanceledException){break;}catch(Exception ex){logger.LogError(ex,"No se ha completado la copia automática");}
            try { await Task.Delay(TimeSpan.FromMinutes(engine.Settings.BackupMinutes),stoppingToken); }catch(OperationCanceledException){break;}
        }
    }
}
