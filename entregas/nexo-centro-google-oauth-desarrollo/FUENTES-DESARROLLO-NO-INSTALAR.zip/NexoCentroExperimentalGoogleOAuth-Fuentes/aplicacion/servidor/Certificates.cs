#nullable enable
using System.Net;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text.Json;

[assembly: System.Runtime.Versioning.SupportedOSPlatform("windows")]
namespace AgendaClara.Server;
public sealed class ServerSettings
{
    public string ListenHost { get; set; }="127.0.0.1";
    public int Port { get; set; }=7445;
    public string PublicHost { get; set; }="";
    public List<string> AllowedNetworks { get; set; }=[];
    public string BackupDirectory { get; set; }="";
    public string ExternalBackupDirectory { get; set; }="";
    public int BackupMinutes { get; set; }=60;
    public int RetentionDays { get; set; }=30;
    public bool OfflineCacheAllowed { get; set; }=true;
}
public static class Certificates
{
    public static byte[] Protect(byte[] data)=>ProtectedData.Protect(data,null,DataProtectionScope.LocalMachine);
    public static byte[] Unprotect(byte[] data)=>ProtectedData.Unprotect(data,null,DataProtectionScope.LocalMachine);
    static X509EnhancedKeyUsageExtension Usage(string oid)=>new(new OidCollection { new Oid(oid) },true);
    static X509Certificate2 Issue(X509Certificate2 ca,string name,bool server,string host)
    {
        using var rsa=RSA.Create(3072); var req=new CertificateRequest("CN="+name,rsa,HashAlgorithmName.SHA256,RSASignaturePadding.Pkcs1);
        req.CertificateExtensions.Add(new X509BasicConstraintsExtension(false,false,0,true));
        req.CertificateExtensions.Add(new X509KeyUsageExtension(X509KeyUsageFlags.DigitalSignature|X509KeyUsageFlags.KeyEncipherment,true));
        req.CertificateExtensions.Add(Usage(server?"1.3.6.1.5.5.7.3.1":"1.3.6.1.5.5.7.3.2"));
        if(server) { var san=new SubjectAlternativeNameBuilder(); foreach(var item in ServerNames(host)){if(IPAddress.TryParse(item,out var ip))san.AddIpAddress(ip);else san.AddDnsName(item);} req.CertificateExtensions.Add(san.Build()); }
        using var pub=req.Create(ca,DateTimeOffset.UtcNow.AddMinutes(-5),DateTimeOffset.UtcNow.AddYears(2),RandomNumberGenerator.GetBytes(16));
        return pub.CopyWithPrivateKey(rsa);
    }
    public static void Initialize(string root,string host)
    {
        string password=Convert.ToBase64String(RandomNumberGenerator.GetBytes(32));
        using var rsa=RSA.Create(3072); var request=new CertificateRequest("CN=AgendaClara CA "+Guid.NewGuid().ToString("N"),rsa,HashAlgorithmName.SHA256,RSASignaturePadding.Pkcs1);
        request.CertificateExtensions.Add(new X509BasicConstraintsExtension(true,false,0,true)); request.CertificateExtensions.Add(new X509KeyUsageExtension(X509KeyUsageFlags.KeyCertSign|X509KeyUsageFlags.CrlSign,true));
        using var ca=request.CreateSelfSigned(DateTimeOffset.UtcNow.AddMinutes(-5),DateTimeOffset.UtcNow.AddYears(5));
        using var cert=Issue(ca,"AgendaClara servidor",true,host);
        Files.Atomic(Path.Combine(root,"certificate-password.dpapi"),Protect(System.Text.Encoding.UTF8.GetBytes(password)));
        Files.Atomic(Path.Combine(root,"server.pfx"),cert.Export(X509ContentType.Pfx,password));
        Files.Atomic(Path.Combine(root,"authority.pfx"),ca.Export(X509ContentType.Pfx,password));
        Files.Atomic(Path.Combine(root,"authority.cer"),ca.Export(X509ContentType.Cert));
        Files.Atomic(Path.Combine(root,"backup-key.dpapi"),Protect(RandomNumberGenerator.GetBytes(32)));
    }
    public static X509Certificate2 Load(string root,string file)
    {
        string pw=System.Text.Encoding.UTF8.GetString(Unprotect(File.ReadAllBytes(Path.Combine(root,"certificate-password.dpapi"))));
        return X509CertificateLoader.LoadPkcs12FromFile(Path.Combine(root,file),pw,file=="server.pfx"?X509KeyStorageFlags.MachineKeySet:X509KeyStorageFlags.EphemeralKeySet);
    }
    public static void RenewServer(string root,string host)
    {
        if(Uri.CheckHostName(host)==UriHostNameType.Unknown)throw new ArgumentException("Nombre de servidor no válido.");
        using var authority=Load(root,"authority.pfx");using var cert=Issue(authority,"AgendaClara servidor",true,host);
        string password=System.Text.Encoding.UTF8.GetString(Unprotect(File.ReadAllBytes(Path.Combine(root,"certificate-password.dpapi"))));
        Files.Atomic(Path.Combine(root,"server.pfx"),cert.Export(X509ContentType.Pfx,password));
    }
    public static void Enroll(string root,string name,string password,string destination,string automaticRole="")
    {
        if(name.Length<1 || name.Length>80 || name.Any(c=>!char.IsLetterOrDigit(c)&&c!='-'&&c!='_'&&c!=' '))throw new ArgumentException("Nombre de equipo no válido.");
        SecurityState.ValidatePassword(password); Directory.CreateDirectory(destination);
        using var ca=Load(root,"authority.pfx"); using var cert=Issue(ca,name,false,"");
                var security=new SecurityState(root);string automaticUser="";
        if(automaticRole.Length>0)
        {
            if(!new[]{"Jefatura","Direccion","Secretaria"}.Contains(automaticRole))throw new ArgumentException("Puesto no válido.");
            automaticUser="Puesto-"+name;
            security.ChangeUser(new UserChange{UserName=automaticUser,Role=automaticRole,Admin=automaticRole=="Jefatura",Enabled=true,Password=Convert.ToBase64String(System.Security.Cryptography.RandomNumberGenerator.GetBytes(48))});
        }
        security.Enroll(new TrustedDevice { Name=name, Thumbprint=SecurityState.CertificateId(cert),AutomaticUser=automaticUser });
        if(automaticUser.Length>0)File.WriteAllText(Path.Combine(destination,"usuario.txt"),automaticUser);
        Files.Atomic(Path.Combine(destination,"equipo.pfx"),cert.Export(X509ContentType.Pfx,password));
        File.Copy(Path.Combine(root,"authority.cer"),Path.Combine(destination,"servidor-raiz.cer"),false);
        var settings=JsonSerializer.Deserialize<ServerSettings>(File.ReadAllText(Path.Combine(root,"server.json")))!;
        File.WriteAllText(Path.Combine(destination,"servidor.txt"),"https://"+settings.PublicHost+":"+settings.Port);
    }
    public static bool ValidateClient(X509Certificate2? cert,X509Certificate2 ca)
    {
        if(cert==null || DateTime.UtcNow<cert.NotBefore.ToUniversalTime() || DateTime.UtcNow>cert.NotAfter.ToUniversalTime())return false;
        using var chain=new X509Chain(); chain.ChainPolicy.TrustMode=X509ChainTrustMode.CustomRootTrust; chain.ChainPolicy.CustomTrustStore.Add(ca); chain.ChainPolicy.RevocationMode=X509RevocationMode.NoCheck; chain.ChainPolicy.ApplicationPolicy.Add(new Oid("1.3.6.1.5.5.7.3.2")); return chain.Build(cert);
    }
    // The address chosen for the clients comes first. The other names and private addresses of this computer let a
    // school switch between computer name, DNS name and fixed IP without a new authority or new client packages.
    public static List<string> ServerNames(string host)
    {
        var names=new List<string>{host.Trim(),Environment.MachineName};
        string domain=System.Net.NetworkInformation.IPGlobalProperties.GetIPGlobalProperties().DomainName;
        if(!string.IsNullOrWhiteSpace(domain))names.Add(Environment.MachineName+"."+domain.Trim('.'));
        foreach(var adapter in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces().Where(n=>n.OperationalStatus==System.Net.NetworkInformation.OperationalStatus.Up))
            foreach(var unicast in adapter.GetIPProperties().UnicastAddresses.Where(a=>a.Address.AddressFamily==System.Net.Sockets.AddressFamily.InterNetwork))
            {
                try{ValidateLocalNetwork(unicast.Address+"/32");names.Add(unicast.Address.ToString());}catch(ArgumentException){}
            }
        return names.Where(n=>Uri.CheckHostName(n)!=UriHostNameType.Unknown).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
    }
    // Several subnets (for example Jefatura, Dirección and Secretaría on different VLANs), separated by commas, semicolons or lines.
    public static List<string> ParseNetworks(string text)
    {
        var list=(text??"").Split(new[]{',',';',' ','\r','\n','\t'},StringSplitOptions.RemoveEmptyEntries).Select(s=>s.Trim()).Where(s=>s.Length>0).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        if(list.Count==0)throw new ArgumentException("Indica al menos una red autorizada.");
        if(list.Count>32)throw new ArgumentException("Se admiten como máximo 32 redes autorizadas.");
        foreach(var item in list)ValidateLocalNetwork(item);
        return list;
    }
    public static void ValidateLocalNetwork(string value)
    {
        var parts=value.Split('/');if(parts.Length>2 || !IPAddress.TryParse(parts[0],out var address))throw new ArgumentException("La red autorizada debe ser una dirección o CIDR de red local.");
        int bits=parts.Length==1?address.GetAddressBytes().Length*8:int.Parse(parts[1]);var bytes=address.GetAddressBytes();
        if(bits<0 || bits>bytes.Length*8)throw new ArgumentException("Máscara de red no válida.");
        bool allowed=IPAddress.IsLoopback(address) && bits>=(bytes.Length==4?8:128);
        if(bytes.Length==4)allowed|=bytes[0]==10&&bits>=8 || bytes[0]==172&&bytes[1]>=16&&bytes[1]<=31&&bits>=12 || bytes[0]==192&&bytes[1]==168&&bits>=16;
        else allowed|=(bytes[0]&254)==252&&bits>=7 || bytes[0]==254&&(bytes[1]&192)==128&&bits>=10;
        if(!allowed)throw new ArgumentException("La red autorizada debe limitarse a una red privada local; no se permite abrir el servicio a Internet.");
    }
    public static bool NetworkAllowed(IPAddress? address,IEnumerable<string> ranges)
    {
        if(address==null)return false; if(address.IsIPv4MappedToIPv6)address=address.MapToIPv4(); if(IPAddress.IsLoopback(address))return true;
        byte[] bytes=address.GetAddressBytes();
        foreach(string range in ranges)
        {
            string[] parts=range.Split('/'); if(!IPAddress.TryParse(parts[0],out var network))continue;
            byte[] net=network.GetAddressBytes(); if(net.Length!=bytes.Length)continue;
            int bits=parts.Length==1?net.Length*8:int.Parse(parts[1]); if(bits<0||bits>net.Length*8)throw new ArgumentException("Red autorizada no válida.");
            bool match=true; for(int i=0;i<net.Length;i++){int mask=bits>=8?255:bits<=0?0:255<<(8-bits)&255; if((bytes[i]&mask)!=(net[i]&mask)){match=false;break;}bits-=8;}
            if(match)return true;
        }
        return false;
    }
}

