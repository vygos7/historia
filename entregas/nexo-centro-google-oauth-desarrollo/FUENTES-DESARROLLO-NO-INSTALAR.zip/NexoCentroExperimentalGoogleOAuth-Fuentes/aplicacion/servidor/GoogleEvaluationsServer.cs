#nullable enable
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using AgendaClara;
using Microsoft.AspNetCore.SignalR;

namespace AgendaClara.Server;
public interface IGoogleSecretProtector { string Protect(string value); string Unprotect(string value); }
public sealed class GoogleMachineSecret : IGoogleSecretProtector
{
    public string Protect(string value){byte[] b=Encoding.UTF8.GetBytes(value);try{return Convert.ToBase64String(Certificates.Protect(b));}finally{CryptographicOperations.ZeroMemory(b);}}
    public string Unprotect(string value){byte[] b=Certificates.Unprotect(Convert.FromBase64String(value));try{return Encoding.UTF8.GetString(b);}finally{CryptographicOperations.ZeroMemory(b);}}
}
public sealed class GoogleServerSettings
{
    public int Format {get;set;}=1;
    public string PrefillTemplate {get;set;}="";
    public string Endpoint {get;set;}="";
    public string SecretProtected {get;set;}="";
    public bool Enabled {get;set;}
    public int PollMinutes {get;set;}=15;
}
public sealed class GoogleBridgeEnvelope { public string Payload {get;set;}=""; public string Signature {get;set;}=""; }
public sealed class GoogleBridgePage
{
    public int Protocol {get;set;}
    public string Nonce {get;set;}="";
    public string FormId {get;set;}="";
    public int NextIndex {get;set;}=-1;
    public List<GoogleEvaluationResponse> Responses {get;set;}=[];
}
public sealed class GoogleBridgeClient
{
    public static readonly JsonSerializerOptions Json=new(){PropertyNamingPolicy=JsonNamingPolicy.CamelCase,IncludeFields=true,MaxDepth=24};
    readonly HttpClient http;
    public GoogleBridgeClient(HttpClient http){this.http=http;}
    public static Uri Endpoint(string text)
    {
        if(!Uri.TryCreate(text,UriKind.Absolute,out var uri)||uri.Scheme!="https"||!uri.Host.Equals("script.google.com",StringComparison.OrdinalIgnoreCase)||!uri.IsDefaultPort||uri.UserInfo.Length>0||uri.Query.Length>0||uri.Fragment.Length>0||!System.Text.RegularExpressions.Regex.IsMatch(uri.AbsolutePath,@"^/macros/s/[A-Za-z0-9_-]{8,}/exec$"))throw new ArgumentException("Usa la URL HTTPS /exec del despliegue de Google Apps Script.");return uri;
    }
    public static string Sign(string payload,string secret){using var hmac=new HMACSHA256(Encoding.UTF8.GetBytes(secret));return Convert.ToBase64String(hmac.ComputeHash(Encoding.UTF8.GetBytes(payload)));}
    public static bool ValidSignature(string payload,string signature,string secret)
    {try{return CryptographicOperations.FixedTimeEquals(Convert.FromBase64String(Sign(payload,secret)),Convert.FromBase64String(signature));}catch(FormatException){return false;}}
    public async Task<GoogleBridgePage> Read(string endpoint,string secret,DateTime since,int index,CancellationToken token)
    {
        Uri uri=Endpoint(endpoint);string nonce=Guid.NewGuid().ToString("N");
        string payload=Convert.ToBase64String(Encoding.UTF8.GetBytes(JsonSerializer.Serialize(new{protocol=1,nonce,timestamp=DateTimeOffset.UtcNow.ToUnixTimeSeconds(),sinceUtc=since.ToUniversalTime().ToString("o"),index,limit=100},Json)));
        using var request=new HttpRequestMessage(HttpMethod.Post,uri){Content=new StringContent(JsonSerializer.Serialize(new GoogleBridgeEnvelope{Payload=payload,Signature=Sign(payload,secret)},Json),Encoding.UTF8,"application/json")};
        using var timeout=CancellationTokenSource.CreateLinkedTokenSource(token);timeout.CancelAfter(TimeSpan.FromSeconds(8));
        using var response=await http.SendAsync(request,HttpCompletionOption.ResponseHeadersRead,timeout.Token);
        HttpResponseMessage final=response;HttpResponseMessage? redirectResponse=null;
        try
        {
            if(response.StatusCode==HttpStatusCode.Redirect||response.StatusCode==HttpStatusCode.SeeOther)
            {
                var next=response.Headers.Location;
                if(next==null||!next.IsAbsoluteUri||next.Scheme!="https"||next.Host!="script.googleusercontent.com"||!next.IsDefaultPort||next.UserInfo.Length>0||!next.AbsolutePath.StartsWith("/macros/echo",StringComparison.Ordinal))throw new HttpRequestException("Google no ha devuelto un resultado autorizado.");
                // ContentService devuelve un GET firmado; no reenviar el POST a otro destino.
                redirectResponse=await http.GetAsync(next,HttpCompletionOption.ResponseHeadersRead,timeout.Token);final=redirectResponse;
            }
            final.EnsureSuccessStatusCode();
            using var stream=await final.Content.ReadAsStreamAsync(timeout.Token);using var memory=new MemoryStream();byte[] buffer=new byte[8192];int count;
            while((count=await stream.ReadAsync(buffer,timeout.Token))>0){if(memory.Length+count>4*1024*1024)throw new InvalidDataException("Respuesta de Google demasiado grande.");memory.Write(buffer,0,count);}
            var envelope=JsonSerializer.Deserialize<GoogleBridgeEnvelope>(memory.ToArray(),Json)??throw new InvalidDataException("Respuesta vacía de Google.");
            if(!ValidSignature(envelope.Payload,envelope.Signature,secret))throw new CryptographicException("Firma de respuesta no válida.");
            var page=JsonSerializer.Deserialize<GoogleBridgePage>(Convert.FromBase64String(envelope.Payload),Json)??throw new InvalidDataException("Resultado no válido.");
            if(page.Protocol!=1||page.Nonce!=nonce||page.Responses==null||page.Responses.Count>100||page.NextIndex>=0&&page.NextIndex<=index)throw new InvalidDataException("Protocolo, nonce o paginación no válidos.");
            return page;
        }
        finally{redirectResponse?.Dispose();}
    }
}
public sealed class GoogleEvaluationService
{
    readonly ServerEngine engine;readonly IGoogleSecretProtector secrets;readonly GoogleBridgeClient bridge;readonly string configPath;
    GoogleServerSettings config=new();GoogleEvaluationManager? manager;readonly SemaphoreSlim polling=new(1,1),trigger=new(0,1);
    string lastResult="Integración desactivada. No se consulta Google.";DateTime lastPollUtc;
    readonly Func<DateTime> clock;int resumeIndex,configurationRevision;DateTime resumeSince;
    public GoogleEvaluationService(ServerEngine engine,IGoogleSecretProtector secrets,GoogleBridgeClient bridge,Func<DateTime>? clock=null)
    {
        this.engine=engine;this.secrets=secrets;this.bridge=bridge;this.clock=clock??(()=>DateTime.UtcNow);configPath=Path.Combine(engine.Root,"google-settings.xml");
        try{if(File.Exists(configPath)){config=XmlData.Read<GoogleServerSettings>(File.ReadAllText(configPath));if(config.Format!=1||config.PollMinutes<5||config.PollMinutes>1440)throw new IOException();}}
        catch(Exception ex)when(ex is IOException||ex is InvalidOperationException||ex is ArgumentException){config=new();lastResult="La configuración de Google no se pudo leer; integración desactivada, agenda disponible.";}
    }
    GoogleEvaluationManager Manager
    {
        get{lock(engine.Gate)return manager??=new GoogleEvaluationManager(()=>engine.Store,engine.Gate,Path.Combine(engine.Root,"google-evaluations.xml"),Files.Atomic,clock,c=>engine.Apply(c,new Principal(GoogleEvaluationManager.Actor,"servidor-experimental","Jefatura",true,clock().AddMinutes(5))));}
    }
    public bool Enabled {get{lock(engine.Gate)return config.Enabled;}}
    public int Minutes {get{lock(engine.Gate)return config.PollMinutes;}}
    public GoogleEvaluationStatus Status()
    {
        lock(engine.Gate)
        {
            var result=new GoogleEvaluationStatus{Settings=new GoogleEvaluationSettings{PrefillTemplate=config.PrefillTemplate,Endpoint=config.Endpoint,Enabled=config.Enabled,PollMinutes=config.PollMinutes,HasSecret=config.SecretProtected.Length>0},LastPollUtc=lastPollUtc,LastResult=lastResult};
            try{result.Items=Manager.Items();}catch(Exception ex)when(ex is IOException||ex is InvalidOperationException){result.LastResult="Registro de respuestas no disponible; no se han aplicado cambios.";}return result;
        }
    }
    public void Configure(GoogleEvaluationSettings settings)
    {
        if(settings.PollMinutes<5||settings.PollMinutes>1440)throw new ArgumentException("El intervalo debe estar entre 5 y 1440 minutos.");
        if(settings.PrefillTemplate.Length>0)GoogleEvaluationRules.ValidateTemplate(settings.PrefillTemplate);
        if(settings.Endpoint.Length>0)GoogleBridgeClient.Endpoint(settings.Endpoint);
        if(settings.Secret.Length>0&&(settings.Secret.Length<32||settings.Secret.Length>256))throw new ArgumentException("El secreto debe tener entre 32 y 256 caracteres.");
        lock(engine.Gate)
        {
            var next=new GoogleServerSettings{Enabled=settings.Enabled,Endpoint=settings.Endpoint,PollMinutes=settings.PollMinutes,PrefillTemplate=settings.PrefillTemplate,SecretProtected=settings.Secret.Length>0?secrets.Protect(settings.Secret):config.SecretProtected};
            if(next.Enabled&&(next.SecretProtected.Length==0||next.Endpoint.Length==0||next.PrefillTemplate.Length==0))throw new ArgumentException("Faltan plantilla, despliegue o secreto de Google.");
            Files.Atomic(configPath,Encoding.UTF8.GetBytes(XmlData.Write(next)));config=next;configurationRevision++;resumeIndex=0;lastResult=next.Enabled?"Consulta automática activada.":"Consulta automática desactivada.";
        }
        if(settings.Enabled)RequestPoll();
    }
    public GoogleEvaluationLink Issue(GoogleLinkRequest request){lock(engine.Gate)return Manager.Issue(request,config.PrefillTemplate);}
    public void Csv(string text){var rows=GoogleEvaluationCsvReader.Parse(text);if(rows.Count>500)throw new ArgumentException("Importa como máximo 500 respuestas por archivo.");foreach(var r in rows)Manager.Ingest(r,false);}
    public GoogleEvaluationItem Apply(GoogleEvaluationApply request)=>Manager.Apply(request);
    public void RequestPoll(){lock(engine.Gate){if(config.Endpoint.Length==0||config.SecretProtected.Length==0)throw new ArgumentException("Configura primero la conexión autorizada con Google.");lastResult="Consulta programada; pulsa Actualizar para ver el resultado.";}try{trigger.Release();}catch(SemaphoreFullException){}}
    public Task<bool> Wait(CancellationToken token)=>trigger.WaitAsync(TimeSpan.FromMinutes(Minutes),token);
    public async Task<int> Poll(CancellationToken token)
    {
        if(!await polling.WaitAsync(0,token))return 0;int applied=0;
        try
        {
            GoogleServerSettings current;int revision;lock(engine.Gate){current=XmlData.Read<GoogleServerSettings>(XmlData.Write(config));revision=configurationRevision;}
            if(current.Endpoint.Length==0||current.SecretProtected.Length==0)return 0;
            string secret=secrets.Unprotect(current.SecretProtected);int index;DateTime since=Manager.SinceUtc;
            lock(engine.Gate){index=resumeSince==since?resumeIndex:0;resumeSince=since;}
            for(int page=0;page<20;page++)
            {
                var data=await bridge.Read(current.Endpoint,secret,since,index,token);
                foreach(var r in data.Responses)
                {token.ThrowIfCancellationRequested();bool had=Manager.IsApplied(r);GoogleEvaluationItem item;lock(engine.Gate){if(configurationRevision!=revision)return applied;bool auto=config.Enabled;item=Manager.Ingest(r,auto);}if(!had&&item.Status=="Aplicada")applied++;await Task.Yield();}
                if(data.NextIndex<0){lock(engine.Gate){if(configurationRevision!=revision)return applied;resumeIndex=0;lastPollUtc=clock();lastResult="Consulta correcta. Memorias incorporadas: "+applied+". Las incidencias quedan pendientes de revisión.";}return applied;}
                index=data.NextIndex;lock(engine.Gate){if(configurationRevision!=revision)return applied;resumeIndex=index;}
            }
            lock(engine.Gate)lastResult="Límite de consulta alcanzado; faltan páginas por revisar. Ninguna memoria existente se sobrescribe automáticamente.";return applied;
        }
        catch(OperationCanceledException)when(token.IsCancellationRequested){throw;}
        catch(Exception ex)when(ex is HttpRequestException||ex is InvalidDataException||ex is IOException||ex is CryptographicException||ex is JsonException||ex is FormatException||ex is OperationCanceledException||ex is ArgumentException||ex is InvalidOperationException)
        {lock(engine.Gate){lastPollUtc=clock();lastResult="No se pudo completar la consulta Google ("+ex.GetType().Name+"). La agenda sigue funcionando.";}return applied;}
        finally{polling.Release();}
    }
}
public sealed class GoogleEvaluationWorker(GoogleEvaluationService service,IHubContext<ChangesHub> hub,ServerEngine engine,ILogger<GoogleEvaluationWorker> logger):BackgroundService
{
    protected override async Task ExecuteAsync(CancellationToken token)
    {
        bool first=true;
        while(!token.IsCancellationRequested)
        {
            try
            {
                bool requested=first?false:await service.Wait(token);bool enabled=service.Enabled;first=false;
                if(!requested&&!enabled)continue;
                int changed=await service.Poll(token);
                if(changed>0)await hub.Clients.All.SendAsync("Changed",engine.Snapshot().Generation,engine.Snapshot().Revision,token);
            }
            catch(OperationCanceledException)when(token.IsCancellationRequested){break;}
            catch(Exception ex){logger.LogWarning("Integración Google detenida temporalmente: {Tipo}. No se registran respuestas ni credenciales.",ex.GetType().Name);try{await Task.Delay(TimeSpan.FromMinutes(1),token);}catch(OperationCanceledException){break;}}
        }
    }
}
