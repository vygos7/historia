#nullable enable
using System.Diagnostics;
using System.Text.Json;
using System.Threading.Channels;

namespace AgendaClara.Server;

// Cola acotada: el diagnóstico nunca espera al disco desde la autenticación.
// No se registran cuerpos, nombres de usuario, certificados, cabeceras de autorización ni tokens.
public sealed class SessionDiagnostics : IAsyncDisposable
{
    readonly Channel<string> queue=Channel.CreateBounded<string>(new BoundedChannelOptions(2048){FullMode=BoundedChannelFullMode.Wait,SingleReader=true});
    readonly Task writer;
    readonly string path;
    long dropped;
    public long Dropped=>Interlocked.Read(ref dropped);
    public bool WriteFailed {get;private set;}
    public SessionDiagnostics(string root)
    {
        path=Path.Combine(root,"diagnostico","sesiones.jsonl");
        writer=Task.Run(async()=>
        {
            await foreach(string line in queue.Reader.ReadAllAsync())
            {
                try
                {
                    Directory.CreateDirectory(Path.GetDirectoryName(path)!);
                    if(File.Exists(path) && new FileInfo(path).Length>1048576)File.Move(path,path+".anterior",true);
                    await File.AppendAllTextAsync(path,line+Environment.NewLine);
                }
                catch(Exception ex)when(ex is IOException || ex is UnauthorizedAccessException || ex is System.Security.SecurityException){WriteFailed=true;}
            }
        });
    }
    public async Task InvokeAsync(HttpContext context,RequestDelegate next)
    {
        if(context.Request.Path!="/api/session"){await next(context);return;}
        var trace=Begin(context);
        context.Response.OnStarting(()=>{trace.Mark("response_headers");return Task.CompletedTask;});
        context.Response.OnCompleted(()=>{trace.Mark("response_completed");return Task.CompletedTask;});
        using var aborted=context.RequestAborted.Register(()=>trace.Mark("request_aborted"));
        try{await next(context);}
        catch(Exception ex){trace.Mark("exception_"+ex.GetType().Name);throw;}
        finally{trace.End();}
    }
    public static string RequestId(string? supplied)=>Guid.TryParseExact(supplied,"N",out var id)?id.ToString("N"):Guid.NewGuid().ToString("N");
    public SessionTrace Begin(HttpContext context)
    {
        var trace=new SessionTrace(this,RequestId(context.Request.Headers["X-Agenda-Request-Id"].ToString()),context);
        context.Items[typeof(SessionTrace)]=trace;
        context.Response.Headers["X-Agenda-Request-Id"]=trace.Id;
        trace.Mark("http_received");return trace;
    }
    internal void Record(SessionTrace trace,string phase,int? status=null)
    {
        var line=JsonSerializer.Serialize(new{revision="2026-11-05-r1",utc=DateTime.UtcNow,request=trace.Id,phase,ms=trace.ElapsedMilliseconds,
            connection=trace.Context.Connection.Id,local=trace.Context.Connection.LocalIpAddress?.ToString(),localPort=trace.Context.Connection.LocalPort,
            remote=trace.Context.Connection.RemoteIpAddress?.ToString(),remotePort=trace.Context.Connection.RemotePort,status,
            aborted=trace.Context.RequestAborted.IsCancellationRequested,dropped=Dropped});
        if(!queue.Writer.TryWrite(line))Interlocked.Increment(ref dropped);
    }
    // Sólo metadatos técnicos: nunca mensaje, ruta de disco, cuerpo ni credenciales.
    public void StorageFailure(HttpContext context,IOException error)
    {
        try
        {
            var causes=new List<object>();
            for(Exception? ex=error;ex!=null && causes.Count<8;ex=ex.InnerException)
            {
                var frames=new StackTrace(ex,false).GetFrames()??[];
                causes.Add(new{type=ex.GetType().FullName,hresult=ex.HResult.ToString("X8"),
                    sqliteCode=ex is AgendaClara.StoreException store?(int?)store.Code:null,
                    methods=frames.Take(12).Select(f=>{var m=f.GetMethod();return (m?.DeclaringType?.FullName??"")+"."+(m?.Name??"");}).ToArray()});
            }
            string route=context.Request.Path=="/api/session"?"/api/session":context.Request.Path=="/api/snapshot"?"/api/snapshot":"other";
            string line=JsonSerializer.Serialize(new{revision="2026-11-05-storage-r1",utc=DateTime.UtcNow,
                request=SessionTrace.From(context)?.Id,phase="storage_exception",route,causes});
            if(!queue.Writer.TryWrite(line))Interlocked.Increment(ref dropped);
        }
        catch(Exception){WriteFailed=true;}
    }
    public async ValueTask DisposeAsync(){queue.Writer.TryComplete();await writer;}
}
public sealed class SessionTrace
{
    readonly SessionDiagnostics owner;
    readonly Stopwatch watch=Stopwatch.StartNew();
    public string Id {get;}
    internal HttpContext Context {get;}
    public long ElapsedMilliseconds=>watch.ElapsedMilliseconds;
    internal SessionTrace(SessionDiagnostics owner,string id,HttpContext context){this.owner=owner;Id=id;Context=context;}
    public static SessionTrace? From(HttpContext context)=>context.Items.TryGetValue(typeof(SessionTrace),out var value)?value as SessionTrace:null;
    // Los valores proceden exclusivamente de llamadas constantes del código del servidor.
    public void Mark(string phase)=>owner.Record(this,phase);
    public void End()=>owner.Record(this,"pipeline_end",Context.Response.StatusCode);
}
