#nullable enable
using System.Security.Claims;
using System.Security.AccessControl;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text.Json;
using AgendaClara;
using Microsoft.AspNetCore.Identity;

namespace AgendaClara.Server;

public sealed class Person
{
    public string UserName { get; set; } = "";
    public string Role { get; set; } = "";
    public string PasswordHash { get; set; } = "";
    public string Stamp { get; set; } = Guid.NewGuid().ToString("N");
    public bool Enabled { get; set; } = true;
    public bool Admin { get; set; }
}
public sealed class TrustedDevice
{
    public string AutomaticUser { get; set; } = "";
    public string Name { get; set; } = "";
    public string Thumbprint { get; set; } = "";
    public bool Enabled { get; set; } = true;
}
public sealed class Renewal
{
    public string Hash { get; set; } = ""; public string UserName { get; set; } = ""; public string Device { get; set; } = ""; public string Stamp { get; set; } = "";
    public DateTime UntilUtc { get; set; }
}
public sealed class SecurityFile
{
    public string ServerId { get; set; } = Guid.NewGuid().ToString("N");
    public List<Person> People { get; set; } = [];
    public List<TrustedDevice> Devices { get; set; } = [];
    public List<Renewal> Renewals { get; set; } = [];
}
public sealed record Access(string UserName, string Device, string Stamp, DateTime UntilUtc);
public sealed record Principal(string UserName, string Device, string Role, bool Admin, DateTime UntilUtc);
public sealed class SecurityState
{
    readonly object gate = new();
    readonly string path;
    SecurityFile state;
    readonly Dictionary<string, Access> access = new();
    readonly Dictionary<string, (int Count, DateTime Until)> failures = new();
    readonly PasswordHasher<Person> hasher = new();
    readonly Person dummy = new Person { UserName="invalid" };
    public SecurityState(string root) { path = Path.Combine(root,"security.json"); state = JsonSerializer.Deserialize<SecurityFile>(File.ReadAllText(path)) ?? throw new IOException("Configuración de seguridad vacía."); dummy.PasswordHash=hasher.HashPassword(dummy,Convert.ToBase64String(RandomNumberGenerator.GetBytes(32))); }
    public string ServerId { get { lock(gate) return state.ServerId; } }
    public int ActiveSessions { get { lock(gate) return access.Values.Count(a=>a.UntilUtc>DateTime.UtcNow); } }
    public static string Hash(string text) => Convert.ToHexString(SHA256.HashData(System.Text.Encoding.UTF8.GetBytes(text)));
    public static string CertificateId(X509Certificate2 cert) => cert.GetCertHashString(HashAlgorithmName.SHA256);
    static string Token() => Convert.ToBase64String(RandomNumberGenerator.GetBytes(32));
    void Save()
    {
        try { Files.Atomic(path, JsonSerializer.SerializeToUtf8Bytes(state)); }
        catch
        {
            // Do not keep permissions or passwords in memory when their durable save failed.
            try { state=JsonSerializer.Deserialize<SecurityFile>(File.ReadAllText(path))??new SecurityFile(); } catch { state=new SecurityFile(); }
            access.Clear();throw;
        }
    }
    public static void ValidatePassword(string password) { if(password.Length < 12 || password.Length > 256) throw new ArgumentException("La contraseña debe tener entre 12 y 256 caracteres."); }
    public static void Initialize(string root, string name, string password)
    {
        ValidatePassword(password); if(string.IsNullOrWhiteSpace(name) || name.Length>80) throw new ArgumentException("Nombre de usuario no válido.");
        var p = new Person { UserName=name.Trim(), Role="Jefatura", Admin=true }; p.PasswordHash=new PasswordHasher<Person>().HashPassword(p,password);
        Files.Atomic(Path.Combine(root,"security.json"), JsonSerializer.SerializeToUtf8Bytes(new SecurityFile { People=[p] }));
    }
    public void Enroll(TrustedDevice device) { lock(gate) { if(state.Devices.Any(d=>d.Name.Equals(device.Name,StringComparison.OrdinalIgnoreCase))) throw new ArgumentException("Ya existe un equipo con ese nombre."); state.Devices.Add(device); Save(); } }
    public bool DeviceAllowed(string device) { lock(gate) return state.Devices.Any(d=>d.Enabled && d.Thumbprint==device); }
    static void Report(Action<string>? progress,string phase)
    {
        // Un observador nunca cambia el resultado de la autenticación.
        try{progress?.Invoke(phase);}catch(Exception){}
    }
    public SessionReply Login(LoginRequest input, string device,Action<string>? progress=null)
    {
        Report(progress,"security_lock_wait");
        lock(gate)
        {
            Report(progress,"security_lock_acquired");
            if(!DeviceAllowed(device)) throw new UnauthorizedAccessException("Equipo no autorizado.");
            string key=device+":"+(input.UserName??"").ToUpperInvariant();
            if(failures.TryGetValue(key,out var f) && f.Count>=5 && f.Until>DateTime.UtcNow) throw new UnauthorizedAccessException("Demasiados intentos. Espera quince minutos.");
            Person? person;
            if(!string.IsNullOrEmpty(input.RefreshToken))
            {
                var renewal=state.Renewals.FirstOrDefault(r=>r.Hash==Hash(input.RefreshToken) && r.Device==device && r.UntilUtc>DateTime.UtcNow);
                person=renewal==null?null:state.People.FirstOrDefault(p=>p.Enabled && p.UserName==renewal.UserName && p.Stamp==renewal.Stamp);
                if(person==null) throw new UnauthorizedAccessException("La sesión ha caducado. Identifícate de nuevo.");
                state.Renewals.Remove(renewal!);
            }
            else if(input.Automatic)
            {
                var enrolled=state.Devices.SingleOrDefault(d=>d.Enabled && d.Thumbprint==device && d.AutomaticUser.Length>0);
                person=enrolled==null?null:state.People.SingleOrDefault(p=>p.Enabled && p.UserName==enrolled.AutomaticUser);
                if(person==null || !person.UserName.Equals(input.UserName,StringComparison.OrdinalIgnoreCase))throw new UnauthorizedAccessException("Este puesto no tiene acceso automático autorizado.");
            }
            else
            {
                person=state.People.FirstOrDefault(p=>p.Enabled && p.UserName.Equals(input.UserName?.Trim(),StringComparison.OrdinalIgnoreCase));
                Report(progress,"password_check_start");
                var checkedPerson=person??dummy;
                var verification=input.Password==null||input.Password.Length>256?PasswordVerificationResult.Failed:hasher.VerifyHashedPassword(checkedPerson,checkedPerson.PasswordHash,input.Password);
                Report(progress,"password_check_end");
                if(person==null || verification==PasswordVerificationResult.Failed)
                {
                    failures[key]=(f.Until>DateTime.UtcNow?f.Count+1:1,DateTime.UtcNow.AddMinutes(15));
                    throw new UnauthorizedAccessException("Usuario o contraseña incorrectos.");
                }
            }
            Report(progress,"credentials_accepted");
            if(input.Automatic)state.Renewals.RemoveAll(r=>r.UserName==person.UserName && r.Device==device);
            failures.Remove(key);
            string token=Token(), refresh=Token(); var until=DateTime.UtcNow.AddMinutes(15);
            foreach(var expired in access.Where(a=>a.Value.UntilUtc<=DateTime.UtcNow).Select(a=>a.Key).ToList())access.Remove(expired);
            access[Hash(token)]=new Access(person.UserName,device,person.Stamp,until);
            state.Renewals.RemoveAll(r=>r.UntilUtc<=DateTime.UtcNow);
            // A remembered session is tied to this user and enrolled machine.
            state.Renewals.Add(new Renewal { Hash=Hash(refresh), UserName=person.UserName, Device=device, Stamp=person.Stamp, UntilUtc=DateTime.UtcNow.AddDays(30) });
            Report(progress,"session_save_start");Save();Report(progress,"session_save_end");
            return new SessionReply { AccessToken=token, RefreshToken=refresh, UserName=person.UserName, Role=person.Role, Admin=person.Admin, ServerId=state.ServerId, ExpiresUtc=until, OfflineUntilUtc=DateTime.UtcNow.AddHours(36) };
        }
    }
    public Principal? Authenticate(string token,string device)
    {
        lock(gate)
        {
            if(!DeviceAllowed(device) || !access.TryGetValue(Hash(token),out var a) || a.Device!=device || a.UntilUtc<=DateTime.UtcNow) return null;
            var p=state.People.FirstOrDefault(p=>p.UserName==a.UserName && p.Enabled && p.Stamp==a.Stamp);
            return p==null?null:new Principal(p.UserName,device,p.Role,p.Admin,a.UntilUtc);
        }
    }
    public void Logout(string name,string device) { lock(gate) { state.Renewals.RemoveAll(r=>r.UserName==name && r.Device==device); foreach(var k in access.Where(x=>x.Value.UserName==name && x.Value.Device==device).Select(x=>x.Key).ToList()) access.Remove(k); Save(); } }
    public List<UserView> Users() { lock(gate) return state.People.Select(p=>new UserView { UserName=p.UserName, Role=p.Role, Enabled=p.Enabled, Admin=p.Admin }).ToList(); }
    public List<DeviceView> Devices() { lock(gate) return state.Devices.Select(d=>new DeviceView { Name=d.Name, Thumbprint=d.Thumbprint, Enabled=d.Enabled }).ToList(); }
    public void ChangeUser(UserChange change)
    {
        lock(gate)
        {
            if(string.IsNullOrWhiteSpace(change.UserName)||change.UserName.Length>80 || !new[]{"Direccion","Jefatura","Secretaria"}.Contains(change.Role)) throw new ArgumentException("Usuario o perfil no válido.");
            var p=state.People.FirstOrDefault(p=>p.UserName.Equals(change.UserName.Trim(),StringComparison.OrdinalIgnoreCase));
            bool added=p==null; p??=new Person { UserName=change.UserName.Trim() };
            if(added && string.IsNullOrEmpty(change.Password)) throw new ArgumentException("El usuario nuevo necesita contraseña.");
            if(p.Admin && p.Enabled && (!change.Admin || !change.Enabled) && state.People.Count(u=>u.Enabled && u.Admin)<2) throw new ArgumentException("Debe quedar al menos un administrador activo.");
            if(!string.IsNullOrEmpty(change.Password)) { ValidatePassword(change.Password); p.PasswordHash=hasher.HashPassword(p,change.Password); }
            p.Role=change.Role; p.Admin=change.Admin; p.Enabled=change.Enabled; p.Stamp=Guid.NewGuid().ToString("N");
            if(added) state.People.Add(p); Save();
        }
    }
    public void SetDevice(string thumbprint,bool enabled) { lock(gate) { var d=state.Devices.SingleOrDefault(d=>d.Thumbprint==thumbprint)??throw new ArgumentException("Equipo desconocido."); d.Enabled=enabled; Save(); } }
    public byte[] ExportForBackup() { lock(gate) { var copy=JsonSerializer.Deserialize<SecurityFile>(JsonSerializer.Serialize(state))!; copy.Renewals.Clear(); return JsonSerializer.SerializeToUtf8Bytes(copy); } }
    public static void ValidateExport(byte[] data)
    {
        var state=JsonSerializer.Deserialize<SecurityFile>(data)??throw new IOException("Configuración de seguridad no válida.");
        if(!state.People.Any(p=>p.Admin && p.Enabled) || state.People.Any(p=>string.IsNullOrWhiteSpace(p.PasswordHash)) || state.People.Select(p=>p.UserName.ToUpperInvariant()).Distinct().Count()!=state.People.Count) throw new IOException("La copia no conserva usuarios y administrador válidos.");
    }
    public void Restore(byte[] data)
    {
        ValidateExport(data);
        var recovered=JsonSerializer.Deserialize<SecurityFile>(data)??throw new IOException("Copia de seguridad de acceso no válida.");
        if(!recovered.People.Any(p=>p.Enabled && p.Admin) || recovered.People.Any(p=>string.IsNullOrEmpty(p.PasswordHash))) throw new IOException("La copia no conserva un administrador válido.");
        lock(gate) { string id=state.ServerId; state=recovered; state.ServerId=id; state.Renewals.Clear(); access.Clear(); Save(); }
    }
}
public static class Files
{
    public static void Atomic(string path, byte[] bytes)
    {
        string temp=path+"."+Guid.NewGuid().ToString("N")+".tmp";
        try
        {
            using(var f=new FileStream(temp,FileMode.CreateNew,FileAccess.Write,FileShare.None)){f.Write(bytes);f.Flush(true);}
            // ReplaceFile intenta combinar metadatos y falló con ERROR_UNABLE_TO_REMOVE_REPLACED
            // (1175) al guardar sesiones después de la reversión. La renombración es atómica
            // en el mismo volumen; conservamos explícitamente la DACL antes de publicarla.
            if(OperatingSystem.IsWindows() && File.Exists(path))
            {
                var access=new FileInfo(path).GetAccessControl(AccessControlSections.Access);
                // SetAccessControl sólo persiste secciones marcadas como modificadas.
                var preserved=new FileSecurity();
                preserved.SetSecurityDescriptorBinaryForm(access.GetSecurityDescriptorBinaryForm(),AccessControlSections.Access);
                new FileInfo(temp).SetAccessControl(preserved);
            }
            File.Move(temp,path,true);
        }
        finally { if(File.Exists(temp)) File.Delete(temp); }
    }
}
