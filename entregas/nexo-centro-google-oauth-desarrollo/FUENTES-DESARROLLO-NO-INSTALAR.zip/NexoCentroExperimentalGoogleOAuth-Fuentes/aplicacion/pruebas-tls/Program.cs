using System.Net.Security;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using AgendaClara;
using AgendaClara.Server;
[assembly:System.Runtime.Versioning.SupportedOSPlatform("windows")]
class TlsTests
{
    static int count;
    static void Check(bool value,string message){Console.WriteLine((value?"CORRECTO: ":"FALLO: ")+message);if(!value)throw new Exception(message);count++;}
    static X509Certificate2 Leaf(X509Certificate2 root,string oid,bool expired=false)
    {
        using var rsa=RSA.Create(2048);var req=new CertificateRequest("CN=JEFATURA",rsa,HashAlgorithmName.SHA256,RSASignaturePadding.Pkcs1);
        req.CertificateExtensions.Add(new X509BasicConstraintsExtension(false,false,0,true));
        req.CertificateExtensions.Add(new X509KeyUsageExtension(X509KeyUsageFlags.DigitalSignature|X509KeyUsageFlags.KeyEncipherment,true));
        req.CertificateExtensions.Add(new X509EnhancedKeyUsageExtension(new OidCollection{new Oid(oid)},true));
        var san=new SubjectAlternativeNameBuilder();san.AddDnsName("JEFATURA");req.CertificateExtensions.Add(san.Build());
        using var pub=req.Create(root,DateTimeOffset.UtcNow.AddMinutes(-4),expired?DateTimeOffset.UtcNow.AddMinutes(-1):DateTimeOffset.UtcNow.AddDays(10),RandomNumberGenerator.GetBytes(16));return pub.CopyWithPrivateKey(rsa);
    }
    static int Main(string[] args)
    {
        string folder=Path.GetFullPath(args[0]);Directory.CreateDirectory(folder);var imported=new List<X509Certificate2>();
        try
        {
            Certificates.Initialize(folder,"JEFATURA");
            using var ca=Certificates.Load(folder,"authority.pfx");using var server=Certificates.Load(folder,"server.pfx");
            Check(server.GetNameInfo(X509NameType.DnsName,false).Equals("JEFATURA",StringComparison.OrdinalIgnoreCase),"El generador incluye JEFATURA como SAN DNS");
            using var device=Leaf(ca,"1.3.6.1.5.5.7.3.2");
            var persisted=X509CertificateLoader.LoadPkcs12(device.Export(X509ContentType.Pfx,"synthetic"),"synthetic",X509KeyStorageFlags.UserKeySet|X509KeyStorageFlags.PersistKeySet);imported.Add(persisted);
            using(var personal=new X509Store(StoreName.My,StoreLocation.CurrentUser)){personal.Open(OpenFlags.ReadWrite);personal.Add(persisted);}
            var cfg=new SharedConfiguration{Shared=true,ServerUrl="https://JEFATURA:7443",ClientThumbprint=persisted.Thumbprint,UserName="sintetico",ServerAuthority=Convert.ToBase64String(ca.RawData)};
            using var remote=new RemoteConnection(cfg,Path.Combine(folder,"config.xml"));
            Check(remote.ValidateServerCertificate(server,SslPolicyErrors.RemoteCertificateChainErrors),"La cadena de servidor correcta se valida exclusivamente contra la CA esperada");
            Check(!remote.ValidateServerCertificate(server,SslPolicyErrors.RemoteCertificateNameMismatch),"El nombre TLS incorrecto se rechaza");
            using var expired=Leaf(ca,"1.3.6.1.5.5.7.3.1",true);
            Check(!remote.ValidateServerCertificate(expired,SslPolicyErrors.RemoteCertificateChainErrors),"Un certificado de servidor realmente caducado se rechaza");
            Check(!remote.ValidateServerCertificate(device,SslPolicyErrors.RemoteCertificateChainErrors),"Un certificado clientAuth no sirve como certificado serverAuth");
            byte[] broken=server.RawData;broken[^1]^=1;using var bad=X509CertificateLoader.LoadCertificate(broken);
            Check(!remote.ValidateServerCertificate(bad,SslPolicyErrors.RemoteCertificateChainErrors),"Una firma de servidor alterada se rechaza");
            Check(Certificates.ValidateClient(device,ca),"El servidor acepta el certificado clientAuth de su CA");
            Check(!Certificates.ValidateClient(server,ca),"El servidor rechaza un certificado serverAuth como certificado de cliente");
            using var expiredDevice=Leaf(ca,"1.3.6.1.5.5.7.3.2",true);
            Check(!Certificates.ValidateClient(expiredDevice,ca),"El servidor rechaza un certificado cliente realmente caducado");
            string other=Path.Combine(folder,"otra-ca");Directory.CreateDirectory(other);Certificates.Initialize(other,"JEFATURA");using var otherServer=Certificates.Load(other,"server.pfx");using var otherRoot=Certificates.Load(other,"authority.pfx");
            Check(!remote.ValidateServerCertificate(otherServer,SslPolicyErrors.None),"Incluso una cadena confiable en Windows se rechaza si corresponde a otra CA");
            Check(!Certificates.ValidateClient(device,otherRoot),"El servidor rechaza un cliente emitido por otra autoridad");
            Console.WriteLine("RESUMEN: "+count+" comprobaciones de certificados correctas; 0 fallos.");return 0;
        }
        catch(Exception ex){Console.WriteLine(ex);return 1;}
        finally
        {
            using var store=new X509Store(StoreName.My,StoreLocation.CurrentUser);store.Open(OpenFlags.ReadWrite);
            foreach(var cert in imported){store.Remove(cert);using var rsa=cert.GetRSAPrivateKey();if(rsa is RSACng cng)cng.Key.Delete();cert.Dispose();}
        }
    }
}

