using System.Net;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.Json;
using AgendaClara;
static class OfficialTests
{
    const string FormId="FORM_1234567890";
    static int passed,failed;
    static GoogleAppRegistration Registration()=>new(){ClientId="123456-test.apps.googleusercontent.com",ClientSecret="CREDENCIAL-FICTICIA-DE-DESARROLLO",PickerApiKey="AIza"+new string('A',32),ProjectNumber="1234567890"};
    static GoogleAccountTokens Tokens()=>new(){AccessToken="ACCESS-FICTICIO-NO-PUBLICAR-EN-URL",RefreshToken="REFRESH-FICTICIO-NO-RESPONDER",Scope=GoogleAppRegistration.Scope,ExpiresUtc=DateTime.UtcNow.AddHours(1)};
    static void Check(bool v,string why="Comprobación"){if(!v)throw new Exception(why);}
    static async Task Reject(Func<Task> action){try{await action();}catch(Exception e)when(e is ArgumentException||e is IOException||e is InvalidOperationException){return;}throw new Exception("La operación debía rechazarse");}
    static async Task Test(string name,Func<Task> action){try{await action();passed++;Console.WriteLine("OK · "+name);}catch(Exception ex){failed++;Console.WriteLine("FALLO · "+name+" · "+ex);}}
    static Task Sync(Action action){action();return Task.CompletedTask;}
    public static async Task<int> Main()
    {
        if(!OperatingSystem.IsWindows())NativeLibrary.SetDllImportResolver(typeof(Store).Assembly,(n,a,p)=>n=="winsqlite3.dll"?NativeLibrary.Load("libsqlite3.so.0"):IntPtr.Zero);
        await Test("Registro ausente bloquea distribución y no se presenta como conectado",()=>Sync(()=>{var r=GoogleAppRegistration.Load();Check(!r.IsPrepared&&!r.CanDistribute);using var f=new Fixture(r);Check(!f.Controller.Status().ApplicationPrepared&&!f.Controller.Status().Connected);}));
        await Test("Credenciales de pruebas no autorizan distribución",()=>Sync(()=>{var r=Registration();Check(r.IsPrepared&&!r.CanDistribute);r.ProductionApproved=true;Check(!r.CanDistribute);}));
        await Test("Se solicita únicamente el permiso oficial drive.file",()=>Sync(()=>Check(GoogleAppRegistration.Scope=="https://www.googleapis.com/auth/drive.file")));
        await Test("Conectar se verifica en Google y protege tokens",async()=>{using var f=new Fixture();f.Controller.Connect(Tokens());await f.Controller.CurrentJob;var s=f.Controller.Status();Check(s.Connected&&s.AccountId=="account-1",s.Error);Check(f.Api.Calls.Contains("refresh")&&f.Api.Calls.Contains("account"));string xml=XmlData.Write(s);Check(!xml.Contains(Tokens().RefreshToken)&&!xml.Contains(Tokens().AccessToken));Check(f.Vault.Token.AccountId=="account-1");});
        await Test("No acepta tokens sin el permiso solicitado",async()=>{using var f=new Fixture();var token=Tokens();token.Scope="https://www.googleapis.com/auth/drive.readonly";await Reject(()=>{f.Controller.Connect(token);return Task.CompletedTask;});Check(!f.Api.Calls.Any());});
        await Test("Preparación del formulario se ejecuta en segundo plano",async()=>{using var f=new Fixture();await f.Connect();f.Api.Block=new TaskCompletionSource();f.Controller.Choose(new GoogleChooseForm{FormId=FormId});Check(f.Controller.Status().Busy);f.Api.Block.SetResult();await f.Controller.CurrentJob;Check(f.Controller.Status().FormReady,f.Controller.Status().Error);});
        await Test("Una respuesta completa la memoria automáticamente",async()=>{using var f=new Fixture();await f.Ready();var e=f.Event();var link=f.Controller.Link(new GoogleLinkRequest{EventId=e.Id});f.Api.Rows.Add(Response(link));long revision=f.Store.LoadSnapshot().Revision;f.Controller.Poll();await f.Controller.CurrentJob;Check(f.Store.Find(e.Id).Options.Memory.Rating=="Buena");Check(f.Store.Find(e.Id).Notes=="Conservar");Check(f.Store.Find(e.Id).Options.Tasks.Count==1);Check(f.Store.LoadSnapshot().Revision==revision+1);Check(f.Changes>0);});
        await Test("Volver a consultar no duplica ni cambia memorias",async()=>{using var f=new Fixture();await f.Ready();var e=f.Event();f.Api.Rows.Add(Response(f.Controller.Link(new GoogleLinkRequest{EventId=e.Id})));f.Controller.Poll();await f.Controller.CurrentJob;long revision=f.Store.LoadSnapshot().Revision;f.Controller.Poll();await f.Controller.CurrentJob;Check(f.Store.LoadSnapshot().Revision==revision&&f.Controller.Status().Items.Count==1);});
        await Test("Una segunda respuesta exige revisión",async()=>{using var f=new Fixture();await f.Ready();var e=f.Event();var link=f.Controller.Link(new GoogleLinkRequest{EventId=e.Id});f.Api.Rows.Add(Response(link));f.Controller.Poll();await f.Controller.CurrentJob;var second=Response(link);second.Memory.Rating="Otra";f.Api.Rows.Add(second);f.Controller.Poll();await f.Controller.CurrentJob;Check(f.Store.Find(e.Id).Options.Memory.Rating=="Buena");Check(f.Controller.Status().Items.Count(x=>x.Status=="Pendiente")==1);});
        await Test("Conserva una memoria existente",async()=>{using var f=new Fixture();await f.Ready();var e=f.Event();var link=f.Controller.Link(new GoogleLinkRequest{EventId=e.Id});e=f.Store.Find(e.Id);e.Options.Memory=new ActivityMemory{Rating="Manual",Continuity="No",Justification="Se conserva"};f.Store.Save(e);f.Api.Rows.Add(Response(link));f.Controller.Poll();await f.Controller.CurrentJob;Check(f.Store.Find(e.Id).Options.Memory.Rating=="Manual");Check(f.Controller.Status().Items.Single().Status=="Pendiente");});
        await Test("No asigna por proximidad de fechas",async()=>{using var f=new Fixture();await f.Ready();var e=f.Event();var r=Response(f.Controller.Link(new GoogleLinkRequest{EventId=e.Id}));r.Code="otro-codigo";f.Api.Rows.Add(r);f.Controller.Poll();await f.Controller.CurrentJob;Check(!f.Store.Find(e.Id).Options.Memory.HasContent);Check(f.Controller.Status().Items.Single().Status=="Pendiente");});
        await Test("Dos respuestas nuevas para la misma salida quedan para revisión",async()=>{using var f=new Fixture();await f.Ready();var e=f.Event();var link=f.Controller.Link(new GoogleLinkRequest{EventId=e.Id});f.Api.Rows.Add(Response(link));f.Api.Rows.Add(Response(link));f.Controller.Poll();await f.Controller.CurrentJob;Check(!f.Store.Find(e.Id).Options.Memory.HasContent);Check(f.Controller.Status().Items.All(x=>x.Status=="Pendiente"));});
        await Test("Renovar el token conserva la asociación con la cuenta",async()=>{using var f=new Fixture();await f.Ready();f.Vault.Token.ExpiresUtc=DateTime.UtcNow.AddDays(-10);f.Controller.Poll();await f.Controller.CurrentJob;f.Restart();Check(f.Controller.Status().Connected);});
        await Test("Fallo de Google no cambia la agenda",async()=>{using var f=new Fixture();await f.Ready();var e=f.Event();long v=f.Store.LoadSnapshot().Revision;f.Api.Fail=true;f.Controller.Poll();await f.Controller.CurrentJob;Check(f.Store.LoadSnapshot().Revision==v&&!f.Store.Find(e.Id).Options.Memory.HasContent);Check(f.Controller.Status().Error.Length>0);});
        await Test("Google revocado solicita reconexión y detiene la importación",async()=>{using var f=new Fixture();await f.Ready();f.Api.Revoked=true;f.Controller.Poll();await f.Controller.CurrentJob;Check(!f.Controller.Status().Connected&&!f.Controller.Status().FormReady);});
        await Test("Restablecer conserva la conexión sin autorizar más archivos",async()=>{using var f=new Fixture();await f.Ready();f.Restart();Check(f.Controller.Status().Connected&&f.Controller.Status().FormReady);});
        await Test("Persistencia parcial de cuentas falla de forma cerrada",async()=>{using var f=new Fixture();await f.Ready();f.Vault.Token.AccountId="otra-cuenta";f.Restart();Check(!f.Controller.Status().Connected);});
        await Test("Desconectar conserva las memorias y elimina credenciales",async()=>{using var f=new Fixture();await f.Ready();var e=f.Event();f.Controller.Disconnect();Check(f.Vault.Token==null&&!f.Controller.Status().Connected);Check(f.Store.Find(e.Id)!=null);});
        await Test("Cliente REST prepara sólo los identificadores que faltan",async()=>{var h=new Handler{MissingIdentifiers=true};var api=new GoogleOfficialApi(new HttpClient(h),Registration());var form=await api.PrepareForm("ACCESS",FormId,default);Check(form.Fields.Count==10);Check(h.Requests.Count(x=>x.Url.EndsWith(":batchUpdate"))==1);var body=h.Requests.Single(x=>x.Url.EndsWith(":batchUpdate")).Body;Check(body.Contains("createItem")&&!body.Contains("deleteItem")&&!body.Contains("updateItem"));Check(!h.Requests.Any(x=>x.Url.Contains("permissions")));});
        await Test("No duplica las preguntas existentes",async()=>{var h=new Handler();var api=new GoogleOfficialApi(new HttpClient(h),Registration());var f=await api.PrepareForm("ACCESS",FormId,default);Check(!h.Requests.Any(x=>x.Method==HttpMethod.Post));Check(f.Template.Contains("entry.16=__NEXO_CODE__"));});
        await Test("No escribe en un formulario que la cuenta no puede editar",async()=>{var h=new Handler{ReadOnly=true};await Reject(async()=>await new GoogleOfficialApi(new HttpClient(h),Registration()).PrepareForm("ACCESS",FormId,default));Check(h.Requests.All(x=>x.Method==HttpMethod.Get));});
        await Test("Preguntas de memoria incompletas se rechazan antes de escribir",async()=>{var h=new Handler{MissingRating=true,MissingIdentifiers=true};await Reject(async()=>await new GoogleOfficialApi(new HttpClient(h),Registration()).PrepareForm("ACCESS",FormId,default));Check(h.Requests.All(x=>x.Method==HttpMethod.Get));});
        await Test("Publicación conserva permisos y restricciones",async()=>{var h=new Handler{Unpublished=true};await new GoogleOfficialApi(new HttpClient(h),Registration()).PrepareForm("ACCESS",FormId,default);Check(h.Requests.Any(x=>x.Url.EndsWith(":setPublishSettings")));Check(!h.Requests.Any(x=>x.Url.Contains("permissions")));});
        await Test("Se leen las seis respuestas sin recopilar el correo del docente",async()=>{var h=new Handler();var api=new GoogleOfficialApi(new HttpClient(h),Registration());var p=await api.Responses("ACCESS",Form(),"",default);var r=p.Responses.Single();Check(r.Memory.Rating=="Buena"&&r.Memory.Continuity=="Sí"&&r.Memory.Justification=="Objetivos");Check(r.Code=="NCX-1");Check(!XmlData.Write(r).Contains("correo-que-no-se-recoge"));});
        await Test("Tokens nunca se añaden a las direcciones del formulario",async()=>{var h=new Handler();var api=new GoogleOfficialApi(new HttpClient(h),Registration());await api.Account(Tokens().AccessToken,default);Check(h.Requests.All(x=>!x.Url.Contains(Tokens().AccessToken)));Check(h.Requests.Single().Authorization=="Bearer "+Tokens().AccessToken);});
        await Test("Respuesta 401 requiere reconexión",async()=>{var h=new Handler{Unauthorized=true};try{await new GoogleOfficialApi(new HttpClient(h),Registration()).Account("ACCESS",default);throw new Exception();}catch(GoogleReconnectException){}});
        await Test("No acepta un enlace de respuesta ajeno a Google",async()=>await Reject(()=>Sync(()=>GoogleOfficialApi.Prefill("https://otro.ejemplo/viewform",Form()))));
        await Test("Selector usa sólo el tipo formulario y no pone tokens en URL",()=>Sync(()=>{var page=GoogleFormPicker.Page(Registration(),"TOKEN-SOLO-EN-MEMORIA","nonce","http://127.0.0.1:12345");Check(page.Contains("ViewId.FORMS")&&page.Contains("setOAuthToken(token)"));Check(page.Contains("script.onload=load")&&!page.Contains("onload='"));Check(!page.Contains("?access_token="));}));
        await Test("Selector completo en loopback rechaza peticiones cruzadas",async()=>{
            var opened=new TaskCompletionSource<string>();using var cancel=new CancellationTokenSource(TimeSpan.FromSeconds(15));var selected=GoogleFormPicker.Choose(Registration(),"ACCESS-PICKER",url=>opened.SetResult(url),cancel.Token);var url=new Uri(await opened.Task);string nonce=url.AbsolutePath.Replace("/choose-","");using var http=new HttpClient(new HttpClientHandler{UseProxy=false});
            using(var page=await http.GetAsync(url,cancel.Token)){Check(page.IsSuccessStatusCode);Check((await page.Content.ReadAsStringAsync()).Contains("ACCESS-PICKER"));Check(page.Headers.CacheControl.NoStore);Check(page.Headers.Contains("Content-Security-Policy"));}
            string callback=url.GetLeftPart(UriPartial.Authority)+"/picked-"+nonce;using(var invalid=await http.PostAsync(callback,new StringContent("{\"id\":\"FORM_1234567890\"}"),cancel.Token))Check(invalid.StatusCode==HttpStatusCode.Forbidden);
            using var good=new HttpRequestMessage(HttpMethod.Post,callback){Content=new StringContent("{\"id\":\"FORM_1234567890\"}",Encoding.UTF8,"application/json")};good.Headers.Add("Origin",url.GetLeftPart(UriPartial.Authority));using var response=await http.SendAsync(good,cancel.Token);Check(response.IsSuccessStatusCode);Check(await selected==FormId);
        });
        await Test("Callback OAuth usa PKCE y rechaza un estado ajeno",async()=>{
            var opened=new TaskCompletionSource<string>();using var receiver=new GoogleLoopbackReceiver(u=>opened.SetResult(u));using var flow=new Google.Apis.Auth.OAuth2.Flows.PkceGoogleAuthorizationCodeFlow(new Google.Apis.Auth.OAuth2.Flows.GoogleAuthorizationCodeFlow.Initializer{ClientSecrets=new Google.Apis.Auth.OAuth2.ClientSecrets{ClientId=Registration().ClientId,ClientSecret=Registration().ClientSecret},Scopes=new[]{GoogleAppRegistration.Scope}});
            var request=flow.CreateAuthorizationCodeRequest(receiver.RedirectUri,out var verifier);Check(verifier.Length>=43);using var cancel=new CancellationTokenSource(TimeSpan.FromSeconds(15));var received=receiver.ReceiveCodeAsync(request,cancel.Token);string auth=await opened.Task;Check(auth.Contains("code_challenge_method=S256")&&auth.Contains("code_challenge="));Check(request.State.Length>=32);
            using var http=new HttpClient(new HttpClientHandler{UseProxy=false});using(var bad=await http.GetAsync(receiver.RedirectUri+"?state=ajeno&code=INVALID",cancel.Token))Check(bad.StatusCode==HttpStatusCode.Forbidden);
            using(var good=await http.GetAsync(receiver.RedirectUri+"?state="+Uri.EscapeDataString(request.State)+"&code=AUTORIZACION-FICTICIA",cancel.Token))Check(good.IsSuccessStatusCode);Check((await received).Code=="AUTORIZACION-FICTICIA");
        });
        Console.WriteLine($"RESUMEN: {passed} comprobaciones correctas; {failed} fallos. Simuladores oficiales; conexión Google real y Windows pendientes.");return failed==0?0:1;
    }
    static GoogleOfficialForm Form(){using var json=JsonDocument.Parse(RawForm());var f=GoogleOfficialApi.MapForm(json.RootElement);f.Template=GoogleOfficialApi.Prefill("https://docs.google.com/forms/d/e/TESTFORM/viewform",f);return f;}
    static GoogleEvaluationResponse Response(GoogleEvaluationLink link)=>new(){ResponseId=Guid.NewGuid().ToString("N"),Code=link.Code,Title=link.Title,Date=link.Date,Group=link.Group,Memory=new ActivityMemory{Rating="Buena",Continuity="Sí",Justification="Objetivos"}};
    static readonly string[] Keys={"code","title","date","group","rating","positives","difficulties","improvements","continuity","justification"};
    static readonly string[] Labels={"Código de la actividad","Nombre de la actividad","Fecha de la salida","Curso o grupo","1. Valoración general","2. Aspectos positivos","3. Incidencias y dificultades","4. Propuestas de mejora","5. ¿Se recomienda repetir esta salida en próximos cursos?","6. Justificación de la continuidad"};
    static string RawForm(bool missingIdentifiers=false,bool missingRating=false,bool unpublished=false)
    {
        var items=new List<object>();for(int i=0;i<Keys.Length;i++){if(missingIdentifiers&&i<2||missingRating&&i==4)continue;var q=new Dictionary<string,object>{{"questionId",(i+16).ToString("x8")},{i==2?"dateQuestion":"textQuestion",i==2?new{includeYear=true}:(object)new{paragraph=i>=4}}};items.Add(new{title=Labels[i],questionItem=new{question=q}});}
        return JsonSerializer.Serialize(new{formId=FormId,info=new{title="Formulario de prueba"},responderUri="https://docs.google.com/forms/d/e/TESTFORM/viewform",items,publishSettings=new{publishState=new{isPublished=!unpublished,isAcceptingResponses=!unpublished}}});
    }
    sealed class Handler:HttpMessageHandler
    {
        public bool MissingIdentifiers,MissingRating,ReadOnly,Unpublished,Unauthorized;public List<(HttpMethod Method,string Url,string Body,string Authorization)> Requests=[];
        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage r,CancellationToken ct)
        {
            string body=r.Content==null?"":await r.Content.ReadAsStringAsync(ct);string url=r.RequestUri.AbsoluteUri;Requests.Add((r.Method,url,body,r.Headers.Authorization?.ToString()??""));if(Unauthorized)return new HttpResponseMessage(HttpStatusCode.Unauthorized);
            string response="{}";
            if(url.Contains("/drive/v3/about"))response="{\"user\":{\"permissionId\":\"account-1\",\"emailAddress\":\"pruebas@example.test\"}}";
            else if(url.Contains("/drive/v3/files/"))response=JsonSerializer.Serialize(new{id=FormId,mimeType="application/vnd.google-apps.form",capabilities=new{canEdit=!ReadOnly}});
            else if(url.EndsWith(":batchUpdate")){MissingIdentifiers=false;}
            else if(url.EndsWith(":setPublishSettings")){Unpublished=false;}
            else if(url.Contains("/responses?"))
            {var answers=new Dictionary<string,object>();string[] values={"NCX-1","Cine","2026-11-05","3.º","Buena","Positivo","Ninguna","Tiempo","Sí","Objetivos"};for(int i=0;i<values.Length;i++)answers[(i+16).ToString("x8")]=new{textAnswers=new{answers=new[]{new{value=values[i]}}}};response=JsonSerializer.Serialize(new{responses=new[]{new{responseId="resp-1",lastSubmittedTime="2026-11-06T12:00:00Z",respondentEmail="correo-que-no-se-recoge@example.test",answers}}});}
            else response=RawForm(MissingIdentifiers,MissingRating,Unpublished);
            return new HttpResponseMessage(HttpStatusCode.OK){Content=new StringContent(response,Encoding.UTF8,"application/json")};
        }
    }
    sealed class Vault:IGoogleTokenVault {public GoogleAccountTokens Token;public void Save(GoogleAccountTokens t){Token=t;}public GoogleAccountTokens Load()=>Token;public void Clear(){Token=null;}}
    sealed class Api:IGoogleOfficialApi
    {
        public bool Fail,Revoked;public TaskCompletionSource Block;public List<string> Calls=[];public List<GoogleEvaluationResponse> Rows=[];
        public Task<GoogleAccountTokens> Refresh(GoogleAccountTokens t,CancellationToken ct){Calls.Add("refresh");return Task.FromResult(new GoogleAccountTokens{AccessToken="ACCESS",RefreshToken=t.RefreshToken,Scope=t.Scope,ExpiresUtc=DateTime.UtcNow.AddHours(1)});}
        public Task<GoogleAccountInfo> Account(string a,CancellationToken ct){Calls.Add("account");return Task.FromResult(new GoogleAccountInfo{Id="account-1",Label="Pruebas"});}
        public async Task<GoogleOfficialForm> PrepareForm(string a,string id,CancellationToken ct){Calls.Add("prepare");if(Block!=null)await Block.Task;return Form();}
        public Task<GoogleOfficialPage> Responses(string a,GoogleOfficialForm f,string page,CancellationToken ct){Calls.Add("responses");if(Revoked)throw new GoogleReconnectException();if(Fail)throw new HttpRequestException("fallo sintético");return Task.FromResult(new GoogleOfficialPage{Responses=Rows.ToList()});}
    }
    sealed class Fixture:IDisposable
    {
        public string Root=Path.Combine(Path.GetTempPath(),"NexoCentroExperimentalGoogleOAuth",Guid.NewGuid().ToString("N"));public Store Store;public Vault Vault=new();public Api Api=new();public GoogleOfficialCoordinator Controller;public int Changes;readonly GoogleAppRegistration registration;
        public Fixture(GoogleAppRegistration r=null){registration=r??Registration();Directory.CreateDirectory(Root);Store=new Store(Path.Combine(Root,"agenda.sqlite3"),false);Create();}
        void Create()=>Controller=new GoogleOfficialCoordinator(Root,registration,Api,Vault,()=>Store,new object(),c=>Store.Apply(c,GoogleEvaluationManager.Actor,"pruebas"),File.WriteAllBytes,action=>Task.FromResult(action()),()=>Changes++,()=>new DateTime(2026,11,6,12,0,0,DateTimeKind.Utc));
        public void Restart(){Controller.Dispose();Create();}
        public async Task Connect(){Controller.Connect(Tokens());await Controller.CurrentJob;Check(Controller.Status().Connected,Controller.Status().Error);}
        public async Task Ready(){await Connect();Controller.Choose(new GoogleChooseForm{FormId=FormId});await Controller.CurrentJob;Check(Controller.Status().FormReady,Controller.Status().Error);}
        public AgendaEvent Event(){var e=new AgendaEvent{Title="Cine",Notes="Conservar",Start=new DateTime(2026,11,5),End=new DateTime(2026,11,5),AllDay=true};e.Options.Group="3.º";e.Options.Tasks.Add(new PreparationTask{Description="Preparativo",Responsible="Tutoría"});Store.StampNew(e);Store.Save(e);return Store.Find(e.Id);}
        public void Dispose(){Controller.Dispose();Store.Dispose();Directory.Delete(Root,true);}
    }
}
