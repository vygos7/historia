using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;

// Sólo se compila en las baterías sintéticas de .NET 10, nunca en el cliente.
// En Windows no dependemos de que Schannel pueda utilizar claves CNG efímeras.
// Se exportan y reimportan únicamente certificados recién generados por la prueba;
// no se importan raíces de confianza y al terminar se eliminan esas claves.
internal static class TlsFixtureKeys
{
    static readonly List<X509Certificate2> owned=new List<X509Certificate2>();
    internal static X509Certificate2 ForTls(X509Certificate2 generated)
    {
        if(!OperatingSystem.IsWindows())return generated;
        string password=Convert.ToBase64String(RandomNumberGenerator.GetBytes(32));
        byte[] bytes=generated.Export(X509ContentType.Pfx,password);
        try
        {
            var loaded=X509CertificateLoader.LoadPkcs12(bytes,password,X509KeyStorageFlags.UserKeySet|X509KeyStorageFlags.PersistKeySet|X509KeyStorageFlags.Exportable);
            try
            {
                using var key=loaded.GetRSAPrivateKey();
                if(key==null)throw new CryptographicException("La clave sintética no es accesible.");
                key.SignData(new byte[32],HashAlgorithmName.SHA256,RSASignaturePadding.Pkcs1);
                owned.Add(new X509Certificate2(loaded));
                return loaded;
            }
            catch{loaded.Dispose();throw;}
        }
        finally{CryptographicOperations.ZeroMemory(bytes);generated.Dispose();}
    }
    internal static void Cleanup()
    {
        if(!OperatingSystem.IsWindows())return;
        List<Exception> failures=new List<Exception>();
        foreach(var certificate in owned)
        {
            try
            {
                using var key=certificate.GetRSAPrivateKey();
                if(key is RSACng cng && !cng.Key.IsEphemeral)cng.Key.Delete();
                else if(key is RSACryptoServiceProvider csp){csp.PersistKeyInCsp=false;csp.Clear();}
            }
            catch(Exception ex){failures.Add(ex);}
            finally{certificate.Dispose();}
        }
        owned.Clear();
        if(failures.Count>0)throw new AggregateException("No se pudieron retirar todas las claves sintéticas.",failures);
    }
}
