using System.Security.Cryptography;
using AgendaClara;
using AgendaClara.Server;
[assembly:System.Runtime.Versioning.SupportedOSPlatform("windows")]
static class SecurityTests
{
    static List<string> log=[];static int count;
    static void Check(bool value,string text){log.Add((value?"CORRECTO: ":"FALLO: ")+text);Console.WriteLine(log[^1]);if(!value)throw new Exception(text);count++;}
    static bool Rejected(Action action){try{action();return false;}catch{return true;}}
    static System.Security.Cryptography.X509Certificates.X509SubjectAlternativeNameExtension ServerNames(string root)
    {
        string password=System.Text.Encoding.UTF8.GetString(Certificates.Unprotect(File.ReadAllBytes(Path.Combine(root,"certificate-password.dpapi"))));
        using var cert=System.Security.Cryptography.X509Certificates.X509CertificateLoader.LoadPkcs12FromFile(Path.Combine(root,"server.pfx"),password,System.Security.Cryptography.X509Certificates.X509KeyStorageFlags.EphemeralKeySet);
        return new System.Security.Cryptography.X509Certificates.X509SubjectAlternativeNameExtension(cert.Extensions["2.5.29.17"]!.RawData);
    }
    // Several subnets, server names for other subnets and changing the network of an installed server.
    static void Networks(string root)
    {
        Directory.CreateDirectory(root);
        var list=Certificates.ParseNetworks("192.168.10.0/24, 192.168.30.0/24;10.20.0.0/16\n192.168.10.0/24");
        Check(list.SequenceEqual(new[]{"192.168.10.0/24","192.168.30.0/24","10.20.0.0/16"}),"Se admiten varias subredes separadas por comas, punto y coma o líneas, sin duplicados");
        Check(Rejected(()=>Certificates.ParseNetworks("192.168.10.0/24, 8.8.8.0/24")),"Una lista con una red de Internet se rechaza entera");
        Check(Rejected(()=>Certificates.ParseNetworks(" , ")),"Una lista vacía se rechaza");
        Check(Certificates.ParseNetworks("10.0.0.0/8,172.16.0.0/12,192.168.0.0/16").Count==3,"Se admite autorizar toda la red privada del centro");
        Check(Certificates.NetworkAllowed(System.Net.IPAddress.Parse("192.168.30.15"),list) && Certificates.NetworkAllowed(System.Net.IPAddress.Parse("10.20.4.1"),list) && !Certificates.NetworkAllowed(System.Net.IPAddress.Parse("192.168.40.2"),list),"Con varias subredes se admiten todas las autorizadas y ninguna más");
        Check(Certificates.NetworkAllowed(System.Net.IPAddress.Parse("::ffff:192.168.30.15"),list),"Una dirección IPv4 representada en IPv6 se reconoce");
        var names=Certificates.ServerNames("JEFATURA");
        Check(names[0]=="JEFATURA" && names.Contains(Environment.MachineName,StringComparer.OrdinalIgnoreCase),"El certificado del servidor incluye la dirección elegida y el nombre del equipo");
        Certificates.Initialize(root,"JEFATURA");
        var san=ServerNames(root);
        Check(san.EnumerateDnsNames().Contains("JEFATURA") && san.EnumerateDnsNames().Contains(Environment.MachineName,StringComparer.OrdinalIgnoreCase),"El certificado generado contiene el nombre elegido y el del equipo");
        var own=names.Where(n=>System.Net.IPAddress.TryParse(n,out _)).ToList();
        Check(own.All(ip=>san.EnumerateIPAddresses().Any(a=>a.ToString()==ip)),"El certificado contiene las IP privadas del equipo ("+(own.Count>0?string.Join(", ",own):"ninguna detectada")+"), para poder usar la IP fija desde otra subred");
        File.WriteAllText(Path.Combine(root,"server.json"),System.Text.Json.JsonSerializer.Serialize(new ServerSettings{PublicHost="JEFATURA",Port=7443,AllowedNetworks=["192.168.10.0/24"],BackupDirectory=Path.Combine(root,"copias")}));
        var config=AgendaClara.Server.Program.ConfigureNetwork(root,"192.168.10.5","192.168.10.0/24, 192.168.30.0/24","7450");
        var saved=System.Text.Json.JsonSerializer.Deserialize<ServerSettings>(File.ReadAllText(Path.Combine(root,"server.json")))!;
        Check(saved.PublicHost=="192.168.10.5" && saved.Port==7450 && saved.AllowedNetworks.SequenceEqual(new[]{"192.168.10.0/24","192.168.30.0/24"}) && saved.BackupDirectory==Path.Combine(root,"copias"),"Cambiar la red de un servidor instalado conserva el resto de su configuración");
        Check(ServerNames(root).EnumerateIPAddresses().Any(a=>a.ToString()=="192.168.10.5"),"Al cambiar la dirección se renueva el certificado con la nueva IP");
        var certificateBefore=File.ReadAllBytes(Path.Combine(root,"server.pfx"));var authorityBefore=File.ReadAllBytes(Path.Combine(root,"authority.cer"));
        AgendaClara.Server.Program.ConfigureNetwork(root,"192.168.10.5","192.168.10.0/24, 192.168.30.0/24","7450");
        Check(certificateBefore.SequenceEqual(File.ReadAllBytes(Path.Combine(root,"server.pfx"))) && authorityBefore.SequenceEqual(File.ReadAllBytes(Path.Combine(root,"authority.cer"))),"Actualizar sin cambiar dirección conserva exactamente el certificado y la autoridad");
        Check(Rejected(()=>AgendaClara.Server.Program.ConfigureNetwork(root,"","1.2.3.0/24","")) && System.Text.Json.JsonSerializer.Deserialize<ServerSettings>(File.ReadAllText(Path.Combine(root,"server.json")))!.AllowedNetworks.Count==2,"Una red no válida no modifica la configuración guardada");
    }
    static int Main(string[] args)
    {
        var root=Path.GetFullPath(args[0]);Directory.CreateDirectory(root);
        try
        {
            SecurityState.Initialize(root,"administrador-prueba","Password-Sintetico-2026!");var security=new SecurityState(root);security.Enroll(new TrustedDevice{Name="Prueba lógica sin TLS",Thumbprint="logical-test"});
            var session=security.Login(new LoginRequest{UserName="administrador-prueba",Password="Password-Sintetico-2026!"},"logical-test");
            Check(security.Authenticate(session.AccessToken,"logical-test")?.Admin==true,"La sesión válida conserva los permisos del servidor");
            Check(security.Authenticate(session.AccessToken,"otro-equipo")==null,"La sesión no se puede trasladar a otro equipo");
            Check(!File.ReadAllText(Path.Combine(root,"security.json")).Contains("Password-Sintetico-2026!"),"La contraseña no aparece en el archivo de seguridad");
            security.ChangeUser(new UserChange{UserName="persona-prueba",Role="Direccion",Password="Password-Usuario-2026!",Enabled=true});
            Check(Rejected(()=>security.ChangeUser(new UserChange{UserName="administrador-prueba",Role="Jefatura",Enabled=false,Admin=false})),"Se protege al último administrador activo");
            using(var locked=new FileStream(Path.Combine(root,"security.json"),FileMode.Open,FileAccess.Read,FileShare.Read))
            {
                Check(Rejected(()=>security.ChangeUser(new UserChange{UserName="persona-prueba",Role="Direccion",Enabled=false})),"Un fallo de escritura impide confirmar un cambio de permisos");
                Check(security.Users().Single(p=>p.UserName=="persona-prueba").Enabled,"El fallo de escritura revierte los permisos en memoria al estado duradero");
            }
            Check(security.Authenticate(session.AccessToken,"logical-test")==null,"Un fallo al guardar seguridad invalida los accesos en memoria");
            security.ChangeUser(new UserChange{UserName="persona-prueba",Role="Direccion",Enabled=false});Check(!security.Users().Single(p=>p.UserName=="persona-prueba").Enabled,"El cambio se guarda al recuperarse el almacenamiento");
            Check(Rejected(()=>Certificates.ValidateLocalNetwork("0.0.0.0/0")),"No se permite autorizar todo Internet como red local");
            Certificates.ValidateLocalNetwork("192.168.20.0/24");Check(Certificates.NetworkAllowed(System.Net.IPAddress.Parse("192.168.20.10"),new[]{"192.168.20.0/24"}),"La restricción permite la subred privada configurada");
            Check(Rejected(()=>XmlData.Read<AgendaCommand>("<!DOCTYPE AgendaCommand [<!ENTITY example 'forbidden'>]><AgendaCommand><A>&example;</A></AgendaCommand>")),"La deserialización rechaza DTD y entidades XML");
            Check(Rejected(()=>security.Login(new LoginRequest{UserName="administrador-prueba",Password="incorrecta"},"logical-test")),"El servidor rechaza una contraseña incorrecta");
            Check(AgendaClara.Server.Program.RedirectedPassword(new StringReader("﻿Clave-Paquete-2026!\n"))=="Clave-Paquete-2026!","Una marca BOM delante de la contraseña recibida por la entrada estándar se descarta");
            Check(AgendaClara.Server.Program.RedirectedPassword(new StringReader("Clave-Paquete-2026!\n"))=="Clave-Paquete-2026!","La contraseña sin marca BOM se lee sin cambios");
            Networks(Path.Combine(root,"red"));
            log.Add("RESUMEN: "+count+" comprobaciones de seguridad correctas, 0 fallos.");Console.WriteLine(log[^1]);return 0;
        }
        catch(Exception ex){log.Add("FALLO: "+ex);Console.WriteLine(ex);return 1;}
        finally{File.WriteAllLines(Path.Combine(root,"resultado-seguridad.txt"),log);}
    }
}
