using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Threading;
using System.Threading.Tasks;
using AgendaClara;

class DiagnosticsTests
{
    static int passed;static string folder,root,dotnet,host;static Process server;
    static readonly List<X509Certificate2> imported=new List<X509Certificate2>();
    static void Check(bool value,string name){Console.WriteLine((value?"CORRECTO: ":"FALLO: ")+name);if(!value)throw new Exception(name);passed++;}
    static void StartServer()
    {
        string ready=Path.Combine(root,"listo.txt");if(File.Exists(ready))File.Delete(ready);
        var start=new ProcessStartInfo(dotnet,"\""+host+"\" \""+root+"\""){UseShellExecute=false,CreateNoWindow=true,RedirectStandardOutput=true,RedirectStandardError=true};
        server=Process.Start(start);server.OutputDataReceived+=(s,e)=>{};server.ErrorDataReceived+=(s,e)=>{};server.BeginOutputReadLine();server.BeginErrorReadLine();
        var until=DateTime.UtcNow.AddSeconds(30);while(!File.Exists(ready)&&!server.HasExited&&DateTime.UtcNow<until)Thread.Sleep(100);
        Check(File.Exists(ready)&&!server.HasExited,"El servidor sintético escucha sólo en loopback");
    }
    static void StopServer(){if(server!=null){if(!server.HasExited){server.Kill();server.WaitForExit(10000);}server.Dispose();server=null;}}
    static X509Certificate2 Import(string relative)
    {
        var cert=new X509Certificate2(File.ReadAllBytes(Path.Combine(root,relative,"equipo.pfx")),"Prueba-Paquete-2026!",X509KeyStorageFlags.UserKeySet|X509KeyStorageFlags.PersistKeySet);
        using(var store=new X509Store(StoreName.My,StoreLocation.CurrentUser)){store.Open(OpenFlags.ReadWrite);store.Add(cert);}imported.Add(cert);return cert;
    }
    static SharedConfiguration Config(X509Certificate2 cert,bool ip=false)
    {
        string address=File.ReadAllText(Path.Combine(root,"puesto","servidor.txt"));if(ip)address=address.Replace("localhost","127.0.0.1");
        return new SharedConfiguration{Shared=true,ServerUrl=address,ClientThumbprint=cert.Thumbprint,UserName="pruebas",ServerAuthority=Convert.ToBase64String(File.ReadAllBytes(Path.Combine(root,"authority.cer")))};
    }
    static RemoteConnection Remote(SharedConfiguration config){return new RemoteConnection(config,Path.Combine(folder,Guid.NewGuid().ToString("N"),"config.xml"));}
    static string[] StoreIds(StoreName name){using(var store=new X509Store(name,StoreLocation.CurrentUser)){store.Open(OpenFlags.ReadOnly);return store.Certificates.Cast<X509Certificate2>().Select(c=>c.Thumbprint).OrderBy(s=>s).ToArray();}}
    static async Task Run()
    {
        var pending=new TaskCompletionSource<bool>();var watch=Stopwatch.StartNew();bool timeout=false;
        try{await ConnectionProbe.Bounded(pending.Task,TimeSpan.FromMilliseconds(100),CancellationToken.None);}catch(TimeoutException){timeout=true;}
        pending.SetResult(true);Check(timeout&&watch.Elapsed<TimeSpan.FromSeconds(2),"Un plazo real interrumpe la espera de una operación que no responde");
        using(var cancel=new CancellationTokenSource()){cancel.Cancel();bool cancelled=false;try{await ConnectionProbe.Bounded(Task.Delay(10000),TimeSpan.FromSeconds(5),cancel.Token);}catch(OperationCanceledException){cancelled=true;}Check(cancelled,"Cancelar se distingue de agotar un plazo");}
        Check(ConnectionProbe.SameSubnet(IPAddress.Parse("192.168.4.153"),IPAddress.Parse("255.255.252.0"),IPAddress.Parse("192.168.6.135")),"Dirección y Jefatura pertenecen a la misma /22 cuando ésa es la máscara local");
        Check(!ConnectionProbe.SameSubnet(IPAddress.Parse("192.168.4.153"),IPAddress.Parse("255.255.255.0"),IPAddress.Parse("192.168.6.135")),"Una /24 produce un resultado diferente y no se presupone la máscara");
        Check(!ConnectionDiagnostics.Explain(new SocketException((int)SocketError.TimedOut),false).Message.Contains("otra subred"),"Un tiempo de espera genérico no culpa a las subredes");
        StartServer();var cert=Import("puesto");var revoked=Import("revocado");
        var foreign=Import(Path.Combine("otra-ca","puesto"));
        var silent=new TcpListener(IPAddress.Loopback,0);silent.Start();
        try
        {
            int port=((IPEndPoint)silent.LocalEndpoint).Port;var accept=silent.AcceptTcpClientAsync();var report=new ConnectionReport();bool tlsTimeout=false;
            var probe=ConnectionProbe.ProbeAsync(new Uri("https://127.0.0.1:"+port),cert,(s,c,ch,e)=>false,report,null,CancellationToken.None,TimeSpan.FromMilliseconds(250));
            using(var socket=await accept)try{await probe;}catch(ConnectionFailure ex){tlsTimeout=ex.Code=="tls-timeout";}
            Check(tlsTimeout,"Un puerto TCP abierto que no negocia HTTPS se identifica como espera TLS, sin culpar a la API");
        }
        finally{silent.Stop();}
        using(var remote=Remote(Config(cert)))
        {
            var report=await remote.DiagnoseAsync("Prueba-Usuario-2026!");File.WriteAllText(Path.Combine(folder,"diagnostico-correcto.txt"),report.Text);
            Check(report.ApiAvailable&&report.RealtimeAvailable,"Cliente real .NET Framework 4.8: nombre localhost, TLS, API y SignalR");
            Check(report.Text.Contains("HTTP id=") && report.Text.Contains("cabeceras recibidas") && report.Text.Contains("cuerpo recibido"),"El diagnóstico del cliente net48 separa petición, cabeceras y cuerpo");
            Check(report.Text.Contains("TCP observado por proceso"),"La observación nativa se identifica como evidencia del proceso, sin atribuirla a un socket único");
            Check(remote.CanWrite,"La agenda sólo permite escribir tras recuperar los datos");
            var health=await remote.Admin<ServerHealth>("GET","api/health");Check(health.Version=="4.0.4","El diagnóstico del servidor informa de la versión real");
            StopServer();StartServer();await remote.SynchronizeAsync();await remote.CheckRealtimeAsync();Check(remote.CanWrite,"Se recupera la API después de reiniciar el servidor");
        }
        using(var remote=Remote(Config(cert,true))){var report=await remote.DiagnoseAsync("Prueba-Usuario-2026!");Check(report.ApiAvailable&&report.RealtimeAvailable,"Conexión por IP con SAN IP válido sin desactivar TLS");}
        var wrong=Config(cert);wrong.ServerAuthority=Convert.ToBase64String(File.ReadAllBytes(Path.Combine(root,"otra-ca","authority.cer")));
        using(var remote=Remote(wrong)){var report=await remote.DiagnoseAsync("Prueba-Usuario-2026!");Check(!report.ApiAvailable&&report.FailureCode=="tls-untrusted","Una autoridad incorrecta se rechaza y se identifica como fallo de confianza");}
        using(var remote=Remote(Config(revoked))){var report=await remote.DiagnoseAsync("Prueba-Usuario-2026!");Check(!report.ApiAvailable&&report.FailureCode=="tls-client","El certificado de puesto revocado se distingue de una contraseña incorrecta");}
        using(var remote=Remote(Config(foreign))){var report=await remote.DiagnoseAsync("Prueba-Usuario-2026!");Check(!report.ApiAvailable,"Un certificado emitido por otra autoridad no obtiene una sesión");}
        var missing=Config(cert);missing.ServerUrl="https://agendaclara-prueba.inexistente.invalid:7443";
        using(var remote=Remote(missing)){var report=await remote.DiagnoseAsync("Prueba-Usuario-2026!");Check(!report.ApiAvailable&&report.FailedStage=="DNS","Un nombre inexistente falla en DNS antes de TCP o TLS");}
        using(var remote=Remote(Config(cert))){var report=await remote.DiagnoseAsync("Incorrecta-2026!");Check(!report.ApiAvailable&&report.FailureCode=="authentication","Credenciales incorrectas: la red y TLS no se culpan");}
        File.WriteAllText(Path.Combine(root,"fallo.txt"),"slow-session");
        using(var remote=Remote(Config(cert))){var report=await remote.DiagnoseAsync("Prueba-Usuario-2026!");File.WriteAllText(Path.Combine(folder,"diagnostico-api-lenta.txt"),report.Text);Check(!report.ApiAvailable&&report.FailureCode=="request-timeout"&&report.FailedStage.Contains("Autenticación"),"Una API de autenticación que tarda 12 s se identifica después de comprobar TCP y TLS");}
        File.WriteAllText(Path.Combine(root,"fallo.txt"),"slow-snapshot");
        using(var remote=Remote(Config(cert))){var report=await remote.DiagnoseAsync("Prueba-Usuario-2026!");Check(!report.ApiAvailable&&report.FailureCode=="request-timeout"&&report.FailedStage.Contains("datos"),"La espera de los datos iniciales no se confunde con la autenticación");}
        File.WriteAllText(Path.Combine(root,"fallo.txt"),"broken-signalr");
        using(var remote=Remote(Config(cert))){var report=await remote.DiagnoseAsync("Prueba-Usuario-2026!");Check(report.ApiAvailable&&!report.RealtimeAvailable&&report.FailureCode=="signalr","Un fallo SignalR no invalida una API correcta");remote.Start();await Task.Delay(500);Check(remote.CanWrite,"La sincronización periódica sigue disponible sin SignalR");}
        File.WriteAllText(Path.Combine(root,"fallo.txt"),"slow-signalr");
        using(var remote=Remote(Config(cert))){var clock=Stopwatch.StartNew();var report=await remote.DiagnoseAsync("Prueba-Usuario-2026!");Check(report.ApiAvailable&&!report.RealtimeAvailable&&clock.Elapsed<TimeSpan.FromSeconds(30),"SignalR que no responde se cancela a los 15 s y conserva la API");}
        File.WriteAllText(Path.Combine(root,"fallo.txt"),"");
        using(var remote=Remote(Config(cert)))
        {
            await remote.ConnectAsync("Prueba-Usuario-2026!");remote.Start();var until=DateTime.UtcNow.AddSeconds(15);while(!remote.RealtimeConnected&&DateTime.UtcNow<until)await Task.Delay(100);
            Check(remote.RealtimeConnected,"SignalR se establece con el cliente de escritorio");
            StopServer();await Task.Delay(1000);StartServer();until=DateTime.UtcNow.AddSeconds(25);while((!remote.RealtimeConnected||!remote.CanWrite)&&DateTime.UtcNow<until)await Task.Delay(250);
            Check(remote.RealtimeConnected&&remote.CanWrite,"La reconexión automática recupera SignalR y la agenda tras el reinicio");
        }
        StopServer();
        using(var remote=Remote(Config(cert))){var report=await remote.DiagnoseAsync("Prueba-Usuario-2026!");Check(!report.ApiAvailable&&report.FailureCode=="tcp-unavailable","El servidor detenido se identifica en TCP sin intentar autenticar");}
        var logFiles=Directory.GetFiles(folder,"conexion.log",SearchOption.AllDirectories);
        Check(logFiles.Length>0&&logFiles.All(f=>!File.ReadAllText(f).Contains("Prueba-Usuario-2026!")&&!File.ReadAllText(f).Contains("Bearer")&&!File.ReadAllText(f).Contains("access_token")),"Los registros no contienen contraseñas ni cabeceras o parámetros de tokens");
    }
    static IEnumerable<System.Windows.DependencyObject> Tree(System.Windows.DependencyObject root)
    {yield return root;foreach(var child in System.Windows.LogicalTreeHelper.GetChildren(root)){var item=child as System.Windows.DependencyObject;if(item!=null)foreach(var nested in Tree(item))yield return nested;}}
    static void Pump()
    {
        var frame=new System.Windows.Threading.DispatcherFrame();System.Windows.Threading.Dispatcher.CurrentDispatcher.BeginInvoke(System.Windows.Threading.DispatcherPriority.Background,new Action(()=>frame.Continue=false));System.Windows.Threading.Dispatcher.PushFrame(frame);
    }
    static void Ui()
    {
        var app=new System.Windows.Application{ShutdownMode=System.Windows.ShutdownMode.OnExplicitShutdown};Theme.Install(app);
        var configuration=new ConnectionWindow(Path.Combine(folder,"interfaz","config.xml"));configuration.Show();Pump();
        Check(Tree(configuration).OfType<System.Windows.Controls.Button>().Any(b=>(b.Content as string)=="Diagnosticar conexión con Jefatura"),"La configuración ofrece el diagnóstico antes de poder conectar o guardar");configuration.Close();
        using(var remote=Remote(Config(imported[0])))
        {
            var window=new ConnectionDiagnosisWindow(remote,"");window.Show();var until=DateTime.UtcNow.AddSeconds(20);
            while(DateTime.UtcNow<until&&!Tree(window).OfType<System.Windows.Controls.Button>().Any(b=>(b.Content as string)=="Cerrar")){Pump();Thread.Sleep(25);}Pump();
            Check(Tree(window).OfType<System.Windows.Controls.TextBox>().Any(t=>t.Text.Contains("tcp-unavailable")&&t.Text.Contains("Fin del diagnóstico")),"La ventana WPF muestra el resultado por etapas sin bloquear su Dispatcher");
            var bitmap=new System.Windows.Media.Imaging.RenderTargetBitmap((int)window.ActualWidth,(int)window.ActualHeight,96,96,System.Windows.Media.PixelFormats.Pbgra32);bitmap.Render(window);var encoder=new System.Windows.Media.Imaging.PngBitmapEncoder();encoder.Frames.Add(System.Windows.Media.Imaging.BitmapFrame.Create(bitmap));using(var file=File.Create(Path.Combine(folder,"diagnostico-interfaz.png")))encoder.Save(file);
            window.Close();
        }
        app.Shutdown();
    }
    [STAThread]static int Main(string[] args)
    {
        folder=Path.GetFullPath(args[0]);dotnet=args[1];host=args[2];root=Path.Combine(folder,"servidor");Directory.CreateDirectory(folder);
        var roots=StoreIds(StoreName.Root);var personal=StoreIds(StoreName.My);int code=0;
        try{Run().GetAwaiter().GetResult();Ui();}
        catch(Exception ex){Console.WriteLine("FALLO: "+ex);code=1;}
        finally
        {
            StopServer();foreach(var cert in imported){using(var store=new X509Store(StoreName.My,StoreLocation.CurrentUser)){store.Open(OpenFlags.ReadWrite);store.Remove(cert);}using(var key=cert.GetRSAPrivateKey()){var cng=key as RSACng;if(cng!=null)cng.Key.Delete();}cert.Dispose();}
            try{Check(roots.SequenceEqual(StoreIds(StoreName.Root))&&personal.SequenceEqual(StoreIds(StoreName.My)),"Los almacenes personal y de raíces quedan idénticos al estado inicial");}catch{code=1;}
        }
        Console.WriteLine("RESUMEN: "+passed+" comprobaciones; resultado "+code+".");return code;
    }
}
