using System.Runtime.InteropServices;
using AgendaClara;
using AgendaClara.Pruebas;
if(!OperatingSystem.IsWindows())NativeLibrary.SetDllImportResolver(typeof(Store).Assembly,(name,assembly,path)=>name=="winsqlite3.dll"?NativeLibrary.Load("libsqlite3.so.0"):IntPtr.Zero);
Format.ApplyCulture();
string root=Path.Combine(Path.GetTempPath(),"NexoCentroExperimentalGoogleOAuth", "regresion-"+Guid.NewGuid().ToString("N"));
try {DataTests.Run(root,null);foreach(var line in T.Log)Console.WriteLine(line);Console.WriteLine($"RESUMEN: {T.Passed} correctas; {T.Failed} fallos. Sin interfaz WPF; permisos Windows e informe WPF omitidos.");return T.Failed==0?0:1;}
finally {if(Directory.Exists(root))Directory.Delete(root,true);}
