﻿param([string]$Salida=(Join-Path $PSScriptRoot 'compilado'),[switch]$Pruebas)
& (Join-Path (Split-Path $PSScriptRoot -Parent) 'Compilar.ps1') -Salida $Salida -Pruebas:$Pruebas
