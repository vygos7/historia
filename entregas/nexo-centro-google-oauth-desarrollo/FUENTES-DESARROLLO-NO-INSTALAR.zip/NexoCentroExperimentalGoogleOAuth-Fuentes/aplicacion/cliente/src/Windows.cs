using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace AgendaClara
{
    public static class Dialogs
    {
        // Replaced by the interface tests so that confirmations can be answered automatically.
        internal static Func<Window, string, string, string, bool> ConfirmImpl = ShowConfirm;
        internal static Action<Window, string, string> InfoImpl = ShowInfo;

        public static bool Confirm(Window owner, string title, string message, string confirmLabel) { return ConfirmImpl(owner, title, message, confirmLabel); }
        public static void Info(Window owner, string title, string message) { InfoImpl(owner, title, message); }

        static Window Make(Window owner, string title)
        {
            var w = new Window { Title = title, SizeToContent = SizeToContent.Height, Width = 520, MinWidth = 380, MaxHeight = 700, ShowInTaskbar = false, ResizeMode = ResizeMode.CanResizeWithGrip };
            Theme.ApplyWindow(w);
            if (owner != null && owner.IsVisible) { w.Owner = owner; w.WindowStartupLocation = WindowStartupLocation.CenterOwner; }
            else w.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            w.PreviewKeyDown += (s, e) => { if (e.Key == Key.Escape) { e.Handled = true; w.Close(); } };
            return w;
        }

        static bool ShowConfirm(Window owner, string title, string message, string confirmLabel)
        {
            var w = Make(owner, title);
            bool result = false;
            var p = new StackPanel { Margin = new Thickness(24, 20, 24, 18) };
            p.Children.Add(Theme.Text(title, 19, Theme.Ink, true));
            var body = Theme.Text(message, 14, Theme.Ink); body.Margin = new Thickness(0, 10, 0, 18);
            p.Children.Add(new ScrollViewer { Content = body, VerticalScrollBarVisibility = ScrollBarVisibility.Auto, MaxHeight = 460 });
            var buttons = new WrapPanel { HorizontalAlignment = HorizontalAlignment.Right };
            var cancel = Theme.Button("Cancelar", w.Close); cancel.Margin = new Thickness(0, 0, 8, 4);
            var ok = Theme.Button(confirmLabel, () => { result = true; w.Close(); }, "DangerSolid"); ok.Margin = new Thickness(0, 0, 0, 4);
            buttons.Children.Add(cancel); buttons.Children.Add(ok);
            p.Children.Add(buttons);
            w.Content = p;
            w.Loaded += (s, e) => cancel.Focus();
            w.ShowDialog();
            return result;
        }

        static void ShowInfo(Window owner, string title, string message)
        {
            var w = Make(owner, title);
            var p = new StackPanel { Margin = new Thickness(24, 20, 24, 18) };
            p.Children.Add(Theme.Text(title, 19, Theme.Ink, true));
            var body = Theme.Text(message, 14, Theme.Ink); body.Margin = new Thickness(0, 10, 0, 18);
            p.Children.Add(new ScrollViewer { Content = body, VerticalScrollBarVisibility = ScrollBarVisibility.Auto, MaxHeight = 460 });
            var ok = Theme.Button("Aceptar", w.Close, "Primary"); ok.HorizontalAlignment = HorizontalAlignment.Right; ok.MinWidth = 100;
            p.Children.Add(ok);
            w.Content = p;
            w.Loaded += (s, e) => ok.Focus();
            w.ShowDialog();
        }

        public static Window Plain(string title, double width, double height)
        {
            var w = new Window();
            Setup(w, title, width, height, 400, 300);
            return w;
        }

        public static void Setup(Window w, string title, double width, double height, double minWidth, double minHeight)
        {
            var area = SystemParameters.WorkArea;
            w.Title = title; w.MinWidth = minWidth; w.MinHeight = minHeight;
            w.Width = Math.Max(minWidth, Math.Min(width, area.Width - 40)); w.Height = Math.Max(minHeight, Math.Min(height, area.Height - 40));
            w.ShowInTaskbar = false; w.WindowStartupLocation = WindowStartupLocation.CenterOwner;
            Theme.ApplyWindow(w);
            w.PreviewKeyDown += (s, e) => { if (e.Key == Key.Escape) { e.Handled = true; w.Close(); } };
        }

        // Window layout with a scrolling body and a fixed bottom bar.
        public static void Layout(Window w, UIElement body, UIElement bottom)
        {
            var root = new Grid();
            root.RowDefinitions.Add(new RowDefinition());
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            root.Children.Add(new ScrollViewer { Content = body, VerticalScrollBarVisibility = ScrollBarVisibility.Auto, HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled });
            var bar = new Border { BorderBrush = Theme.Line, BorderThickness = new Thickness(0, 1, 0, 0), Background = Theme.Surface, Padding = new Thickness(24, 10, 24, 14), Child = bottom };
            Grid.SetRow(bar, 1); root.Children.Add(bar);
            w.Content = root;
        }
    }

    public sealed class RemindersWindow : Window
    {
        public Occurrence Selected { get; private set; }
        public RemindersWindow(List<Reminder> reminders)
        {
            Dialogs.Setup(this, "Avisos de próximas actividades", 640, 700, 480, 360);
            var p = new StackPanel { Margin = new Thickness(24, 20, 24, 12) };
            p.Children.Add(Theme.Text("Avisos de próximas actividades", 22, Theme.Ink, true));
            p.Children.Add(Theme.Notice("La antelación de cada aviso se cuenta en días naturales y se aplica a la próxima fecha real de la actividad (respetando fines de semana, festivos, repeticiones y exclusiones). Los avisos se muestran mientras Nexo Centro está abierta; no hay notificaciones con el programa cerrado.", Theme.Pale, Theme.Ink));
            foreach (var r in reminders)
            {
                var captured = r;
                var head = Theme.Text(r.Message, 14, r.DaysLeft == 0 ? Theme.AccentDark : Theme.Ink, true); head.Margin = new Thickness(0, 8, 0, 4);
                p.Children.Add(head);
                p.Children.Add(Cards.Full(r.Occurrence, () => { Selected = captured.Occurrence; Close(); }, true));
            }
            if (reminders.Count == 0) p.Children.Add(Theme.Text("No hay avisos pendientes dentro de los plazos configurados.", 14, Theme.Muted));
            var close = Theme.Button("Cerrar", Close, "Primary"); close.HorizontalAlignment = HorizontalAlignment.Right; close.MinWidth = 100;
            Dialogs.Layout(this, p, close);
        }
    }

    public sealed class CategoryManager : Window
    {
        internal static Func<Window, string, string> ChooseColor = PickColor;
        internal static Func<Window, Category, List<string>, string> ChooseTarget = PickTarget;

        readonly Store store;
        readonly StackPanel list = new StackPanel();
        readonly TextBox newName = new TextBox { MinWidth = 220 };
        readonly TextBlock message = Theme.Text("", 13, Theme.AccentDark, true);
        public bool Changed { get; private set; }

        public CategoryManager(Store store)
        {
            this.store = store;
            Dialogs.Setup(this, "Categorías", 760, 720, 560, 400);
            var p = new StackPanel { Margin = new Thickness(24, 20, 24, 12) };
            p.Children.Add(Theme.Text("Categorías", 22, Theme.Ink, true));
            p.Children.Add(Theme.Text("El color identifica cada categoría en todas las vistas y siempre va acompañado de su nombre. Al cambiar el nombre, sus actividades pasan a tener el nombre nuevo. Al eliminar una categoría, sus actividades se mueven a otra que elijas: no se borra ninguna actividad.", 12.5, Theme.Muted));
            var add = new WrapPanel { Margin = new Thickness(0, 14, 0, 10) };
            AutomationProperties.SetName(newName, "Nombre de la nueva categoría");
            add.Children.Add(newName);
            var addButton = Theme.Button("Añadir categoría", Add, "Primary"); addButton.Margin = new Thickness(8, 0, 0, 0);
            add.Children.Add(addButton);
            p.Children.Add(add);
            newName.KeyDown += (s, e) => { if (e.Key == Key.Enter) Add(); };
            p.Children.Add(message);
            p.Children.Add(list);
            var close = Theme.Button("Cerrar", Close, "Primary"); close.HorizontalAlignment = HorizontalAlignment.Right; close.MinWidth = 100;
            Dialogs.Layout(this, p, close);
            Reload();
        }

        void Say(string text, bool problem) { message.Text = text; message.Foreground = problem ? Theme.Danger : Theme.AccentDark; }

        async void Run(Action action, string success)
        {
            if (!store.CanWrite) { Say("No se pueden cambiar datos sin conexión.", true); return; }
            try { if (store.IsShared) await System.Threading.Tasks.Task.Run(action); else action(); Changed = true; Say(success, false); Reload(); }
            catch (ArgumentException ex) { Say(Branding.Error(ex.Message), true); }
            catch (IOException ex) { Say("No se pudo guardar el cambio. " + Branding.Error(ex.Message), true); }
        }

        void Add()
        {
            string name = newName.Text.Trim();
            Run(() => { store.AddCategory(name, null); }, "Categoría «" + name + "» añadida.");
        }

        void Reload()
        {
            list.Children.Clear();
            var all = store.Categories();
            Cards.SetCategories(all);
            for (int i = 0; i < all.Count; i++)
            {
                var c = all[i];
                var row = new Grid();
                row.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
                row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
                row.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
                row.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
                var sw = Theme.Swatch(c.Color, 20); sw.Margin = new Thickness(0, 0, 10, 0); sw.ToolTip = CategoryPalette.ColorName(c.Color);
                row.Children.Add(sw);
                var nameArea = new ContentControl { VerticalAlignment = VerticalAlignment.Center, IsTabStop = false };
                var label = new StackPanel();
                label.Children.Add(Theme.Text(c.Name, 14, Theme.Ink, true));
                label.Children.Add(Theme.Text(Format.Count(c.Count, "actividad", "actividades") + " · color " + CategoryPalette.ColorName(c.Color).ToLower(Format.Spanish), 12, Theme.Muted));
                nameArea.Content = label;
                Grid.SetColumn(nameArea, 1); row.Children.Add(nameArea);
                var buttons = new WrapPanel { Margin = new Thickness(26, 4, 0, 0) };
                var captured = c;
                var up = Small("↑", () => Run(() => store.MoveCategory(captured.Name, -1), "Orden actualizado.")); up.IsEnabled = i > 0; AutomationProperties.SetName(up, "Subir " + c.Name); up.ToolTip = "Subir en la lista";
                var down = Small("↓", () => Run(() => store.MoveCategory(captured.Name, 1), "Orden actualizado.")); down.IsEnabled = i < all.Count - 1; AutomationProperties.SetName(down, "Bajar " + c.Name); down.ToolTip = "Bajar en la lista";
                var rename = Small("Cambiar nombre", () => StartRename(captured, nameArea)); AutomationProperties.SetName(rename, "Cambiar nombre de " + c.Name);
                var color = Small("Color", () => { string chosen = ChooseColor(this, captured.Color); if (chosen != null) Run(() => store.SetCategoryColor(captured.Name, chosen), "Color de «" + captured.Name + "» actualizado."); });
                AutomationProperties.SetName(color, "Cambiar color de " + c.Name);
                var delete = Small("Eliminar", () => Delete(captured)); delete.Style = Theme.Style("DangerButton"); delete.Margin = new Thickness(4, 2, 0, 2); delete.Padding = new Thickness(10, 3, 10, 3); delete.MinHeight = 30;
                AutomationProperties.SetName(delete, "Eliminar " + c.Name);
                delete.IsEnabled = all.Count > 1;
                foreach (var b in new[] { up, down, rename, color, delete }) buttons.Children.Add(b);
                Grid.SetRow(buttons, 1); Grid.SetColumnSpan(buttons, 2); row.Children.Add(buttons);
                list.Children.Add(new Border { Background = Theme.Surface, BorderBrush = Theme.Line, BorderThickness = new Thickness(1), CornerRadius = new CornerRadius(8), Padding = new Thickness(10, 6, 8, 6), Child = row, Margin = new Thickness(0, 0, 0, 6) });
            }
        }

        static Button Small(string label, Action action)
        {
            var b = Theme.Button(label, action);
            b.Margin = new Thickness(4, 2, 0, 2); b.Padding = new Thickness(10, 3, 10, 3); b.MinHeight = 30;
            return b;
        }

        void StartRename(Category c, ContentControl area)
        {
            var box = new TextBox { Text = c.Name, MinWidth = 160 };
            AutomationProperties.SetName(box, "Nuevo nombre para " + c.Name);
            var ok = Small("Guardar nombre", () => { string value = box.Text.Trim(); Run(() => store.RenameCategory(c.Name, value), "Categoría «" + c.Name + "» renombrada como «" + value + "»."); });
            var cancel = Small("Cancelar", Reload);
            var p = new WrapPanel(); p.Children.Add(box); p.Children.Add(ok); p.Children.Add(cancel);
            box.KeyDown += (s, e) => { if (e.Key == Key.Enter) ok.RaiseEvent(new RoutedEventArgs(Button.ClickEvent)); };
            area.Content = p;
            box.Focus(); box.SelectAll();
        }

        void Delete(Category c)
        {
            var others = store.Categories().Where(x => x.Name != c.Name).Select(x => x.Name).ToList();
            if (others.Count == 0) { Say("Debe quedar al menos una categoría.", true); return; }
            string target = ChooseTarget(this, c, others);
            if (target == null) return;
            Run(() => store.DeleteCategory(c.Name, target), "Categoría «" + c.Name + "» eliminada." + (c.Count > 0 ? " Sus " + Format.Count(c.Count, "actividad ha", "actividades han") + " pasado a «" + target + "»." : ""));
        }

        static string PickColor(Window owner, string current)
        {
            string result = null;
            var w = Dialogs.Plain("Elegir color", 560, 420);
            w.Owner = owner; w.MinWidth = 400; w.MinHeight = 300;
            var p = new StackPanel { Margin = new Thickness(24, 20, 24, 12) };
            p.Children.Add(Theme.Text("Elige un color", 19, Theme.Ink, true));
            var grid = new WrapPanel { Margin = new Thickness(0, 12, 0, 0) };
            for (int i = 0; i < CategoryPalette.Colors.Length; i++)
            {
                string hex = CategoryPalette.Colors[i];
                var content = new StackPanel { Orientation = Orientation.Horizontal };
                content.Children.Add(Theme.Swatch(hex, 18));
                content.Children.Add(new TextBlock { Text = CategoryPalette.ColorNames[i], Margin = new Thickness(8, 0, 0, 0), VerticalAlignment = VerticalAlignment.Center });
                var b = new Button { Content = content, Width = 150, Margin = new Thickness(0, 0, 8, 8), HorizontalContentAlignment = HorizontalAlignment.Left };
                if (String.Equals(hex, current, StringComparison.OrdinalIgnoreCase)) { b.BorderBrush = Theme.AccentDark; b.BorderThickness = new Thickness(2); }
                AutomationProperties.SetName(b, CategoryPalette.ColorNames[i]);
                b.Click += (s, e) => { result = hex; w.Close(); };
                grid.Children.Add(b);
            }
            p.Children.Add(grid);
            var cancel = Theme.Button("Cancelar", w.Close); cancel.HorizontalAlignment = HorizontalAlignment.Right;
            Dialogs.Layout(w, p, cancel);
            w.ShowDialog();
            return result;
        }

        static string PickTarget(Window owner, Category c, List<string> others)
        {
            string result = null;
            var w = Dialogs.Plain("Eliminar categoría", 560, 360);
            w.Owner = owner; w.MinWidth = 420; w.MinHeight = 300; w.SizeToContent = SizeToContent.Height;
            var p = new StackPanel { Margin = new Thickness(24, 20, 24, 12) };
            p.Children.Add(Theme.Text("Eliminar la categoría «" + c.Name + "»", 19, Theme.Ink, true));
            var combo = new ComboBox { ItemsSource = others, SelectedItem = others.Contains("Otros") ? "Otros" : others[0], Margin = new Thickness(0, 6, 0, 0) };
            AutomationProperties.SetName(combo, "Categoría de destino");
            var text = Theme.Text(c.Count > 0
                ? "Tiene " + Format.Count(c.Count, "actividad", "actividades") + ". No se borrará ninguna: elige a qué categoría pasan."
                : "No tiene actividades. Si en el futuro aparece alguna con este nombre, pasará a la categoría elegida.", 14, Theme.Ink);
            text.Margin = new Thickness(0, 10, 0, 8);
            p.Children.Add(text);
            p.Children.Add(Theme.Label("Mover sus actividades a"));
            p.Children.Add(combo);
            var buttons = new WrapPanel { HorizontalAlignment = HorizontalAlignment.Right };
            var cancel = Theme.Button("Cancelar", w.Close); cancel.Margin = new Thickness(0, 0, 8, 0);
            var ok = Theme.Button(c.Count > 0 ? "Eliminar y mover actividades" : "Eliminar categoría", () => { result = combo.SelectedItem as string; w.Close(); }, "DangerSolid");
            buttons.Children.Add(cancel); buttons.Children.Add(ok);
            Dialogs.Layout(w, p, buttons);
            w.ShowDialog();
            return result;
        }
    }

    public sealed class CalendarEditor : Window
    {
        sealed class Row { public TextBox Name; public DatePicker Start, End; public ComboBox Kind; public FrameworkElement Panel; }

        readonly Store store;
        readonly SchoolCalendar original;
        readonly List<Row> years = new List<Row>(), terms = new List<Row>(), breaks = new List<Row>();
        readonly StackPanel yearsPanel = new StackPanel(), termsPanel = new StackPanel(), breaksPanel = new StackPanel();
        readonly TextBlock error = Theme.Text("", 13, Theme.Danger, true);
        public bool Saved { get; private set; }

        public CalendarEditor(Store store)
        {
            this.store = store; original = store.Calendar.Copy();
            Dialogs.Setup(this, "Calendario escolar", 960, 860, 700, 420);
            var p = new StackPanel { Margin = new Thickness(24, 20, 24, 12) };
            p.Children.Add(Theme.Text("Calendario escolar", 22, Theme.Ink, true));
            p.Children.Add(Theme.Notice((original.Source.Length > 0 ? original.Source : "Calendario configurado en la aplicación.") +
                "\n\nEsta versión no importa archivos PDF automáticamente. Para otro curso, añade aquí su periodo de clases, sus trimestres y sus días no lectivos. Cambiar el calendario no borra actividades: las que queden en días no lectivos se ocultan del calendario y siguen apareciendo en el buscador.", Theme.Pale, Theme.Ink));

            Section(p, "Periodo de clases", "Fuera de estos periodos los días se consideran no lectivos.", yearsPanel, "＋ Añadir periodo de clases", () => AddRow(years, yearsPanel, "Curso", DateTime.Today, DateTime.Today, null));
            Section(p, "Trimestres", "Solo informativos: se muestran junto a la fecha. No figuran en el PDF de Huelva; los precargados son una propuesta.", termsPanel, "＋ Añadir trimestre", () => AddRow(terms, termsPanel, "Trimestre", DateTime.Today, DateTime.Today, null));
            Section(p, "Días y periodos no lectivos", "Vacaciones, festivos nacionales, autonómicos y locales, otros días no lectivos y cambios del centro.", breaksPanel, "＋ Añadir día o periodo no lectivo", () => AddRow(breaks, breaksPanel, "No lectivo", DateTime.Today, DateTime.Today, "No lectivo"));

            foreach (var y in original.Years) AddRow(years, yearsPanel, y.Name, y.Start, y.End, null);
            foreach (var t in original.Terms) AddRow(terms, termsPanel, t.Name, t.Start, t.End, null);
            foreach (var b in original.Breaks.OrderBy(x => x.Start).ThenByDescending(x => x.End)) AddRow(breaks, breaksPanel, b.Name, b.Start, b.End, b.Kind);

            var bottom = new Grid();
            bottom.ColumnDefinitions.Add(new ColumnDefinition());
            bottom.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            error.Margin = new Thickness(0, 0, 12, 0); error.VerticalAlignment = VerticalAlignment.Center;
            bottom.Children.Add(error);
            var buttons = new StackPanel { Orientation = Orientation.Horizontal };
            var cancel = Theme.Button("Cancelar", Close); cancel.Margin = new Thickness(0, 0, 8, 0);
            buttons.Children.Add(cancel); buttons.Children.Add(Theme.Button("Guardar calendario", Save, "Primary"));
            Grid.SetColumn(buttons, 1); bottom.Children.Add(buttons);
            Dialogs.Layout(this, p, bottom);
        }

        static void Section(StackPanel p, string title, string hint, StackPanel rows, string addLabel, Action add)
        {
            var head = Theme.Text(title, 16, Theme.Ink, true); head.Margin = new Thickness(0, 16, 0, 2);
            p.Children.Add(head);
            var h = Theme.Text(hint, 12, Theme.Muted); h.Margin = new Thickness(0, 0, 0, 8);
            p.Children.Add(h);
            p.Children.Add(rows);
            var b = Theme.Button(addLabel, add); b.HorizontalAlignment = HorizontalAlignment.Left; b.Margin = new Thickness(0, 4, 0, 0);
            p.Children.Add(b);
        }

        void AddRow(List<Row> rows, StackPanel panel, string name, DateTime start, DateTime end, string kind)
        {
            var r = new Row { Name = new TextBox { Text = name }, Start = new DatePicker { SelectedDate = start }, End = new DatePicker { SelectedDate = end } };
            AutomationProperties.SetName(r.Name, "Nombre del periodo"); AutomationProperties.SetName(r.Start, "Desde"); AutomationProperties.SetName(r.End, "Hasta");
            foreach (var picker in new[] { r.Start, r.End }) picker.DateValidationError += (s, e) => { error.Text = "«" + e.Text + "» no es una fecha válida (DD/MM/AAAA)."; e.ThrowException = false; };
            r.Start.SelectedDateChanged += (s, e) => { if (r.Start.SelectedDate.HasValue && (!r.End.SelectedDate.HasValue || r.End.SelectedDate < r.Start.SelectedDate)) r.End.SelectedDate = r.Start.SelectedDate; };
            var g = new Grid { Margin = new Thickness(0, 0, 0, 6) };
            if (kind != null)
            {
                var kinds = SchoolCalendar.Kinds.ToList();
                if (!kinds.Contains(kind)) kinds.Add(kind);
                r.Kind = new ComboBox { ItemsSource = kinds, SelectedItem = kind, Margin = new Thickness(0, 0, 6, 0) };
                AutomationProperties.SetName(r.Kind, "Tipo");
                g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(150) });
            }
            else g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(0) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star), MinWidth = 120 });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(128) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(128) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            if (r.Kind != null) g.Children.Add(r.Kind);
            r.Name.Margin = new Thickness(0, 0, 6, 0); Grid.SetColumn(r.Name, 1); g.Children.Add(r.Name);
            r.Start.Margin = new Thickness(0, 0, 6, 0); r.Start.ToolTip = "Desde"; Grid.SetColumn(r.Start, 2); g.Children.Add(r.Start);
            r.End.Margin = new Thickness(0, 0, 6, 0); r.End.ToolTip = "Hasta (incluido)"; Grid.SetColumn(r.End, 3); g.Children.Add(r.End);
            var remove = Theme.Button("Quitar", () => { rows.Remove(r); panel.Children.Remove(r.Panel); });
            AutomationProperties.SetName(remove, "Quitar " + name);
            Grid.SetColumn(remove, 4); g.Children.Add(remove);
            r.Panel = g;
            rows.Add(r); panel.Children.Add(g);
        }

        static void Read(List<Row> rows, Action<string, DateTime, DateTime, string> add)
        {
            foreach (var r in rows)
            {
                string name = r.Name.Text.Trim();
                if (!r.Start.SelectedDate.HasValue || !r.End.SelectedDate.HasValue) throw new ArgumentException("Completa las fechas de «" + (name.Length > 0 ? name : "periodo sin nombre") + "».");
                add(name, r.Start.SelectedDate.Value.Date, r.End.SelectedDate.Value.Date, r.Kind == null ? "" : (r.Kind.SelectedItem as string ?? "No lectivo"));
            }
        }

        async void Save()
        {
            if (!store.CanWrite) { error.Text = "No se pueden cambiar datos sin conexión."; return; }
            try
            {
                var c = new SchoolCalendar { Source = original.Source, ConfigVersion = original.ConfigVersion };
                Read(years, (n, s, e, k) => c.Years.Add(new SchoolYear { Name = n, Start = s, End = e }));
                Read(terms, (n, s, e, k) => c.Terms.Add(new DatePeriod { Name = n, Start = s, End = e }));
                Read(breaks, (n, s, e, k) => c.Breaks.Add(new DatePeriod { Name = n, Start = s, End = e, Kind = k }));
                if (XmlData.Write(c) != XmlData.Write(original) && !c.Source.Contains("Modificado en la aplicación"))
                    c.Source = (c.Source + " Modificado en la aplicación el " + Format.Date(DateTime.Today) + ".").Trim();
                if (store.IsShared) await System.Threading.Tasks.Task.Run(() => store.SaveCalendar(c)); else store.SaveCalendar(c);
                Saved = true;
                Close();
            }
            catch (ArgumentException ex) { error.Text = Branding.Error(ex.Message); }
            catch (IOException ex) { error.Text = "No se pudo guardar el calendario. " + Branding.Error(ex.Message); }
        }
    }

    public sealed class BackupWindow : Window
    {
        internal static Func<Window, string> ChooseSavePath = owner =>
        {
            var d = new Microsoft.Win32.SaveFileDialog { Title = "Guardar una copia de la agenda", Filter = "Copia de Nexo Centro (*.sqlite3)|*.sqlite3", DefaultExt = ".sqlite3", AddExtension = true, OverwritePrompt = true, FileName = "NexoCentro-copia-" + DateTime.Now.ToString("yyyy-MM-dd-HHmm") + ".sqlite3" };
            return d.ShowDialog(owner) == true ? d.FileName : null;
        };
        internal static Func<Window, string, string> ChooseOpenPath = (owner, folder) =>
        {
            var d = new Microsoft.Win32.OpenFileDialog { Title = "Elegir una copia para restaurar", Filter = "Copia de Nexo Centro (*.sqlite3)|*.sqlite3|Todos los archivos (*.*)|*.*", CheckFileExists = true };
            if (Directory.Exists(folder)) d.InitialDirectory = folder;
            return d.ShowDialog(owner) == true ? d.FileName : null;
        };

        readonly Store store;
        readonly ListBox copies = new ListBox { Height = 170, Margin = new Thickness(0, 6, 0, 6) };
        readonly TextBlock details = Theme.Text("", 12.5, Theme.Muted), message = Theme.Text("", 13, Theme.AccentDark, true);
        readonly StackPanel statusBox = new StackPanel();
        public bool Restored { get; private set; }

        public BackupWindow(Store store)
        {
            this.store = store;
            Dialogs.Setup(this, "Copias de seguridad", 820, 860, 600, 420);
            var p = new StackPanel { Margin = new Thickness(24, 20, 24, 12) };
            p.Children.Add(Theme.Text("Copias de seguridad", 22, Theme.Ink, true));
            p.Children.Add(statusBox);
            p.Children.Add(Theme.Text("Mientras Nexo Centro está abierta, cada cambio guardado actualiza la copia automática del día y, si el programa sigue abierto al cambiar de día, se crea la copia del día nuevo. Las copias de días anteriores se conservan. Con el programa cerrado no se hacen copias: la última queda guardada en la carpeta. Cada copia incluye actividades, categorías, calendario escolar, repeticiones y excepciones.", 12.5, Theme.Muted));
            p.Children.Add(PathRow("Agenda en uso", store.DatabasePath));
            p.Children.Add(PathRow("Carpeta de copias automáticas", store.BackupDirectory));
            var actions = new WrapPanel { Margin = new Thickness(0, 12, 0, 4) };
            var manual = Theme.Button("Guardar una copia en otra carpeta o USB…", Manual, "Primary"); manual.Margin = new Thickness(0, 0, 8, 6);
            var fromFile = Theme.Button("Restaurar desde un archivo…", () => { string f = ChooseOpenPath(this, store.BackupDirectory); if (f != null) Restore(f); }); fromFile.Margin = new Thickness(0, 0, 8, 6);
            actions.Children.Add(manual); actions.Children.Add(fromFile);
            p.Children.Add(actions);
            p.Children.Add(message);
            var head = Theme.Text("Copias guardadas en la carpeta automática", 15, Theme.Ink, true); head.Margin = new Thickness(0, 14, 0, 0);
            p.Children.Add(head);
            AutomationProperties.SetName(copies, "Copias guardadas");
            p.Children.Add(copies);
            p.Children.Add(details);
            var restoreSelected = Theme.Button("Restaurar la copia seleccionada…", () => { var b = copies.SelectedItem as ListBoxItem; if (b != null) Restore((string)b.Tag); });
            restoreSelected.HorizontalAlignment = HorizontalAlignment.Left; restoreSelected.Margin = new Thickness(0, 8, 0, 0);
            p.Children.Add(restoreSelected);
            p.Children.Add(Theme.Text("Antes de restaurar, Nexo Centro guarda la agenda actual en la carpeta de copias («Antes-de-restaurar-…»), de modo que siempre se puede volver atrás.", 12, Theme.Muted));
            copies.SelectionChanged += (s, e) =>
            {
                var item = copies.SelectedItem as ListBoxItem;
                if (item == null) { details.Text = ""; return; }
                var info = Store.Inspect((string)item.Tag);
                details.Text = info.Error.Length > 0 ? "⚠ " + info.Error : "Contiene " + Format.Count(info.Events, "actividad", "actividades") + (info.Categories >= 0 ? ", " + Format.Count(info.Categories, "categoría", "categorías") : "") + (info.HasCalendar ? " y el calendario escolar" : " (sin calendario: es de una versión anterior; se aplicará el calendario precargado)") + ".";
            };
            var close = Theme.Button("Cerrar", Close, "Primary"); close.HorizontalAlignment = HorizontalAlignment.Right; close.MinWidth = 100;
            Dialogs.Layout(this, p, close);
            Reload();
        }

        static FrameworkElement PathRow(string label, string path)
        {
            var p = new StackPanel { Margin = new Thickness(0, 10, 0, 0) };
            p.Children.Add(Theme.Label(label));
            var row = new DockPanel();
            var copy = Theme.Button("Copiar ruta", () => { try { Clipboard.SetText(path); } catch (System.Runtime.InteropServices.ExternalException) { } });
            copy.Margin = new Thickness(6, 0, 0, 0);
            DockPanel.SetDock(copy, Dock.Right); row.Children.Add(copy);
            var box = new TextBox { Text = path, IsReadOnly = true, Background = Theme.Background };
            AutomationProperties.SetName(box, label);
            row.Children.Add(box);
            p.Children.Add(row);
            return p;
        }

        void Reload()
        {
            statusBox.Children.Clear();
            if (String.IsNullOrEmpty(store.BackupError))
                statusBox.Children.Add(Theme.Notice("✓ Última copia de seguridad: " + (store.LastBackup.HasValue ? Format.LongDate(store.LastBackup.Value) + " a las " + store.LastBackup.Value.ToString("HH:mm") : "todavía no hay ninguna") + (store.LastBackupFile != null ? "\n" + store.LastBackupFile : ""), Theme.Pale, Theme.AccentDark));
            else
                statusBox.Children.Add(Theme.Notice("⚠ Los cambios de la agenda están guardados, pero la última copia automática ha fallado:\n" + store.BackupError + "\n\nSe volverá a intentar con el próximo cambio o dentro de un minuto. Puedes guardar también una copia manual en otra carpeta.", Theme.DangerSoft, Theme.Danger));
            copies.Items.Clear();
            try
            {
                foreach (var b in store.ListBackups())
                {
                    var item = new ListBoxItem { Tag = b.Path, Content = b.Modified.ToString("dd/MM/yyyy HH:mm") + " · " + b.Kind + " · " + Math.Max(1, b.Size / 1024) + " KB · " + Path.GetFileName(b.Path), Padding = new Thickness(6, 4, 6, 4) };
                    copies.Items.Add(item);
                }
            }
            catch (IOException ex) { details.Text = "No se puede leer la carpeta de copias: " + Branding.Error(ex.Message); }
            catch (UnauthorizedAccessException ex) { details.Text = "No se puede leer la carpeta de copias: " + Branding.Error(ex.Message); }
            if (copies.Items.Count == 0) copies.Items.Add(new ListBoxItem { Content = "No hay copias en la carpeta automática.", IsEnabled = false });
        }

        void Say(string text, bool problem) { message.Text = text; message.Foreground = problem ? Theme.Danger : Theme.AccentDark; }

        void Manual()
        {
            string path = ChooseSavePath(this);
            if (String.IsNullOrEmpty(path)) return;
            try { store.BackupTo(path); Say("✓ Copia guardada en " + path, false); }
            catch (Exception ex) { Say("No se pudo guardar la copia manual: " + Branding.Error(ex.Message) + " La agenda no se ha modificado.", true); }
        }

        void Restore(string path)
        {
            var info = Store.Inspect(path);
            if (info.Error.Length > 0) { Say("No se puede restaurar «" + Path.GetFileName(path) + "»: " + info.Error, true); return; }
            int current = store.EventCount();
            string text = "Se sustituirá el contenido actual de la agenda (" + Format.Count(current, "actividad", "actividades") + ") por el de la copia «" + Path.GetFileName(path) + "», del " + Format.Date(info.Modified) + " a las " + info.Modified.ToString("HH:mm") + " (" + Format.Count(info.Events, "actividad", "actividades") + ").\n\n" +
                "Antes de hacerlo, la agenda actual se guardará en la carpeta de copias con el nombre «Antes-de-restaurar-…». Si te equivocas, puedes restaurar esa copia.";
            if (!Dialogs.Confirm(this, "Restaurar una copia", text, "Restaurar esta copia")) return;
            try
            {
                string safety = store.RestoreFrom(path);
                Restored = true;
                Say("✓ Copia restaurada. La agenda anterior está guardada en " + safety, false);
                Reload();
                Dialogs.Info(this, "Copia restaurada", "La agenda contiene ahora " + Format.Count(store.EventCount(), "actividad", "actividades") + ".\n\nLa agenda anterior se ha guardado en:\n" + safety);
            }
            catch (Exception ex) { Say("No se pudo restaurar la copia: " + Branding.Error(ex.Message), true); Reload(); }
        }
    }
}
