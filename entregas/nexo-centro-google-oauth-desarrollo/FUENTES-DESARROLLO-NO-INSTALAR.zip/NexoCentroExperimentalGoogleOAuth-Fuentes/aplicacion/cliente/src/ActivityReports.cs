using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Microsoft.Win32;

namespace AgendaClara
{
    public sealed class ReportsWindow : Window
    {
        readonly Store store;
        readonly ComboBox period = new ComboBox { MinWidth = 250 };
        readonly TextBox search = new TextBox { MinWidth = 180 };
        readonly DatePicker from = new DatePicker(), to = new DatePicker();
        readonly StackPanel list = new StackPanel();
        readonly TextBlock count = Theme.Text("", 13, Theme.Muted);
        readonly Dictionary<long, CheckBox> checks = new Dictionary<long, CheckBox>();
        List<AgendaEvent> visible = new List<AgendaEvent>();
        AgendaSnapshot viewSnapshot; bool updatingPeriods;
        public ReportsWindow(Store store)
        {
            this.store = store; Theme.ApplyWindow(this); Title = "Seguimiento, memorias e informes"; Width = 950; Height = 720; MinWidth = 680; MinHeight = 480; WindowStartupLocation = WindowStartupLocation.CenterOwner;
            var root = new DockPanel { Margin = new Thickness(22) };
            var top = new StackPanel(); DockPanel.SetDock(top, Dock.Top); root.Children.Add(top);
            top.Children.Add(Theme.Text("Seguimiento, memorias e informes", 24, Theme.Ink, true));
            top.Children.Add(Theme.Text("Consulta todos los cursos. Marca las actividades que quieras incluir: una para el informe individual o varias para el conjunto, trimestral o anual.", 13, Theme.Muted));
            var filters = new WrapPanel { Margin = new Thickness(0, 12, 0, 10) };
            filters.Children.Add(Theme.Label("Periodo: ")); filters.Children.Add(period); filters.Children.Add(Theme.Label(" Buscar: ")); filters.Children.Add(search); top.Children.Add(filters);
            period.Items.Add(new ComboBoxItem { Content = "Todos los cursos", Tag = null });
            foreach (var y in store.Calendar.Years) period.Items.Add(new ComboBoxItem { Content = "Anual · " + y.Name, Tag = new DatePeriod { Start = y.Start, End = y.End } });
            foreach (var t in store.Calendar.Terms) period.Items.Add(new ComboBoxItem { Content = "Trimestral · " + t.Name, Tag = t });
            period.Items.Add(new ComboBoxItem { Content = "Fechas personalizadas", Tag = "custom" }); period.SelectedIndex = 0;
            var range = new WrapPanel(); range.Children.Add(Theme.Label("Desde: ")); range.Children.Add(from); range.Children.Add(Theme.Label(" Hasta: ")); range.Children.Add(to); top.Children.Add(range); range.IsEnabled = false;
            var select = new WrapPanel(); select.Children.Add(Theme.Button("Marcar todas las visibles", () => { foreach (var c in checks.Values) c.IsChecked = true; UpdateCount(); })); select.Children.Add(Theme.Button("Desmarcar todas", () => { foreach (var c in checks.Values) c.IsChecked = false; UpdateCount(); })); select.Children.Add(count); top.Children.Add(select);
            var bottom = new WrapPanel { Margin = new Thickness(0, 12, 0, 0) }; DockPanel.SetDock(bottom, Dock.Bottom); root.Children.Add(bottom);
            bottom.Children.Add(Theme.Button("Vista previa / PDF / Imprimir", () => {
                var selected = visible.Where(e => checks[e.Id].IsChecked == true).ToList();
                if (selected.Count == 0) { MessageBox.Show(this, "Marca al menos una actividad.", Title); return; }
                ActivityReports.Preview(this, selected, ((ComboBoxItem)period.SelectedItem).Content.ToString() + (from.SelectedDate.HasValue ? " · " + Format.Date(from.SelectedDate.Value) + " - " + Format.Date(to.SelectedDate ?? from.SelectedDate.Value) : "") + (store.IsShared ? "\nDatos del servidor: " + viewSnapshot.ServerUtc.ToLocalTime().ToString("dd/MM/yyyy HH:mm:ss") + " · revisión " + viewSnapshot.Revision + "\n" + store.ConnectionStatus : ""));
            }, "Primary")); bottom.Children.Add(Theme.Button("Cerrar", Close));
            root.Children.Add(new ScrollViewer { Content = list, VerticalScrollBarVisibility = ScrollBarVisibility.Auto }); Content = root;
            period.SelectionChanged += (s, e) => {
                if (updatingPeriods) return;
                range.IsEnabled = ((ComboBoxItem)period.SelectedItem).Tag is string;
                var p = ((ComboBoxItem)period.SelectedItem).Tag as DatePeriod;
                from.SelectedDate = p == null ? (DateTime?)null : p.Start; to.SelectedDate = p == null ? (DateTime?)null : p.End; Reload();
            };
            search.TextChanged += (s, e) => Reload(); from.SelectedDateChanged += (s, e) => Reload(); to.SelectedDateChanged += (s, e) => Reload();
            Action changed = () => Dispatcher.BeginInvoke(new Action(() => Reload(true))); store.Changed += changed; Closed += (s, e) => store.Changed -= changed; Reload();
        }
        public static bool InPeriod(AgendaEvent e, SchoolCalendar calendar, DateTime? a, DateTime? b)
        { return !a.HasValue && !b.HasValue || Planning.All(e, calendar).Any(o => (!a.HasValue || o.Date >= a.Value.Date) && (!b.HasValue || o.Date <= b.Value.Date)); }
        void RefreshPeriods()
        {
            string selected = period.SelectedItem == null ? "Todos los cursos" : ((ComboBoxItem)period.SelectedItem).Content.ToString();
            updatingPeriods = true;
            try {
                period.Items.Clear(); period.Items.Add(new ComboBoxItem { Content = "Todos los cursos" });
                foreach (var y in viewSnapshot.Calendar.Years) period.Items.Add(new ComboBoxItem { Content = "Anual · " + y.Name, Tag = new DatePeriod { Start = y.Start, End = y.End } });
                foreach (var t in viewSnapshot.Calendar.Terms) period.Items.Add(new ComboBoxItem { Content = "Trimestral · " + t.Name, Tag = t });
                period.Items.Add(new ComboBoxItem { Content = "Fechas personalizadas", Tag = "custom" });
                period.SelectedItem = period.Items.Cast<ComboBoxItem>().FirstOrDefault(i => i.Content.ToString() == selected) ?? period.Items[0];
                var value = ((ComboBoxItem)period.SelectedItem).Tag;
                if (!(value is string)) { var d = value as DatePeriod; from.SelectedDate = d == null ? (DateTime?)null : d.Start; to.SelectedDate = d == null ? (DateTime?)null : d.End; }
            } finally { updatingPeriods = false; }
        }
        void UpdateCount() { count.Text = checks.Values.Count(c => c.IsChecked == true) + " seleccionadas / " + visible.Count + " visibles"; }
        void Reload(bool keepSelection = false)
        {
            if (updatingPeriods) return;
            viewSnapshot = store.LoadSnapshot();
            if (keepSelection) RefreshPeriods();
            var selectedIds = keepSelection ? checks.Where(x => x.Value.IsChecked == true).Select(x => x.Key).ToList() : new List<long>();
            checks.Clear(); list.Children.Clear();
            if (from.SelectedDate.HasValue && to.SelectedDate.HasValue && from.SelectedDate > to.SelectedDate) { visible.Clear(); list.Children.Add(Theme.Text("La fecha final debe ser igual o posterior a la inicial.", 13, Theme.Danger)); UpdateCount(); return; }
            visible = viewSnapshot.Events.Where(e => InPeriod(e, viewSnapshot.Calendar, from.SelectedDate, to.SelectedDate) && (e.Title + " " + e.Options.HistoryKey + " " + e.Options.Responsible).IndexOf(search.Text.Trim(), StringComparison.CurrentCultureIgnoreCase) >= 0).OrderByDescending(e => e.Start).ToList();
            foreach (var e in visible)
            {
                var item = e; var row = new DockPanel { Margin = new Thickness(0, 4, 0, 8) };
                var c = new CheckBox { VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 12, 0), Content = "Incluir", ToolTip = e.Title }; c.IsChecked = selectedIds.Contains(e.Id); checks.Add(e.Id, c); c.Checked += (s, ev) => UpdateCount(); c.Unchecked += (s, ev) => UpdateCount(); DockPanel.SetDock(c, Dock.Left); row.Children.Add(c);
                var edit = Theme.Button("Abrir actividad", () => { var editor = new EventEditor(store.EditSession(), store.Find(item.Id), null, item.Start); editor.Owner = this; editor.ShowDialog(); if (editor.Changed) Reload(); }); DockPanel.SetDock(edit, Dock.Right); row.Children.Add(edit);
                var p = new StackPanel(); p.Children.Add(Theme.Text(e.Title + " · " + e.DateLabel, 14, Theme.Ink, true));
                p.Children.Add(Theme.Text(viewSnapshot.Calendar.YearName(e.Start) + " · " + e.Options.Tasks.Count(t => !t.Completed) + " tareas pendientes · " + ActivityHistory.AttentionCount(e, DateTime.Today) + " requieren atención", 12, Theme.Muted));
                p.Children.Add(Theme.Text(e.Options.Memory.HasContent ? "Valoración: " + e.Options.Memory.Rating + " · Continuidad: " + e.Options.Memory.Continuity : "Sin memoria", 12, e.Options.Memory.Continuity == "No" ? Theme.Warning : Theme.Muted)); row.Children.Add(p); list.Children.Add(row);
            }
            if (visible.Count == 0) list.Children.Add(Theme.Text("No hay actividades en este periodo o búsqueda.", 14, Theme.Muted)); UpdateCount();
        }
    }
    public static class ActivityReports
    {
        static Paragraph P(string text, double size, bool bold)
        { return new Paragraph(new Run(String.IsNullOrWhiteSpace(text) ? "Sin registrar" : text)) { KeepWithNext = bold, FontSize = size, FontWeight = bold ? FontWeights.Bold : FontWeights.Normal, Margin = new Thickness(0, 0, 0, 9) }; }
        static TableCell Cell(string text, bool bold)
        { return new TableCell(P(text, 10, bold)) { Padding = new Thickness(6), BorderBrush = Brushes.LightGray, BorderThickness = new Thickness(0.5) }; }
        public static FlowDocument Build(IEnumerable<AgendaEvent> source, string title)
        {
            var events = source.OrderBy(e => e.Start).ToList();
            var doc = new FlowDocument { PageWidth = 793.7, PageHeight = 1122.5, PagePadding = new Thickness(50), ColumnWidth = 10000, FontFamily = new FontFamily("Segoe UI"), FontSize = 12, Background = Brushes.White, Foreground = Brushes.Black };
            doc.Blocks.Add(P("NEXO CENTRO · INFORME DE ACTIVIDADES", 22, true)); doc.Blocks.Add(P(title, 14, true)); doc.Blocks.Add(P("Generado el " + DateTime.Now.ToString("dd/MM/yyyy HH:mm") + " · " + events.Count + " actividades", 10, false));
            var table = new Table { CellSpacing = 0 };
            foreach (double width in new[] { 210.0, 110, 220, 150 }) table.Columns.Add(new TableColumn { Width = new GridLength(width) });
            var group = new TableRowGroup(); table.RowGroups.Add(group); var header = new TableRow { Background = Brushes.LightGray };
            foreach (var h in new[] { "Actividad", "Fechas", "Valoración", "Continuidad" }) header.Cells.Add(Cell(h, true)); group.Rows.Add(header);
            foreach (var e in events) { var r = new TableRow(); r.Cells.Add(Cell(e.Title, false)); r.Cells.Add(Cell(e.DateLabel, false)); r.Cells.Add(Cell(e.Options.Memory.Rating, false)); r.Cells.Add(Cell(e.Options.Memory.HasContent ? e.Options.Memory.Continuity + "\n" + e.Options.Memory.Justification : "Sin memoria", false)); group.Rows.Add(r); }
            doc.Blocks.Add(table);
            foreach (var e in events)
            {
                var section = new Section { BreakPageBefore = true };
                section.Blocks.Add(P(e.Title, 21, true)); section.Blocks.Add(P(e.DateLabel + " · " + e.TimeLabel + " · " + e.Options.Category, 12, false));
                section.Blocks.Add(P("Responsable: " + e.Options.Responsible + " · Grupos: " + e.Options.Group + " · Lugar: " + e.Options.Location, 11, false));
                var m = e.Options.Memory;
                if (!m.HasContent) section.Blocks.Add(P("Memoria pendiente de elaborar.", 14, true));
                else
                {
                    string[] labels = { "Valoración general", "Aspectos positivos", "Incidencias y dificultades", "Propuestas de mejora", "Continuidad en próximos cursos", "Justificación" };
                    string[] values = { m.Rating, m.Positives, m.Difficulties, m.Improvements, m.Continuity, m.Justification };
                    for (int i = 0; i < labels.Length; i++) { section.Blocks.Add(P(labels[i], 13, true)); section.Blocks.Add(P(values[i], 12, false)); }
                    if (m.Updated.HasValue) section.Blocks.Add(P("Última actualización de la memoria: " + m.Updated.Value.ToString("dd/MM/yyyy HH:mm"), 10, false));
                }
                section.Blocks.Add(P("Preparación y seguimiento", 14, true));
                if (e.Options.Tasks.Count == 0) section.Blocks.Add(P("Sin preparativos registrados.", 11, false));
                foreach (var t in e.Options.Tasks) section.Blocks.Add(P((t.Completed ? "Completada" : "Pendiente") + " · " + t.Description + " · Responsable: " + t.Responsible + (t.Due.HasValue ? " · Fecha límite: " + Format.Date(t.Due.Value) : "") + (t.Attention && !t.Completed ? " · Requiere atención" : ""), 11, false));
                doc.Blocks.Add(section);
            }
            return doc;
        }
        public static void Preview(Window owner, IEnumerable<AgendaEvent> source, string title)
        {
            var doc = Build(source, title); var paginator = ((IDocumentPaginatorSource)doc).DocumentPaginator;
            var window = new Window { Title = "Informe · vista previa", Width = 900, Height = 760, MinWidth = 600, MinHeight = 450, Owner = owner, WindowStartupLocation = WindowStartupLocation.CenterOwner }; Theme.ApplyWindow(window);
            var root = new DockPanel(); var buttons = new WrapPanel { Margin = new Thickness(12) }; DockPanel.SetDock(buttons, Dock.Top); root.Children.Add(buttons);
            var viewer = new FlowDocumentPageViewer { Document = doc }; root.Children.Add(viewer);
            buttons.Children.Add(Theme.Button("Exportar a PDF", () => {
                var save = new SaveFileDialog { Filter = "Documento PDF (*.pdf)|*.pdf", FileName = "Informe-actividades-" + DateTime.Today.ToString("yyyy-MM-dd") + ".pdf", DefaultExt = ".pdf", AddExtension = true };
                if (save.ShowDialog(window) != true) return;
                try { ExportPdf(paginator, save.FileName); MessageBox.Show(window, "PDF guardado correctamente.", "Informe"); } catch (Exception ex) { MessageBox.Show(window, "No se pudo guardar el PDF. " + ex.Message, "Informe"); }
            }, "Primary"));
            buttons.Children.Add(Theme.Button("Imprimir", () => {
                try { var dialog = new PrintDialog(); if (dialog.ShowDialog() == true) dialog.PrintDocument(paginator, title); }
                catch (Exception ex) { MessageBox.Show(window, "No se pudo imprimir. " + ex.Message, "Informe"); }
            })); buttons.Children.Add(Theme.Button("Cerrar", window.Close)); window.Content = root; window.ShowDialog();
        }
        // The same WPF pagination is used for preview, paper and PDF. Embedding rendered
        // pages preserves all Unicode glyphs without requiring fonts or a PDF printer.
        public static void ExportPdf(DocumentPaginator paginator, string path)
        {
            paginator.ComputePageCount(); var images = new List<byte[]>(); var widths = new List<int>(); var heights = new List<int>();
            for (int i = 0; i < paginator.PageCount; i++)
            {
                var page = paginator.GetPage(i); var visual = new DrawingVisual();
                using (var dc = visual.RenderOpen()) { dc.DrawRectangle(Brushes.White, null, new Rect(page.Size)); dc.DrawRectangle(new VisualBrush(page.Visual) { Stretch = Stretch.None, AlignmentX = AlignmentX.Left, AlignmentY = AlignmentY.Top }, null, new Rect(page.Size)); }
                var bmp = new RenderTargetBitmap((int)Math.Ceiling(page.Size.Width * 2), (int)Math.Ceiling(page.Size.Height * 2), 192, 192, PixelFormats.Pbgra32); bmp.Render(visual);
                var frame = new DrawingVisual(); using (var dc = frame.RenderOpen()) { dc.DrawImage(bmp, new Rect(page.Size)); var footer = new FormattedText("Nexo Centro · " + (i + 1) + " / " + paginator.PageCount, Format.Spanish, FlowDirection.LeftToRight, new Typeface("Segoe UI"), 10, Brushes.Gray, 1.0); dc.DrawText(footer, new Point(50, page.Size.Height - 32)); }
                var final = new RenderTargetBitmap(bmp.PixelWidth, bmp.PixelHeight, 192, 192, PixelFormats.Pbgra32); final.Render(frame);
                var jpeg = new JpegBitmapEncoder { QualityLevel = 92 }; widths.Add(final.PixelWidth); heights.Add(final.PixelHeight); jpeg.Frames.Add(BitmapFrame.Create(final)); using (var ms = new MemoryStream()) { jpeg.Save(ms); images.Add(ms.ToArray()); }
            }
            string temp = path + "." + Guid.NewGuid().ToString("N") + ".tmp";
            try
            {
                using (var stream = new FileStream(temp, FileMode.CreateNew))
                {
                    var offsets = new List<long> { 0 }; Action<string> write = s => { var bytes = Encoding.ASCII.GetBytes(s); stream.Write(bytes, 0, bytes.Length); };
                    Action<int, string> obj = (n, body) => { offsets.Add(stream.Position); write(n + " 0 obj\n" + body + "\nendobj\n"); };
                    write("%PDF-1.4\n"); obj(1, "<< /Type /Catalog /Pages 2 0 R >>"); obj(2, "<< /Type /Pages /Count " + images.Count + " /Kids [" + String.Join(" ", Enumerable.Range(0, images.Count).Select(i => (3 + i * 3) + " 0 R")) + "] >>");
                    for (int i = 0; i < images.Count; i++)
                    {
                        int n = 3 + i * 3; obj(n, "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595.28 841.89] /Resources << /XObject << /Im " + (n + 2) + " 0 R >> >> /Contents " + (n + 1) + " 0 R >>");
                        string content = "q 595.28 0 0 841.89 0 0 cm /Im Do Q\n"; obj(n + 1, "<< /Length " + content.Length + " >>\nstream\n" + content + "endstream");
                        offsets.Add(stream.Position); write((n + 2) + " 0 obj\n<< /Type /XObject /Subtype /Image /Width " + widths[i] + " /Height " + heights[i] + " /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length " + images[i].Length + " >>\nstream\n"); stream.Write(images[i], 0, images[i].Length); write("\nendstream\nendobj\n");
                    }
                    long xref = stream.Position; write("xref\n0 " + offsets.Count + "\n0000000000 65535 f \n"); foreach (long offset in offsets.Skip(1)) write(offset.ToString("0000000000", CultureInfo.InvariantCulture) + " 00000 n \n"); write("trailer\n<< /Size " + offsets.Count + " /Root 1 0 R >>\nstartxref\n" + xref + "\n%%EOF\n");
                }
                if (File.Exists(path)) File.Replace(temp, path, null); else File.Move(temp, path);
            }
            finally { if (File.Exists(temp)) File.Delete(temp); }
        }
    }
}
