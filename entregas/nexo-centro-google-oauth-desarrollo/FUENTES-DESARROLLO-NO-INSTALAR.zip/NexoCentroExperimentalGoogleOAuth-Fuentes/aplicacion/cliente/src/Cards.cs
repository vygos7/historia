using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Media;

namespace AgendaClara
{
    // Activity cards shared by every view, so colours and labels stay consistent.
    public static class Cards
    {
        static Dictionary<string, string> colors = new Dictionary<string, string>();
        public static SchoolCalendar Calendar = new SchoolCalendar();

        public static void SetCategories(IEnumerable<Category> list)
        {
            colors = new Dictionary<string, string>(StringComparer.CurrentCultureIgnoreCase);
            foreach (var c in list) colors[c.Name] = c.Color;
        }
        public static string ColorOf(string category)
        {
            string c;
            if (category != null && colors.TryGetValue(category, out c) && !String.IsNullOrEmpty(c)) return c;
            return CategoryPalette.DefaultColor(category) ?? "#66747B";
        }

        public static string Describe(Occurrence o)
        {
            var e = o.View;
            var lines = new List<string> { e.Title, Format.LongDate(o.Date) + " · " + e.TimeLabel, "Categoría: " + e.Options.Category };
            if (o.Total > 1) lines.Add("Fecha " + o.Number + " de " + o.Total + " · " + o.Source.DateLabel);
            if (o.Moved) lines.Add("Trasladada desde el " + Format.Date(o.OriginalDate));
            if (!String.IsNullOrWhiteSpace(e.Options.Location)) lines.Add("Lugar: " + e.Options.Location);
            return String.Join("\n", lines);
        }

        static Button Wrap(UIElement content, string name, Action open, object tooltip)
        {
            var b = new Button { Style = Theme.Style("Quiet"), Content = content, Padding = new Thickness(0), ToolTip = tooltip, HorizontalContentAlignment = HorizontalAlignment.Stretch };
            AutomationProperties.SetName(b, name);
            b.Click += (s, e) => open();
            return b;
        }

        public static Button Compact(Occurrence o, Action open)
        {
            var e = o.View; string color = ColorOf(e.Options.Category);
            string prefix = (o.Total > 1 ? "↔ " : "") + (e.AllDay ? "" : AgendaEvent.Clock(e.StartMinute) + " ");
            var text = new TextBlock { Text = prefix + e.Title, FontSize = 12, Foreground = Theme.Ink, TextTrimming = TextTrimming.CharacterEllipsis, TextWrapping = TextWrapping.NoWrap };
            var row = new DockPanel(); var dot = Theme.Swatch(color, 7); dot.Margin = new Thickness(0, 0, 6, 0);
            DockPanel.SetDock(dot, Dock.Left); row.Children.Add(dot); row.Children.Add(text);
            var border = new Border { Background = Brushes.Transparent, Padding = new Thickness(2, 1, 2, 2), Child = row };
            var b = Wrap(border, e.Title + ", " + e.TimeLabel + ", " + e.Options.Category, open, Describe(o));
            b.Margin = new Thickness(0, 1, 0, 1);
            b.Height = 22;
            return b;
        }

        public static Button Full(Occurrence o, Action open, bool showDate, bool compactWidth = false)
        {
            var e = o.View; string color = ColorOf(e.Options.Category);
            var p = new StackPanel();
            var title = Theme.Text(e.Title, compactWidth ? 13 : 14.5, Theme.Ink, true);
            p.Children.Add(title);
            var meta = Theme.Text(e.TimeLabel + " · " + e.Options.Category, 12, Theme.Shade(color, 0.25), true);
            meta.Margin = new Thickness(0, 2, 0, 0);
            p.Children.Add(meta);
            if (showDate) p.Children.Add(Theme.Text(Format.LongDate(o.Date), 12, Theme.Muted));
            if (o.Total > 1) p.Children.Add(Theme.Text("↔ Fecha " + o.Number + " de " + o.Total + " · " + o.Source.DateLabel, 12, Theme.Muted));
            if (!compactWidth)
            {
                var extra = new List<string>();
                if (!String.IsNullOrWhiteSpace(e.Options.Group)) extra.Add("Grupos: " + e.Options.Group.Trim());
                if (!String.IsNullOrWhiteSpace(e.Options.Responsible)) extra.Add("Responsable: " + e.Options.Responsible.Trim());
                if (!String.IsNullOrWhiteSpace(e.Options.Location)) extra.Add("Lugar: " + e.Options.Location.Trim());
                if (extra.Count > 0) p.Children.Add(Theme.Text(String.Join(" · ", extra), 12, Theme.Muted));
                if (!String.IsNullOrWhiteSpace(e.Notes))
                {
                    var notes = Theme.Text(e.Notes.Trim(), 12, Theme.Muted);
                    notes.MaxHeight = 52; notes.TextTrimming = TextTrimming.CharacterEllipsis; notes.Margin = new Thickness(0, 3, 0, 0);
                    p.Children.Add(notes);
                }
            }
            var badges = new WrapPanel { Margin = new Thickness(0, 3, 0, 0) };
            int pending = e.Options.Tasks.Count(t => !t.Completed);
            if (pending > 0) badges.Children.Add(Theme.Pill(pending + " tareas pendientes · " + ActivityHistory.AttentionCount(e, DateTime.Today) + " requieren atención", Theme.WarningSoft, Theme.Warning));
            if (e.Options.Memory.HasContent) badges.Children.Add(Theme.Pill("Memoria · continuidad: " + e.Options.Memory.Continuity, Theme.Pale, Theme.Muted));
            if (o.Moved) badges.Children.Add(Theme.Pill("Trasladada desde el " + Format.DayMonth(o.OriginalDate), Theme.WarningSoft, Theme.Warning));
            else if (o.Changed) badges.Children.Add(Theme.Pill("Cambios solo en esta fecha", Theme.WarningSoft, Theme.Warning));
            if (!Calendar.IsSchoolDay(o.Date)) badges.Children.Add(Theme.Pill("Excepción: día no lectivo", Theme.NonSchool, Theme.NonSchoolInk));
            if (badges.Children.Count > 0) p.Children.Add(badges);

            var grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(3) });
            grid.ColumnDefinitions.Add(new ColumnDefinition());
            grid.Children.Add(new Border { Background = Theme.Tint(color, 0), CornerRadius = new CornerRadius(6, 0, 0, 6) });
            p.Margin = new Thickness(compactWidth ? 9 : 14, 12, 12, 13);
            Grid.SetColumn(p, 1); grid.Children.Add(p);
            var card = new Border { Background = Theme.Surface, BorderBrush = Theme.Line, BorderThickness = new Thickness(1), CornerRadius = new CornerRadius(10), Child = grid };
            var b = Wrap(card, e.Title + ", " + e.TimeLabel + ", " + e.Options.Category, open, Describe(o));
            b.Margin = new Thickness(0, 0, 0, 8);
            return b;
        }

        public static Button Result(AgendaEvent e, List<Occurrence> dates, DateTime today, Action open)
        {
            string color = ColorOf(e.Options.Category);
            var p = new StackPanel { Margin = new Thickness(11, 8, 8, 9) };
            p.Children.Add(Theme.Text(e.Title, 14.5, Theme.Ink, true));
            p.Children.Add(Theme.Text(e.TimeLabel + " · " + e.Options.Category, 12, Theme.Shade(color, 0.25), true));
            p.Children.Add(Theme.Text(e.DateLabel + " · " + Planning.RepetitionSummary(e), 12, Theme.Muted));
            var extra = new[] { e.Options.Group, e.Options.Responsible, e.Options.Location }.Where(x => !String.IsNullOrWhiteSpace(x)).ToList();
            if (extra.Count > 0) p.Children.Add(Theme.Text(String.Join(" · ", extra), 12, Theme.Muted));
            var badges = new WrapPanel { Margin = new Thickness(0, 3, 0, 0) };
            var next = dates.FirstOrDefault(o => o.Date >= today.Date);
            if (dates.Count == 0) badges.Children.Add(Theme.Pill("Sin fechas visibles con el calendario actual", Theme.WarningSoft, Theme.Warning));
            else if (next != null) badges.Children.Add(Theme.Pill("Próxima fecha: " + Format.LongDate(next.Date), Theme.AccentSoft, Theme.AccentDark));
            else badges.Children.Add(Theme.Pill("Pasada · última fecha " + Format.Date(dates.Last().Date), Theme.Weekend, Theme.Muted));
            if (dates.Count > 1) badges.Children.Add(Theme.Pill(Format.Count(dates.Count, "fecha", "fechas"), Theme.Weekend, Theme.Muted));
            p.Children.Add(badges);
            var grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(3) });
            grid.ColumnDefinitions.Add(new ColumnDefinition());
            grid.Children.Add(new Border { Background = Theme.Tint(color, 0), CornerRadius = new CornerRadius(6, 0, 0, 6) });
            Grid.SetColumn(p, 1); grid.Children.Add(p);
            var card = new Border { Background = Theme.Surface, BorderBrush = Theme.Line, BorderThickness = new Thickness(1), CornerRadius = new CornerRadius(10), Child = grid };
            var b = Wrap(card, e.Title + ", " + e.Options.Category + ", " + e.DateLabel, open, "Abrir y editar la actividad completa");
            b.Margin = new Thickness(0, 0, 0, 8);
            return b;
        }
    }
}
