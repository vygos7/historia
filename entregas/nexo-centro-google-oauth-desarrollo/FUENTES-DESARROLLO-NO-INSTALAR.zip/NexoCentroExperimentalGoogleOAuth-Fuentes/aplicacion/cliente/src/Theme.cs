using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Media;

namespace AgendaClara
{
    public static class Theme
    {
        public static readonly SolidColorBrush Ink = Solid("#203044"), Muted = Solid("#637287"), Accent = Solid("#186E63"), AccentDark = Solid("#14574F"),
            AccentSoft = Solid("#E8F4EF"), Line = Solid("#E3E8EF"), Pale = Solid("#E8F4EF"), Surface = Solid("#FFFFFF"), Background = Solid("#F5F7FA"),
            Danger = Solid("#B1343A"), DangerSoft = Solid("#FBEAEA"), Warning = Solid("#8A5A12"), WarningSoft = Solid("#FFF3DC"),
            Weekend = Solid("#F0F3F7"), NonSchool = Solid("#F8F1E6"), NonSchoolInk = Solid("#7E5426"), Selected = Solid("#E4F2EB");

        static readonly Dictionary<string, SolidColorBrush> cache = new Dictionary<string, SolidColorBrush>();

        public static SolidColorBrush Solid(string hex)
        {
            var b = new SolidColorBrush((Color)ColorConverter.ConvertFromString(hex));
            b.Freeze(); return b;
        }
        static Color ParseColor(string hex)
        {
            try { return (Color)ColorConverter.ConvertFromString(String.IsNullOrEmpty(hex) ? "#66747B" : hex); }
            catch (FormatException) { return (Color)ColorConverter.ConvertFromString("#66747B"); }
        }
        // amount 0 = original colour, 1 = white.
        public static SolidColorBrush Tint(string hex, double amount)
        {
            string key = hex + "|" + amount;
            SolidColorBrush b;
            if (cache.TryGetValue(key, out b)) return b;
            Color c = ParseColor(hex);
            Func<byte, byte> mix = v => (byte)Math.Round(v + (255 - v) * amount);
            b = new SolidColorBrush(Color.FromRgb(mix(c.R), mix(c.G), mix(c.B)));
            b.Freeze(); cache[key] = b; return b;
        }
        public static SolidColorBrush Shade(string hex, double amount)
        {
            string key = hex + "|d" + amount;
            SolidColorBrush b;
            if (cache.TryGetValue(key, out b)) return b;
            Color c = ParseColor(hex);
            Func<byte, byte> mix = v => (byte)Math.Round(v * (1 - amount));
            b = new SolidColorBrush(Color.FromRgb(mix(c.R), mix(c.G), mix(c.B)));
            b.Freeze(); cache[key] = b; return b;
        }

        public static void Install(Application app)
        {
            app.Resources = (ResourceDictionary)XamlReader.Parse(@"<ResourceDictionary xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation' xmlns:x='http://schemas.microsoft.com/winfx/2006/xaml' xmlns:p='clr-namespace:System.Windows.Controls.Primitives;assembly=PresentationFramework'>
  <Style TargetType='Window'><Setter Property='FontFamily' Value='Segoe UI'/><Setter Property='FontSize' Value='14'/><Setter Property='Foreground' Value='#203044'/><Setter Property='Background' Value='#F5F7FA'/><Setter Property='UseLayoutRounding' Value='True'/><Setter Property='TextOptions.TextFormattingMode' Value='Display'/></Style>
  <ControlTemplate x:Key='RoundButton' TargetType='ButtonBase'>
    <Border x:Name='B' Background='{TemplateBinding Background}' BorderBrush='{TemplateBinding BorderBrush}' BorderThickness='{TemplateBinding BorderThickness}' CornerRadius='9' Padding='{TemplateBinding Padding}' SnapsToDevicePixels='True'>
      <ContentPresenter HorizontalAlignment='{TemplateBinding HorizontalContentAlignment}' VerticalAlignment='{TemplateBinding VerticalContentAlignment}' RecognizesAccessKey='False'/>
    </Border>
    <ControlTemplate.Triggers>
      <Trigger Property='IsMouseOver' Value='True'><Setter TargetName='B' Property='Opacity' Value='0.85'/></Trigger>
      <Trigger Property='IsPressed' Value='True'><Setter TargetName='B' Property='Opacity' Value='0.7'/></Trigger>
      <Trigger Property='IsKeyboardFocused' Value='True'><Setter TargetName='B' Property='BorderBrush' Value='#14574F'/><Setter TargetName='B' Property='BorderThickness' Value='2'/></Trigger>
      <Trigger Property='IsEnabled' Value='False'><Setter TargetName='B' Property='Opacity' Value='0.45'/></Trigger>
    </ControlTemplate.Triggers>
  </ControlTemplate>
  <Style TargetType='Button'><Setter Property='Background' Value='White'/><Setter Property='Foreground' Value='#203044'/><Setter Property='BorderBrush' Value='#DCE3EB'/><Setter Property='BorderThickness' Value='1'/><Setter Property='Padding' Value='14,8'/><Setter Property='MinHeight' Value='34'/><Setter Property='Cursor' Value='Hand'/><Setter Property='HorizontalContentAlignment' Value='Center'/><Setter Property='VerticalContentAlignment' Value='Center'/><Setter Property='Template' Value='{StaticResource RoundButton}'/></Style>
  <Style x:Key='Primary' TargetType='Button' BasedOn='{StaticResource {x:Type Button}}'><Setter Property='Background' Value='#186E63'/><Setter Property='Foreground' Value='White'/><Setter Property='BorderBrush' Value='#186E63'/><Setter Property='FontWeight' Value='SemiBold'/></Style>
  <Style x:Key='DangerButton' TargetType='Button' BasedOn='{StaticResource {x:Type Button}}'><Setter Property='Foreground' Value='#B1343A'/><Setter Property='BorderBrush' Value='#E2B5B7'/></Style>
  <Style x:Key='DangerSolid' TargetType='Button' BasedOn='{StaticResource {x:Type Button}}'><Setter Property='Background' Value='#B1343A'/><Setter Property='Foreground' Value='White'/><Setter Property='BorderBrush' Value='#B1343A'/><Setter Property='FontWeight' Value='SemiBold'/></Style>
  <Style x:Key='Quiet' TargetType='Button' BasedOn='{StaticResource {x:Type Button}}'><Setter Property='Background' Value='Transparent'/><Setter Property='BorderThickness' Value='0'/><Setter Property='Padding' Value='2'/><Setter Property='MinHeight' Value='0'/><Setter Property='HorizontalContentAlignment' Value='Stretch'/></Style>
  <Style x:Key='Segment' TargetType='RadioButton'><Setter Property='Background' Value='White'/><Setter Property='Foreground' Value='#203044'/><Setter Property='BorderBrush' Value='#DCE3EB'/><Setter Property='BorderThickness' Value='1'/><Setter Property='Padding' Value='14,8'/><Setter Property='MinHeight' Value='34'/><Setter Property='Margin' Value='0,0,4,0'/><Setter Property='Cursor' Value='Hand'/><Setter Property='HorizontalContentAlignment' Value='Center'/><Setter Property='VerticalContentAlignment' Value='Center'/><Setter Property='Template' Value='{StaticResource RoundButton}'/>
    <Style.Triggers><Trigger Property='IsChecked' Value='True'><Setter Property='Background' Value='#186E63'/><Setter Property='Foreground' Value='White'/><Setter Property='BorderBrush' Value='#186E63'/><Setter Property='FontWeight' Value='SemiBold'/></Trigger></Style.Triggers></Style>
  <Style TargetType='TextBox'><Setter Property='Padding' Value='7,5'/><Setter Property='MinHeight' Value='34'/><Setter Property='BorderBrush' Value='#C7D2DF'/><Setter Property='VerticalContentAlignment' Value='Center'/></Style>
  <Style TargetType='ComboBox'><Setter Property='MinHeight' Value='34'/><Setter Property='Padding' Value='8,5'/><Setter Property='VerticalContentAlignment' Value='Center'/></Style>
  <Style TargetType='DatePicker'><Setter Property='MinHeight' Value='34'/><Setter Property='Padding' Value='6,4'/><Setter Property='VerticalContentAlignment' Value='Center'/><Setter Property='BorderBrush' Value='#C7D2DF'/><Setter Property='SelectedDateFormat' Value='Short'/><Setter Property='FirstDayOfWeek' Value='Monday'/></Style>
  <Style TargetType='p:DatePickerTextBox'><Setter Property='VerticalContentAlignment' Value='Center'/><Setter Property='Background' Value='Transparent'/></Style>
  <Style TargetType='Calendar'><Setter Property='FirstDayOfWeek' Value='Monday'/></Style>
  <Style TargetType='CheckBox'><Setter Property='VerticalContentAlignment' Value='Center'/><Setter Property='Margin' Value='0,4,0,4'/></Style>
  <Style TargetType='RadioButton'><Setter Property='VerticalContentAlignment' Value='Center'/><Setter Property='Margin' Value='0,4,0,4'/></Style>
  <Style TargetType='ToolTip'><Setter Property='MaxWidth' Value='420'/></Style>
  <Style TargetType='ScrollViewer'><Setter Property='Focusable' Value='False'/></Style>
</ResourceDictionary>");
        }

        public static Style Style(string key) { return (Style)Application.Current.Resources[key]; }
        public static void ApplyWindow(Window w)
        {
            w.Style = (Style)Application.Current.Resources[typeof(Window)];
            // Icono visible en el titulo, Alt+Tab y en la barra de tareas de Windows.
            w.Icon = AppIcon.Source;
        }

        public static TextBlock Text(string value, double size, Brush color, bool bold = false)
        {
            var t = new TextBlock { Text = value ?? "", FontSize = size, Foreground = color, TextWrapping = TextWrapping.Wrap };
            if (bold) t.FontWeight = FontWeights.SemiBold;
            return t;
        }

        public static Button Button(string label, Action action, string style = null)
        {
            var b = new Button { Content = label };
            if (style != null) b.Style = Style(style);
            AutomationProperties.SetName(b, label);
            b.Click += (s, e) => action();
            return b;
        }

        public static TextBlock Label(string text) { var t = Text(text, 13, Ink, true); t.Margin = new Thickness(0, 0, 0, 5); return t; }

        public static Border Swatch(string color, double size = 14)
        {
            return new Border { Width = size, Height = size, CornerRadius = new CornerRadius(3), Background = Tint(color, 0), VerticalAlignment = VerticalAlignment.Center };
        }

        public static Border Pill(string text, Brush background, Brush foreground)
        {
            var t = Text(text, 11, foreground, true); t.TextWrapping = TextWrapping.NoWrap;
            return new Border { Background = background, CornerRadius = new CornerRadius(9), Padding = new Thickness(7, 1, 7, 2), Margin = new Thickness(0, 2, 6, 2), Child = t, VerticalAlignment = VerticalAlignment.Center };
        }

        public static Border Panel(UIElement child, Thickness padding)
        {
            return new Border { Background = Surface, BorderBrush = Line, BorderThickness = new Thickness(1), CornerRadius = new CornerRadius(14), Padding = padding, Child = child };
        }

        public static Border Notice(string text, Brush background, Brush foreground)
        {
            return new Border { Background = background, CornerRadius = new CornerRadius(8), Padding = new Thickness(12, 8, 12, 8), Margin = new Thickness(0, 6, 0, 10), Child = Text(text, 13, foreground) };
        }
    }
}
