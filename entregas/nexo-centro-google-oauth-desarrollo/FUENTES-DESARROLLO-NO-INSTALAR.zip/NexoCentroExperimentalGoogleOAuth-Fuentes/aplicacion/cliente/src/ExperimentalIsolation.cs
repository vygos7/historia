using System;
using System.IO;
using System.Linq;
namespace AgendaClara
{
    public sealed class ExperimentalIdentity { public string Edition {get;set;} = ""; }
    public static class ExperimentalIsolation
    {
        public const string Edition="NexoCentro-4.2.0-experimental-google-oauth-r1";
        public const string Marker="nexo-experimental.marker";
        public static void PathForWrite(string path)
        {
            string full=Path.GetFullPath(path);
            if(!full.Split(Path.DirectorySeparatorChar,Path.AltDirectorySeparatorChar).Any(s=>{string n=s.Replace("-", "").ToUpperInvariant();return n.StartsWith("NEXOCENTROEXPERIMENTALGOOGLEOAUTH",StringComparison.Ordinal)||n.StartsWith("NEXOCENTRO4.2.0EXPERIMENTAL",StringComparison.Ordinal);}))
                throw new IOException("Esta versión sólo puede escribir dentro de una carpeta NexoCentroExperimentalGoogleOAuth. La instalación estable no se abre ni se actualiza.");
            string cursor=Directory.Exists(full)?full:Path.GetDirectoryName(full);
            while(!String.IsNullOrEmpty(cursor))
            {
                if(Directory.Exists(cursor) && (new DirectoryInfo(cursor).Attributes&FileAttributes.ReparsePoint)!=0)throw new IOException("La carpeta experimental no puede ser un enlace a otra ubicación.");
                cursor=Path.GetDirectoryName(cursor);
            }
        }
        public static void Server(string root,bool initialize)
        {
            PathForWrite(root);string marker=Path.Combine(root,Marker);
            if(File.Exists(marker)) {if(File.ReadAllText(marker).Trim()!=Edition)throw new IOException("La marca de esta carpeta experimental no es válida.");return;}
            if(!initialize || Directory.Exists(root)&&Directory.EnumerateFileSystemEntries(root).Any())throw new IOException("El servidor experimental necesita una carpeta nueva y vacía; no admite datos de la instalación estable.");
            Directory.CreateDirectory(root);File.WriteAllText(marker,Edition);
        }
    }
}
