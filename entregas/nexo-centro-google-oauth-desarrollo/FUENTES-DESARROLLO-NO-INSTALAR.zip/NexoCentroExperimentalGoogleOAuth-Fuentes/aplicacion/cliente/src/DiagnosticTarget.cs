using System;
using System.Net;
using System.Net.Sockets;

namespace AgendaClara
{
    public static class DiagnosticTarget
    {
        // Sólo la herramienta portátil: prueba comparativa, nunca una URL persistida ni
        // una relajación TLS. La IP tendrá que figurar en el SAN del certificado HTTPS.
        public static string WithIPv4(string configured,string literal)
        {
            var original=new Uri(configured,UriKind.Absolute);IPAddress ip;
            if(original.Scheme!="https" || original.UserInfo.Length!=0 || !IPAddress.TryParse(literal,out ip) || ip.AddressFamily!=AddressFamily.InterNetwork)
                throw new ArgumentException("Indica una dirección IPv4 privada, sin puerto ni prefijo https://.");
            var b=ip.GetAddressBytes();
            if(!(b[0]==10 || b[0]==172 && b[1]>=16 && b[1]<=31 || b[0]==192 && b[1]==168))
                throw new ArgumentException("La prueba comparativa sólo admite una IPv4 de red privada.");
            var target=new UriBuilder(original){Host=ip.ToString()};return target.Uri.AbsoluteUri;
        }
    }
}
