﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;

namespace AgendaClara
{
    public sealed class StoreException : IOException
    {
        public readonly int Code;
        public StoreException(int code, string message) : base(message) { Code = code; }
    }

    public sealed class BackupInfo
    {
        public string Path = "";
        public DateTime Modified;
        public long Size;
        public int Events = -1;
        public int Categories = -1;
        public bool HasCalendar;
        public string Error = "";
        public string Kind
        {
            get
            {
                string name = System.IO.Path.GetFileName(Path);
                if (name.StartsWith("Antes-de-restaurar", StringComparison.OrdinalIgnoreCase)) return "Agenda guardada antes de una restauración";
                if (name.StartsWith("Antes-", StringComparison.OrdinalIgnoreCase)) return "Agenda guardada antes de una actualización";
                if (name.StartsWith("AgendaClara-", StringComparison.OrdinalIgnoreCase)) return "Copia automática del día";
                return "Copia";
            }
        }
    }

    // Local SQLite database supplied by Windows (winsqlite3.dll). All user values are bound parameters.
    public sealed partial class Store : IDisposable
    {
        public const int SchemaVersion = 5;
        IntPtr db;
        readonly bool automaticBackups;
        internal Func<DateTime> Clock = () => DateTime.Now;
        public string DatabasePath { get; private set; }
        public string BackupDirectory { get; private set; }
        public string BackupError { get; private set; }
        public DateTime? LastBackup { get; private set; }
        public string LastBackupFile { get; private set; }
        public string MigrationBackup { get; private set; }
        public int MigratedFrom { get; private set; }
        SchoolCalendar localCalendar;
        public SchoolCalendar Calendar { get { return remote == null ? localCalendar : remote.Snapshot.Calendar; } private set { localCalendar = value; } }

        const int SQLITE_OK = 0, SQLITE_ROW = 100, SQLITE_DONE = 101, SQLITE_OPEN_READONLY = 1;
        [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)] static extern int sqlite3_open16(string path, out IntPtr db);
        [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)] static extern int sqlite3_open_v2(byte[] utf8Path, out IntPtr db, int flags, IntPtr vfs);
        [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)] static extern int sqlite3_close(IntPtr db);
        [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)] static extern int sqlite3_busy_timeout(IntPtr db, int ms);
        [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)] static extern IntPtr sqlite3_errmsg16(IntPtr db);
        [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)] static extern int sqlite3_prepare16_v2(IntPtr db, string sql, int bytes, out IntPtr stmt, IntPtr tail);
        [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)] static extern int sqlite3_step(IntPtr stmt);
        [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)] static extern int sqlite3_finalize(IntPtr stmt);
        [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)] static extern int sqlite3_bind_text16(IntPtr stmt, int index, string value, int bytes, IntPtr destructor);
        [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)] static extern int sqlite3_bind_int64(IntPtr stmt, int index, long value);
        [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)] static extern long sqlite3_column_int64(IntPtr stmt, int column);
        [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)] static extern IntPtr sqlite3_column_text16(IntPtr stmt, int column);
        [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)] static extern long sqlite3_last_insert_rowid(IntPtr db);
        [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)] static extern IntPtr sqlite3_backup_init(IntPtr destination, string destinationName, IntPtr source, string sourceName);
        [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)] static extern int sqlite3_backup_step(IntPtr backup, int pages);
        [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)] static extern int sqlite3_backup_finish(IntPtr backup);
        [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)] static extern int sqlite3_errcode(IntPtr db);

        public Store(string path, bool automaticBackups = true)
        {
            DatabasePath = Path.GetFullPath(path);
            this.automaticBackups = automaticBackups;
            BackupDirectory = Path.Combine(Path.GetDirectoryName(DatabasePath), Path.GetFileNameWithoutExtension(DatabasePath) + "-copias");
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(DatabasePath));
                int code = sqlite3_open16(DatabasePath, out db);
                if (code != SQLITE_OK) throw Error(db, code, "No se pudo abrir la agenda.");
#if !SERVER
                if (TableExists(db, "settings") && ReadSetting("shared_owner").Length > 0) throw new IOException("Esta base pertenece al servidor central. Conecta mediante Trabajo compartido; no puede abrirse como agenda individual.");
#endif
                sqlite3_busy_timeout(db, 5000);
                Execute("PRAGMA journal_mode=WAL");
                Execute("PRAGMA synchronous=FULL");
                Initialize();
                UpdateAutomaticBackup();
                if (!LastBackup.HasValue) FindLatestBackup();
            }
            catch { Dispose(); throw; }
        }

        // ---- low level -------------------------------------------------------------------

        static string Friendly(int code)
        {
            switch (code & 0xFF)
            {
                case 5: case 6: return "La agenda está ocupada por otro programa. Cierra otras ventanas de Agenda Clara e inténtalo de nuevo.";
                case 8: return "No se puede escribir en el archivo de la agenda: es de solo lectura o faltan permisos.";
                case 10: return "Error de lectura o escritura en el disco.";
                case 11: case 26: return "El archivo no es una agenda válida o está dañado.";
                case 13: return "El disco está lleno.";
                case 14: return "No se puede abrir el archivo indicado.";
                default: return "Error de la base de datos.";
            }
        }
        static StoreException Error(IntPtr handle, int code, string prefix)
        {
            string detail = handle == IntPtr.Zero ? "" : Marshal.PtrToStringUni(sqlite3_errmsg16(handle));
            return new StoreException(code, prefix + " " + Friendly(code) + (String.IsNullOrEmpty(detail) ? "" : " (Detalle técnico: " + detail + ")"));
        }
        void Check(int code) { if (code != SQLITE_OK) throw Error(db, code, "No se pudo completar la operación."); }
        static IntPtr Prepare(IntPtr handle, string sql)
        {
            IntPtr stmt; int code = sqlite3_prepare16_v2(handle, sql, -1, out stmt, IntPtr.Zero);
            if (code != SQLITE_OK) throw Error(handle, code, "No se pudo leer la agenda.");
            return stmt;
        }
        static void Bind(IntPtr handle, IntPtr stmt, object[] values)
        {
            for (int i = 0; i < values.Length; i++)
            {
                int code = values[i] is string
                    ? sqlite3_bind_text16(stmt, i + 1, (string)values[i], -1, new IntPtr(-1))
                    : sqlite3_bind_int64(stmt, i + 1, Convert.ToInt64(values[i], CultureInfo.InvariantCulture));
                if (code != SQLITE_OK) throw Error(handle, code, "No se pudo preparar la operación.");
            }
        }
        static void ExecuteOn(IntPtr handle, string sql, params object[] values)
        {
            IntPtr stmt = Prepare(handle, sql);
            try
            {
                Bind(handle, stmt, values);
                int code; do { code = sqlite3_step(stmt); } while (code == SQLITE_ROW);
                if (code != SQLITE_DONE) throw Error(handle, code, "No se pudo guardar en la agenda.");
            }
            finally { sqlite3_finalize(stmt); }
        }
        static List<T> QueryOn<T>(IntPtr handle, string sql, Func<IntPtr, T> read, params object[] values)
        {
            var result = new List<T>();
            IntPtr stmt = Prepare(handle, sql);
            try
            {
                Bind(handle, stmt, values);
                int code;
                while ((code = sqlite3_step(stmt)) == SQLITE_ROW) result.Add(read(stmt));
                if (code != SQLITE_DONE) throw Error(handle, code, "No se pudo leer la agenda.");
            }
            finally { sqlite3_finalize(stmt); }
            return result;
        }
        void Execute(string sql, params object[] values) { ExecuteOn(db, sql, values); }
        List<T> Query<T>(string sql, Func<IntPtr, T> read, params object[] values) { return QueryOn(db, sql, read, values); }
        static string Text(IntPtr stmt, int i) { return Marshal.PtrToStringUni(sqlite3_column_text16(stmt, i)) ?? ""; }
        static long Int(IntPtr stmt, int i) { return sqlite3_column_int64(stmt, i); }

        int transactionDepth;
        void InTransaction(Action work)
        {
            if (transactionDepth > 0) { work(); return; }
            Execute("BEGIN IMMEDIATE");
            transactionDepth++;
            try { work(); Execute("COMMIT"); }
            catch
            {
                try { Execute("ROLLBACK"); } catch (IOException) { }
                throw;
            }
            finally { transactionDepth--; }
        }

        static bool TableExists(IntPtr handle, string table) { return QueryOn(handle, "SELECT name FROM sqlite_master WHERE type='table' AND name=?", s => Text(s, 0), table).Count > 0; }
        bool HasColumn(string table, string column) { return Query("PRAGMA table_info(" + table + ")", s => Text(s, 1)).Contains(column); }
        static string Stamp(DateTime t) { return t.ToString("yyyyMMdd-HHmmss-fff", CultureInfo.InvariantCulture); }

        // ---- schema and migration -------------------------------------------------------

        int StoredVersion()
        {
            if (!TableExists(db, "events")) return 0;
            if (!HasColumn("events", "options")) return 1;
            if (!TableExists(db, "settings")) return 2;
            var v = Query("SELECT value FROM settings WHERE name='schema_version'", s => Text(s, 0));
            int n; return v.Count > 0 && Int32.TryParse(v[0], out n) ? n : 2;
        }

        void Initialize()
        {
            int version = StoredVersion();
            MigratedFrom = 0;
            if (version > SchemaVersion) throw new StoreException(0, "Esta agenda se creó con una versión más reciente de Agenda Clara. Usa esa versión para abrirla.");
            if (version > 0 && version < SchemaVersion)
            {
                // Never migrate without a copy of the previous data.
                string copy = Path.Combine(BackupDirectory, "Antes-de-actualizar-a-v5-" + Stamp(Clock()) + ".sqlite3");
                try { BackupTo(copy); }
                catch (Exception ex) { throw new StoreException(0, "No se pudo crear la copia previa a la actualización de la agenda, así que no se ha modificado. " + ex.Message); }
                MigrationBackup = copy; MigratedFrom = version;
            }
            InTransaction(() =>
            {
                Execute("CREATE TABLE IF NOT EXISTS events (id INTEGER PRIMARY KEY, title TEXT NOT NULL, notes TEXT NOT NULL, start_date TEXT NOT NULL, end_date TEXT NOT NULL CHECK(end_date>=start_date), start_min INTEGER NOT NULL, end_min INTEGER NOT NULL, all_day INTEGER NOT NULL, options TEXT NOT NULL DEFAULT '',version INTEGER NOT NULL DEFAULT 1)");
                Execute("CREATE INDEX IF NOT EXISTS events_dates ON events(start_date,end_date)");
                if (!HasColumn("events", "options")) Execute("ALTER TABLE events ADD COLUMN options TEXT NOT NULL DEFAULT ''");
                if (!HasColumn("events", "version")) Execute("ALTER TABLE events ADD COLUMN version INTEGER NOT NULL DEFAULT 1");
                Execute("CREATE TABLE IF NOT EXISTS settings (name TEXT PRIMARY KEY, value TEXT NOT NULL)");
                Execute("CREATE TABLE IF NOT EXISTS shared_operations (id TEXT PRIMARY KEY, actor TEXT NOT NULL, request_hash TEXT NOT NULL, result_id INTEGER NOT NULL)");
                Execute("CREATE TABLE IF NOT EXISTS audit (revision INTEGER NOT NULL, utc TEXT NOT NULL, actor TEXT NOT NULL, device TEXT NOT NULL, operation TEXT NOT NULL, entity TEXT NOT NULL)");
                if (ReadSetting("generation").Length == 0) WriteSetting("generation", Guid.NewGuid().ToString("N"));
                if (ReadSetting("revision").Length == 0) WriteSetting("revision", "0");
                if (ReadSetting("config_version").Length == 0) WriteSetting("config_version", "0");
                bool newCategories = !TableExists(db, "categories");
                Execute("CREATE TABLE IF NOT EXISTS categories (name TEXT PRIMARY KEY, color TEXT NOT NULL DEFAULT '', position INTEGER NOT NULL DEFAULT 0)");
                if (!HasColumn("categories", "color")) Execute("ALTER TABLE categories ADD COLUMN color TEXT NOT NULL DEFAULT ''");
                if (!HasColumn("categories", "position")) Execute("ALTER TABLE categories ADD COLUMN position INTEGER NOT NULL DEFAULT 0");
                // Defaults are only added once, so a category deleted by the user does not come back.
                if (newCategories || version < 3)
                    for (int i = 0; i < CategoryPalette.DefaultNames.Length; i++)
                        Execute("INSERT OR IGNORE INTO categories(name,color,position) VALUES(?,?,?)", CategoryPalette.DefaultNames[i], CategoryPalette.Colors[i], i);
                foreach (var c in Query("SELECT name FROM categories WHERE color='' ORDER BY rowid", s => Text(s, 0)))
                    Execute("UPDATE categories SET color=? WHERE name=?", CategoryPalette.DefaultColor(c) ?? CategoryPalette.Next(Query("SELECT color FROM categories", s => Text(s, 0))), c);
                foreach (var name in LoadEvents("").Select(e => e.Options.Category).Distinct()) EnsureCategory(name);
                string xml = ReadSetting("calendar");
                SchoolCalendar calendar = SchoolCalendar.Huelva();
                if (xml.Length > 0)
                {
                    try { calendar = XmlData.Read<SchoolCalendar>(xml); }
                    catch (InvalidOperationException) { throw new StoreException(0, "El calendario escolar guardado está dañado. Restaura una copia de seguridad."); }
                }
                calendar.Upgrade();
                WriteSetting("calendar", XmlData.Write(calendar));
                WriteSetting("schema_version", SchemaVersion.ToString(CultureInfo.InvariantCulture));
                Calendar = calendar;
            });
        }

        string ReadSetting(string name)
        {
            var v = Query("SELECT value FROM settings WHERE name=?", s => Text(s, 0), name);
            return v.Count > 0 ? v[0] : "";
        }
        void WriteSetting(string name, string value) { Execute("INSERT OR REPLACE INTO settings(name,value) VALUES(?,?)", name, value); }

        // ---- activities -----------------------------------------------------------------

        AgendaEvent ReadEvent(IntPtr s)
        {
            var e = new AgendaEvent
            {
                Id = Int(s, 0), Title = Text(s, 1), Notes = Text(s, 2),
                Start = DateTime.ParseExact(Text(s, 3), "yyyy-MM-dd", CultureInfo.InvariantCulture),
                End = DateTime.ParseExact(Text(s, 4), "yyyy-MM-dd", CultureInfo.InvariantCulture),
                StartMinute = (int)Int(s, 5), EndMinute = (int)Int(s, 6), AllDay = Int(s, 7) != 0
            };
            string xml = Text(s, 8);
            if (xml.Length > 0)
            {
                try { e.Options = XmlData.Read<EventOptions>(xml); }
                catch (InvalidOperationException ex) { throw new IOException("Las opciones de la actividad " + e.Id + " no se pueden leer. No se ha descartado su contenido.", ex); }
            }
            else e.Options.Weekdays = 31; // versions before 2: Monday to Friday
            e.Version = Int(s, 9); e.Generation = ReadSetting("generation"); e.ConfigVersion = SettingNumber("config_version");
            if (String.IsNullOrWhiteSpace(e.Options.Category)) e.Options.Category = "Otros";
            return e;
        }
        List<AgendaEvent> LoadEvents(string where, params object[] values)
        {
            return Query("SELECT id,title,notes,start_date,end_date,start_min,end_min,all_day,options,version FROM events " + where + " ORDER BY start_date,id", ReadEvent, values);
        }
        public List<AgendaEvent> AllEvents() { return remote == null ? LoadEvents("") : remote.Snapshot.Events; }
        public AgendaEvent Find(long id) { return remote == null ? LoadEvents("WHERE id=?", id).FirstOrDefault() : remote.Snapshot.Events.FirstOrDefault(e => e.Id == id); }
        public int EventCount() { if (remote != null) return remote.Snapshot.Events.Count; return (int)Query("SELECT count(*) FROM events", s => Int(s, 0))[0]; }

        // Checks that depend on the school calendar, shared by Save and the editor preview.
        public void ValidateDates(AgendaEvent e)
        {
            var dates = Planning.All(e, Calendar);
            if (dates.Count == 0)
                throw new ArgumentException("La actividad no tendría ninguna fecha: todas las fechas elegidas son no lectivas (fines de semana, festivos o vacaciones) o están excluidas. Revisa las fechas o marca la excepción para días no lectivos.");
            var clash = dates.GroupBy(o => o.Date).FirstOrDefault(g => g.Count() > 1);
            if (clash != null) throw new ArgumentException("Dos fechas de la actividad coincidirían el " + Format.Date(clash.Key) + ". Elige otro día para el traslado.");
        }

        public void Save(AgendaEvent e)
        {
            if (remote != null) { var c = Command("save"); c.Event = e; c.Generation = e.Id == 0 ? remote.Snapshot.Generation : e.Generation; c.ConfigVersion = e.ConfigVersion; var reply = remote.Execute(c); e.Id = reply.ResultId; var saved = reply.Snapshot.Events.FirstOrDefault(x => x.Id == e.Id); if (saved != null) { e.Version = saved.Version; e.Generation = saved.Generation; e.ConfigVersion = saved.ConfigVersion; } return; }
            e.Title = (e.Title ?? "").Trim();
            e.Notes = e.Notes ?? "";
            e.Options.Category = String.IsNullOrWhiteSpace(e.Options.Category) ? "Otros" : e.Options.Category.Trim();
            var existing = Categories().FirstOrDefault(c => String.Equals(c.Name, e.Options.Category, StringComparison.CurrentCultureIgnoreCase));
            if (existing != null) e.Options.Category = existing.Name;
            if (e.Options.Category.Length > 60) throw new ArgumentException("El nombre de la categoría es demasiado largo (máximo 60 caracteres).");
            e.Validate();
            ValidateDates(e);
            long originalId = e.Id;
            string options = XmlData.Write(e.Options);
            object[] values = { e.Title, e.Notes, Day(e.Start), Day(e.End), e.StartMinute, e.EndMinute, e.AllDay ? 1 : 0, options };
            try
            {
                InTransaction(() =>
                {
                    if (e.Id == 0)
                    {
                        Execute("INSERT INTO events(title,notes,start_date,end_date,start_min,end_min,all_day,options) VALUES(?,?,?,?,?,?,?,?)", values);
                        e.Id = sqlite3_last_insert_rowid(db);
                    }
                    else
                    {
                        var current = Find(e.Id);
                        if (current == null || current.Version != e.Version || current.Generation != e.Generation) throw new ConflictException("Otra persona ha cambiado o eliminado esta actividad. Tus cambios siguen en el formulario. Consulta la versión actual antes de volver a editar.");
                        Execute("UPDATE events SET title=?,notes=?,start_date=?,end_date=?,start_min=?,end_min=?,all_day=?,options=?,version=version+1 WHERE id=? AND version=?", values.Concat(new object[] { e.Id, e.Version }).ToArray());
                    }
                    EnsureCategory(e.Options.Category);
                    var fresh = Find(e.Id); e.Version = fresh.Version; e.Generation = fresh.Generation; e.ConfigVersion = fresh.ConfigVersion;
                });
            }
            catch { e.Id = originalId; throw; }
            // The change is committed; a failed copy is reported apart and never retried as a save.
            UpdateAutomaticBackup();
        }
        static string Day(DateTime d) { return d.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture); }

        public void Delete(long id)
        {
            if (remote != null) { var c = Command("delete"); c.Event = Find(id); if (c.Event == null) throw new ConflictException("La actividad ya no está disponible."); remote.Execute(c); return; }
            Execute("DELETE FROM events WHERE id=?", id);
            UpdateAutomaticBackup();
        }

        // ---- categories ------------------------------------------------------------------

        public List<Category> Categories()
        {
            if (remote != null) return remote.Snapshot.Categories;
            var list = Query("SELECT name,color,position FROM categories ORDER BY position,name", s => new Category { Name = Text(s, 0), Color = Text(s, 1), Position = (int)Int(s, 2) });
            var counts = AllEvents().GroupBy(e => e.Options.Category).ToDictionary(g => g.Key, g => g.Count());
            foreach (var c in list) { int n; c.Count = counts.TryGetValue(c.Name, out n) ? n : 0; }
            return list;
        }

        void EnsureCategory(string name)
        {
            if (Query("SELECT name FROM categories WHERE name=?", s => Text(s, 0), name).Count > 0) return;
            string color = CategoryPalette.DefaultColor(name) ?? CategoryPalette.Next(Query("SELECT color FROM categories", s => Text(s, 0)));
            long position = Query("SELECT coalesce(max(position),-1)+1 FROM categories", s => Int(s, 0))[0];
            Execute("INSERT INTO categories(name,color,position) VALUES(?,?,?)", name, color, position);
        }

        static string CleanCategoryName(string name)
        {
            name = (name ?? "").Trim();
            if (name.Length == 0) throw new ArgumentException("Escribe un nombre para la categoría.");
            if (name.Length > 60) throw new ArgumentException("El nombre de la categoría es demasiado largo (máximo 60 caracteres).");
            return name;
        }
        Category FindCategory(string name) { return Categories().FirstOrDefault(c => String.Equals(c.Name, name, StringComparison.CurrentCultureIgnoreCase)); }

        public void AddCategory(string name, string color)
        {
            if (remote != null) { var c = Command("category-add"); c.A = name; c.B = color; var reply = remote.Execute(c); return; }
            name = CleanCategoryName(name);
            var same = FindCategory(name);
            if (same != null) throw new ArgumentException("Ya existe la categoría «" + same.Name + "».");
            InTransaction(() =>
            {
                EnsureCategory(name);
                if (!String.IsNullOrEmpty(color)) Execute("UPDATE categories SET color=? WHERE name=?", color, name);
            });
            UpdateAutomaticBackup();
        }

        public void RenameCategory(string oldName, string newName)
        {
            if (remote != null) { var c = Command("category-rename"); c.A = oldName; c.B = newName; var reply = remote.Execute(c); return; }
            newName = CleanCategoryName(newName);
            var current = Categories().FirstOrDefault(c => c.Name == oldName);
            if (current == null) throw new ArgumentException("La categoría «" + oldName + "» ya no existe.");
            if (newName == oldName) return;
            var other = FindCategory(newName);
            if (other != null && other.Name != oldName) throw new ArgumentException("Ya existe la categoría «" + other.Name + "». Para unirlas, elimina «" + oldName + "» y mueve sus actividades a «" + other.Name + "».");
            InTransaction(() =>
            {
                Execute("UPDATE categories SET name=? WHERE name=?", newName, oldName);
                MoveActivities(oldName, newName);
            });
            UpdateAutomaticBackup();
        }

        public void SetCategoryColor(string name, string color)
        {
            if (remote != null) { var c = Command("category-color"); c.A = name; c.B = color; var reply = remote.Execute(c); return; }
            Execute("UPDATE categories SET color=? WHERE name=?", color, name);
            UpdateAutomaticBackup();
        }

        public void MoveCategory(string name, int direction)
        {
            if (remote != null) { var c = Command("category-move"); c.A = name; c.Number = direction; var reply = remote.Execute(c); return; }
            var list = Categories();
            int i = list.FindIndex(c => c.Name == name), j = i + direction;
            if (i < 0 || j < 0 || j >= list.Count) return;
            var a = list[i]; list[i] = list[j]; list[j] = a;
            InTransaction(() => { for (int k = 0; k < list.Count; k++) Execute("UPDATE categories SET position=? WHERE name=?", k, list[k].Name); });
            UpdateAutomaticBackup();
        }

        // Activities are never lost: they move to the chosen category before the old one is removed.
        public int DeleteCategory(string name, string target)
        {
            if (remote != null) { var c = Command("category-delete"); c.A = name; c.B = target; var reply = remote.Execute(c); return (int)reply.ResultId; }
            var list = Categories();
            if (!list.Any(c => c.Name == name)) throw new ArgumentException("La categoría «" + name + "» ya no existe.");
            if (list.Count < 2) throw new ArgumentException("Debe quedar al menos una categoría.");
            if (target == name || !list.Any(c => c.Name == target)) throw new ArgumentException("Elige otra categoría existente para las actividades de «" + name + "».");
            int moved = 0;
            InTransaction(() =>
            {
                moved = MoveActivities(name, target);
                Execute("DELETE FROM categories WHERE name=?", name);
            });
            UpdateAutomaticBackup();
            return moved;
        }

        int MoveActivities(string from, string to)
        {
            int n = 0;
            foreach (var e in AllEvents().Where(x => x.Options.Category == from))
            {
                e.Options.Category = to;
                Execute("UPDATE events SET options=?,version=version+1 WHERE id=?", XmlData.Write(e.Options), e.Id);
                n++;
            }
            return n;
        }

        // ---- school calendar ----------------------------------------------------------------

        public void SaveCalendar(SchoolCalendar calendar)
        {
            if (remote != null) { var c = Command("calendar-save"); c.Calendar = calendar; c.ConfigVersion = calendar.ConfigVersion; var reply = remote.Execute(c); return; }
            calendar.Validate();
            Execute("INSERT OR REPLACE INTO settings(name,value) VALUES('calendar',?)", XmlData.Write(calendar));
            Calendar = calendar;
            UpdateAutomaticBackup();
        }

        public List<AgendaEvent> WithoutVisibleDates()
        {
            return AllEvents().Where(e => Planning.All(e, Calendar).Count == 0).ToList();
        }

        // ---- backups ---------------------------------------------------------------------

        internal string DailyBackupPath(DateTime date) { return Path.Combine(BackupDirectory, "AgendaClara-" + date.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture) + ".sqlite3"); }

        public void EnsureDailyBackup()
        {
            if (remote != null) return;
            DateTime now = Clock();
            if (!LastBackup.HasValue || LastBackup.Value.Date != now.Date || !String.IsNullOrEmpty(BackupError) || !File.Exists(DailyBackupPath(now))) UpdateAutomaticBackup();
        }

        void UpdateAutomaticBackup()
        {
            if (!automaticBackups || transactionDepth > 0) return;
            DateTime now = Clock();
            try
            {
                string path = DailyBackupPath(now);
                BackupTo(path);
                LastBackup = now; LastBackupFile = path; BackupError = null;
            }
            catch (Exception ex) { BackupError = ex.Message; }
        }

        void FindLatestBackup()
        {
            try
            {
                var latest = ListBackups().FirstOrDefault();
                if (latest != null) { LastBackup = latest.Modified; LastBackupFile = latest.Path; }
            }
            catch (IOException) { }
            catch (UnauthorizedAccessException) { }
        }

        public List<BackupInfo> ListBackups()
        {
            if (remote != null) throw new IOException("Gestiona las copias centrales desde Trabajo compartido.");
            if (!Directory.Exists(BackupDirectory)) return new List<BackupInfo>();
            return new DirectoryInfo(BackupDirectory).GetFiles("*.sqlite3")
                .Select(f => new BackupInfo { Path = f.FullName, Modified = f.LastWriteTime, Size = f.Length })
                .OrderByDescending(b => b.Modified).ToList();
        }

        // Consistent snapshot through the SQLite backup API; includes committed WAL data.
        public void BackupTo(string path)
        {
            if (remote != null) throw new IOException("Las copias centrales se gestionan desde Trabajo compartido.");
            path = Path.GetFullPath(path);
            if (String.Equals(path, DatabasePath, StringComparison.OrdinalIgnoreCase)) throw new IOException("La copia debe guardarse en un archivo diferente de la agenda en uso.");
            try { Directory.CreateDirectory(Path.GetDirectoryName(path)); }
            catch (Exception ex) { throw new IOException("No se puede crear la carpeta de la copia: " + ex.Message); }
            string temporary = path + "." + Guid.NewGuid().ToString("N") + ".tmp";
            IntPtr destination = IntPtr.Zero, backup = IntPtr.Zero;
            try
            {
                if (sqlite3_open16(temporary, out destination) != SQLITE_OK) throw new IOException("No se puede crear el archivo de copia en «" + Path.GetDirectoryName(path) + "». Comprueba que la carpeta o el dispositivo permiten escribir.");
                backup = sqlite3_backup_init(destination, "main", db, "main");
                if (backup == IntPtr.Zero) throw Error(destination, sqlite3_errcode(destination), "No se pudo iniciar la copia.");
                int code = 0;
                for (int attempt = 0; attempt < 50; attempt++)
                {
                    code = sqlite3_backup_step(backup, -1);
                    if (code != 5 && code != 6) break;
                    System.Threading.Thread.Sleep(100);
                }
                int finished = sqlite3_backup_finish(backup); backup = IntPtr.Zero;
                if (code != SQLITE_DONE) throw new StoreException(code, "No se pudo completar la copia. " + Friendly(code));
                if (finished != SQLITE_OK) throw new StoreException(finished, "No se pudo completar la copia. " + Friendly(finished));
                // A single self-contained file, readable even from read-only media.
                ExecuteOn(destination, "PRAGMA journal_mode=DELETE");
                int closed = sqlite3_close(destination); destination = IntPtr.Zero;
                if (closed != SQLITE_OK) throw new IOException("No se pudo cerrar el archivo de copia.");
                using (var file = new FileStream(temporary, FileMode.Open, FileAccess.ReadWrite, FileShare.None)) file.Flush(true);
                if (File.Exists(path)) File.Replace(temporary, path, null);
                else File.Move(temporary, path);
            }
            catch (UnauthorizedAccessException ex) { throw new IOException("No hay permiso para guardar la copia en esa ubicación. " + ex.Message); }
            finally
            {
                if (backup != IntPtr.Zero) sqlite3_backup_finish(backup);
                if (destination != IntPtr.Zero) sqlite3_close(destination);
                try { if (File.Exists(temporary)) File.Delete(temporary); } catch (IOException) { } catch (UnauthorizedAccessException) { }
            }
        }

        static IntPtr OpenReadOnly(string path)
        {
            if (!File.Exists(path)) throw new IOException("No se encuentra el archivo «" + path + "».");
            IntPtr handle;
            int code = sqlite3_open_v2(Encoding.UTF8.GetBytes(path + "\0"), out handle, SQLITE_OPEN_READONLY, IntPtr.Zero);
            if (code != SQLITE_OK) { var ex = Error(handle, code, "No se pudo abrir la copia."); sqlite3_close(handle); throw ex; }
            sqlite3_busy_timeout(handle, 3000);
            return handle;
        }

        // Reads a copy without modifying it and checks that it is an Agenda Clara database.
        public static BackupInfo Inspect(string path)
        {
            path = Path.GetFullPath(path);
            var info = new BackupInfo { Path = path };
            var file = new FileInfo(path);
            if (file.Exists) { info.Modified = file.LastWriteTime; info.Size = file.Length; }
            IntPtr handle = IntPtr.Zero;
            try
            {
                handle = OpenReadOnly(path);
                var check = QueryOn(handle, "PRAGMA quick_check", s => Text(s, 0));
                if (check.Count == 0 || check[0] != "ok") throw new IOException("La copia está dañada (comprobación de integridad fallida).");
                if (!TableExists(handle, "events")) throw new IOException("El archivo no contiene una agenda de Agenda Clara.");
                info.Events = (int)QueryOn(handle, "SELECT count(*) FROM events", s => Int(s, 0))[0];
                if (TableExists(handle, "categories")) info.Categories = (int)QueryOn(handle, "SELECT count(*) FROM categories", s => Int(s, 0))[0];
                info.HasCalendar = TableExists(handle, "settings") && QueryOn(handle, "SELECT name FROM settings WHERE name='calendar'", s => Text(s, 0)).Count > 0;
            }
            catch (StoreException ex) { info.Error = (ex.Code & 0xFF) == 26 ? "El archivo no es una agenda válida o está dañado." : ex.Message; }
            catch (IOException ex) { info.Error = ex.Message; }
            finally { if (handle != IntPtr.Zero) sqlite3_close(handle); }
            return info;
        }

        // Saves the current agenda first, then replaces its content with the copy. Returns the safety copy.
        public string RestoreFrom(string path)
        {
            if (remote != null) throw new IOException("La restauración central requiere administración del servidor.");
            path = Path.GetFullPath(path);
            if (String.Equals(path, DatabasePath, StringComparison.OrdinalIgnoreCase)) throw new IOException("Elige una copia, no el archivo de la agenda en uso.");
            var info = Inspect(path);
            if (info.Error.Length > 0) throw new IOException(info.Error);
            string safety = Path.Combine(BackupDirectory, "Antes-de-restaurar-" + Stamp(Clock()) + ".sqlite3");
            BackupTo(safety);
            IntPtr source = OpenReadOnly(path), backup = IntPtr.Zero;
            try
            {
                backup = sqlite3_backup_init(db, "main", source, "main");
                if (backup == IntPtr.Zero) throw Error(db, sqlite3_errcode(db), "No se pudo iniciar la restauración.");
                int code = 0;
                for (int attempt = 0; attempt < 50; attempt++)
                {
                    code = sqlite3_backup_step(backup, -1);
                    if (code != 5 && code != 6) break;
                    System.Threading.Thread.Sleep(100);
                }
                int finished = sqlite3_backup_finish(backup); backup = IntPtr.Zero;
                if (code != SQLITE_DONE || finished != SQLITE_OK) throw new StoreException(code, "No se pudo restaurar la copia. La agenda anterior está guardada en «" + safety + "». " + Friendly(code));
            }
            finally
            {
                if (backup != IntPtr.Zero) sqlite3_backup_finish(backup);
                sqlite3_close(source);
            }
            Execute("PRAGMA journal_mode=WAL");
            Initialize();
            UpdateAutomaticBackup();
            return safety;
        }

        public void Dispose() { if (db != IntPtr.Zero) { sqlite3_close(db); db = IntPtr.Zero; } }
    }
}
