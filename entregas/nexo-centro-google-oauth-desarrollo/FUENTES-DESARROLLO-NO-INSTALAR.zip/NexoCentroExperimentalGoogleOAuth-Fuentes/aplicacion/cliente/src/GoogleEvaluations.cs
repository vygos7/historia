using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;

namespace AgendaClara
{
    public sealed class GoogleEvaluationSettings
    {
        public string PrefillTemplate {get;set;} = "";
        public string Endpoint {get;set;} = "";
        public bool Enabled {get;set;}
        public int PollMinutes {get;set;} = 15;
        public bool HasSecret {get;set;}
        public string Secret {get;set;} = "";
    }
    public sealed class GoogleLinkRequest { public long EventId {get;set;} public string Date {get;set;} = ""; }
    public sealed class GoogleEvaluationLink
    {
        public string Code {get;set;} = ""; public string Url {get;set;} = ""; public string Title {get;set;} = ""; public string Date {get;set;} = ""; public string Group {get;set;} = "";
        public long EventId {get;set;}
    }
    public sealed class GoogleEvaluationResponse
    {
        public string ResponseId {get;set;} = ""; public string Code {get;set;} = ""; public string Title {get;set;} = ""; public string Date {get;set;} = ""; public string Group {get;set;} = ""; public string SubmittedUtc {get;set;} = "";
        public ActivityMemory Memory {get;set;} = new ActivityMemory();
    }
    public sealed class GoogleEvaluationBinding
    {
        public string ActivityKey {get;set;} = "";
        public string Code {get;set;} = ""; public string Generation {get;set;} = ""; public string Title {get;set;} = ""; public string Date {get;set;} = ""; public string Group {get;set;} = "";
        public long EventId {get;set;}
        public DateTime IssuedUtc {get;set;}
    }
    public sealed class GoogleEvaluationItem
    {
        public string Id {get;set;} = ""; public string Hash {get;set;} = ""; public string Status {get;set;} = "Pendiente"; public string Reason {get;set;} = "";
        public GoogleEvaluationResponse Response {get;set;} = new GoogleEvaluationResponse();
        public long EventId {get;set;}
        public DateTime ReceivedUtc {get;set;} public DateTime AppliedUtc {get;set;}
    }
    public sealed class GoogleEvaluationState
    {
        public int Format {get;set;} = 1;
        public List<GoogleEvaluationBinding> Bindings {get;set;} = new List<GoogleEvaluationBinding>();
        public List<GoogleEvaluationItem> Inbox {get;set;} = new List<GoogleEvaluationItem>();
    }
    public sealed class GoogleEvaluationStatus
    {
        public GoogleEvaluationSettings Settings {get;set;} = new GoogleEvaluationSettings();
        public List<GoogleEvaluationItem> Items {get;set;} = new List<GoogleEvaluationItem>();
        public string LastResult {get;set;} = "Sin consultas a Google.";
        public DateTime LastPollUtc {get;set;}
    }
    public sealed class GoogleEvaluationApply
    {
        public string ItemId {get;set;} = "";
        public long EventId {get;set;} public long ExpectedVersion {get;set;}
        public bool ConfirmOverwrite {get;set;} public bool ConfirmAssignment {get;set;}
    }
    public sealed class GoogleEvaluationCsv { public string Text {get;set;} = ""; }
    public static class GoogleEvaluationRules
    {
        public static string Hash(string text) { using(var sha=SHA256.Create())return BitConverter.ToString(sha.ComputeHash(Encoding.UTF8.GetBytes(text??""))).Replace("-","").ToLowerInvariant(); }
        public static string Normalize(string text)
        {
            var s=new StringBuilder();foreach(char c in (text??"").Normalize(NormalizationForm.FormD))if(CharUnicodeInfo.GetUnicodeCategory(c)!=UnicodeCategory.NonSpacingMark)s.Append(c);
            return Regex.Replace(s.ToString().Normalize(NormalizationForm.FormC).Trim(),@"\s+"," ").ToUpperInvariant();
        }
        public static DateTime Today(DateTime utc)
        {
            TimeZoneInfo zone;try{zone=TimeZoneInfo.FindSystemTimeZoneById("Europe/Madrid");}catch(TimeZoneNotFoundException){zone=TimeZoneInfo.FindSystemTimeZoneById("Romance Standard Time");}
            return TimeZoneInfo.ConvertTimeFromUtc(utc.ToUniversalTime(),zone).Date;
        }
        public static DateTime Date(string text)
        {
            DateTime d;if(!DateTime.TryParseExact(text,new[]{"yyyy-MM-dd","dd/MM/yyyy","d/M/yyyy"},CultureInfo.InvariantCulture,DateTimeStyles.None,out d))throw new ArgumentException("Fecha de salida no válida. Usa día/mes/año o año-mes-día.");return d.Date;
        }
        public static string MemoryHash(ActivityMemory m) { return Hash(XmlData.Write(m??new ActivityMemory())); }
        public static string Fingerprint(GoogleEvaluationResponse r) { return Hash(XmlData.Write(r)); }
        public static string OperationId(GoogleEvaluationItem row) { return Hash("google-memory-v1|"+row.Id+"|"+row.Hash).Substring(0,32); }
        public static void ValidateResponse(GoogleEvaluationResponse r)
        {
            if(r==null || r.Memory==null)throw new ArgumentException("Respuesta vacía.");
            foreach(string s in new[]{r.ResponseId,r.Code,r.Title,r.Date,r.Group,r.SubmittedUtc,r.Memory.Rating,r.Memory.Positives,r.Memory.Difficulties,r.Memory.Improvements,r.Memory.Continuity,r.Memory.Justification})if(s==null||s.Length>20000)throw new ArgumentException("Campo ausente o demasiado largo.");
            if(String.IsNullOrWhiteSpace(r.ResponseId)||r.ResponseId.Length>250)throw new ArgumentException("La respuesta no tiene un identificador válido.");
            Date(r.Date);r.Memory.Validate();if(!r.Memory.HasContent)throw new ArgumentException("La evaluación está vacía.");
        }
        public static void ValidateTemplate(string template)
        {
            Uri u;if(!Uri.TryCreate(template,UriKind.Absolute,out u)||u.Scheme!="https"||!u.Host.Equals("docs.google.com",StringComparison.OrdinalIgnoreCase)||!u.IsDefaultPort||u.UserInfo.Length>0||!u.AbsolutePath.StartsWith("/forms/d/",StringComparison.Ordinal)||!u.AbsolutePath.EndsWith("/viewform",StringComparison.Ordinal)||u.Fragment.Length>0)throw new ArgumentException("Se necesita una plantilla HTTPS de Google Forms.");
            if(template.Length>12000 || !template.Contains("__NEXO_CODE__")||!template.Contains("__NEXO_TITLE__")||!template.Contains("__NEXO_GROUP__")||!(template.Contains("__NEXO_DATE__")||(template.Contains("__NEXO_YEAR__")&&template.Contains("__NEXO_MONTH__")&&template.Contains("__NEXO_DAY__"))))throw new ArgumentException("La plantilla debe contener código, nombre, fecha y grupo. Obténla con el script de configuración.");
        }
        public static string Link(string template,GoogleEvaluationBinding b)
        {
            ValidateTemplate(template);DateTime d=Date(b.Date);
            var values=new Dictionary<string,string>{{"__NEXO_CODE__",b.Code},{"__NEXO_TITLE__",b.Title},{"__NEXO_GROUP__",b.Group},{"__NEXO_DATE__",d.ToString("yyyy-MM-dd",CultureInfo.InvariantCulture)},{"__NEXO_YEAR__",d.Year.ToString(CultureInfo.InvariantCulture)},{"__NEXO_MONTH__",d.Month.ToString(CultureInfo.InvariantCulture)},{"__NEXO_DAY__",d.Day.ToString(CultureInfo.InvariantCulture)}};
            string url=Regex.Replace(template,@"__NEXO_(CODE|TITLE|GROUP|DATE|YEAR|MONTH|DAY)__",m=>Uri.EscapeDataString(values[m.Value]));
            if(url.Length>16000)throw new ArgumentException("Los datos de la actividad producen un enlace demasiado largo.");return url;
        }
    }
    // Se usa la misma puerta de exclusión que la agenda. Nunca se mantiene durante una consulta HTTP.
    public sealed class GoogleEvaluationManager
    {
        readonly Func<Store> provideStore;Store store {get{return provideStore();}} readonly object gate;readonly string path;readonly Action<string,byte[]> atomic;readonly Func<DateTime> now;readonly Func<AgendaCommand,AgendaReply> apply;
        GoogleEvaluationState state;
        public const string Actor="integracion-google";
        public GoogleEvaluationManager(Func<Store> store,object gate,string path,Action<string,byte[]> atomic,Func<DateTime> now,Func<AgendaCommand,AgendaReply> apply)
        {
            this.provideStore=store;this.gate=gate;this.path=path;this.atomic=atomic;this.now=now;this.apply=apply;
            state=File.Exists(path)?XmlData.Read<GoogleEvaluationState>(File.ReadAllText(path)):new GoogleEvaluationState();
            if(state.Format!=1||state.Bindings==null||state.Inbox==null||state.Bindings.Count>10000||state.Inbox.Count>10000||state.Inbox.Select(x=>x.Id).Distinct().Count()!=state.Inbox.Count)throw new IOException("Registro de evaluaciones no válido. No se ha sustituido ni borrado.");
        }
        void Persist(){Directory.CreateDirectory(Path.GetDirectoryName(path));atomic(path,Encoding.UTF8.GetBytes(XmlData.Write(state)));}
        public List<GoogleEvaluationItem> Items(){lock(gate)return XmlData.Read<GoogleEvaluationState>(XmlData.Write(state)).Inbox.OrderByDescending(x=>x.ReceivedUtc).Take(500).ToList();}
        public DateTime SinceUtc {get{lock(gate)return state.Bindings.Count==0?now().ToUniversalTime():state.Bindings.Min(b=>b.IssuedUtc).AddMinutes(-5);}}
        public GoogleEvaluationLink Issue(GoogleLinkRequest request,string template)
        {
            lock(gate)
            {
                GoogleEvaluationRules.ValidateTemplate(template);
                var e=store.Find(request.EventId);if(e==null)throw new ArgumentException("Guarda primero la actividad.");
                if(String.IsNullOrWhiteSpace(e.Options.Group))throw new ArgumentException("Completa y guarda el curso o grupo antes de generar el enlace.");
                var dates=Planning.All(e,store.Calendar);if(dates.Count==0)throw new ArgumentException("La actividad no tiene fechas visibles.");
                var date=String.IsNullOrWhiteSpace(request.Date)?dates[0].Date:GoogleEvaluationRules.Date(request.Date);
                if(!dates.Any(o=>o.Date==date))throw new ArgumentException("La fecha elegida no pertenece a la actividad.");
                if(String.IsNullOrEmpty(e.Options.GoogleEvaluationId))
                {
                    var identified=e.Copy();identified.Options.GoogleEvaluationId="NEI-"+Guid.NewGuid().ToString("N");
                    apply(new AgendaCommand{Operation="save",Generation=e.Generation,ConfigVersion=e.ConfigVersion,Event=identified});
                    e=store.Find(e.Id);
                }
                var b=state.Bindings.LastOrDefault(x=>x.ActivityKey==e.Options.GoogleEvaluationId&&x.EventId==e.Id&&x.Generation==e.Generation&&x.Title==e.Title&&x.Group==e.Options.Group&&x.Date==date.ToString("yyyy-MM-dd"));
                if(b==null)
                {
                    if(state.Bindings.Count>=10000)throw new IOException("Registro de enlaces lleno; revisar con administración.");
                    var bytes=new byte[18];using(var rng=RandomNumberGenerator.Create())rng.GetBytes(bytes);
                    b=new GoogleEvaluationBinding{ActivityKey=e.Options.GoogleEvaluationId,Code="NCX-"+Convert.ToBase64String(bytes).TrimEnd('=').Replace('+','-').Replace('/','_'),Generation=e.Generation,EventId=e.Id,Title=e.Title,Group=e.Options.Group,Date=date.ToString("yyyy-MM-dd"),IssuedUtc=now().ToUniversalTime()};
                    string checkedUrl=GoogleEvaluationRules.Link(template,b);state.Bindings.Add(b);Persist();
                }
                return new GoogleEvaluationLink{Code=b.Code,Url=GoogleEvaluationRules.Link(template,b),Title=b.Title,Group=b.Group,Date=b.Date,EventId=e.Id};
            }
        }
        string Reason(GoogleEvaluationItem item,out AgendaEvent e)
        {
            e=null;try{GoogleEvaluationRules.ValidateResponse(item.Response);}catch(ArgumentException ex){return ex.Message;}
            var r=item.Response;var binding=state.Bindings.FirstOrDefault(b=>b.Code==r.Code);
            if(binding==null)return "Código desconocido: requiere asignación manual.";
            e=store.Find(binding.EventId);item.EventId=binding.EventId;
            if(e==null)return "La actividad fue eliminada.";
            if(e.Options.GoogleEvaluationId!=binding.ActivityKey || String.IsNullOrEmpty(binding.ActivityKey))return "La identidad de la actividad no corresponde al enlace.";
            if(e.Generation!=binding.Generation)return "La agenda fue restaurada o cambió de generación; revisar el enlace.";
            DateTime date=GoogleEvaluationRules.Date(r.Date);
            if(date>GoogleEvaluationRules.Today(now()))return "La fecha de la actividad todavía no ha llegado.";
            if(r.Date.Length==0||date!=GoogleEvaluationRules.Date(binding.Date)||!Planning.All(e,store.Calendar).Any(o=>o.Date==date))return "La fecha no corresponde al enlace y a la actividad guardada.";
            if(GoogleEvaluationRules.Normalize(r.Title)!=GoogleEvaluationRules.Normalize(binding.Title)||GoogleEvaluationRules.Normalize(e.Title)!=GoogleEvaluationRules.Normalize(binding.Title))return "El nombre de la actividad no coincide o fue modificado.";
            if(GoogleEvaluationRules.Normalize(r.Group)!=GoogleEvaluationRules.Normalize(binding.Group)||GoogleEvaluationRules.Normalize(e.Options.Group)!=GoogleEvaluationRules.Normalize(binding.Group))return "El grupo no coincide o fue modificado.";
            long matchedEventId=e.Id;
            if(state.Inbox.Any(x=>x.Id!=item.Id&&x.Status=="Aplicada"&&(x.Response.Code==r.Code||x.EventId==matchedEventId)))return "Ya existe otra respuesta aplicada a esta actividad.";
            if(state.Inbox.Any(x=>x.Id!=item.Id&&x.Response.ResponseId==r.ResponseId))return "La respuesta fue editada; requiere revisión.";
            if(e.Options.Memory.HasContent)return "La actividad ya tiene una memoria; no se sustituye automáticamente.";
            return "";
        }
        public bool IsApplied(GoogleEvaluationResponse response)
        {lock(gate){string id=GoogleEvaluationRules.Hash(response.ResponseId+"|"+GoogleEvaluationRules.Fingerprint(response));return state.Inbox.Any(x=>x.Id==id&&x.Status=="Aplicada");}}
        public GoogleEvaluationItem Ingest(GoogleEvaluationResponse response,bool automatic)
        {
            if(response==null)throw new ArgumentException("Respuesta ausente.");
            lock(gate)
            {
                string fingerprint=GoogleEvaluationRules.Fingerprint(response),id=GoogleEvaluationRules.Hash(response.ResponseId+"|"+fingerprint);
                var found=state.Inbox.FirstOrDefault(x=>x.Id==id);if(found!=null)
                {
                    if(found.Status!="Aplicada" && store.OperationState(GoogleEvaluationRules.OperationId(found),Actor).Known)
                    {found.Status="Aplicada";found.Reason="Operación recuperada tras un corte.";found.AppliedUtc=now().ToUniversalTime();Persist();}
                    if(automatic && found.Status!="Aplicada")
                    {AgendaEvent retry;string reason=Reason(found,out retry);if(reason.Length==0)ApplyInternal(found,retry);else if(found.Reason!=reason){found.Reason=reason;Persist();}}
                    return found;
                }
                if(state.Inbox.Count>=10000)throw new IOException("Registro de respuestas lleno; no se descartan respuestas.");
                var item=new GoogleEvaluationItem{Id=id,Hash=fingerprint,Response=XmlData.Read<GoogleEvaluationResponse>(XmlData.Write(response)),ReceivedUtc=now().ToUniversalTime()};
                state.Inbox.Add(item);Persist();
                AgendaEvent e;item.Reason=Reason(item,out e);
                if(item.Reason.Length==0 && automatic)
                {
                    // Recuperación tras un corte entre la confirmación SQLite y el guardado del registro.
                    var known=store.OperationState(GoogleEvaluationRules.OperationId(item),Actor);
                    if(known.Known){item.Status="Aplicada";item.Reason="Operación ya confirmada anteriormente.";item.AppliedUtc=now().ToUniversalTime();Persist();}
                    else ApplyInternal(item,e);
                }
                else{if(item.Reason.Length==0)item.Reason="Lista para revisar y aplicar.";Persist();}
                return item;
            }
        }
        void ApplyInternal(GoogleEvaluationItem item,AgendaEvent current)
        {
            var edited=current.Copy();edited.Options.Memory=XmlData.Read<ActivityMemory>(XmlData.Write(item.Response.Memory));edited.Options.Memory.Updated=now();
            var command=new AgendaCommand{RequestId=GoogleEvaluationRules.OperationId(item),Operation="save",Generation=edited.Generation,ConfigVersion=edited.ConfigVersion,Event=edited};
            apply(command);item.EventId=current.Id;item.Status="Aplicada";item.Reason="Memoria incorporada.";item.AppliedUtc=now().ToUniversalTime();Persist();
        }
        public GoogleEvaluationItem Apply(GoogleEvaluationApply request)
        {
            lock(gate)
            {
                var item=state.Inbox.SingleOrDefault(x=>x.Id==request.ItemId);if(item==null)throw new ArgumentException("Respuesta no encontrada.");
                if(item.Status=="Aplicada")return item;
                GoogleEvaluationRules.ValidateResponse(item.Response);
                var current=store.Find(request.EventId==0?item.EventId:request.EventId);if(current==null)throw new ArgumentException("Selecciona la actividad correcta.");
                if(current.Version!=request.ExpectedVersion)throw new ConflictException("La actividad ha cambiado. Actualiza y revisa antes de aplicar.");
                DateTime date=GoogleEvaluationRules.Date(item.Response.Date);
                if(date>GoogleEvaluationRules.Today(now())||!Planning.All(current,store.Calendar).Any(o=>o.Date==date))throw new ArgumentException("La fecha de la respuesta no pertenece a una actividad ya realizada.");
                AgendaEvent expected;string reason=Reason(item,out expected);
                if((reason.Length>0||expected==null||current.Id!=expected.Id)&&!request.ConfirmAssignment)throw new ArgumentException("La correspondencia requiere confirmación manual.");
                if(current.Options.Memory.HasContent&&!request.ConfirmOverwrite)throw new ArgumentException("Ya existe una memoria. Confirma expresamente su sustitución.");
                ApplyInternal(item,current);return item;
            }
        }
    }
    public static class GoogleEvaluationCsvReader
    {
        static string Header(string value){return Regex.Replace(GoogleEvaluationRules.Normalize(value).Trim('\ufeff'),@"^\d+[.\s)\-]*","");}
        static List<List<string>> Rows(string text,char delimiter)
        {
            var rows=new List<List<string>>();var row=new List<string>();var value=new StringBuilder();bool quoted=false,closed=false;
            for(int i=0;i<text.Length;i++)
            {
                char c=text[i];if(closed && c!=delimiter && c!='\n' && c!='\r')throw new ArgumentException("CSV con texto después de una comilla de cierre.");if(c=='"'){if(quoted&&i+1<text.Length&&text[i+1]=='"'){value.Append('"');i++;}else if(!quoted&&value.Length>0)throw new ArgumentException("CSV con comillas no válidas.");else{quoted=!quoted;if(!quoted)closed=true;}}
                else if(!quoted&&(c==delimiter||c=='\n'||c=='\r'))
                {row.Add(value.ToString());value.Clear();closed=false;if(c!=delimiter){if(c=='\r'&&i+1<text.Length&&text[i+1]=='\n')i++;if(row.Any(x=>x.Length>0))rows.Add(row);row=new List<string>();}}
                else value.Append(c);
                if(value.Length>20000||row.Count>64||rows.Count>2000)throw new ArgumentException("CSV demasiado grande.");
            }
            if(quoted)throw new ArgumentException("CSV con comillas sin cerrar.");if(value.Length>0||row.Count>0){row.Add(value.ToString());rows.Add(row);}return rows;
        }
        public static List<GoogleEvaluationResponse> Parse(string text)
        {
            if(text==null||text.Length>4000000)throw new ArgumentException("CSV vacío o demasiado grande.");
            text=text.TrimStart('\ufeff');var choices=new List<List<List<string>>>();foreach(char delimiter in new[]{',',';','\t'})try{var candidate=Rows(text,delimiter);if(candidate.Count>0)choices.Add(candidate);}catch(ArgumentException){} choices=choices.OrderByDescending(r=>r[0].Count).ToList();if(choices.Count==0)throw new ArgumentException("CSV vacío.");var rows=choices[0];var headers=rows[0].Select(Header).ToList();
            int Column(params string[] names){var matches=headers.Select((h,i)=>new{h,i}).Where(x=>names.Select(Header).Contains(x.h)).Select(x=>x.i).ToList();if(matches.Count!=1)throw new ArgumentException("Falta una columna o está duplicada: "+names[0]);return matches[0];}
            int code=Column("Código de la actividad"),title=Column("Nombre de la actividad"),date=Column("Fecha de la salida","Fecha de realización"),group=Column("Curso o grupo","Grupo"),rating=Column("Valoración general"),positive=Column("Aspectos positivos"),difficult=Column("Incidencias y dificultades"),improve=Column("Propuestas de mejora"),continuity=Column("¿Se recomienda repetir esta salida en próximos cursos?","Continuidad"),why=Column("Justificación de la continuidad");
            int stamp=headers.FindIndex(x=>x==Header("Marca temporal")||x==Header("Timestamp"));var result=new List<GoogleEvaluationResponse>();
            foreach(var row in rows.Skip(1))
            {
                if(row.Count!=headers.Count)throw new ArgumentException("Una fila no tiene el número esperado de columnas.");
                var r=new GoogleEvaluationResponse{Code=row[code].Trim(),Title=row[title].Trim(),Date=row[date].Trim(),Group=row[group].Trim(),SubmittedUtc=stamp<0?"":row[stamp],Memory=new ActivityMemory{Rating=row[rating],Positives=row[positive],Difficulties=row[difficult],Improvements=row[improve],Continuity=row[continuity].Trim(),Justification=row[why]}};
                r.ResponseId="csv-"+GoogleEvaluationRules.Hash(XmlData.Write(r));result.Add(r);
            }
            return result;
        }
    }
}
