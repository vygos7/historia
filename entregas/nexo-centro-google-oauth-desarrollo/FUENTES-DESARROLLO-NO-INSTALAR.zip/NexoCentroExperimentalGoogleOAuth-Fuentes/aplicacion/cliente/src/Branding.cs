using System;
namespace AgendaClara
{
    // Traduce sólo mensajes propios conocidos; no transforma títulos de actividades,
    // nombres de categorías, rutas, certificados ni identificadores de protocolo.
    public static class Branding
    {
        public static string Error(string message)
        {
            return (message ?? "")
                .Replace("Cierra otras ventanas de Agenda Clara e inténtalo de nuevo.", "Cierra otras ventanas de Nexo Centro e inténtalo de nuevo.")
                .Replace("Esta agenda se creó con una versión más reciente de Agenda Clara.", "Esta agenda se creó con una versión más reciente de Nexo Centro.")
                .Replace("El archivo no contiene una agenda de Agenda Clara.", "El archivo no contiene una agenda de Nexo Centro.")
                .Replace("detenido el servicio de AgendaClara;", "detenido el servicio de Nexo Centro;");
        }
        public static string Diagnostic(string text)
        {
            return (text ?? "").Replace(" · AgendaClara ", " · Nexo Centro ")
                .Replace(" · validación AgendaClara:", " · validación Nexo Centro:");
        }
    }
}
