using System;
using System.IO;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows;

[assembly: AssemblyTitle("Nexo Centro EXPERIMENTAL")]
[assembly: AssemblyDescription("Agenda local de planificación escolar para el equipo directivo de un centro de Educación Primaria.")]
[assembly: AssemblyProduct("Nexo Centro EXPERIMENTAL")]
[assembly: AssemblyCopyright("Uso interno del centro, 2026")]
[assembly: AssemblyVersion("4.2.0.0")]
[assembly: AssemblyFileVersion("4.2.0.0")]
[assembly: AssemblyInformationalVersion("4.2.0-experimental-google-oauth-r1 (06/11/2026)")]
[assembly: InternalsVisibleTo("AgendaClara.Pruebas")]

namespace AgendaClara
{
    public static class Program
    {
        public const string Version = "4.2.0";
        public const string VersionDate = "06/11/2026";

        public static string DefaultDatabasePath()
        {
            return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "NexoCentroExperimentalGoogleOAuth", "agenda.sqlite3");
        }

        static string MutexName(string path)
        {
            uint hash = 2166136261;
            foreach (char c in path.ToLowerInvariant()) { hash ^= c; hash *= 16777619; }
            return "Local\\NexoCentroExperimentalGoogleOAuth-" + hash.ToString("x8");
        }

        [STAThread]
        public static int Main(string[] args)
        {
            Format.ApplyCulture();
            string path = DefaultDatabasePath();
            bool summaryOnly = false, valid = true;
            for (int i = 0; i < args.Length; i++)
            {
                if (args[i] == Startup.Argument && !summaryOnly) summaryOnly = true;
                else if (args[i] == "--config" && i + 1 < args.Length) SharedRuntime.ConfigurationPath = Path.GetFullPath(args[++i]);
                else if (args[i] == "--agenda" && i + 1 < args.Length) path = Path.GetFullPath(args[++i]);
                else valid = false;
            }
            if (!valid)
            {
                MessageBox.Show("Opción no reconocida. Abre Nexo Centro con doble clic, o con «--agenda ruta-del-archivo» para usar otra agenda.", "Nexo Centro", MessageBoxButton.OK, MessageBoxImage.Information);
                return 2;
            }
            try{ExperimentalIsolation.PathForWrite(path);ExperimentalIsolation.PathForWrite(SharedRuntime.ConfigurationPath);}
            catch(Exception ex){MessageBox.Show(ex.Message,"Nexo Centro EXPERIMENTAL");return 2;}
            bool first;
            using (var mutex = new Mutex(true, MutexName(path), out first))
            {
                if (!first)
                {
                    // At sign-in the agenda being open already means there is nothing to remind.
                    if (summaryOnly) return 0;
                    MessageBox.Show("Nexo Centro ya está abierta. Usa la ventana que ya tienes abierta (puede estar minimizada en la barra de tareas).", "Nexo Centro", MessageBoxButton.OK, MessageBoxImage.Information);
                    return 0;
                }
                // Only for the personal agenda: an agenda opened with --agenda (tests, copies) never changes the sign-in setting.
                if (path == DefaultDatabasePath())
                {
                    // En la versión experimental el inicio automático sólo se activa a petición del usuario.
                }
                var app = new Application { ShutdownMode = ShutdownMode.OnExplicitShutdown };
                Theme.Install(app);
                app.DispatcherUnhandledException += (s, e) =>
                {
                    MessageBox.Show("No se pudo completar la operación. Los cambios confirmados anteriormente siguen guardados.\n\n" + Branding.Error(e.Exception.Message), "Nexo Centro", MessageBoxButton.OK, MessageBoxImage.Error);
                    e.Handled = true;
                };
                Store store;
                try { store = SharedRuntime.OpenStore(path); if (store == null) return 1; }
                catch (Exception ex)
                {
                    if (summaryOnly) ShowAtSignIn(new TodaySummaryWindow(() => { throw ex; }, DateTime.Today, path));
                    else MessageBox.Show("No se pudo abrir la agenda.\n\n" + Branding.Error(ex.Message) + "\n\nArchivo: " + path, "Nexo Centro", MessageBoxButton.OK, MessageBoxImage.Error);
                    return 1;
                }
                using (store)
                {
                    string migrated = "Tu agenda se ha actualizado al formato de la versión " + Version + ". Se conservan todas las actividades.\n\nAntes de actualizarla se guardó una copia de los datos anteriores en:\n" + store.MigrationBackup;
                    if (summaryOnly)
                    {
                        var summary = new TodaySummaryWindow(store, DateTime.Today);
                        if (store.MigratedFrom > 0) summary.Loaded += (s, e) => Dialogs.Info(summary, "Agenda actualizada", migrated);
                        ShowAtSignIn(summary);
                        if (!summary.OpenAgendaRequested) return 0;
                    }
                    var window = new MainWindow(store);
                    if (summaryOnly) window.Loaded += (s, e) => window.OpenToday();
                    else if (store.MigratedFrom > 0) window.Loaded += (s, e) => Dialogs.Info(window, "Agenda actualizada", migrated);
                    app.MainWindow = window;
                    app.ShutdownMode = ShutdownMode.OnMainWindowClose;
                    app.Run(window);
                    if (SharedRuntime.Connection != null) SharedRuntime.Connection.Dispose();
                }
            }
            return 0;
        }

        // The summary on its own, as Windows opens it at sign-in: centred and visible in the taskbar.
        static void ShowAtSignIn(TodaySummaryWindow summary)
        {
            summary.ShowInTaskbar = true;
            summary.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            summary.ShowDialog();
        }
    }
}

