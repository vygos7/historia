using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AgendaClara
{
    // El ejecutor agenda se inyecta: puerta del servidor o Dispatcher del cliente local.
    public sealed class GoogleOfficialCoordinator:IDisposable
    {
        readonly object stateGate=new object();readonly GoogleAppRegistration registration;readonly IGoogleOfficialApi api;readonly IGoogleTokenVault vault;
        readonly string root,statePath;readonly object agendaGate;readonly Func<Store> store;readonly Func<AgendaCommand,AgendaReply> apply;readonly Action<string,byte[]> atomic;
        readonly Func<Func<object>,Task<object>> onAgenda;readonly Action changed;readonly Func<DateTime> now;
        readonly CancellationTokenSource lifetime=new CancellationTokenSource();readonly SemaphoreSlim work=new SemaphoreSlim(1,1);readonly SemaphoreSlim wake=new SemaphoreSlim(0,1);
        GoogleOfficialConnection connection=new GoogleOfficialConnection();GoogleAccountTokens tokens;GoogleEvaluationManager manager;
        string message="Conecta tu cuenta de Google para comenzar.",error="",nextPage="";bool busy;bool disposed;DateTime lastPoll;
        List<GoogleEvaluationItem> items=new List<GoogleEvaluationItem>();Task job=Task.FromResult(0);
        public GoogleOfficialCoordinator(string root,GoogleAppRegistration registration,IGoogleOfficialApi api,IGoogleTokenVault vault,Func<Store> store,object agendaGate,Func<AgendaCommand,AgendaReply> apply,Action<string,byte[]> atomic,Func<Func<object>,Task<object>> onAgenda,Action changed,Func<DateTime> now=null)
        {
            this.root=root;this.registration=registration;this.api=api;this.vault=vault;this.store=store;this.agendaGate=agendaGate;this.apply=apply;this.atomic=atomic;this.onAgenda=onAgenda;this.changed=changed;this.now=now??(()=>DateTime.UtcNow);statePath=Path.Combine(root,"google-oficial.xml");
            try
            {
                if(File.Exists(statePath)){connection=XmlData.Read<GoogleOfficialConnection>(File.ReadAllText(statePath));if(connection.Format!=1||connection.Account==null||connection.Form==null)throw new IOException();}
                if(connection.Form.Id.Length>0){GoogleOfficialApi.ValidateFormId(connection.Form.Id);GoogleEvaluationRules.ValidateTemplate(connection.Form.Template);if(connection.Form.Fields==null||connection.Form.Fields.Count!=10||connection.Form.Fields.Select(f=>f.Key).Distinct().Count()!=10)throw new IOException("Conexión del formulario no válida.");}
                tokens=vault.Load();if(tokens!=null){tokens.Validate();if(tokens.AccountId!=connection.Account.Id)tokens=null;}
                if(tokens!=null&&connection.Account.Id.Length>0)message=connection.Form.Id.Length>0?"Formulario conectado. Las evaluaciones se recogerán automáticamente.":"Cuenta conectada. Pulsa Elegir formulario.";
            }
            catch(Exception ex)when(ex is IOException||ex is InvalidOperationException||ex is ArgumentException||ex is System.Security.Cryptography.CryptographicException)
            {tokens=null;message="La conexión con Google necesita volver a autorizarse. La agenda conserva sus datos.";}
            if(!registration.IsPrepared)message="La conexión con Google todavía no está preparada en esta compilación. Es una tarea pendiente del desarrollo del programa.";
        }
        GoogleEvaluationManager Manager()
        {
            lock(agendaGate)
            {
                string id;lock(stateGate)id=connection.Form.Id;
                if(id.Length==0)throw new ArgumentException("Elige primero tu formulario.");
                return manager??(manager=new GoogleEvaluationManager(store,agendaGate,Path.Combine(root,"evaluaciones-google-"+GoogleEvaluationRules.Hash(id).Substring(0,24)+".xml"),atomic,now,apply));
            }
        }
        public GoogleOfficialStatus Status()
        {
            lock(stateGate)return new GoogleOfficialStatus{ApplicationPrepared=registration.IsPrepared,Busy=busy,Connected=tokens!=null&&connection.Account.Id.Length>0,FormReady=tokens!=null&&connection.Form.Id.Length>0,AccountId=connection.Account.Id,AccountLabel=connection.Account.Label,FormName=connection.Form.Name,Message=message,Error=error,LastPollUtc=lastPoll,Items=XmlData.Read<GoogleOfficialStatus>(XmlData.Write(new GoogleOfficialStatus{Items=items})).Items};
        }
        void RequirePrepared(){if(!registration.IsPrepared)throw new InvalidOperationException("La conexión con Google requiere una preparación pendiente del desarrollador. No tienes que configurar scripts, claves ni plantillas.");}
        void Persist(GoogleOfficialConnection value){atomic(statePath,Encoding.UTF8.GetBytes(XmlData.Write(value)));lock(stateGate)connection=value;}
        public Task CurrentJob {get{lock(stateGate)return job;}}
        void Queue(Func<CancellationToken,Task> action,string progress)
        {
            RequirePrepared();lock(stateGate){if(disposed)throw new ObjectDisposedException("Google");if(busy)throw new ArgumentException("Espera a que termine la operación con Google.");busy=true;message=progress;error="";
                job=Task.Run(async()=>{
                    await work.WaitAsync().ConfigureAwait(false);
                    try{lifetime.Token.ThrowIfCancellationRequested();await action(lifetime.Token).ConfigureAwait(false);}
                    catch(OperationCanceledException){lock(stateGate){if(!disposed)error="La operación con Google no se completó. Puedes volver a intentarlo.";}}
                    catch(GoogleReconnectException){lock(stateGate){tokens=null;error="Google necesita que vuelvas a pulsar Conectar con Google.";}}
                    catch(Exception ex)when(ex is IOException||ex is ArgumentException||ex is InvalidOperationException||ex is System.Text.Json.JsonException||ex is System.Security.Cryptography.CryptographicException||ex is System.Net.Http.HttpRequestException)
                    {lock(stateGate)error=ex is System.Net.Http.HttpRequestException?"No se pudo contactar con Google. Puedes volver a intentarlo; la agenda conserva sus datos.":ex.Message;}
                    catch(Exception){lock(stateGate)error="La conexión con Google ha encontrado un problema del programa. La agenda conserva sus datos.";}
                    finally{lock(stateGate)busy=false;work.Release();}
                });}
        }
        async Task<string> Access(CancellationToken ct)
        {
            GoogleAccountTokens current;lock(stateGate)current=tokens;
            if(current==null)throw new GoogleReconnectException();
            if(current.AccessToken.Length==0||current.ExpiresUtc<=now().AddMinutes(1))
            {string accountId=current.AccountId;current=await api.Refresh(current,ct).ConfigureAwait(false);current.AccountId=accountId;vault.Save(current);lock(stateGate)tokens=current;}
            return current.AccessToken;
        }
        public void Connect(GoogleAccountTokens input)
        {
            input.Validate();var copy=XmlData.Read<GoogleAccountTokens>(XmlData.Write(input));
            Queue(async ct=>{
                // No se confía en las etiquetas ni en una cuenta declarada por el cliente.
                var verified=await api.Refresh(copy,ct).ConfigureAwait(false);var account=await api.Account(verified.AccessToken,ct).ConfigureAwait(false);
                GoogleOfficialConnection next;lock(stateGate)next=XmlData.Read<GoogleOfficialConnection>(XmlData.Write(connection));
                if(next.Account.Id!=account.Id){next.Form=new GoogleOfficialForm();await onAgenda(()=>{lock(agendaGate){manager=null;return null;}}).ConfigureAwait(false);}
                next.Account=account;verified.AccountId=account.Id;vault.Save(verified);Persist(next);lock(stateGate){tokens=verified;nextPage="";items=new List<GoogleEvaluationItem>();message=next.Form.Id.Length>0?"Cuenta y formulario conectados.":"Cuenta conectada. Ahora pulsa Elegir formulario.";}
                if(next.Form.Id.Length>0)await UpdateItems().ConfigureAwait(false);
            },"Comprobando tu conexión con Google…");
        }
        public void Choose(GoogleChooseForm request)
        {
            GoogleOfficialApi.ValidateFormId(request.FormId);string id=request.FormId;
            Queue(async ct=>{
                string access=await Access(ct).ConfigureAwait(false);var prepared=await api.PrepareForm(access,id,ct).ConfigureAwait(false);
                var account=await api.Account(access,ct).ConfigureAwait(false);
                GoogleOfficialConnection next;lock(stateGate){if(connection.Account.Id!=account.Id)throw new GoogleReconnectException();next=new GoogleOfficialConnection{Account=connection.Account,Form=prepared};}
                Persist(next);await onAgenda(()=>{lock(agendaGate){manager=null;return null;}}).ConfigureAwait(false);
                lock(stateGate){nextPage="";message="Formulario preparado. Selecciona una salida y copia el enlace para el docente.";}
                await UpdateItems().ConfigureAwait(false);RequestPoll();
            },"Preparando automáticamente tu formulario…");
        }
        async Task UpdateItems(){var rows=(List<GoogleEvaluationItem>)await onAgenda(()=>Manager().Items()).ConfigureAwait(false);lock(stateGate)items=rows;}
        public GoogleEvaluationLink Link(GoogleLinkRequest request)
        {
            string template;lock(stateGate){if(busy)throw new ArgumentException("Espera a que termine la preparación de Google.");if(tokens==null||connection.Form.Id.Length==0)throw new ArgumentException("Conecta Google y elige tu formulario antes de copiar el enlace.");template=connection.Form.Template;}
            var result=Manager().Issue(request,template);changed();return result;
        }
        public void Poll()
        {
            Queue(async ct=>{
                string access=await Access(ct).ConfigureAwait(false);GoogleOfficialForm form;string page;lock(stateGate){form=connection.Form;page=nextPage;}
                if(form.Id.Length==0)throw new ArgumentException("Elige tu formulario para recibir las evaluaciones.");
                int applied=0;var seen=new HashSet<string>();
                for(int n=0;n<20;n++)
                {
                    var response=await api.Responses(access,form,page,ct).ConfigureAwait(false);
                    var ambiguous=new HashSet<string>(response.Responses.GroupBy(r=>r.Code??"").Where(g=>g.Select(GoogleEvaluationRules.Fingerprint).Distinct().Count()>1).Select(g=>g.Key));
                    foreach(var row in response.Responses)
                    {
                        ct.ThrowIfCancellationRequested();bool imported=(bool)await onAgenda(()=>{
                            var m=Manager();bool previous=m.IsApplied(row);var item=m.Ingest(row,!ambiguous.Contains(row.Code??""));return !previous&&item.Status=="Aplicada";
                        }).ConfigureAwait(false);if(imported){applied++;changed();}
                    }
                    if(response.NextPage.Length==0){lock(stateGate){nextPage="";lastPoll=now();message=applied>0?"Evaluaciones incorporadas: "+applied+".":"Consulta completada. Las respuestas que necesitan revisión aparecen debajo.";}await UpdateItems().ConfigureAwait(false);return;}
                    if(response.NextPage==page||!seen.Add(response.NextPage))throw new IOException("Google ha repetido una página. La consulta se ha detenido conservando los cambios confirmados.");
                    page=response.NextPage;lock(stateGate)nextPage=page;
                }
                lock(stateGate)message="Se han recibido muchas respuestas. La recogida continuará automáticamente.";RequestPoll();await UpdateItems().ConfigureAwait(false);
            },"Buscando nuevas evaluaciones en Google…");
        }
        public void Apply(GoogleEvaluationApply request){lock(stateGate){if(busy)throw new ArgumentException("Espera a que termine la consulta con Google.");}Manager().Apply(request);var rows=Manager().Items();lock(stateGate)items=rows;changed();}
        public void Disconnect()
        {
            lock(stateGate){if(busy)throw new ArgumentException("Espera a que termine la operación con Google.");vault.Clear();tokens=null;message="Google desconectado. Las memorias ya guardadas se conservan.";error="";}
        }
        public void RequestPoll(){try{wake.Release();}catch(SemaphoreFullException){}}
        public async Task Run(CancellationToken external)
        {
            using(var linked=CancellationTokenSource.CreateLinkedTokenSource(external,lifetime.Token))
            {
                bool first=true;while(!linked.IsCancellationRequested)
                {
                    try
                    {
                        if(!first)await wake.WaitAsync(TimeSpan.FromMinutes(5),linked.Token).ConfigureAwait(false);first=false;
                        var s=Status();if(!s.ApplicationPrepared||!s.Connected||!s.FormReady)continue;
                        if(s.Busy){await CurrentJob.ConfigureAwait(false);RequestPoll();continue;}
                        Poll();await CurrentJob.ConfigureAwait(false);
                    }
                    catch(OperationCanceledException){break;}catch(Exception){lock(stateGate)error="La consulta a Google se ha detenido temporalmente. La agenda sigue disponible.";}
                }
            }
        }
        public void Dispose(){lock(stateGate){if(disposed)return;disposed=true;}lifetime.Cancel();}
    }
}
