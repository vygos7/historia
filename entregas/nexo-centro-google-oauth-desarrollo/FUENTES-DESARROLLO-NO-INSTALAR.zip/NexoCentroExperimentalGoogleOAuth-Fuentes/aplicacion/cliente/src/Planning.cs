using System;
using System.Collections.Generic;
using System.Linq;

namespace AgendaClara
{
    // One real date of an activity, with the per-date changes already applied in View.
    public sealed class Occurrence
    {
        public AgendaEvent Source;
        public AgendaEvent View;
        public DateTime Date;
        public DateTime OriginalDate;
        public OccurrenceChange Change;
        public int Number;
        public int Total;
        public bool Moved { get { return Date != OriginalDate; } }
        public bool Changed { get { return Change != null; } }
    }

    public sealed class Reminder
    {
        public Occurrence Occurrence;
        public int DaysLeft;
        public string Message;
    }

    public static class Planning
    {
        static int Bit(DateTime d) { return 1 << (((int)d.DayOfWeek + 6) % 7); }

        public static IEnumerable<DateTime> Days(DateTime from, DateTime to)
        {
            for (DateTime d = from.Date; d <= to.Date; d = d.AddDays(1))
            {
                yield return d;
                if (d == DateTime.MaxValue.Date) yield break;
            }
        }

        // Dates produced by the repetition rule, before moves, honouring the school calendar.
        public static bool RuleOccurs(AgendaEvent e, DateTime date, SchoolCalendar calendar)
        {
            date = date.Date;
            if (date < e.Start.Date || date > e.End.Date) return false;
            var o = e.Options;
            if (o.SpecificDates.Count > 0) { if (!o.SpecificDates.Any(d => d.Date == date)) return false; }
            else if ((o.Weekdays & Bit(date)) == 0) return false;
            if (o.ExcludedDates.Any(d => d.Date == date)) return false;
            return o.AllowNonSchool || calendar.IsSchoolDay(date);
        }

        // Explains why a rule date is not shown; empty when it is.
        public static string SkipReason(AgendaEvent e, DateTime date, SchoolCalendar calendar)
        {
            if (e.Options.ExcludedDates.Any(d => d.Date == date.Date)) return "excluida";
            if (!e.Options.AllowNonSchool) return calendar.Reason(date);
            return "";
        }

        public static OccurrenceChange ChangeFor(AgendaEvent e, DateTime original)
        {
            return e.Options.Changes.FirstOrDefault(c => c.Date.Date == original.Date);
        }

        static bool TargetAllowed(AgendaEvent e, OccurrenceChange c, DateTime target, SchoolCalendar calendar)
        {
            return c.AllowNonSchool || e.Options.AllowNonSchool || calendar.IsSchoolDay(target);
        }

        static Occurrence Make(AgendaEvent e, DateTime original, DateTime date, OccurrenceChange change)
        {
            var view = e;
            if (change != null)
            {
                view = e.Copy();
                if (change.Title != null) view.Title = change.Title;
                if (change.Notes != null) view.Notes = change.Notes;
                if (change.Location != null) view.Options.Location = change.Location;
                view.AllDay = change.AllDay; view.StartMinute = change.StartMinute; view.EndMinute = change.EndMinute;
            }
            return new Occurrence { Source = e, View = view, Date = date.Date, OriginalDate = original.Date, Change = change };
        }

        public static List<Occurrence> All(AgendaEvent e, SchoolCalendar calendar)
        {
            var list = new List<Occurrence>();
            IEnumerable<DateTime> candidates = e.Options.SpecificDates.Count > 0
                ? e.Options.SpecificDates.Select(d => d.Date).Distinct().OrderBy(d => d)
                : Days(e.Start, e.End);
            foreach (var d in candidates)
            {
                if (!RuleOccurs(e, d, calendar)) continue;
                var c = ChangeFor(e, d);
                DateTime target = c != null && c.MovedTo.HasValue ? c.MovedTo.Value.Date : d;
                if (target != d && !TargetAllowed(e, c, target, calendar)) continue;
                list.Add(Make(e, d, target, c));
            }
            list = list.OrderBy(o => o.Date).ThenBy(o => o.OriginalDate).ToList();
            for (int i = 0; i < list.Count; i++) { list[i].Number = i + 1; list[i].Total = list.Count; }
            return list;
        }

        public static Occurrence At(AgendaEvent e, DateTime date, SchoolCalendar calendar)
        {
            return All(e, calendar).FirstOrDefault(o => o.Date == date.Date);
        }

        public static Occurrence Next(AgendaEvent e, DateTime from, SchoolCalendar calendar)
        {
            return All(e, calendar).FirstOrDefault(o => o.Date >= from.Date);
        }

        public static Dictionary<DateTime, List<Occurrence>> Index(IEnumerable<List<Occurrence>> lists)
        {
            var index = new Dictionary<DateTime, List<Occurrence>>();
            foreach (var list in lists)
                foreach (var o in list)
                {
                    List<Occurrence> day;
                    if (!index.TryGetValue(o.Date, out day)) { day = new List<Occurrence>(); index[o.Date] = day; }
                    day.Add(o);
                }
            foreach (var day in index.Values) Sort(day);
            return index;
        }

        public static void Sort(List<Occurrence> day)
        {
            day.Sort((a, b) =>
            {
                int x = (a.View.AllDay ? -1 : a.View.StartMinute).CompareTo(b.View.AllDay ? -1 : b.View.StartMinute);
                if (x != 0) return x;
                x = (a.View.AllDay ? 0 : a.View.EndMinute).CompareTo(b.View.AllDay ? 0 : b.View.EndMinute);
                if (x != 0) return x;
                x = String.Compare(a.View.Title, b.View.Title, StringComparison.CurrentCultureIgnoreCase);
                return x != 0 ? x : a.Source.Id.CompareTo(b.Source.Id);
            });
        }

        public static List<Occurrence> Day(IEnumerable<AgendaEvent> events, DateTime date, SchoolCalendar calendar)
        {
            var day = events.Select(e => At(e, date, calendar)).Where(o => o != null).ToList();
            Sort(day);
            return day;
        }

        // Every word of the query must appear, ignoring case and accents.
        public static bool Matches(AgendaEvent e, string query, string category)
        {
            if (!String.IsNullOrEmpty(category) && !String.Equals(category, e.Options.Category, StringComparison.CurrentCultureIgnoreCase)) return false;
            string q = Format.Fold(query).Trim();
            if (q.Length == 0) return true;
            string text = Format.Fold(String.Join(" ", new[] { e.Title, e.Notes, e.Options.Category, e.Options.Group, e.Options.Responsible, e.Options.Location }
                .Concat(e.Options.Changes.SelectMany(c => new[] { c.Title, c.Notes, c.Location }))
                .Where(s => !String.IsNullOrEmpty(s))));
            return q.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries).All(word => text.Contains(word));
        }

        public static string ReminderMessage(Occurrence o, int days)
        {
            string what = "«" + o.View.Title + "» (" + o.View.Options.Category + ")";
            if (days == 0) return "Hoy: " + what + (o.View.AllDay ? "" : " a las " + AgendaEvent.Clock(o.View.StartMinute));
            if (days == 1) return "Mañana: " + what + (o.View.AllDay ? "" : " a las " + AgendaEvent.Clock(o.View.StartMinute));
            return "Faltan " + days + " días para " + what + " · " + Format.LongDate(o.Date);
        }

        public static List<Reminder> Reminders(IEnumerable<AgendaEvent> events, DateTime today, SchoolCalendar calendar)
        {
            var result = new List<Reminder>();
            foreach (var e in events)
            {
                if (e.Options.ReminderDays < 0) continue;
                var next = Next(e, today, calendar);
                if (next == null) continue;
                int days = (int)(next.Date - today.Date).TotalDays;
                if (days <= e.Options.ReminderDays) result.Add(new Reminder { Occurrence = next, DaysLeft = days, Message = ReminderMessage(next, days) });
            }
            return result.OrderBy(r => r.DaysLeft).ThenBy(r => r.Occurrence.View.AllDay ? -1 : r.Occurrence.View.StartMinute).ThenBy(r => r.Occurrence.View.Title).ToList();
        }

        public static string RepetitionSummary(AgendaEvent e)
        {
            var o = e.Options;
            string s;
            if (o.SpecificDates.Count > 0) s = "Fechas concretas: " + Format.Count(o.SpecificDates.Count, "fecha", "fechas");
            else if (!e.MultiDay) s = "Un día";
            else if ((o.Weekdays & 127) == 127 || ((o.Weekdays & 127) == 31 && !o.AllowNonSchool)) s = "Días lectivos del intervalo";
            else
            {
                string[] names = { "lun", "mar", "mié", "jue", "vie", "sáb", "dom" };
                s = "Solo " + String.Join(", ", Enumerable.Range(0, 7).Where(i => (o.Weekdays & (1 << i)) != 0).Select(i => names[i]));
            }
            if (o.ExcludedDates.Count > 0) s += " · " + Format.Count(o.ExcludedDates.Count, "fecha excluida", "fechas excluidas");
            if (o.AllowNonSchool) s += " · Excepción: admite días no lectivos";
            return s;
        }
    }
}
