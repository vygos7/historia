using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Security;
using System.Net.Sockets;
using System.Security.Authentication;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Threading;
using System.Threading.Tasks;

namespace AgendaClara
{
    public sealed class ConnectionReport
    {
        readonly List<string> lines=new List<string>();
        public bool ApiAvailable, RealtimeAvailable;
        public string FailedStage="", FailureCode="";
        public readonly DateTime StartedUtc=DateTime.UtcNow;
        public string Text { get { lock(lines)return String.Join(Environment.NewLine,lines); } }
        public void Add(string text,IProgress<string> progress=null)
        {
            lock(lines)lines.Add(DateTime.UtcNow.ToString("HH:mm:ss.fff")+" UTC · "+text);
            if(progress!=null)progress.Report(Text);
        }
    }

    public static class ConnectionProbe
    {
        // DNS de .NET Framework no admite un token de cancelación. Se observan los fallos tardíos
        // sin prolongar la espera; para TCP/TLS se cierra además el socket.
        public static async Task Bounded(Task operation,TimeSpan timeout,CancellationToken token,Action abort=null)
        {
            using(var deadline=CancellationTokenSource.CreateLinkedTokenSource(token))
            {
                var delay=Task.Delay(timeout,deadline.Token);
                if(await Task.WhenAny(operation,delay).ConfigureAwait(false)!=operation)
                {
                    if(abort!=null)abort();
                    Observe(operation);
                    token.ThrowIfCancellationRequested();
                    throw new TimeoutException("Se ha alcanzado el plazo de esta etapa.");
                }
                deadline.Cancel();
                await operation.ConfigureAwait(false);
            }
        }
        static void Observe(Task operation)
        { operation.ContinueWith(t=>{var ignored=t.Exception;},CancellationToken.None,TaskContinuationOptions.OnlyOnFaulted|TaskContinuationOptions.ExecuteSynchronously,TaskScheduler.Default); }
        public static bool SameSubnet(IPAddress local,IPAddress mask,IPAddress remote)
        {
            var a=local.GetAddressBytes();var m=mask.GetAddressBytes();var b=remote.GetAddressBytes();
            return a.Length==m.Length && a.Length==b.Length && a.Select((v,i)=>(v&m[i])==(b[i]&m[i])).All(v=>v);
        }
        public static IEnumerable<string> LocalNetworks(IPAddress remote=null)
        {
            var result=new List<string>();
            try
            {
                foreach(var adapter in NetworkInterface.GetAllNetworkInterfaces().Where(n=>n.OperationalStatus==OperationalStatus.Up && n.NetworkInterfaceType!=NetworkInterfaceType.Loopback))
                    foreach(var address in adapter.GetIPProperties().UnicastAddresses.Where(a=>a.Address.AddressFamily==AddressFamily.InterNetwork))
                    {
                        var mask=address.IPv4Mask;
                        result.Add("IP local "+address.Address+" · máscara "+(mask==null?"no disponible":mask.ToString())+
                            (remote==null||remote.AddressFamily!=AddressFamily.InterNetwork||mask==null?"":" · destino "+remote+": "+(SameSubnet(address.Address,mask,remote)?"misma subred según esta máscara":"otra subred según esta máscara")));
                    }
            }
            catch(NetworkInformationException){result.Add("No se ha podido consultar la máscara de las interfaces locales.");}
            return result;
        }
        public static async Task ProbeAsync(Uri address,X509Certificate2 certificate,RemoteCertificateValidationCallback validate,ConnectionReport report,IProgress<string> progress,CancellationToken token,TimeSpan? stepTimeout=null)
        {
            TimeSpan timeout=stepTimeout??TimeSpan.FromSeconds(10);
            report.FailedStage="DNS";
            IPAddress literal;
            IPAddress[] addresses;
            if(IPAddress.TryParse(address.DnsSafeHost,out literal))addresses=new[]{literal};
            else
            {
                report.Add("Resolviendo el nombre "+address.DnsSafeHost+"…",progress);
                var lookup=Dns.GetHostAddressesAsync(address.DnsSafeHost);
                await Bounded(lookup,timeout,token).ConfigureAwait(false);addresses=await lookup.ConfigureAwait(false);
            }
            addresses=addresses.Distinct().ToArray();
            if(addresses.Length==0)throw new ConnectionFailure("dns","El nombre no devuelve ninguna dirección IP.");
            report.Add("Direcciones de destino: "+String.Join(", ",addresses.Select(a=>a.ToString())),progress);
            foreach(var line in LocalNetworks())report.Add(line,progress);
            Exception last=null;bool reachedTls=false;
            // Se prueban las direcciones resueltas: un fallo IPv6 no oculta un éxito IPv4.
            foreach(var ip in addresses)
            {
                token.ThrowIfCancellationRequested();report.FailedStage="TCP";
                using(var tcp=new TcpClient(ip.AddressFamily))
                {
                    try
                    {
                        var watch=Stopwatch.StartNew();report.Add("TCP: comprobando "+ip+":"+address.Port+"…",progress);
                        await Bounded(tcp.ConnectAsync(ip,address.Port),timeout,token,tcp.Close).ConfigureAwait(false);
                        report.Add("TCP accesible: "+ip+":"+address.Port+" ("+watch.ElapsedMilliseconds+" ms).",progress);
                        foreach(var line in LocalNetworks(ip))report.Add(line,progress);
                    }
                    catch(OperationCanceledException){throw;}
                    catch(Exception ex)
                    {
                        last=ex;report.Add("TCP fallido para "+ip+": "+ex.GetType().Name+(ex is SocketException?" / "+((SocketException)ex).SocketErrorCode:""),progress);continue;
                    }
                    report.FailedStage="TLS";reachedTls=true;
                    using(var ssl=new SslStream(tcp.GetStream(),false,validate))
                    {
                        report.Add("Negociando HTTPS y presentando el certificado del puesto…",progress);
                        try
                        {
                            await Bounded(ssl.AuthenticateAsClientAsync(address.DnsSafeHost,new X509CertificateCollection{certificate},SslProtocols.Tls12,false),timeout,token,tcp.Close).ConfigureAwait(false);
                        }
                        catch(OperationCanceledException){throw;}
                        catch(Exception ex){last=ex;report.Add("TLS no completado para "+ip+". No se aceptan certificados inválidos.",progress);continue;}
                        report.Add("TLS negociado: "+ssl.SslProtocol+" · certificado de cliente presentado: "+(ssl.IsMutuallyAuthenticated?"sí":"no confirmado por el canal")+". La autorización del puesto se comprueba después en la API.",progress);
                        report.FailedStage="";return;
                    }
                }
            }
            if(!reachedTls)throw new ConnectionFailure("tcp-unavailable","No se puede acceder al puerto "+address.Port+" en ninguna dirección resuelta. Comprueba el servicio y la accesibilidad actual del puerto.",last);
            report.FailedStage="TLS";
            if(last is TimeoutException)throw new ConnectionFailure("tls-timeout","TCP es accesible, pero la negociación TLS no se ha completado dentro del plazo.",last);
            throw new ConnectionFailure("tls-handshake","No se pudo completar TLS en ninguna dirección accesible. El fallo no demuestra por sí solo que el servidor haya rechazado el certificado del puesto.",last);
        }
    }

    public sealed partial class RemoteConnection
    {
        readonly SemaphoreSlim hubStart=new SemaphoreSlim(1,1);
        public event Action<string> ConnectionStage;
        public event Action<string> ConnectionDetail;
        void ReportDetail(string detail)
        {
            // Información controlada; nunca XML, credenciales, sesiones ni mensajes arbitrarios.
            // El diagnóstico no debe interrumpir una solicitud ni bloquear el hilo de red.
            var listener=ConnectionDetail;if(listener!=null)try{listener(detail);}catch(Exception){}
        }
        void ReportStage(string stage){var listener=ConnectionStage;if(listener!=null)listener(stage);}
        void RecordStep(string stage,string code,long milliseconds)
        {
            // Sólo nombres de etapa y códigos controlados; nunca mensajes de excepción, consultas,
            // credenciales, contenido XML, tokens ni material privado de certificados.
            ConnectionDiagnostics.Record(Path.GetDirectoryName(cachePath),new ConnectionFailure(code+" stage="+stage+" ms="+milliseconds,""));
        }
        public async Task CheckRealtimeAsync(CancellationToken token=default(CancellationToken))
        {
            using(var limit=CancellationTokenSource.CreateLinkedTokenSource(lifetime.Token,token))
            {
                limit.CancelAfter(TimeSpan.FromSeconds(15));
                await hubStart.WaitAsync(limit.Token).ConfigureAwait(false);
                try { await EnsureHub(limit.Token).ConfigureAwait(false); }
                finally { hubStart.Release(); }
            }
        }
        public async Task<ConnectionReport> DiagnoseAsync(string password,IProgress<string> progress=null,CancellationToken token=default(CancellationToken))
        {
            var report=new ConnectionReport();
            Action<string> stage=s=>{report.FailedStage=s;report.Add(s+"…",progress);};
            Action<string> detail=s=>report.Add(s,progress);
            ConnectionStage+=stage;ConnectionDetail+=detail;
            try
            {
                report.Add("Diagnóstico HTTP · fallback de direcciones · revisión 2026-11-05-r2. Las observaciones TCP son por proceso y pueden omitir conexiones breves; correlacionar el ID HTTP con Jefatura.",progress);
                report.Add("AgendaClara "+ProgramVersion()+" · diagnóstico "+report.StartedUtc.ToString("o"),progress);
                report.Add("Servidor configurado: "+http.BaseAddress.GetLeftPart(UriPartial.Authority),progress);
                report.FailedStage="Certificado del puesto";
                // Firmar datos aleatorios demuestra que el usuario puede utilizar la clave privada.
                // HasPrivateKey por sí solo no demuestra que sea accesible.
                using(var key=certificate.GetRSAPrivateKey())
                {
                    if(key==null)throw new ConnectionFailure("client-key","El certificado no dispone de una clave RSA accesible.");
                    byte[] challenge=new byte[32];using(var rng=RandomNumberGenerator.Create())rng.GetBytes(challenge);
                    key.SignData(challenge,HashAlgorithmName.SHA256,RSASignaturePadding.Pkcs1);
                }
                report.Add("Certificado del puesto vigente, con uso clientAuth y clave privada accesible; caduca "+certificate.NotAfter.ToString("dd/MM/yyyy")+".",progress);
                await ConnectionProbe.ProbeAsync(http.BaseAddress,certificate,(sender,cert,chain,errors)=>
                {
                    bool valid=configuration.ServerAuthority.Length>0?ValidateServerCertificate(cert as X509Certificate2,errors):errors==SslPolicyErrors.None;
                    if(configuration.ServerAuthority.Length==0 && !valid)tlsFailure=(errors&SslPolicyErrors.RemoteCertificateNameMismatch)!=0?"name":"untrusted";
                    report.Add("Certificado HTTPS: "+(valid?"válido para la identidad y confianza configuradas":"rechazado")+" · política Windows: "+errors+" · validación AgendaClara: "+(valid?"correcta":tlsFailure),progress);
                    if(cert!=null)using(var sha=SHA256.Create())report.Add("Huella pública SHA-256 del servidor: "+BitConverter.ToString(sha.ComputeHash(cert.GetRawCertData())).Replace("-",""),progress);
                    return valid;
                },report,progress,token).ConfigureAwait(false);
                await ConnectAsync(password,token).ConfigureAwait(false);
                report.ApiAvailable=true;report.Add("API: puesto y usuario autorizados; datos iniciales recuperados. Revisión "+Snapshot.Revision+".",progress);
                report.FailedStage="SignalR";report.Add("Comprobando la sincronización SignalR…",progress);
                try
                {
                    await CheckRealtimeAsync(token).ConfigureAwait(false);report.RealtimeAvailable=RealtimeConnected;
                    if(!report.RealtimeAvailable)throw new IOException("El canal no está conectado.");
                    report.Add("SignalR conectado. La conexión es correcta. Verifica la propagación creando un acontecimiento de prueba autorizado desde otro puesto.",progress);report.FailedStage="";
                }
                catch(OperationCanceledException)when(token.IsCancellationRequested){throw;}
                catch(Exception ex)
                {
                    report.FailureCode="signalr";RecordStep("SignalR","failed-"+ex.GetType().Name,0);
                    report.Add("La API funciona, pero SignalR no está disponible. La consulta periódica puede seguir sincronizando. Tipo técnico: "+ex.GetType().Name+".",progress);
                }
            }
            catch(Exception ex)
            {
                var failure=ex is TimeoutException?new ConnectionFailure("stage-timeout","Se ha agotado el plazo en la etapa "+report.FailedStage+".",ex):
                    ex is SessionExpiredException?new ConnectionFailure("authentication",ex.Message,ex):
                    ConnectionDiagnostics.Explain(ex,token.IsCancellationRequested,report.FailedStage=="TLS"?tlsFailure:"");
                report.FailureCode=failure.Code;RecordStep(report.FailedStage,failure.Code,0);ConnectionDiagnostics.Record(Path.GetDirectoryName(cachePath),new ConnectionFailure(failure.Code,"",ex));
                report.Add("FALLO · "+report.FailedStage+" · "+failure.Code+": "+failure.Message,progress);
                report.Add("Tipo técnico: "+ex.GetType().Name+" · HRESULT "+ex.HResult.ToString("X8")+".",progress);
            }
            finally
            {
                ConnectionStage-=stage;ConnectionDetail-=detail;
                report.Add("Fin del diagnóstico. No se ha modificado la configuración de red, el almacén de confianza ni la agenda.",progress);
            }
            return report;
        }
        static string ProgramVersion(){return typeof(RemoteConnection).Assembly.GetName().Version.ToString();}
    }
}
