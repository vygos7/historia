using System;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Google.Apis.Auth.OAuth2;
using Google.Apis.Auth.OAuth2.Flows;
using Google.Apis.Util.Store;

namespace AgendaClara
{
    public sealed class GoogleEncryptedDataStore:IDataStore
    {
        readonly string root;
        public GoogleEncryptedDataStore(string root){ExperimentalIsolation.PathForWrite(root);this.root=root;Directory.CreateDirectory(root);}
        string PathFor<T>(string key){return Path.Combine(root,"oauth-"+GoogleEvaluationRules.Hash(typeof(T).FullName+"|"+key)+".dpapi");}
        public Task StoreAsync<T>(string key,T value)
        {byte[] bytes=Encoding.UTF8.GetBytes(JsonSerializer.Serialize(value));try{SharedConfiguration.Atomic(PathFor<T>(key),ProtectedData.Protect(bytes,null,DataProtectionScope.CurrentUser));}finally{Array.Clear(bytes,0,bytes.Length);}return Task.FromResult(0);}
        public Task<T> GetAsync<T>(string key)
        {
            string path=PathFor<T>(key);if(!File.Exists(path))return Task.FromResult(default(T));
            byte[] bytes=ProtectedData.Unprotect(File.ReadAllBytes(path),null,DataProtectionScope.CurrentUser);try{return Task.FromResult(JsonSerializer.Deserialize<T>(Encoding.UTF8.GetString(bytes)));}finally{Array.Clear(bytes,0,bytes.Length);}
        }
        public Task DeleteAsync<T>(string key){string path=PathFor<T>(key);if(File.Exists(path))File.Delete(path);return Task.FromResult(0);}
        public Task ClearAsync(){foreach(var path in Directory.GetFiles(root,"oauth-*.dpapi"))File.Delete(path);return Task.FromResult(0);}
    }
    public sealed class GoogleDesktopConnect
    {
        readonly GoogleAppRegistration registration;readonly GoogleEncryptedDataStore data;
        public GoogleDesktopConnect(GoogleAppRegistration registration,string root){this.registration=registration;data=new GoogleEncryptedDataStore(Path.Combine(root,"CuentaGoogle"));}
        async Task<UserCredential> Credential(CancellationToken ct)
        {
            if(!registration.IsPrepared)throw new InvalidOperationException("La conexión con Google requiere una preparación pendiente del desarrollo del programa.");
            var initializer=new GoogleAuthorizationCodeFlow.Initializer{ClientSecrets=new ClientSecrets{ClientId=registration.ClientId,ClientSecret=registration.ClientSecret},Prompt="consent select_account",IncludeGrantedScopes=false};
            return await GoogleWebAuthorizationBroker.AuthorizeAsync(initializer,new[]{GoogleAppRegistration.Scope},"nexo-centro-google",usePkce:true,taskCancellationToken:ct,dataStore:data).ConfigureAwait(false);
        }
        public async Task<GoogleAccountTokens> Connect(CancellationToken ct)
        {
            await data.ClearAsync().ConfigureAwait(false);
            var credential=await Credential(ct).ConfigureAwait(false);string access=await credential.GetAccessTokenForRequestAsync(null,ct).ConfigureAwait(false);var t=credential.Token;
            var result=new GoogleAccountTokens{AccessToken=access,RefreshToken=t.RefreshToken??"",Scope=String.IsNullOrWhiteSpace(t.Scope)?GoogleAppRegistration.Scope:t.Scope,ExpiresUtc=t.IssuedUtc.AddSeconds(t.ExpiresInSeconds??3600)};
            result.Validate();return result;
        }
        public async Task<string> ChooseForm(string expectedAccount,CancellationToken ct)
        {
            var credential=await Credential(ct).ConfigureAwait(false);string access=await credential.GetAccessTokenForRequestAsync(null,ct).ConfigureAwait(false);
            using(var http=new System.Net.Http.HttpClient(new System.Net.Http.HttpClientHandler{AllowAutoRedirect=false}))
            {var account=await new GoogleOfficialApi(http,registration).Account(access,ct).ConfigureAwait(false);if(account.Id!=expectedAccount)throw new ArgumentException("La cuenta elegida en Google no coincide con la conectada a esta agenda. Pulsa Conectar con Google para usar esa cuenta.");}
            return await GoogleFormPicker.Choose(registration,access,uri=>System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(uri){UseShellExecute=true}),ct).ConfigureAwait(false);
        }
    }
}
