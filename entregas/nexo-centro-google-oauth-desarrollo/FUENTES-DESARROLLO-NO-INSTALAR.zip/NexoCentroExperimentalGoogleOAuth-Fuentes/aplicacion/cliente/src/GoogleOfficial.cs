using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace AgendaClara
{
    public sealed class GoogleAppRegistration
    {
        public const string Scope="https://www.googleapis.com/auth/drive.file";
        public string ClientId {get;set;}="";
        public string ClientSecret {get;set;}="";
        public string PickerApiKey {get;set;}="";
        public string ProjectNumber {get;set;}="";
        public bool ProductionApproved {get;set;}
        public bool LiveContractVerified {get;set;}
        public bool IsPrepared {get{return !String.IsNullOrWhiteSpace(ClientSecret)&&Regex.IsMatch(ClientId??"",@"^[a-zA-Z0-9_-]+\.apps\.googleusercontent\.com$")&&Regex.IsMatch(ProjectNumber??"",@"^[0-9]{6,30}$")&&Regex.IsMatch(PickerApiKey??"",@"^AIza[\w-]{20,100}$");}}
        public bool CanDistribute {get{return IsPrepared&&ProductionApproved&&LiveContractVerified;}}
        public static GoogleAppRegistration Load()
        {
            using(var stream=typeof(GoogleAppRegistration).Assembly.GetManifestResourceStream("NexoCentro.GoogleApp.json"))
            {if(stream==null)return new GoogleAppRegistration();return JsonSerializer.Deserialize<GoogleAppRegistration>(new StreamReader(stream).ReadToEnd())??new GoogleAppRegistration();}
        }
    }
    public sealed class GoogleAccountTokens
    {
        public string AccountId {get;set;}="";public string AccessToken {get;set;}="";public string RefreshToken {get;set;}="";public string Scope {get;set;}="";
        public DateTime ExpiresUtc {get;set;}
        public void Validate(){if(String.IsNullOrWhiteSpace(RefreshToken)||RefreshToken.Length>16000||AccessToken==null||AccessToken.Length>16000||!((Scope??"").Split(' ').Contains(GoogleAppRegistration.Scope)))throw new ArgumentException("Google no ha autorizado el acceso al formulario. Vuelve a pulsar Conectar con Google.");}
    }
    public sealed class GoogleAccountInfo {public string Id {get;set;}="";public string Label {get;set;}="";}
    public sealed class GoogleOfficialField {public string Key {get;set;}="";public string QuestionId {get;set;}="";}
    public sealed class GoogleOfficialForm
    {
        public string Id {get;set;}="";public string Name {get;set;}="";public string Template {get;set;}="";
        public List<GoogleOfficialField> Fields {get;set;}=new List<GoogleOfficialField>();
        public string Question(string key){return Fields.Single(f=>f.Key==key).QuestionId;}
    }
    public sealed class GoogleOfficialPage {public string NextPage {get;set;}="";public List<GoogleEvaluationResponse> Responses {get;set;}=new List<GoogleEvaluationResponse>();}
    public sealed class GoogleChooseForm {public string FormId {get;set;}="";}
    public sealed class GoogleOfficialStatus
    {
        public bool ApplicationPrepared {get;set;}public bool Busy {get;set;}public bool Connected {get;set;}public bool FormReady {get;set;}
        public string AccountId {get;set;}="";public string AccountLabel {get;set;}="";public string FormName {get;set;}="";
        public string Message {get;set;}="";public string Error {get;set;}="";public DateTime LastPollUtc {get;set;}
        public List<GoogleEvaluationItem> Items {get;set;}=new List<GoogleEvaluationItem>();
    }
    public sealed class GoogleOfficialConnection
    {public int Format {get;set;}=1;public GoogleAccountInfo Account {get;set;}=new GoogleAccountInfo();public GoogleOfficialForm Form {get;set;}=new GoogleOfficialForm();}
    public interface IGoogleTokenVault {GoogleAccountTokens Load();void Save(GoogleAccountTokens tokens);void Clear();}
    public sealed class GoogleEncryptedTokenVault:IGoogleTokenVault
    {
        readonly string path;readonly Func<byte[],byte[]> protect,unprotect;readonly Action<string,byte[]> atomic;
        public GoogleEncryptedTokenVault(string root,Func<byte[],byte[]> protect,Func<byte[],byte[]> unprotect,Action<string,byte[]> atomic){path=Path.Combine(root,"google-cuenta.dpapi");this.protect=protect;this.unprotect=unprotect;this.atomic=atomic;}
        public GoogleAccountTokens Load(){if(!File.Exists(path))return null;byte[] bytes=unprotect(File.ReadAllBytes(path));try{return XmlData.Read<GoogleAccountTokens>(Encoding.UTF8.GetString(bytes));}finally{Array.Clear(bytes,0,bytes.Length);}}
        public void Save(GoogleAccountTokens tokens){tokens.Validate();byte[] bytes=Encoding.UTF8.GetBytes(XmlData.Write(tokens));try{atomic(path,protect(bytes));}finally{Array.Clear(bytes,0,bytes.Length);}}
        public void Clear(){if(File.Exists(path))File.Delete(path);}
    }
    public interface IGoogleOfficialApi
    {
        Task<GoogleAccountTokens> Refresh(GoogleAccountTokens tokens,CancellationToken ct);
        Task<GoogleAccountInfo> Account(string access,CancellationToken ct);
        Task<GoogleOfficialForm> PrepareForm(string access,string formId,CancellationToken ct);
        Task<GoogleOfficialPage> Responses(string access,GoogleOfficialForm form,string page,CancellationToken ct);
    }
    public sealed class GoogleOfficialApi:IGoogleOfficialApi
    {
        readonly HttpClient http;readonly GoogleAppRegistration registration;
        public GoogleOfficialApi(HttpClient http,GoogleAppRegistration registration){this.http=http;this.registration=registration;}
        static string Text(JsonElement e,string key){JsonElement value;return e.TryGetProperty(key,out value)&&value.ValueKind==JsonValueKind.String?value.GetString():"";}
        public static void ValidateFormId(string id){if(!Regex.IsMatch(id??"",@"^[a-zA-Z0-9_-]{10,200}$"))throw new ArgumentException("Google no ha devuelto un formulario válido. Pulsa Elegir formulario.");}
        async Task<JsonDocument> Send(HttpMethod method,string url,string access,object body,CancellationToken ct)
        {
            using(var request=new HttpRequestMessage(method,url))
            using(var timeout=CancellationTokenSource.CreateLinkedTokenSource(ct))
            {
                timeout.CancelAfter(TimeSpan.FromSeconds(8));
                if(!String.IsNullOrEmpty(access))request.Headers.Authorization=new AuthenticationHeaderValue("Bearer",access);
                if(body!=null)request.Content=body as HttpContent??new StringContent(JsonSerializer.Serialize(body),Encoding.UTF8,"application/json");
                using(var reply=await http.SendAsync(request,HttpCompletionOption.ResponseHeadersRead,timeout.Token).ConfigureAwait(false))
                {
                    if(reply.StatusCode==HttpStatusCode.Unauthorized||(reply.StatusCode==HttpStatusCode.BadRequest&&request.RequestUri.Host=="oauth2.googleapis.com"))throw new GoogleReconnectException();
                    if(reply.StatusCode==HttpStatusCode.Forbidden)throw new IOException("Google no ha permitido esta operación. Comprueba que has elegido tu formulario y que tu cuenta puede editarlo.");
                    if(!reply.IsSuccessStatusCode)throw new IOException("Google no ha completado la operación. La agenda conserva sus datos; puedes volver a intentarlo.");
                    using(var stream=await reply.Content.ReadAsStreamAsync().ConfigureAwait(false))using(var memory=new MemoryStream())
                    {byte[] buffer=new byte[8192];int n;while((n=await stream.ReadAsync(buffer,0,buffer.Length,timeout.Token).ConfigureAwait(false))>0){if(memory.Length+n>4*1024*1024)throw new IOException("La respuesta de Google supera el tamaño permitido.");memory.Write(buffer,0,n);}return JsonDocument.Parse(memory.ToArray());}
                }
            }
        }
        public async Task<GoogleAccountTokens> Refresh(GoogleAccountTokens tokens,CancellationToken ct)
        {
            tokens.Validate();var values=new Dictionary<string,string>{{"grant_type","refresh_token"},{"client_id",registration.ClientId},{"refresh_token",tokens.RefreshToken}};
            if(registration.ClientSecret.Length>0)values.Add("client_secret",registration.ClientSecret);
            using(var result=await Send(HttpMethod.Post,"https://oauth2.googleapis.com/token",null,new FormUrlEncodedContent(values),ct).ConfigureAwait(false))
            {var r=result.RootElement;JsonElement seconds;var next=new GoogleAccountTokens{AccountId=tokens.AccountId,AccessToken=Text(r,"access_token"),RefreshToken=String.IsNullOrEmpty(Text(r,"refresh_token"))?tokens.RefreshToken:Text(r,"refresh_token"),Scope=String.IsNullOrEmpty(Text(r,"scope"))?tokens.Scope:Text(r,"scope"),ExpiresUtc=DateTime.UtcNow.AddSeconds(r.TryGetProperty("expires_in",out seconds)?seconds.GetDouble():3600)};next.Validate();if(next.AccessToken.Length==0)throw new GoogleReconnectException();return next;}
        }
        public async Task<GoogleAccountInfo> Account(string access,CancellationToken ct)
        {
            using(var data=await Send(HttpMethod.Get,"https://www.googleapis.com/drive/v3/about?fields=user(permissionId,displayName,emailAddress)",access,null,ct).ConfigureAwait(false))
            {JsonElement u;if(!data.RootElement.TryGetProperty("user",out u)||Text(u,"permissionId").Length==0)throw new GoogleReconnectException();return new GoogleAccountInfo{Id=Text(u,"permissionId"),Label=Text(u,"emailAddress").Length>0?Text(u,"emailAddress"):Text(u,"displayName")};}
        }
        static readonly string[][] Names={new[]{"code","Código de la actividad"},new[]{"title","Nombre de la actividad"},new[]{"date","Fecha de la salida","Fecha de realización"},new[]{"group","Curso o grupo","Grupo"},new[]{"rating","Valoración general"},new[]{"positives","Aspectos positivos"},new[]{"difficulties","Incidencias y dificultades"},new[]{"improvements","Propuestas de mejora"},new[]{"continuity","¿Se recomienda repetir esta salida en próximos cursos?","Continuidad"},new[]{"justification","Justificación de la continuidad"}};
        static string Name(string value){return GoogleEvaluationRules.Normalize(Regex.Replace(value??"",@"^\s*(\d+[.\)\-]\s*)+",""));}
        static List<JsonElement> Items(JsonElement form){JsonElement items;return form.TryGetProperty("items",out items)&&items.ValueKind==JsonValueKind.Array?items.EnumerateArray().Select(i=>i.Clone()).ToList():new List<JsonElement>();}
        static string QuestionId(JsonElement item){JsonElement qi,q;if(!item.TryGetProperty("questionItem",out qi)||!qi.TryGetProperty("question",out q))throw new ArgumentException("Una pregunta de identificación no tiene un formato compatible.");return Text(q,"questionId");}
        public static GoogleOfficialForm MapForm(JsonElement form)
        {
            var answer=new GoogleOfficialForm{Id=Text(form,"formId")};JsonElement info;if(form.TryGetProperty("info",out info))answer.Name=Text(info,"title");var items=Items(form);
            foreach(var names in Names)
            {
                var found=items.Where(i=>names.Skip(1).Any(n=>Name(n)==Name(Text(i,"title")))).ToList();
                if(found.Count>1)throw new ArgumentException("Hay preguntas repetidas en el formulario: "+names[1]+".");
                if(found.Count==0){if(names[0]=="code"||names[0]=="title")continue;throw new ArgumentException("El formulario necesita esta pregunta: "+names[1]+".");}
                var question=found[0].GetProperty("questionItem").GetProperty("question");
                if((names[0]=="code"||names[0]=="title"||names[0]=="group")&&!question.TryGetProperty("textQuestion",out _))throw new ArgumentException("La pregunta "+names[1]+" debe permitir texto para identificar las salidas.");
                if(names[0]=="date"&&!question.TryGetProperty("dateQuestion",out _))throw new ArgumentException("La fecha de la salida debe ser una pregunta de fecha.");
                string qid=QuestionId(found[0]);if(qid.Length==0)throw new ArgumentException("Google no ha identificado una pregunta del formulario.");
                answer.Fields.Add(new GoogleOfficialField{Key=names[0],QuestionId=qid});
            }
            return answer;
        }
        // Contrato de prerrellenado pendiente de prueba contra Google real antes de distribuir.
        public static string EntryId(string questionId){uint number;if(!UInt32.TryParse(questionId,NumberStyles.AllowHexSpecifier,CultureInfo.InvariantCulture,out number)||number>Int32.MaxValue)throw new ArgumentException("Google ha devuelto un identificador no compatible. La conexión necesita una revisión del programa.");return number.ToString(CultureInfo.InvariantCulture);}
        public static string Prefill(string responderUri,GoogleOfficialForm form)
        {
            Uri uri;if(!Uri.TryCreate(responderUri,UriKind.Absolute,out uri)||uri.Scheme!="https"||uri.Host!="docs.google.com"||!uri.IsDefaultPort||uri.UserInfo.Length>0||!uri.AbsolutePath.StartsWith("/forms/d/")||!uri.AbsolutePath.EndsWith("/viewform"))throw new ArgumentException("Google no ha devuelto el enlace de respuesta del formulario.");
            string result=uri.GetLeftPart(UriPartial.Path)+"?usp=pp_url";
            foreach(var pair in new[]{new[]{"code","__NEXO_CODE__"},new[]{"title","__NEXO_TITLE__"},new[]{"date","__NEXO_DATE__"},new[]{"group","__NEXO_GROUP__"}})result+="&entry."+EntryId(form.Question(pair[0]))+"="+pair[1];
            GoogleEvaluationRules.ValidateTemplate(result);return result;
        }
        public async Task<GoogleOfficialForm> PrepareForm(string access,string formId,CancellationToken ct)
        {
            ValidateFormId(formId);string route="https://forms.googleapis.com/v1/forms/"+Uri.EscapeDataString(formId);
            using(var meta=await Send(HttpMethod.Get,"https://www.googleapis.com/drive/v3/files/"+Uri.EscapeDataString(formId)+"?fields=id,mimeType,capabilities(canEdit)",access,null,ct).ConfigureAwait(false))
            {JsonElement capability,can;if(Text(meta.RootElement,"mimeType")!="application/vnd.google-apps.form"||!meta.RootElement.TryGetProperty("capabilities",out capability)||!capability.TryGetProperty("canEdit",out can)||can.ValueKind!=JsonValueKind.True)throw new ArgumentException("Elige un formulario que puedas editar con tu cuenta de Google.");}
            string publishedUri;GoogleOfficialForm initial;List<object> requests=new List<object>();
            using(var data=await Send(HttpMethod.Get,route,access,null,ct).ConfigureAwait(false))
            {
                var root=data.RootElement;initial=MapForm(root);if(initial.Id!=formId)throw new IOException("Google no ha devuelto el formulario seleccionado.");publishedUri=Text(root,"responderUri");int index=Items(root).Count;
                foreach(var key in new[]{"code","title"})if(!initial.Fields.Any(f=>f.Key==key))
                {string title=Names.Single(n=>n[0]==key)[1];requests.Add(new{createItem=new{item=new{title,description="Identificación preparada por Nexo Centro. Se completa al abrir el enlace de la salida.",questionItem=new{question=new{required=true,textQuestion=new{paragraph=false}}}},location=new{index=index++}}});}
            }
            // Se añaden los dos identificadores; no se reemplazan preguntas, respuestas ni permisos.
            if(requests.Count>0)using(var saved=await Send(HttpMethod.Post,route+":batchUpdate",access,new{requests,includeFormInResponse=false},ct).ConfigureAwait(false)){}
            GoogleOfficialForm ready;bool publishNeeded=false;
            using(var current=await Send(HttpMethod.Get,route,access,null,ct).ConfigureAwait(false))
            {
                var mapped=MapForm(current.RootElement);mapped.Template=Prefill(Text(current.RootElement,"responderUri"),mapped);
                JsonElement publish,state,isPublished,isAccepting;if(current.RootElement.TryGetProperty("publishSettings",out publish)&&publish.TryGetProperty("publishState",out state))
                    publishNeeded=(state.TryGetProperty("isPublished",out isPublished)&&isPublished.ValueKind==JsonValueKind.False)||(state.TryGetProperty("isAcceptingResponses",out isAccepting)&&isAccepting.ValueKind==JsonValueKind.False);
                ready=mapped;
            }
            if(publishNeeded)using(var published=await Send(HttpMethod.Post,route+":setPublishSettings",access,new{publishSettings=new{publishState=new{isPublished=true,isAcceptingResponses=true}},updateMask="publishState"},ct).ConfigureAwait(false)){}
            return ready;
        }
        public async Task<GoogleOfficialPage> Responses(string access,GoogleOfficialForm form,string page,CancellationToken ct)
        {
            ValidateFormId(form.Id);if((page??"").Length>4000)throw new ArgumentException("Paginación de Google no válida.");
            string url="https://forms.googleapis.com/v1/forms/"+Uri.EscapeDataString(form.Id)+"/responses?pageSize=100"+(String.IsNullOrEmpty(page)?"":"&pageToken="+Uri.EscapeDataString(page));
            using(var data=await Send(HttpMethod.Get,url,access,null,ct).ConfigureAwait(false))
            {
                var result=new GoogleOfficialPage{NextPage=Text(data.RootElement,"nextPageToken")};JsonElement rows;if(!data.RootElement.TryGetProperty("responses",out rows))return result;
                foreach(var row in rows.EnumerateArray())
                {
                    JsonElement answers;bool has=row.TryGetProperty("answers",out answers);
                    Func<string,string> value=key=>{JsonElement a,text,list;if(!has||!answers.TryGetProperty(form.Question(key),out a)||!a.TryGetProperty("textAnswers",out text)||!text.TryGetProperty("answers",out list))return "";return String.Join("\n",list.EnumerateArray().Select(v=>Text(v,"value")));};
                    result.Responses.Add(new GoogleEvaluationResponse{ResponseId=Text(row,"responseId"),Code=value("code").Trim(),Title=value("title"),Date=value("date"),Group=value("group"),SubmittedUtc=Text(row,"lastSubmittedTime"),Memory=new ActivityMemory{Rating=value("rating"),Positives=value("positives"),Difficulties=value("difficulties"),Improvements=value("improvements"),Continuity=value("continuity").Trim(),Justification=value("justification")}});
                }
                return result;
            }
        }
    }
    public sealed class GoogleReconnectException:IOException {public GoogleReconnectException():base("Google necesita que vuelvas a pulsar Conectar con Google.") {}}
}
