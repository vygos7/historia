using System;
using System.Reflection;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace AgendaClara
{
    // Imagen incrustada en AgendaClara.exe: no depende de archivos externos.
    internal static class AppIcon
    {
        private static readonly ImageSource icon = Load();

        public static ImageSource Source { get { return icon; } }

        private static ImageSource Load()
        {
            using (var stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("AgendaClara.Assets.AgendaClara.png"))
            {
                if (stream == null) throw new InvalidOperationException("Falta el icono de Nexo Centro en los recursos del ejecutable.");
                var bitmap = BitmapFrame.Create(stream, BitmapCreateOptions.None, BitmapCacheOption.OnLoad);
                bitmap.Freeze();
                return bitmap;
            }
        }
    }
}
