using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace AgendaClara
{
    public sealed partial class Store
    {
        readonly IRemoteAgenda remote;
        public bool IsShared { get { return remote != null; } }
        public bool CanWrite { get { return remote == null || remote.CanWrite; } }
        public bool IsAdministrator { get { return remote != null && remote.IsAdmin; } }
        public string ConnectionStatus { get { return remote == null ? "Uso individual" : remote.Status; } }
        public event Action Changed { add { if (remote != null) remote.Changed += value; } remove { if (remote != null) remote.Changed -= value; } }
        public Store(IRemoteAgenda remote)
        {
            if (remote == null) throw new ArgumentNullException("remote"); this.remote = remote;
            DatabasePath = "Servidor local · " + remote.Status; BackupDirectory = "Copias gestionadas por el servidor";
        }
        public Store EditSession() { return remote == null ? this : new Store(remote.Fork()); }
        public void StampNew(AgendaEvent e)
        {
            if (remote == null) { e.Generation = ReadSetting("generation"); e.ConfigVersion = SettingNumber("config_version"); }
            else { var s = remote.Snapshot; e.Generation = s.Generation; e.ConfigVersion = s.ConfigVersion; }
        }
        AgendaCommand Command(string operation)
        {
            var s = remote.Snapshot; return new AgendaCommand { Operation = operation, Generation = s.Generation, ConfigVersion = s.ConfigVersion };
        }
        long SettingNumber(string key) { long value; return Int64.TryParse(ReadSetting(key), out value) ? value : 0; }
        public AgendaSnapshot LoadSnapshot()
        {
            if (remote != null) return remote.Snapshot;
            var s = new AgendaSnapshot { Generation = ReadSetting("generation"), Revision = SettingNumber("revision"), ConfigVersion = SettingNumber("config_version"), ServerUtc = DateTime.UtcNow, Events = AllEvents(), Categories = Categories(), Calendar = Calendar.Copy() };
            s.Calendar.ConfigVersion = s.ConfigVersion; return s;
        }
        public void ClaimForServer(string serverId) { WriteSetting("shared_owner", serverId); }
        public bool HasServerOwner { get { return ReadSetting("shared_owner").Length > 0; } }
        public string IntegrityCheck() { return Query("PRAGMA integrity_check", s => Text(s, 0)).Single(); }
        public void SetBackupDirectory(string path) { if (remote != null) throw new InvalidOperationException(); BackupDirectory = Path.GetFullPath(path); }
        public List<AuditRow> Audit(int limit)
        {
            return Query("SELECT revision,utc,actor,device,operation,entity FROM audit ORDER BY rowid DESC LIMIT ?", s => new AuditRow { Revision = Int(s, 0), Utc = DateTime.Parse(Text(s, 1), CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind), Actor = Text(s, 2), Device = Text(s, 3), Operation = Text(s, 4), Entity = Text(s, 5) }, Math.Min(Math.Max(limit, 1), 1000));
        }
        public AgendaReply Apply(AgendaCommand c, string actor, string device)
        {
            if (remote != null) throw new InvalidOperationException();
            Guid requestId;
            if (c == null || !Guid.TryParseExact(c.RequestId, "N", out requestId)) throw new ArgumentException("Identificador de operación no válido.");
            string hash;
            using (var sha = SHA256.Create()) hash = Convert.ToBase64String(sha.ComputeHash(Encoding.UTF8.GetBytes(XmlData.Write(c))));
            long resultId = 0;
            InTransaction(() =>
            {
                if (c.Generation != ReadSetting("generation")) throw new ConflictException("El servidor ha restaurado o sustituido sus datos. Vuelve a cargar la agenda antes de guardar.");
                var receipt = Query("SELECT actor,request_hash,result_id FROM shared_operations WHERE id=?", s => new[] { Text(s, 0), Text(s, 1), Int(s, 2).ToString(CultureInfo.InvariantCulture) }, c.RequestId).FirstOrDefault();
                if (receipt != null)
                {
                    if (receipt[0] != actor || receipt[1] != hash) throw new ConflictException("El identificador de operación ya corresponde a otra petición.");
                    resultId = Int64.Parse(receipt[2], CultureInfo.InvariantCulture); return;
                }
                if (c.ConfigVersion != SettingNumber("config_version")) throw new ConflictException("El calendario o las categorías han cambiado desde que abriste este formulario. Conserva tus anotaciones y vuelve a abrirlo con los datos actuales.");
                int categoryCountBefore = Categories().Count;
                switch (c.Operation)
                {
                    case "save":
                        if (c.Event == null || c.Event.Options == null || c.Event.Options.Memory == null || c.Event.Options.Tasks == null || c.Event.Options.Changes == null || c.Event.Options.SpecificDates == null || c.Event.Options.ExcludedDates == null) throw new ArgumentException("La actividad está incompleta.");
                        if (c.Event.Id != 0 && c.Event.Generation != c.Generation) throw new ConflictException("La actividad pertenece a otra generación de la agenda.");
                        Save(c.Event); resultId = c.Event.Id; break;
                    case "delete":
                        if (c.Event == null) throw new ArgumentException("Falta la actividad.");
                        var current = Find(c.Event.Id);
                        if (current == null || current.Version != c.Event.Version || c.Event.Generation != c.Generation) throw new ConflictException("La actividad ha cambiado o se ha eliminado. La eliminación no se ha aplicado.");
                        Delete(c.Event.Id); resultId = c.Event.Id; break;
                    case "category-add": AddCategory(c.A, c.B); break;
                    case "category-rename": RenameCategory(c.A, c.B); break;
                    case "category-color":
                        if (!CategoryPalette.Colors.Contains(c.B)) throw new ArgumentException("Color no válido."); SetCategoryColor(c.A, c.B); break;
                    case "category-move":
                        if (c.Number != -1 && c.Number != 1) throw new ArgumentException("Dirección no válida."); MoveCategory(c.A, c.Number); break;
                    case "category-delete": resultId = DeleteCategory(c.A, c.B); break;
                    case "calendar-save":
                        if (c.Calendar == null) throw new ArgumentException("Falta el calendario."); SaveCalendar(c.Calendar); break;
                    default: throw new ArgumentException("Operación no admitida.");
                }
                long rev = SettingNumber("revision") + 1;
                WriteSetting("revision", rev.ToString(CultureInfo.InvariantCulture));
                // A new category may also be created while saving an event.
                if ((c.Operation != "save" && c.Operation != "delete") || Categories().Count != categoryCountBefore) WriteSetting("config_version", (SettingNumber("config_version") + 1).ToString(CultureInfo.InvariantCulture));
                Execute("INSERT INTO shared_operations(id,actor,request_hash,result_id) VALUES(?,?,?,?)", c.RequestId, actor, hash, resultId);
                Execute("INSERT INTO audit(revision,utc,actor,device,operation,entity) VALUES(?,?,?,?,?,?)", rev, DateTime.UtcNow.ToString("o"), actor, device, c.Operation, resultId != 0 ? resultId.ToString(CultureInfo.InvariantCulture) : c.A);
            });
            return new AgendaReply { ResultId = resultId, Snapshot = LoadSnapshot() };
        }
        public OperationStatus OperationState(string id,string actor)
        { var result=Query("SELECT result_id FROM shared_operations WHERE id=? AND actor=?",s=>Int(s,0),id,actor); return new OperationStatus { Known=result.Count>0, ResultId=result.Count>0?result[0]:0, Snapshot=LoadSnapshot() }; }
        public void NewGeneration(string actor, string device)
        {
            InTransaction(() => {
                WriteSetting("generation", Guid.NewGuid().ToString("N"));
                WriteSetting("revision", (SettingNumber("revision") + 1).ToString(CultureInfo.InvariantCulture));
                WriteSetting("config_version", (SettingNumber("config_version") + 1).ToString(CultureInfo.InvariantCulture));
                Execute("DELETE FROM shared_operations");
                Execute("INSERT INTO audit VALUES(?,?,?,?,?,?)", SettingNumber("revision"), DateTime.UtcNow.ToString("o"), actor, device, "restore", "agenda");
            });
        }
        public void LogAdministration(string actor, string device, string operation, string entity)
        {
            Execute("INSERT INTO audit VALUES(?,?,?,?,?,?)", SettingNumber("revision"), DateTime.UtcNow.ToString("o"), actor, device, operation, entity);
        }
        public static void CopyReadOnly(string sourcePath, string destinationPath)
        {
            if (File.Exists(destinationPath)) throw new IOException("El destino de importación ya existe.");
            var info = Inspect(sourcePath); if (info.Error.Length != 0) throw new IOException(info.Error);
            IntPtr source = OpenReadOnly(sourcePath), destination = IntPtr.Zero, backup = IntPtr.Zero;
            try
            {
                if (sqlite3_open16(Path.GetFullPath(destinationPath), out destination) != SQLITE_OK) throw new IOException("No se puede crear el destino.");
                backup = sqlite3_backup_init(destination, "main", source, "main");
                if (backup == IntPtr.Zero) throw new IOException("No se puede iniciar la copia consistente.");
                int code = sqlite3_backup_step(backup, -1); int end = sqlite3_backup_finish(backup); backup = IntPtr.Zero;
                if (code != SQLITE_DONE || end != SQLITE_OK) throw new IOException("La copia consistente no se ha completado.");
            }
            finally { if (backup != IntPtr.Zero) sqlite3_backup_finish(backup); if (destination != IntPtr.Zero) sqlite3_close(destination); sqlite3_close(source); }
        }
    }
}
