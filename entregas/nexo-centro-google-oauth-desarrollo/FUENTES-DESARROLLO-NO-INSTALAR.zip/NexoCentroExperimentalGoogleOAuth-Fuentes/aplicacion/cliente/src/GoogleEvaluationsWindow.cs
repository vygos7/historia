using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Threading;
namespace AgendaClara
{
    public sealed class GoogleEvaluationsWindow:Window
    {
        readonly Store store;readonly RemoteConnection remote;readonly GoogleOfficialCoordinator local;readonly GoogleDesktopConnect desktop;
        readonly CancellationTokenSource closing=new CancellationTokenSource();readonly DispatcherTimer timer=new DispatcherTimer{Interval=TimeSpan.FromSeconds(2)};
        readonly TextBlock account=Theme.Text("",14,Theme.Ink),form=Theme.Text("",14,Theme.Ink),status=Theme.Text("",14,Theme.AccentDark),instruction=Theme.Text("",13,Theme.Muted);
        readonly Button connect,choose,copy,check,review,disconnect;readonly ComboBox activity=new ComboBox{MinWidth=320},when=new ComboBox{MinWidth=130,Margin=new Thickness(8,0,0,0)};
        readonly TextBox link=new TextBox{IsReadOnly=true,TextWrapping=TextWrapping.Wrap,MinHeight=55,Visibility=Visibility.Collapsed};
        readonly DataGrid rows=new DataGrid{AutoGenerateColumns=false,IsReadOnly=true,CanUserAddRows=false,MinHeight=140,MaxHeight=240};
        GoogleOfficialStatus current=new GoogleOfficialStatus();bool working,refreshing;long initial;string rowSignature="";DateTime lastSync;
        sealed class Choice{public AgendaEvent Event;public override string ToString(){return Format.Date(Event.Start)+" · "+Event.Title+" · "+Event.Options.Group;}}
        public GoogleEvaluationsWindow(Store store,long eventId=0)
        {
            this.store=store;initial=eventId;remote=store.IsShared?SharedRuntime.Connection:null;Theme.ApplyWindow(this);Title="Evaluaciones de salidas · Nexo Centro 4.2.0 EXPERIMENTAL";
            Width=980;Height=780;MinWidth=760;MinHeight=550;WindowStartupLocation=WindowStartupLocation.CenterOwner;
            var body=new StackPanel{Margin=new Thickness(24)};body.Children.Add(Theme.Text("Evaluaciones de salidas",25,Theme.Ink,true));body.Children.Add(Theme.Text("Conecta tu formulario una vez. Después, elige una salida y copia el enlace para el docente.",14,Theme.Muted));
            if(store.IsShared&&(remote==null||!remote.IsAdmin)){body.Children.Add(Theme.Text("La conexión con Google la realiza la persona administradora de la agenda.",15,Theme.Warning));Content=body;return;}
            var registration=GoogleAppRegistration.Load();string root=remote==null?Path.GetDirectoryName(store.DatabasePath):Path.GetDirectoryName(SharedRuntime.ConfigurationPath);
            if(remote==null)local=GoogleLocalRuntime.Ensure(store);desktop=new GoogleDesktopConnect(registration,root);
            body.Children.Add(Theme.Text("1. Conecta tu cuenta",18,Theme.Ink,true));body.Children.Add(account);
            connect=Theme.Button("Conectar con Google",async()=>await Run(Connect));body.Children.Add(connect);
            body.Children.Add(Theme.Text("2. Elige tu formulario",18,Theme.Ink,true));body.Children.Add(form);
            choose=Theme.Button("Elegir formulario",async()=>await Run(Choose));body.Children.Add(choose);
            body.Children.Add(Theme.Text("El programa prepara los datos de la actividad en el formulario elegido. Se conservarán sus preguntas y restricciones de acceso.",12,Theme.Muted));
            body.Children.Add(Theme.Text("3. Copia el enlace de la salida",18,Theme.Ink,true));var selector=new WrapPanel();selector.Children.Add(activity);selector.Children.Add(when);body.Children.Add(selector);body.Children.Add(instruction);
            copy=Theme.Button("Copiar enlace para el docente",async()=>await Run(CopyLink));body.Children.Add(copy);body.Children.Add(link);
            body.Children.Add(Theme.Text("Evaluaciones recibidas",18,Theme.Ink,true));body.Children.Add(Theme.Text("Las respuestas válidas completan automáticamente las memorias vacías. Las que necesitan revisión aparecen en esta lista.",12,Theme.Muted));
            foreach(var column in new[]{new[]{"Estado","Status"},new[]{"Salida","Response.Title"},new[]{"Fecha","Response.Date"},new[]{"Grupo","Response.Group"},new[]{"Revisión","Reason"}})rows.Columns.Add(new DataGridTextColumn{Header=column[0],Binding=new Binding(column[1]),Width=new DataGridLength(column[1]=="Reason"?2:1,DataGridLengthUnitType.Star)});
            body.Children.Add(rows);var controls=new WrapPanel();check=Theme.Button("Comprobar ahora",async()=>await Run(CheckNow));review=Theme.Button("Revisar respuesta",async()=>await Run(Review));controls.Children.Add(check);controls.Children.Add(review);body.Children.Add(controls);body.Children.Add(status);
            disconnect=Theme.Button("Desconectar Google",async()=>await Run(Disconnect));var bottom=new WrapPanel();bottom.Children.Add(disconnect);bottom.Children.Add(Theme.Button("Cerrar",Close));body.Children.Add(bottom);
            Content=new ScrollViewer{Content=body,VerticalScrollBarVisibility=ScrollBarVisibility.Auto,HorizontalScrollBarVisibility=ScrollBarVisibility.Disabled};
            AutomationProperties.SetName(activity,"Salida guardada");AutomationProperties.SetName(when,"Fecha de la salida");AutomationProperties.SetName(link,"Enlace para el docente");
            activity.SelectionChanged+=(s,e)=>{var item=activity.SelectedItem as Choice;when.ItemsSource=item==null?new string[0]:Planning.All(item.Event,store.Calendar).Select(o=>Format.Date(o.Date)).ToArray();when.SelectedIndex=0;link.Text="";link.Visibility=Visibility.Collapsed;UpdateButtons();};when.SelectionChanged+=(s,e)=>UpdateButtons();
            rows.SelectionChanged+=(s,e)=>UpdateButtons();
            Loaded+=async(s,e)=>{await Refresh();timer.Start();};timer.Tick+=async(s,e)=>await Refresh();Closed+=(s,e)=>{timer.Stop();closing.Cancel();};
        }
        async Task Run(Func<Task> action)
        {
            if(working)return;working=true;UpdateButtons();
            try{await action();}catch(OperationCanceledException){if(!closing.IsCancellationRequested)status.Text="La conexión no se completó. Puedes volver a intentarlo.";}
            catch(Exception ex){status.Text=ex is IOException||ex is ArgumentException||ex is InvalidOperationException?ex.Message:"La conexión con Google no se pudo completar. La agenda conserva sus datos.";}
            finally{working=false;UpdateButtons();}
        }
        void UpdateButtons()
        {
            if(connect==null)return;bool enabled=!working&&!current.Busy;
            connect.IsEnabled=enabled&&current.ApplicationPrepared;choose.IsEnabled=enabled&&current.Connected;
            var selected=activity.SelectedItem as Choice;bool group=selected!=null&&!String.IsNullOrWhiteSpace(selected.Event.Options.Group);
            copy.IsEnabled=enabled&&current.FormReady&&group&&when.SelectedItem!=null;check.IsEnabled=enabled&&current.FormReady;review.IsEnabled=enabled&&rows.SelectedItem!=null;disconnect.IsEnabled=enabled&&current.Connected;
            instruction.Text=selected==null?"Selecciona una salida guardada.":!group?"Completa el grupo en la ficha de la salida y guarda sus cambios.":"El nombre, la fecha y el grupo se rellenarán automáticamente en el formulario.";
        }
        async Task Refresh()
        {
            if(refreshing||closing.IsCancellationRequested)return;refreshing=true;
            try
            {
                var state=remote==null?local.Status():await remote.Admin<GoogleOfficialStatus>("GET","api/admin/google");current=state;
                account.Text=state.Connected?"Cuenta conectada: "+state.AccountLabel:"Conecta la cuenta que administra el formulario.";
                form.Text=state.FormReady?state.FormName:"Todavía no has elegido un formulario.";
                status.Text=state.Error.Length>0?state.Error:state.Message;
                if(state.LastPollUtc!=lastSync&&state.LastPollUtc!=DateTime.MinValue){lastSync=state.LastPollUtc;if(remote!=null)await remote.SynchronizeAsync();}
                string signature=GoogleEvaluationRules.Hash(XmlData.Write(state.Items));if(signature!=rowSignature){var previous=rows.SelectedItem as GoogleEvaluationItem;rows.ItemsSource=state.Items;if(previous!=null)rows.SelectedItem=state.Items.FirstOrDefault(r=>r.Id==previous.Id);rowSignature=signature;}
                if(activity.Items.Count==0)FillActivities();UpdateButtons();
            }
            catch(Exception ex){status.Text=ex is IOException||ex is ArgumentException?ex.Message:"No se pudo actualizar la conexión con Google.";}
            finally{refreshing=false;}
        }
        void FillActivities(){long id=activity.SelectedItem is Choice?((Choice)activity.SelectedItem).Event.Id:initial;var choices=store.AllEvents().OrderByDescending(e=>e.Start).Select(e=>new Choice{Event=e}).ToList();activity.ItemsSource=choices;activity.SelectedItem=choices.FirstOrDefault(c=>c.Event.Id==id)??choices.FirstOrDefault();}
        async Task Connect()
        {
            status.Text="Se abrirá Google para que elijas tu cuenta y aceptes el permiso.";var tokens=await desktop.Connect(closing.Token);
            if(remote==null)local.Connect(tokens);else await remote.Admin<GoogleOfficialStatus>("POST","api/admin/google/connect",tokens);await Refresh();
        }
        async Task Choose()
        {
            status.Text="Elige tu formulario en la ventana de Google.";string id=await desktop.ChooseForm(current.AccountId,closing.Token);if(String.IsNullOrEmpty(id))return;
            if(!Dialogs.Confirm(this,"Usar este formulario","Nexo Centro preparará el formulario elegido para recibir evaluaciones: añadirá el código y el nombre de la actividad y lo activará si está cerrado. Conservará las preguntas, las respuestas y las restricciones de acceso actuales.","Usar este formulario"))return;
            var request=new GoogleChooseForm{FormId=id};if(remote==null)local.Choose(request);else await remote.Admin<GoogleOfficialStatus>("POST","api/admin/google/form",request);await Refresh();
        }
        async Task CopyLink()
        {
            var selected=activity.SelectedItem as Choice;if(selected==null||when.SelectedItem==null)return;
            var request=new GoogleLinkRequest{EventId=selected.Event.Id,Date=(string)when.SelectedItem};var result=remote==null?local.Link(request):await remote.Admin<GoogleEvaluationLink>("POST","api/admin/google/link",request);
            Clipboard.SetText(result.Url);link.Text=result.Url;link.Visibility=Visibility.Visible;status.Text="Enlace copiado. Ya puedes enviárselo al docente.";if(remote!=null)await remote.SynchronizeAsync();FillActivities();
        }
        async Task CheckNow(){if(remote==null)local.Poll();else await remote.Admin<GoogleOfficialStatus>("POST","api/admin/google/check");await Refresh();}
        async Task Review()
        {
            var item=rows.SelectedItem as GoogleEvaluationItem;if(item==null||item.Status=="Aplicada")return;
            var selected=activity.SelectedItem as Choice;long id=item.EventId>0?item.EventId:selected==null?0:selected.Event.Id;var e=store.Find(id);if(e==null)throw new ArgumentException("Selecciona la salida a la que corresponde la respuesta.");
            var m=item.Response.Memory??new ActivityMemory();string summary="SALIDA: "+e.Title+" · "+Format.Date(e.Start)+" · "+e.Options.Group+"\n\nRESPUESTA: "+item.Response.Title+" · "+item.Response.Date+" · "+item.Response.Group+"\n\nValoración: "+m.Rating+"\n\nAspectos positivos: "+m.Positives+"\n\nDificultades: "+m.Difficulties+"\n\nMejoras: "+m.Improvements+"\n\nContinuidad: "+m.Continuity+"\n\nJustificación: "+m.Justification+"\n\nMotivo de revisión: "+item.Reason;
            if(!Dialogs.Confirm(this,"Revisar evaluación",summary,"Confirmar y guardar memoria"))return;bool overwrite=e.Options.Memory.HasContent;if(overwrite&&!Dialogs.Confirm(this,"Sustituir memoria","La salida ya tiene una memoria. Confirma su sustitución por esta respuesta.","Sustituir memoria"))return;
            var request=new GoogleEvaluationApply{ItemId=item.Id,EventId=e.Id,ExpectedVersion=e.Version,ConfirmAssignment=true,ConfirmOverwrite=overwrite};if(remote==null)local.Apply(request);else await remote.Admin<GoogleOfficialStatus>("POST","api/admin/google/apply",request);await Refresh();
        }
        async Task Disconnect(){if(!Dialogs.Confirm(this,"Desconectar Google","Se detendrá la recogida de evaluaciones. Las memorias que ya están en la agenda se conservarán.","Desconectar"))return;if(remote==null)local.Disconnect();else await remote.Admin<GoogleOfficialStatus>("POST","api/admin/google/disconnect");await Refresh();}
    }
}
