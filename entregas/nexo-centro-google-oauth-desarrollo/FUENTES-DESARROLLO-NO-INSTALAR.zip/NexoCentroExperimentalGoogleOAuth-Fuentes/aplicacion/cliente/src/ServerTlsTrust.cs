using System;
using System.Linq;
using System.Net.Security;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;

namespace AgendaClara
{
    internal static class ServerTlsTrust
    {
        // Vacío significa válido. Se conserva la política anterior del cliente, incluido
        // el anclaje a la CA concreta y la comprobación de identidad que hace SslStream.
        internal static string Check(string authority,X509Certificate2 certificate,SslPolicyErrors errors)
        {
            if(certificate==null)return "handshake";
            if((errors&SslPolicyErrors.RemoteCertificateNameMismatch)!=0)return "name";
            if(DateTime.UtcNow<certificate.NotBefore.ToUniversalTime() || DateTime.UtcNow>certificate.NotAfter.ToUniversalTime())return "expired";
            if(authority.Length==0)return errors==SslPolicyErrors.None?"":"untrusted";
            try
            {
#if NETFRAMEWORK
                using(var root=new X509Certificate2(Convert.FromBase64String(authority)))
#else
                using(var root=X509CertificateLoader.LoadCertificate(Convert.FromBase64String(authority)))
#endif
                using(var chain=new X509Chain())
                {
                    if(!root.Extensions.OfType<X509BasicConstraintsExtension>().Any(e=>e.CertificateAuthority))return "untrusted";
                    chain.ChainPolicy.ExtraStore.Add(root);chain.ChainPolicy.RevocationMode=X509RevocationMode.NoCheck;
                    chain.ChainPolicy.VerificationFlags=X509VerificationFlags.AllowUnknownCertificateAuthority;
                    chain.ChainPolicy.ApplicationPolicy.Add(new Oid("1.3.6.1.5.5.7.3.1"));
                    bool valid=chain.Build(certificate) && chain.ChainElements[chain.ChainElements.Count-1].Certificate.RawData.SequenceEqual(root.RawData);
                    return valid?"":chain.ChainStatus.Any(s=>(s.Status&X509ChainStatusFlags.NotTimeValid)!=0)?"expired":"untrusted";
                }
            }
            catch(CryptographicException){return "untrusted";}
            catch(FormatException){return "untrusted";}
        }
    }
}
