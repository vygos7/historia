using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Google.Apis.Auth.OAuth2;
using Google.Apis.Auth.OAuth2.Requests;
using Google.Apis.Auth.OAuth2.Responses;
namespace AgendaClara
{
    // Adaptador del SDK: callback sin HTTP.sys ni permisos de administrador, con estado de un solo uso.
    public sealed class GoogleLoopbackReceiver:ICodeReceiver,IDisposable
    {
        readonly TcpListener listener;readonly Action<string> open;readonly string path;readonly int port;bool received;
        public string RedirectUri {get;private set;}
        public GoogleLoopbackReceiver(Action<string> open=null)
        {this.open=open??(u=>System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(u){UseShellExecute=true}));listener=new TcpListener(IPAddress.Loopback,0);listener.Start();port=((IPEndPoint)listener.LocalEndpoint).Port;path="/authorize-"+Guid.NewGuid().ToString("N")+"/";RedirectUri="http://127.0.0.1:"+port+path;}
        public async Task<AuthorizationCodeResponseUrl> ReceiveCodeAsync(AuthorizationCodeRequestUrl url,CancellationToken cancellationToken)
        {
            if(received)throw new InvalidOperationException("La autorización ya se ha utilizado.");received=true;
            if(String.IsNullOrEmpty(url.State))url.State=Guid.NewGuid().ToString("N");string expected=url.State;
            using(var timeout=CancellationTokenSource.CreateLinkedTokenSource(cancellationToken))
            {timeout.CancelAfter(TimeSpan.FromMinutes(5));using(timeout.Token.Register(()=>listener.Stop()))
             try
             {
                open(url.Build().AbsoluteUri);
                for(int count=0;count<40;count++)
                {
                    TcpClient client;try{client=await listener.AcceptTcpClientAsync().ConfigureAwait(false);}catch(Exception)when(timeout.IsCancellationRequested){throw new OperationCanceledException(timeout.Token);}
                    using(client)using(var stream=client.GetStream())using(var budget=CancellationTokenSource.CreateLinkedTokenSource(timeout.Token))
                    {budget.CancelAfter(TimeSpan.FromSeconds(5));using(budget.Token.Register(()=>client.Close()))
                     {
                        var bytes=new MemoryStream();byte[] b=new byte[1];bool complete=false;
                        while(bytes.Length<16384){if(await stream.ReadAsync(b,0,1,budget.Token).ConfigureAwait(false)==0)break;bytes.WriteByte(b[0]);if(bytes.Length>=4){var data=bytes.GetBuffer();int n=(int)bytes.Length;if(data[n-4]==13&&data[n-3]==10&&data[n-2]==13&&data[n-1]==10){complete=true;break;}}}
                        var lines=Encoding.ASCII.GetString(bytes.ToArray()).Split(new[]{"\r\n"},StringSplitOptions.None);var first=lines[0].Split(' ');
                        if(!complete||first.Length!=3||first[0]!="GET"||!lines.Any(h=>h.Equals("Host: 127.0.0.1:"+port,StringComparison.OrdinalIgnoreCase))){await Reply(stream,403,budget.Token);continue;}
                        Uri callback;if(!Uri.TryCreate("http://127.0.0.1:"+port+first[1],UriKind.Absolute,out callback)||callback.AbsolutePath!=path){await Reply(stream,403,budget.Token);continue;}
                        var values=new Dictionary<string,string>();bool duplicate=false;
                        foreach(string pair in callback.Query.TrimStart('?').Split('&')){int index=pair.IndexOf('=');if(index<0)continue;string k=WebUtility.UrlDecode(pair.Substring(0,index)),v=WebUtility.UrlDecode(pair.Substring(index+1));if(values.ContainsKey(k)){duplicate=true;break;}values.Add(k,v);}
                        string state;if(duplicate||!values.TryGetValue("state",out state)||!Same(expected,state)){await Reply(stream,403,budget.Token);continue;}
                        string code,error;values.TryGetValue("code",out code);values.TryGetValue("error",out error);
                        if(String.IsNullOrWhiteSpace(code)&&String.IsNullOrWhiteSpace(error)||code!=null&&code.Length>8000||error!=null&&error.Length>100){await Reply(stream,403,budget.Token);continue;}
                        await Reply(stream,200,budget.Token);return new AuthorizationCodeResponseUrl{Code=code,Error=error,State=state};
                     }}
                }
                throw new IOException("No se pudo completar la autorización de Google. Vuelve a intentarlo.");
             }
             finally{listener.Stop();}}
        }
        static bool Same(string a,string b){if(a==null||b==null)return false;int result=a.Length^b.Length;for(int i=0;i<Math.Max(a.Length,b.Length);i++)result|=(i<a.Length?a[i]:0)^(i<b.Length?b[i]:0);return result==0;}
        static async Task Reply(Stream s,int code,CancellationToken ct)
        {byte[] body=Encoding.UTF8.GetBytes(code==200?"<!doctype html><meta charset='utf-8'><title>Nexo Centro</title><p>Vuelve a Nexo Centro. Puedes cerrar esta pestaña.</p>":"Solicitud no autorizada.");byte[] header=Encoding.ASCII.GetBytes("HTTP/1.1 "+code+" "+(code==200?"OK":"Forbidden")+"\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: "+body.Length+"\r\nCache-Control: no-store\r\nReferrer-Policy: no-referrer\r\nContent-Security-Policy: default-src 'none'\r\nConnection: close\r\n\r\n");await s.WriteAsync(header,0,header.Length,ct).ConfigureAwait(false);await s.WriteAsync(body,0,body.Length,ct).ConfigureAwait(false);}
        public void Dispose(){listener.Stop();}
    }
}
