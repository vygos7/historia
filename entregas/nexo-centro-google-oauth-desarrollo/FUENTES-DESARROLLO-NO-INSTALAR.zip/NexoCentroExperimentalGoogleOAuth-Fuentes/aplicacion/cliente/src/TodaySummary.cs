using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Media;

namespace AgendaClara
{
    // What the daily summary shows; filled from the same database and rules as the agenda.
    public sealed class DaySummary
    {
        public DateTime Date;
        public string Reason = "";
        public string Term = "";
        public List<Occurrence> Items = new List<Occurrence>();
        public Dictionary<string, string> Colors = new Dictionary<string, string>();

        // Reads only; nothing is written to the agenda.
        public static DaySummary Load(Store store, DateTime date)
        {
            var snapshot = store.LoadSnapshot(); var events = snapshot.Events;
            var s = new DaySummary { Date = date.Date, Reason = snapshot.Calendar.Reason(date), Term = snapshot.Calendar.Term(date) };
            s.Items = Planning.Day(events, date, snapshot.Calendar);
            foreach (var c in snapshot.Categories) s.Colors[c.Name] = c.Color;
            return s;
        }
    }

    public sealed class TodaySummaryWindow : Window
    {
        Action reloadContent;
        readonly TextBlock networkStatus = Theme.Text("", 12, Theme.Warning);
        public bool OpenAgendaRequested { get; private set; }
        public bool LoadFailed { get; private set; }
        public int ItemCount { get; private set; }

        public TodaySummaryWindow(Store store, DateTime date) : this(() => DaySummary.Load(store, date), date, store.DatabasePath)
        {
            Action update = () => Dispatcher.BeginInvoke(new Action(() => { networkStatus.Text = store.IsShared ? store.ConnectionStatus : ""; reloadContent(); }));
            store.Changed += update; Closed += (s, e) => store.Changed -= update; networkStatus.Text = store.IsShared ? store.ConnectionStatus : "";
        }

        // databasePath: the agenda that Windows will open at sign-in if «Mostrar al iniciar Windows» is ticked.
        internal TodaySummaryWindow(Func<DaySummary> load, DateTime date, string databasePath = null)
        {
            Dialogs.Setup(this, "Tu agenda de hoy", 500, 620, 380, 340);
            ResizeMode = ResizeMode.CanResizeWithGrip;
            Topmost = false;
            var p = new StackPanel { Margin = new Thickness(24, 24, 24, 16) };
            p.Children.Add(Theme.Text("Tu agenda de hoy", 25, Theme.Ink, true));
            var when = Theme.Text(Format.LongDate(date), 15, Theme.AccentDark, true); when.Margin = new Thickness(0, 2, 0, 10);
            AutomationProperties.SetName(when, "Fecha del resumen");
            p.Children.Add(when);

            p.Children.Add(networkStatus);
            int fixedCount = p.Children.Count;
            reloadContent = () => {
                while (p.Children.Count > fixedCount) p.Children.RemoveAt(p.Children.Count - 1);
                LoadFailed = false; ItemCount = 0;
            DaySummary summary = null;
            try { summary = load(); }
            catch (Exception ex)
            {
                LoadFailed = true;
                var notice = Theme.Notice("No se han podido leer los datos de la agenda, así que este resumen no puede indicar qué hay previsto hoy. Esto no significa que no haya actividades: ábrela más tarde o consulta la agenda.\n\nDetalle: " + ex.Message, Theme.DangerSoft, Theme.Danger);
                AutomationProperties.SetName(notice, "Error de lectura");
                p.Children.Add(notice);
            }

            if (summary != null)
            {
                if (summary.Term.Length > 0 && summary.Reason.Length == 0) p.Children.Add(Theme.Text(summary.Term, 12.5, Theme.Muted));
                if (summary.Reason.Length > 0)
                    p.Children.Add(Theme.Notice("Día no lectivo: " + summary.Reason + "." + (summary.Items.Count > 0 ? " Solo se muestran las actividades autorizadas expresamente para este día." : ""), Theme.NonSchool, Theme.NonSchoolInk));
                ItemCount = summary.Items.Count;
                if (summary.Items.Count == 0)
                {
                    var empty = Theme.Text("Hoy no tienes actividades programadas", 15, Theme.Muted); empty.Margin = new Thickness(0, 12, 0, 0);
                    p.Children.Add(empty);
                }
                else
                {
                    var count = Theme.Text(Format.Count(summary.Items.Count, "actividad", "actividades"), 12.5, Theme.Muted); count.Margin = new Thickness(0, 4, 0, 8);
                    p.Children.Add(count);
                    foreach (var o in summary.Items) p.Children.Add(Item(o, summary));
                }
            }

            };
            reloadContent();

            var buttons = new WrapPanel { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center };
            var close = Theme.Button("Cerrar", Close); close.Margin = new Thickness(0, 0, 8, 0); close.MinWidth = 90;
            var open = Theme.Button("Abrir agenda", () => { OpenAgendaRequested = true; Close(); }, "Primary"); open.MinWidth = 120;
            buttons.Children.Add(close); buttons.Children.Add(open);
            var bottom = new Grid();
            bottom.ColumnDefinitions.Add(new ColumnDefinition());
            bottom.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            if (databasePath != null) bottom.Children.Add(StartupOption(databasePath));
            Grid.SetColumn(buttons, 1); bottom.Children.Add(buttons);
            Dialogs.Layout(this, p, bottom);
            Loaded += (s, e) => close.Focus();
        }

        CheckBox StartupOption(string databasePath)
        {
            var check = new CheckBox { Content = Theme.Text("Mostrar al iniciar Windows", 12.5, Theme.Ink), VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 12, 0), ToolTip = "Abre este resumen automáticamente cada vez que inicies sesión en Windows. Viene activado de serie y no necesita permisos de administrador. Desmárcalo para dejar de verlo." };
            AutomationProperties.SetName(check, "Mostrar al iniciar Windows");
            try { check.IsChecked = Startup.IsEnabled; } catch (Exception) { check.IsChecked = false; }
            bool reverting = false;
            RoutedEventHandler changed = (s, e) =>
            {
                if (reverting) return;
                bool on = check.IsChecked == true;
                try { if (on) Startup.Enable(databasePath); else Startup.Disable(); }
                catch (Exception ex)
                {
                    reverting = true; check.IsChecked = !on; reverting = false;
                    Dialogs.Info(this, "No se pudo cambiar el inicio automático", "Windows no ha permitido " + (on ? "activar" : "desactivar") + " el resumen al iniciar sesión. El resto de la agenda funciona con normalidad.\n\nDetalle: " + ex.Message);
                }
            };
            check.Checked += changed; check.Unchecked += changed;
            return check;
        }

        static FrameworkElement Item(Occurrence o, DaySummary summary)
        {
            var e = o.View;
            string color;
            if (!summary.Colors.TryGetValue(e.Options.Category, out color) || String.IsNullOrEmpty(color)) color = CategoryPalette.DefaultColor(e.Options.Category) ?? "#66747B";
            var body = new StackPanel { Margin = new Thickness(14, 12, 12, 13) };
            body.Children.Add(Theme.Text(e.TimeLabel, 12.5, Theme.AccentDark, true));
            body.Children.Add(Theme.Text(e.Title, 14.5, Theme.Ink, true));
            var category = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 3, 0, 0) };
            category.Children.Add(Theme.Swatch(color, 11));
            category.Children.Add(new TextBlock { Text = e.Options.Category, FontSize = 12, Foreground = Theme.Shade(color, 0.25), FontWeight = FontWeights.SemiBold, Margin = new Thickness(6, 0, 0, 0), VerticalAlignment = VerticalAlignment.Center });
            body.Children.Add(category);
            var extra = new List<string>();
            if (!String.IsNullOrWhiteSpace(e.Options.Group)) extra.Add("Grupos: " + e.Options.Group.Trim());
            if (!String.IsNullOrWhiteSpace(e.Options.Location)) extra.Add("Lugar: " + e.Options.Location.Trim());
            if (!String.IsNullOrWhiteSpace(e.Options.Responsible)) extra.Add("Responsable: " + e.Options.Responsible.Trim());
            if (extra.Count > 0)
            {
                var t = Theme.Text(String.Join(" · ", extra), 12, Theme.Muted);
                t.TextWrapping = TextWrapping.NoWrap; t.TextTrimming = TextTrimming.CharacterEllipsis; t.ToolTip = String.Join("\n", extra);
                body.Children.Add(t);
            }
            if (o.Moved) body.Children.Add(Theme.Pill("Trasladada desde el " + Format.Date(o.OriginalDate), Theme.WarningSoft, Theme.Warning));
            else if (o.Changed) body.Children.Add(Theme.Pill("Cambios solo en esta fecha", Theme.WarningSoft, Theme.Warning));
            if (summary.Reason.Length > 0) body.Children.Add(Theme.Pill("Excepción: día no lectivo", Theme.NonSchool, Theme.NonSchoolInk));
            var grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(5) });
            grid.ColumnDefinitions.Add(new ColumnDefinition());
            grid.Children.Add(new Border { Background = Theme.Tint(color, 0), CornerRadius = new CornerRadius(6, 0, 0, 6) });
            Grid.SetColumn(body, 1); grid.Children.Add(body);
            var card = new Border { Background = Theme.Surface, BorderBrush = Theme.Line, BorderThickness = new Thickness(1), CornerRadius = new CornerRadius(10), Child = grid, Margin = new Thickness(0, 0, 0, 7) };
            AutomationProperties.SetName(card, "Resumen: " + e.TimeLabel + ", " + e.Title + ", " + e.Options.Category);
            return card;
        }
    }
}
