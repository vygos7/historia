using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Security.Cryptography;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
namespace AgendaClara
{
    public static class GoogleLocalRuntime
    {
        sealed class Local:IDisposable
        {
            public GoogleOfficialCoordinator Controller;public HttpClient Http;public CancellationTokenSource Cancel=new CancellationTokenSource();
            public void Dispose(){Cancel.Cancel();Controller.Dispose();}
        }
        static readonly Dictionary<string,Local> instances=new Dictionary<string,Local>();
        public static event Action<string> Changed;
        public static GoogleOfficialCoordinator Ensure(Store store)
        {
            Local local;if(instances.TryGetValue(store.DatabasePath,out local))return local.Controller;
            string root=Path.GetDirectoryName(store.DatabasePath);ExperimentalIsolation.PathForWrite(root);var registration=GoogleAppRegistration.Load();
            local=new Local{Http=new HttpClient(new HttpClientHandler{AllowAutoRedirect=false})};var selected=local;
            var dispatcher=Application.Current.Dispatcher;
            local.Controller=new GoogleOfficialCoordinator(root,registration,new GoogleOfficialApi(local.Http,registration),new GoogleEncryptedTokenVault(root,b=>ProtectedData.Protect(b,null,DataProtectionScope.CurrentUser),b=>ProtectedData.Unprotect(b,null,DataProtectionScope.CurrentUser),SharedConfiguration.Atomic),()=>store,new object(),c=>store.Apply(c,GoogleEvaluationManager.Actor,"google-local"),SharedConfiguration.Atomic,
                action=>dispatcher.InvokeAsync(()=>{selected.Cancel.Token.ThrowIfCancellationRequested();return action();}).Task,
                ()=>dispatcher.BeginInvoke(new Action(()=>{var handler=Changed;if(handler!=null&&!selected.Cancel.IsCancellationRequested)handler(store.DatabasePath);}))) ;
            instances.Add(store.DatabasePath,local);Observe(local.Controller.Run(local.Cancel.Token));
            Application.Current.Exit+=(s,e)=>selected.Dispose();return local.Controller;
        }
        static async void Observe(Task task){try{await task;}catch(OperationCanceledException){}catch(Exception){}}
        public static void Stop(Store store){Local local;if(instances.TryGetValue(store.DatabasePath,out local)){local.Dispose();instances.Remove(store.DatabasePath);}}
    }
}
