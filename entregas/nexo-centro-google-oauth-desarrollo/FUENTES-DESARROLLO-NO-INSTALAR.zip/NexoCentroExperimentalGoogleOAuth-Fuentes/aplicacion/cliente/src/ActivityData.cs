using System;
using System.Collections.Generic;
using System.Linq;

namespace AgendaClara
{
    public class PreparationTask
    {
        public string Description { get; set; }
        public string Responsible { get; set; }
        public DateTime? Due { get; set; }
        public bool Completed { get; set; }
        public bool Attention { get; set; }
        public PreparationTask() { Description = ""; Responsible = ""; }
    }
    public class ActivityMemory
    {
        public string Rating = "", Positives = "", Difficulties = "", Improvements = "", Justification = "";
        public string Continuity = "";
        public DateTime? Updated;
        public bool HasContent { get { return new[] { Rating, Positives, Difficulties, Improvements, Justification, Continuity }.Any(x => !String.IsNullOrWhiteSpace(x)); } }
        public void Validate()
        {
            if (Continuity != "" && Continuity != "Sí" && Continuity != "No") throw new ArgumentException("Elige Sí o No para la continuidad.");
            if (HasContent && (String.IsNullOrWhiteSpace(Rating) || String.IsNullOrWhiteSpace(Continuity) || String.IsNullOrWhiteSpace(Justification)))
                throw new ArgumentException("La memoria necesita valoración general, continuidad (Sí / No) y justificación.");
        }
    }
    public static class ActivityHistory
    {
        public static string Key(AgendaEvent e) { return Normalize(String.IsNullOrWhiteSpace(e.Options.HistoryKey) ? e.Title : e.Options.HistoryKey); }
        static string Normalize(string s) { return String.Join(" ", (s ?? "").Trim().ToUpperInvariant().Split(new[] {' ', '\t', '\r', '\n'}, StringSplitOptions.RemoveEmptyEntries)); }
        public static List<AgendaEvent> Related(IEnumerable<AgendaEvent> all, AgendaEvent e)
        { return all.Where(x => x.Id != e.Id && x.Start < e.Start && Key(x) == Key(e) && x.Options.Memory.HasContent).OrderByDescending(x => x.Start).ToList(); }
        public static int AttentionCount(AgendaEvent e, DateTime today)
        { return e.Options.Tasks.Count(t => !t.Completed && (t.Attention || (t.Due.HasValue && t.Due.Value.Date <= today.Date) || e.Start.Date <= today.Date)); }
        public static void Validate(EventOptions o)
        {
            o.Memory.Validate();
            foreach (var t in o.Tasks)
            {
                if (String.IsNullOrWhiteSpace(t.Description)) throw new ArgumentException("Cada preparativo necesita una descripción.");
                if (String.IsNullOrWhiteSpace(t.Responsible)) throw new ArgumentException("Indica quién es responsable de cada preparativo.");
            }
        }
    }
}
