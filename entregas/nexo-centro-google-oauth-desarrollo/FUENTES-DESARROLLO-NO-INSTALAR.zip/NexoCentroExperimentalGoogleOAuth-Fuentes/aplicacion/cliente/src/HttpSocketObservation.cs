using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;

namespace AgendaClara
{
    // Observación pasiva de IP Helper: no abre sockets, cambia DNS ni selecciona direcciones.
    // Una fila pertenece al proceso, no necesariamente a una petición concurrente concreta.
    internal sealed class HttpSocketObservation
    {
        [DllImport("iphlpapi.dll", SetLastError=true)]
        static extern uint GetExtendedTcpTable(IntPtr table,ref int size,bool order,int family,int tableClass,uint reserved);
        readonly CancellationTokenSource stop=new CancellationTokenSource();
        readonly Task worker;
        readonly Action<string> report;
        readonly HashSet<string> seen=new HashSet<string>();
        readonly int port,pid;
        HttpSocketObservation(int port,Action<string> report)
        {
            this.port=port;this.report=report;pid=Process.GetCurrentProcess().Id;
            worker=Task.Run(async()=>
            {
                try
                {
                    report("TCP observado por proceso: PID="+pid+"; muestreo 100 ms; no prueba por sí solo qué socket pertenece a esta petición.");
                    while(!stop.IsCancellationRequested)
                    {
                        Sample(2);Sample(23);
                        await Task.Delay(100,stop.Token).ConfigureAwait(false);
                    }
                }
                catch(OperationCanceledException){}
                catch(Exception ex)when(ex is DllNotFoundException || ex is EntryPointNotFoundException || ex is System.ComponentModel.Win32Exception || ex is InvalidOperationException)
                {report("Observación TCP no disponible: "+ex.GetType().Name+". No se deduce ausencia de conexión.");}
            });
        }
        public static HttpSocketObservation Start(int port,Action<string> report){return new HttpSocketObservation(port,report);}
        void Sample(int family)
        {
            int size=0;uint result=GetExtendedTcpTable(IntPtr.Zero,ref size,false,family,5,0);
            if(result!=122 && result!=0)throw new System.ComponentModel.Win32Exception((int)result);
            for(int attempt=0;attempt<3;attempt++)
            {
                if(size<4 || size>4194304)throw new InvalidOperationException("Tamaño de tabla TCP no válido.");
                int capacity=size;IntPtr buffer=Marshal.AllocHGlobal(capacity);
                try
                {
                    result=GetExtendedTcpTable(buffer,ref size,false,family,5,0);
                    if(result==122)continue;
                    if(result!=0)throw new System.ComponentModel.Win32Exception((int)result);
                    var bytes=new byte[size];Marshal.Copy(buffer,bytes,0,size);
                    foreach(string row in Parse(bytes,family,pid,port))
                        if(seen.Count<64 && seen.Add(row))report("TCP observado: "+row);
                    return;
                }
                finally{Marshal.FreeHGlobal(buffer);}
            }
        }
        internal static IList<string> Parse(byte[] bytes,int family,int pid,int port)
        {
            if(family!=2 && family!=23)throw new ArgumentException("Familia TCP no válida.");
            int rowSize=family==2?24:56;
            if(bytes.Length<4)throw new InvalidOperationException("Tabla TCP incompleta.");
            uint count=BitConverter.ToUInt32(bytes,0);
            if(count>(bytes.Length-4)/rowSize)throw new InvalidOperationException("Tabla TCP incompleta.");
            var rows=new List<string>();
            for(int i=0;i<count;i++)
            {
                int b=4+i*rowSize, remotePort=family==2?b+16:b+44;
                if(BitConverter.ToUInt32(bytes,b+rowSize-4)!=(uint)pid || NetworkPort(bytes,remotePort)!=port)continue;
                IPAddress local,remote;int localPort;uint state;
                if(family==2)
                {
                    local=new IPAddress(Copy(bytes,b+4,4));remote=new IPAddress(Copy(bytes,b+12,4));
                    localPort=NetworkPort(bytes,b+8);state=BitConverter.ToUInt32(bytes,b);
                }
                else
                {
                    local=new IPAddress(Copy(bytes,b,16),BitConverter.ToUInt32(bytes,b+16));
                    remote=new IPAddress(Copy(bytes,b+24,16),BitConverter.ToUInt32(bytes,b+40));
                    localPort=NetworkPort(bytes,b+20);state=BitConverter.ToUInt32(bytes,b+48);
                }
                string status=state==3?"SYN_SENT":state==5?"ESTABLISHED":state==8?"CLOSE_WAIT":"estado-"+state;
                rows.Add("PID="+pid+" local="+new IPEndPoint(local,localPort)+" remoto="+new IPEndPoint(remote,port)+" "+status);
            }
            return rows;
        }
        static int NetworkPort(byte[] bytes,int offset){return (bytes[offset]<<8)|bytes[offset+1];}
        static byte[] Copy(byte[] bytes,int offset,int count){var result=new byte[count];Array.Copy(bytes,offset,result,0,count);return result;}
        public async Task StopAsync()
        {
            stop.Cancel();
            try{await worker.ConfigureAwait(false);}
            catch(Exception ex){report("La observación TCP terminó sin completar: "+ex.GetType().Name+". No se deduce ausencia de conexión.");}
            finally{stop.Dispose();}
        }
    }
}
