using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace AgendaClara
{
    // Selector oficial Google Picker. Sólo loopback; no crea reservas HTTP.sys ni requiere administrador.
    public static class GoogleFormPicker
    {
        public static string Page(GoogleAppRegistration app,string access,string nonce,string origin)
        {
            Func<string,string> js=s=>JsonSerializer.Serialize(s);
            return "<!doctype html><html lang='es'><meta charset='utf-8'><title>Nexo Centro · Elegir formulario</title><h1>Elige el formulario de evaluación</h1><p id='status'>Abriendo el selector de Google…</p><script nonce='"+nonce+"'>"+
              "const token="+js(access)+",key="+js(app.PickerApiKey)+",project="+js(app.ProjectNumber)+",origin="+js(origin)+";"+
              "function finish(value){fetch('/picked-"+nonce+"',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(value)}).then(()=>{document.getElementById('status').textContent='Vuelve a Nexo Centro. Puedes cerrar esta pestaña.';}).catch(()=>{document.getElementById('status').textContent='La selección no se pudo enviar. Vuelve a Nexo Centro.';});}"+
              "function load(){gapi.load('picker',()=>{const view=new google.picker.DocsView(google.picker.ViewId.FORMS).setIncludeFolders(false).setSelectFolderEnabled(false);const picker=new google.picker.PickerBuilder().addView(view).setOAuthToken(token).setDeveloperKey(key).setAppId(project).setOrigin(origin).setLocale('es').setCallback(data=>{if(data.action===google.picker.Action.PICKED){const docs=data.docs||[];if(docs.length===1)finish({id:docs[0].id});}else if(data.action===google.picker.Action.CANCEL)finish({cancel:true});}).build();picker.setVisible(true);});}"+
              "const script=document.createElement('script');script.src='https://apis.google.com/js/api.js';script.onload=load;document.head.appendChild(script);</script></html>";
        }
        public static async Task<string> Choose(GoogleAppRegistration app,string access,Action<string> open,CancellationToken token)
        {
            var listener=new TcpListener(IPAddress.Loopback,0);listener.Start();string nonce=Guid.NewGuid().ToString("N");int port=((IPEndPoint)listener.LocalEndpoint).Port;
            string origin="http://127.0.0.1:"+port;string landing="/choose-"+nonce;int requests=0;
            using(var timeout=CancellationTokenSource.CreateLinkedTokenSource(token))
            {
                timeout.CancelAfter(TimeSpan.FromMinutes(5));using(timeout.Token.Register(()=>listener.Stop()))
                try
                {
                    open(origin+landing);
                    while(true)
                    {
                        timeout.Token.ThrowIfCancellationRequested();TcpClient client;
                        try{client=await listener.AcceptTcpClientAsync().ConfigureAwait(false);}catch(Exception)when(timeout.IsCancellationRequested){throw new OperationCanceledException(timeout.Token);}
                        using(client)
                        {
                            if(++requests>40)throw new IOException("El selector de Google ha recibido demasiadas peticiones.");
                            using(var stream=client.GetStream())
                            using(var clientTimeout=CancellationTokenSource.CreateLinkedTokenSource(timeout.Token))
                            {
                                clientTimeout.CancelAfter(TimeSpan.FromSeconds(5));using(var close=clientTimeout.Token.Register(()=>client.Close()))
                            {
                                var bytes=new MemoryStream();byte[] one=new byte[1];bool end=false;
                                while(bytes.Length<16384){if(await stream.ReadAsync(one,0,1,clientTimeout.Token).ConfigureAwait(false)==0)break;bytes.WriteByte(one[0]);if(bytes.Length>=4){var b=bytes.GetBuffer();int n=(int)bytes.Length;if(b[n-4]==13&&b[n-3]==10&&b[n-2]==13&&b[n-1]==10){end=true;break;}}}
                                if(!end){await Reply(stream,400,"Solicitud no válida.","text/plain",nonce,clientTimeout.Token);continue;}
                                string[] lines=Encoding.ASCII.GetString(bytes.ToArray()).Split(new[]{"\r\n"},StringSplitOptions.None);string[] first=lines[0].Split(' ');
                                if(first.Length!=3||!lines.Any(l=>l.Equals("Host: 127.0.0.1:"+port,StringComparison.OrdinalIgnoreCase))){await Reply(stream,403,"Solicitud no autorizada.","text/plain",nonce,clientTimeout.Token);continue;}
                                if(first[0]=="GET"&&first[1]==landing){await Reply(stream,200,Page(app,access,nonce,origin),"text/html; charset=utf-8",nonce,clientTimeout.Token);continue;}
                                var lengths=lines.Where(l=>l.StartsWith("Content-Length:",StringComparison.OrdinalIgnoreCase)).ToArray();int length;
                                if(lengths.Length!=1||!Int32.TryParse(lengths[0].Substring(15).Trim(),out length)||length<2||length>4096){await Reply(stream,400,"Respuesta no válida.","text/plain",nonce,clientTimeout.Token);continue;}
                                byte[] body=new byte[length];int offset=0;while(offset<body.Length){int n=await stream.ReadAsync(body,offset,body.Length-offset,clientTimeout.Token).ConfigureAwait(false);if(n==0)throw new IOException("Google no completó la selección.");offset+=n;}
                                // Consumir sólo el cuerpo acotado antes de rechazar: Windows restablece el socket si quedan bytes sin leer.
                                if(first[0]!="POST"||first[1]!="/picked-"+nonce||!lines.Any(l=>l.Equals("Origin: "+origin,StringComparison.OrdinalIgnoreCase))){await Reply(stream,403,"Solicitud no autorizada.","text/plain",nonce,clientTimeout.Token);continue;}
                                using(var json=JsonDocument.Parse(body))
                                {JsonElement cancelled;if(json.RootElement.TryGetProperty("cancel",out cancelled)&&cancelled.ValueKind==JsonValueKind.True){await Reply(stream,200,"{}","application/json",nonce,clientTimeout.Token);return null;}JsonElement id;if(!json.RootElement.TryGetProperty("id",out id)||id.ValueKind!=JsonValueKind.String)throw new IOException("No se ha seleccionado un formulario.");string selected=id.GetString();GoogleOfficialApi.ValidateFormId(selected);await Reply(stream,200,"{}","application/json",nonce,clientTimeout.Token);return selected;}
                            }
                            }
                        }
                    }
                }
                finally{listener.Stop();}
            }
        }
        static async Task Reply(Stream stream,int status,string body,string type,string nonce,CancellationToken ct)
        {
            byte[] bytes=Encoding.UTF8.GetBytes(body);string csp="default-src 'none'; script-src 'nonce-"+nonce+"' https://apis.google.com https://*.google.com https://*.gstatic.com; frame-src https://*.google.com; connect-src 'self' https://*.google.com https://*.googleapis.com; img-src https://*.google.com https://*.gstatic.com data:; style-src 'unsafe-inline'";
            byte[] header=Encoding.ASCII.GetBytes("HTTP/1.1 "+status+" "+(status==200?"OK":"Error")+"\r\nContent-Type: "+type+"\r\nContent-Length: "+bytes.Length+"\r\nCache-Control: no-store\r\nReferrer-Policy: no-referrer\r\nContent-Security-Policy: "+csp+"\r\nX-Content-Type-Options: nosniff\r\nConnection: close\r\n\r\n");await stream.WriteAsync(header,0,header.Length,ct).ConfigureAwait(false);await stream.WriteAsync(bytes,0,bytes.Length,ct).ConfigureAwait(false);
        }
    }
}
