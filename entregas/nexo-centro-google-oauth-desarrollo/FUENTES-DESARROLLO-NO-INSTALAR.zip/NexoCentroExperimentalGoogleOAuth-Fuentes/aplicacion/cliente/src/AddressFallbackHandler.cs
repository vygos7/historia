using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Security;
using System.Net.Sockets;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;
using System.Threading;
using System.Threading.Tasks;

namespace AgendaClara
{
    internal sealed class EndpointTlsException : HttpRequestException
    {
        internal readonly string Code;
        internal EndpointTlsException(string code,Exception inner):base("No se ha validado la identidad TLS del servidor configurado.",inner){Code=code;}
    }
    internal sealed class ValidatedEndpoint
    {
        internal readonly IPAddress Address;
        internal readonly byte[] Certificate;
        internal readonly DateTime UntilUtc;
        internal ValidatedEndpoint(IPAddress address,byte[] certificate)
        {Address=address;Certificate=(byte[])certificate.Clone();UntilUtc=DateTime.UtcNow.AddSeconds(30);}
    }
    // .NET Framework 4.8 no ofrece ConnectCallback. Primero se autentica el nombre
    // original mediante SslStream y se vincula la ruta IP a ESE certificado exacto.
    // El POST sólo se envía después, una vez: no se repiten solicitudes de escritura.
    internal sealed class EndpointRouter
    {
        readonly Uri origin;
        readonly X509Certificate2 clientCertificate;
        readonly string authority;
        readonly SemaphoreSlim selection=new SemaphoreSlim(1,1);
        readonly Func<string,Task<IPAddress[]>> resolve;
        readonly Func<IPAddress,CancellationToken,Task<ValidatedEndpoint>> connect;
        ValidatedEndpoint cached;
#if !NETFRAMEWORK
        static readonly HttpRequestOptionsKey<ValidatedEndpoint> BindingKey=new HttpRequestOptionsKey<ValidatedEndpoint>("AgendaClara.ValidatedEndpoint");
#endif
        internal EndpointRouter(Uri origin,X509Certificate2 clientCertificate,string authority,
            Func<string,Task<IPAddress[]>> resolve=null,Func<IPAddress,CancellationToken,Task<ValidatedEndpoint>> connect=null)
        {
            if(origin.Scheme!="https" || origin.UserInfo.Length!=0)throw new ArgumentException("El transporte requiere HTTPS sin credenciales en la URL.");
            this.origin=origin;this.clientCertificate=clientCertificate;this.authority=authority;
            this.resolve=resolve??Dns.GetHostAddressesAsync;this.connect=connect??ConnectAsync;
        }
        internal static IEnumerable<IPAddress> Interleave(IEnumerable<IPAddress> addresses)
        {
            var list=addresses.Where(a=>a.AddressFamily==AddressFamily.InterNetwork || a.AddressFamily==AddressFamily.InterNetworkV6).Distinct().ToList();
            if(list.Count==0)return list;
            var first=new Queue<IPAddress>(list.Where(a=>a.AddressFamily==list[0].AddressFamily));
            var other=new Queue<IPAddress>(list.Where(a=>a.AddressFamily!=list[0].AddressFamily));
            var result=new List<IPAddress>();
            while(first.Count>0 || other.Count>0){if(first.Count>0)result.Add(first.Dequeue());if(other.Count>0)result.Add(other.Dequeue());}
            return result;
        }
        internal static async Task<T> Cancellable<T>(Task<T> operation,CancellationToken token)
        {
            var cancelled=new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
            using(var registration=token.Register(()=>cancelled.TrySetCanceled()))
            {
                if(await Task.WhenAny(operation,cancelled.Task).ConfigureAwait(false)!=operation)
                {
                    Observe(operation);token.ThrowIfCancellationRequested();
                }
                return await operation.ConfigureAwait(false);
            }
        }
        static void Observe(Task operation)
        {_ = operation.ContinueWith(t=>{var ignored=t.Exception;},CancellationToken.None,TaskContinuationOptions.OnlyOnFaulted|TaskContinuationOptions.ExecuteSynchronously,TaskScheduler.Default);}
        internal async Task<ValidatedEndpoint> ConnectAsync(IPAddress address,CancellationToken token)
        {
            using(var tcp=new TcpClient(address.AddressFamily))
            using(var abort=token.Register(tcp.Close))
            {
                await Cancellable(tcp.ConnectAsync(address,origin.Port).ContinueWith(t=>{t.GetAwaiter().GetResult();return true;},CancellationToken.None,TaskContinuationOptions.ExecuteSynchronously,TaskScheduler.Default),token).ConfigureAwait(false);
                token.ThrowIfCancellationRequested();
                string rejection="handshake";byte[] accepted=null;
                using(var ssl=new SslStream(tcp.GetStream(),false,(sender,cert,chain,errors)=>
                {
                    using(var leaf=cert==null?null:new X509Certificate2(cert))
                    {
                        rejection=ServerTlsTrust.Check(authority,leaf,errors);
                        if(rejection.Length==0)accepted=leaf.RawData;
                        return rejection.Length==0;
                    }
                }))
                {
                    try
                    {
                        // El targetHost ES el nombre configurado, no la IP candidata: Windows
                        // comprueba su SAN/nombre y envía SNI para ese nombre durante esta prueba.
                        var handshake=ssl.AuthenticateAsClientAsync(origin.DnsSafeHost,new X509CertificateCollection{clientCertificate},SslProtocols.None,false);
                        await Cancellable(handshake.ContinueWith(t=>{t.GetAwaiter().GetResult();return true;},CancellationToken.None,TaskContinuationOptions.ExecuteSynchronously,TaskScheduler.Default),token).ConfigureAwait(false);
                    }
                    catch(Exception ex)when(ex is AuthenticationException || ex is IOException)
                    {token.ThrowIfCancellationRequested();throw new EndpointTlsException(rejection.Length==0?"handshake":rejection,ex);}
                    token.ThrowIfCancellationRequested();
                    if(accepted==null)throw new EndpointTlsException("handshake",null);
                    return new ValidatedEndpoint(address,accepted);
                }
            }
        }
        internal static async Task<ValidatedEndpoint> RaceAsync(IList<IPAddress> addresses,Func<IPAddress,CancellationToken,Task<ValidatedEndpoint>> connector,
            Action<string> report,CancellationToken token)
        {
            if(addresses.Count==0)throw new HttpRequestException("DNS no devuelve direcciones utilizables.",new SocketException((int)SocketError.HostNotFound));
            using(var attempts=CancellationTokenSource.CreateLinkedTokenSource(token))
            {
                var pending=new List<Task<ValidatedEndpoint>>();
                for(int i=0;i<addresses.Count;i++)pending.Add(AttemptAsync(addresses[i],i*250,connector,report,attempts.Token));
                Exception last=null;EndpointTlsException tls=null;
                try
                {
                    while(pending.Count>0)
                    {
                        token.ThrowIfCancellationRequested();
                        var done=await Task.WhenAny(pending).ConfigureAwait(false);pending.Remove(done);
                        try
                        {
                            var endpoint=await done.ConfigureAwait(false);token.ThrowIfCancellationRequested();
                            report("ruta validada: IP="+endpoint.Address+"; identidad TLS del nombre original comprobada");
                            return endpoint;
                        }
                        catch(OperationCanceledException){token.ThrowIfCancellationRequested();throw;}
                        catch(Exception ex)when(ex is HttpRequestException || ex is SocketException || ex is IOException)
                        {last=ex;if(ex is EndpointTlsException)tls=(EndpointTlsException)ex;}
                    }
                    if(tls!=null)throw tls;
                    throw new HttpRequestException("Ninguna dirección del servidor permite completar la conexión.",last);
                }
                finally
                {
                    attempts.Cancel();
                    foreach(var pendingAttempt in pending)Observe(pendingAttempt);
                }
            }
        }
        static async Task<ValidatedEndpoint> AttemptAsync(IPAddress address,int delay,Func<IPAddress,CancellationToken,Task<ValidatedEndpoint>> connector,Action<string> report,CancellationToken token)
        {
            if(delay>0)await Task.Delay(delay,token).ConfigureAwait(false);
            token.ThrowIfCancellationRequested();report("candidato IP="+address+"; TCP y TLS del nombre original");
            try{return await Cancellable(connector(address,token),token).ConfigureAwait(false);}
            catch(OperationCanceledException){throw;}
            catch(Exception ex)when(ex is HttpRequestException || ex is SocketException || ex is IOException)
            {report("candidato IP="+address+" no disponible; tipo="+ex.GetType().Name);throw;}
        }
        internal async Task<ValidatedEndpoint> SelectAsync(Action<string> report,CancellationToken token)
        {
            await selection.WaitAsync(token).ConfigureAwait(false);
            try
            {
                var current=Volatile.Read(ref cached);
                if(current!=null && current.UntilUtc>DateTime.UtcNow)return current;
                IPAddress literal;IPAddress[] addresses;
                if(IPAddress.TryParse(origin.DnsSafeHost,out literal))addresses=new[]{literal};
                else addresses=await Cancellable(resolve(origin.DnsSafeHost),token).ConfigureAwait(false);
                var endpoint=await RaceAsync(Interleave(addresses).ToList(),connect,report,token).ConfigureAwait(false);
                Volatile.Write(ref cached,endpoint);return endpoint;
            }
            finally{selection.Release();}
        }
        internal void Invalidate(ValidatedEndpoint endpoint)
        {Interlocked.CompareExchange(ref cached,null,endpoint);}
        internal void Bind(HttpRequestMessage request,ValidatedEndpoint endpoint)
        {
            if(request.RequestUri.Scheme!=origin.Scheme || request.RequestUri.IdnHost!=origin.IdnHost || request.RequestUri.Port!=origin.Port || request.RequestUri.UserInfo.Length!=0)
                throw new HttpRequestException("No se permite enviar una sesión fuera del servidor configurado.");
            request.Headers.Host=origin.Authority;
            request.RequestUri=new UriBuilder(request.RequestUri){Host=endpoint.Address.ToString()}.Uri;
#if NETFRAMEWORK
            request.Properties["AgendaClara.ValidatedEndpoint"]=endpoint;
#else
            request.Options.Set(BindingKey,endpoint);
#endif
        }
        internal string ValidateHttp(HttpRequestMessage request,X509Certificate2 certificate,SslPolicyErrors errors)
        {
            ValidatedEndpoint endpoint=null;
#if NETFRAMEWORK
            object value;if(request!=null && request.Properties.TryGetValue("AgendaClara.ValidatedEndpoint",out value))endpoint=value as ValidatedEndpoint;
#else
            if(request!=null)request.Options.TryGetValue(BindingKey,out endpoint);
#endif
            // Una diferencia de nombre sólo puede ser la IP de transporte: el certificado
            // debe ser IDÉNTICO al autenticado para origin.DnsSafeHost. Nunca se acepta
            // otra hoja, ni se omiten errores de cadena, fecha o CA esperada.
            if(endpoint==null || certificate==null || !certificate.RawData.SequenceEqual(endpoint.Certificate))return "handshake";
            return ServerTlsTrust.Check(authority,certificate,errors&~SslPolicyErrors.RemoteCertificateNameMismatch);
        }
    }
    internal sealed class AddressFallbackHandler : DelegatingHandler
    {
        readonly EndpointRouter router;
        readonly Action<string> report;
        internal AddressFallbackHandler(EndpointRouter router,HttpMessageHandler inner,Action<string> report):base(inner)
        {this.router=router;this.report=report;}
        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request,CancellationToken token)
        {
            ValidatedEndpoint endpoint;
            try{endpoint=await router.SelectAsync(report,token).ConfigureAwait(false);}
            catch(SocketException ex){throw new HttpRequestException("No se ha podido resolver el nombre del servidor.",ex);}
            router.Bind(request,endpoint);
            report("HTTP destino IP="+endpoint.Address+"; Host="+request.Headers.Host+"; sin repetir la petición");
            try{return await base.SendAsync(request,token).ConfigureAwait(false);}
            catch{router.Invalidate(endpoint);throw;}
        }
    }
}
