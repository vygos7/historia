using System;
using System.Diagnostics;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace AgendaClara
{
    internal static class HttpRequestTiming
    {
        internal static async Task<HttpResponseMessage> SendAsync(HttpClient client,HttpRequestMessage request,Action<string> report,CancellationToken token,TimeSpan? budget=null)
        {
            var watch=Stopwatch.StartNew();
            using(var limit=CancellationTokenSource.CreateLinkedTokenSource(token))
            {
                limit.CancelAfter(budget??TimeSpan.FromSeconds(10));
                HttpResponseMessage response=null;
                try
                {
                    response=await client.SendAsync(request,HttpCompletionOption.ResponseHeadersRead,limit.Token).ConfigureAwait(false);
                    report("cabeceras recibidas; estado="+(int)response.StatusCode+"; ms="+watch.ElapsedMilliseconds);
                    // ResponseHeadersRead no incluye el cuerpo en HttpClient.Timeout. El mismo
                    // plazo global se mantiene hasta disponer del cuerpo completo, como antes.
                    using(var abort=limit.Token.Register(response.Dispose))
                    {
                        var loading=response.Content.LoadIntoBufferAsync();
                        var cancelled=new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
                        using(var cancellation=limit.Token.Register(()=>cancelled.TrySetCanceled()))
                        {
                            if(await Task.WhenAny(loading,cancelled.Task).ConfigureAwait(false)!=loading)
                            {
                                _ = loading.ContinueWith(t=>{var ignored=t.Exception;},CancellationToken.None,TaskContinuationOptions.OnlyOnFaulted|TaskContinuationOptions.ExecuteSynchronously,TaskScheduler.Default);
                                limit.Token.ThrowIfCancellationRequested();
                            }
                            await loading.ConfigureAwait(false);
                        }
                    }
                    limit.Token.ThrowIfCancellationRequested();
                    report("cuerpo recibido; ms="+watch.ElapsedMilliseconds);
                    return response;
                }
                catch(Exception ex)
                {
                    if(response!=null)response.Dispose();
                    if(limit.IsCancellationRequested)throw new OperationCanceledException("Solicitud HTTP cancelada dentro del plazo global.",ex,limit.Token);
                    throw;
                }
            }
        }
    }
}
