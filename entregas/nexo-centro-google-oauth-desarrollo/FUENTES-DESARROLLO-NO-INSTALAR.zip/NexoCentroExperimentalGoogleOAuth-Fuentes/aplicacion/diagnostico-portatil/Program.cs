using System;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using AgendaClara;

static class DiagnosticLauncher
{
    [STAThread]static int Main(string[] args)
    {
        string configuration=SharedConfiguration.DefaultPath;
        string ipv4="";
        for(int i=0;i<args.Length;i+=2)
        {
            if(i+1>=args.Length)return 2;
            if(args[i]=="--config")configuration=Path.GetFullPath(args[i+1]);
            else if(args[i]=="--ipv4")ipv4=args[i+1];
            else return 2;
        }
        try
        {
            if(!File.Exists(configuration))throw new IOException("No se encuentra la configuración de trabajo compartido de este usuario de Windows. Ejecuta la herramienta desde el perfil que utiliza AgendaClara.");
            var settings=SharedConfiguration.Load(configuration);
            if(!settings.Shared)throw new IOException("La configuración de este perfil corresponde a uso individual. No se ha abierto ni modificado su agenda.");
            if(ipv4.Length>0)settings.ServerUrl=DiagnosticTarget.WithIPv4(settings.ServerUrl,ipv4);
            // Las sesiones y la caché del cliente instalado permanecen intactas.
            string scratch=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"AgendaClaraDiagnostico",Guid.NewGuid().ToString("N"),"config.xml");
            settings.AllowOffline=false;settings.IndividualDatabase="";
            var app=new Application{ShutdownMode=ShutdownMode.OnMainWindowClose};Theme.Install(app);
            var window=new Window{Title="AgendaClara · diagnóstico sin instalar",Width=610,Height=420,MinWidth=480,MinHeight=350,WindowStartupLocation=WindowStartupLocation.CenterScreen};Theme.ApplyWindow(window);
            var panel=new StackPanel{Margin=new Thickness(24)};
            panel.Children.Add(Theme.Text("Diagnosticar conexión con Jefatura",22,Theme.Ink,true));
            panel.Children.Add(Theme.Text("Se lee la conexión actual. No se instala nada ni se modifican la configuración, los certificados o la agenda. La prueba puede iniciar una sesión y registrar el acceso en Jefatura.",13,Theme.Muted));
            panel.Children.Add(Theme.Text(settings.ServerUrl+"\nUsuario: "+settings.UserName,14,Theme.Ink));
            if(ipv4.Length>0)panel.Children.Add(Theme.Text("Comparación por IPv4 sólo en esta ventana. La configuración instalada no cambia. TLS debe validar esta IP en el certificado; no se aceptará una identidad incorrecta.",13,Theme.Warning));
            var password=new PasswordBox();if(!settings.AutomaticAccess)SharedUi.Field(panel,"Contraseña de AgendaClara",password);
            var message=Theme.Text("",13,Theme.Warning);
            panel.Children.Add(Theme.Button("Diagnosticar conexión con Jefatura",()=>
            {
                try{using(var remote=new RemoteConnection(settings,scratch))new ConnectionDiagnosisWindow(remote,password.Password){Owner=window}.ShowDialog();}
                catch(Exception ex){message.Text=ex.Message;}
                finally{password.Clear();}
            },"Primary"));panel.Children.Add(message);panel.Children.Add(Theme.Button("Cerrar",window.Close));
            window.Content=new ScrollViewer{Content=panel,VerticalScrollBarVisibility=ScrollBarVisibility.Auto};app.Run(window);return 0;
        }
        catch(Exception ex){MessageBox.Show(ex.Message,"AgendaClara · diagnóstico",MessageBoxButton.OK,MessageBoxImage.Information);return 1;}
    }
}
