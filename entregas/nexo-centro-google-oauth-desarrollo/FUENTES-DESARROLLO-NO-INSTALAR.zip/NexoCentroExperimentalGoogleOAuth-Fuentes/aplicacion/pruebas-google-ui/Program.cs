using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using AgendaClara;
static class GoogleUiTests
{
    static int checks;
    static void Check(bool value,string label){if(!value)throw new Exception(label);checks++;Console.WriteLine("OK · "+label);}
    static IEnumerable<DependencyObject> Tree(DependencyObject root){yield return root;foreach(var x in LogicalTreeHelper.GetChildren(root)){var d=x as DependencyObject;if(d!=null)foreach(var child in Tree(d))yield return child;}}
    static void Pump(Window w){for(int i=0;i<4;i++){w.UpdateLayout();var frame=new DispatcherFrame();w.Dispatcher.BeginInvoke(DispatcherPriority.Background,new Action(()=>frame.Continue=false));Dispatcher.PushFrame(frame);}}
    [STAThread] static int Main()
    {
        string root=Path.Combine(Path.GetTempPath(),"NexoCentroExperimentalGoogleOAuth","ui-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(root);
        try
        {
            var app=new Application{ShutdownMode=ShutdownMode.OnExplicitShutdown};Theme.Install(app);Format.ApplyCulture();
            using(var store=new Store(Path.Combine(root,"agenda.sqlite3"),false))
            {
                var e=new AgendaEvent{Title="Salida ficticia",Start=new DateTime(2026,11,5),End=new DateTime(2026,11,5),AllDay=true};e.Options.Group="3.º A";store.StampNew(e);store.Save(e);
                var main=new MainWindow(store);main.Show();Pump(main);var window=new GoogleEvaluationsWindow(store,e.Id){Owner=main};window.Show();Pump(window);
                Check(Tree(window).OfType<Button>().Any(b=>b.Content as string=="Conectar con Google"),"Existe Conectar con Google");
                Check(Tree(window).OfType<Button>().Any(b=>b.Content as string=="Elegir formulario"),"Existe Elegir formulario");
                Check(Tree(window).OfType<Button>().Any(b=>b.Content as string=="Copiar enlace para el docente"),"Existe la acción única de copiar enlace");
                Check(!Tree(window).OfType<PasswordBox>().Any(),"No se pide ningún secreto");
                Check(Tree(window).OfType<TextBox>().All(t=>t.IsReadOnly),"No se pide pegar una plantilla o una URL técnica");
                Check(!Tree(window).OfType<TextBlock>().Any(t=>t.Text.Contains("Apps Script")||t.Text.Contains("/exec")||t.Text.Contains("prerrellenada")),"La pantalla no traslada los pasos técnicos al usuario");
                if(!GoogleAppRegistration.Load().IsPrepared){Check(!Tree(window).OfType<Button>().Single(b=>b.Content as string=="Conectar con Google").IsEnabled,"Una compilación sin registro no finge una conexión utilizable");Check(Tree(window).OfType<TextBlock>().Any(t=>t.Text.Contains("pendiente del desarrollo")),"Se identifica el bloqueo de desarrollo");}
                Check(!store.Find(e.Id).Options.Memory.HasContent,"Abrir el asistente no cambia la memoria");
                var content=(FrameworkElement)window.Content;var image=new RenderTargetBitmap((int)Math.Ceiling(content.ActualWidth),(int)Math.Ceiling(content.ActualHeight),96,96,PixelFormats.Pbgra32);image.Render(content);var png=new PngBitmapEncoder();png.Frames.Add(BitmapFrame.Create(image));using(var output=File.Create(Path.Combine(root,"asistente-google.png")))png.Save(output);
                window.Close();main.Close();GoogleLocalRuntime.Stop(store);
            }
            app.Shutdown();Console.WriteLine("RESUMEN: "+checks+" comprobaciones Windows correctas; 0 fallos.");Console.WriteLine("Captura y datos ficticios: "+root);return 0;
        }
        catch(Exception e){Console.Error.WriteLine("FALLO: "+e);return 1;}
    }
}
