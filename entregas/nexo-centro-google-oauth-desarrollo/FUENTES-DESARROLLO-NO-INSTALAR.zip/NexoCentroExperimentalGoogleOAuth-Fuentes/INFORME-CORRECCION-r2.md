# AgendaClara 4.0.4 — selección segura de direcciones, revisión r2

5 de noviembre de 2026. **Corrección implementada; verificación real de r2 en el colegio pendiente.** No se ha modificado ni accedido remotamente a ninguna instalación del colegio.

## 1. Causa y evidencia disponible

El usuario probó el diagnóstico r1 desde Dirección el 5 de noviembre de 2026. Por nombre `https://jefatura:7443`, el proceso de diagnóstico mostró un intento TCP a la dirección IPv6 de enlace local del servidor en `SYN_SENT`, sin cabeceras ni validación TLS de HTTP antes de agotar el plazo de 10 segundos. La comprobación TCP/TLS independiente por IPv4 había funcionado.

En la prueba comparativa por `https://192.168.6.135:7443`, desde el mismo puesto, se observó IPv4 establecida, TLS válido, `POST /api/session` con HTTP 200 y cuerpo completo en 176 ms, guardado de sesión, `GET /api/snapshot` con HTTP 200, revisión de agenda 5 y SignalR conectado. La huella pública del servidor coincidió entre las dos pruebas.

**Demostrado:** Dirección puede autenticarse y consultar al servidor por IPv4. No hay evidencia de un bloqueo general de usuarios o sesiones en esa prueba. TCP/TLS independientes y API no usaban la misma conexión en r1.

**Diagnóstico principal, fuertemente respaldado por la comparación:** el transporte por nombre queda esperando una IPv6 no accesible y no completa la alternativa IPv4 dentro de su plazo. El muestreo TCP sigue siendo por proceso: no se afirma que una fila identifique por sí sola un socket exclusivo de una petición. No se ha recibido una traza del servidor del POST fallido y no se inventa una confirmación de llegada a Jefatura.

La corrección aborda la selección de direcciones antes de enviar HTTP y registra la IP elegida. Su éxito debe confirmarse con r2 usando el nombre original en Dirección; el éxito previo del control por IP no valida por sí solo r2.

## 2. Corrección del cliente

El cliente conserva `https://jefatura:7443` como origen lógico, configuración, identidad TLS, clave de sesión/caché y dirección de SignalR. No se fija `192.168.6.135` en el código ni se cambia DNS, IPv6, el cortafuegos o el servidor.

El transporte resuelve las direcciones y alterna familias sin eliminar IPv6. Inicia el primer candidato y los siguientes con una separación de 250 ms. Una IPv6 silenciosa no impide que empiece IPv4. Gana la primera dirección que completa TCP y autenticación TLS válida para el nombre configurado. Se cancelan los intentos restantes. Todos los intentos, DNS, HTTP y lectura del cuerpo quedan dentro del presupuesto global existente de 10 segundos; no se amplía.

La selección se comparte entre API y SignalR y se conserva hasta 30 segundos en memoria. Una operación de red fallida invalida esa selección para la siguiente petición. No hay reintento del POST o de una escritura después de enviarlos: así no se introducen duplicados cuando el resultado es incierto.

### Validación TLS al conectar por una IP seleccionada

.NET Framework 4.8 no ofrece el `ConnectCallback` de las versiones modernas de .NET. Se utiliza una preconexión `TcpClient`/`SslStream` por IP, cuyo `targetHost` es el nombre original (`jefatura`). Esa negociación comprueba la identidad DNS con la plataforma y la misma CA concreta, fecha y uso serverAuth que ya exigía AgendaClara. No envía una petición HTTP ni una contraseña de usuario. Presenta el certificado de puesto como antes.

La petición HTTP se dirige a la IP seleccionada, conserva el encabezado `Host` original y sólo acepta **el certificado de hoja exactamente idéntico** al que acaba de validarse para el nombre original. Se comprueban de nuevo CA y fecha. Si el validador nativo compara esa hoja con la IP de transporte, esa diferencia de nombre no sustituye la comprobación original: ésta ya se ha efectuado sobre la misma hoja mediante SslStream. No se acepta una hoja distinta, aunque provenga de la misma CA. Una URL configurada originalmente por IP sigue necesitando identidad TLS válida para esa IP.

Las pruebas cubren expresamente un certificado con SAN DNS sin SAN IP, un nombre original incorrecto, una CA distinta, fecha caducada, uso clientAuth inadecuado y sustitución de hoja después de la preconexión. Todos los rechazos se mantienen. Si un servidor cambia de certificado entre ambas conexiones, la petición falla de forma cerrada y se invalida la ruta para una operación posterior; no se repite la escritura ni se acepta el certificado nuevo automáticamente.

SignalR utiliza su transporte HTTP LongPolling con el mismo enrutamiento. Era ya el transporte usado por la configuración habitual con CA del centro. También se selecciona LongPolling en configuraciones que sólo usan confianza del sistema, para que WebSocket no abra por su cuenta una conexión DNS sin este fallback. La recepción de avisos y sincronización no se elimina: se prueba entrega real de mensajes SignalR.

La prueba independiente inicial por direcciones de la herramienta sigue pudiendo agotar sus 10 segundos sobre IPv6 para mostrar el fallo. Ese tiempo es anterior al POST y no cambia el presupuesto de éste.

## 3. Archivos modificados respecto a r1

- `aplicacion/cliente/src/AddressFallbackHandler.cs` — nuevo: selección escalonada, cancelación, enlace entre IP y certificado validado, caché corta y transporte HTTP sin repetición de escrituras.
- `aplicacion/cliente/src/ServerTlsTrust.cs` — nuevo: política TLS existente extraída para compartirla entre la selección y el transporte.
- `aplicacion/cliente/src/RemoteConnection.cs` — integra el transporte en la API y SignalR y mantiene la clasificación de errores.
- `aplicacion/cliente/src/ConnectionProbe.cs` — identifica el diagnóstico r2.
- `aplicacion/cliente/src/Program.cs` — versión informativa `4.0.4-http-r2 (05/11/2026)`; versión de ensamblado y protocolo sin cambio.
- `aplicacion/pruebas-transporte/AgendaClara.TransportTests.csproj` y `Program.cs` — nuevos: regresión de selección, TLS, HTTP y SignalR.
- `aplicacion/pruebas-sesion/AgendaClara.SessionTests.csproj` — compilación de los componentes compartidos en las pruebas portables.
- `Verificar.ps1` — incorpora la batería de transporte.

Se añade este informe. Los fuentes y las trazas de servidor r1 se conservan como trabajo histórico; **r2 no modifica el servidor ni distribuye un módulo suyo**. No se cambian esquema de datos, reglas de usuarios, certificados, dependencias existentes ni los instaladores.

## 4. Resultados y límites de las pruebas

SDK .NET 10.0.403. Compilación Windows/net48 del cliente, herramienta portátil, pruebas existentes de diagnóstico y regresión funcional: correcta, sin advertencias ni errores en los registros incluidos.

**Batería nueva de transporte: 32 comprobaciones ejecutadas, 0 fallos.**

- IPv6 que no responde simulada de forma controlada; IPv4 empieza después de 250 ms y completa TLS/HTTP sin consumir 10 segundos esperando la primera dirección.
- Cancelación de perdedores y del conjunto al agotarse el plazo; errores DNS conservados y sin enviar credenciales.
- Alternancia de familias, red sólo IPv6, caché y selección concurrente compartida.
- Fallo tras enviar: exactamente una llamada al transporte HTTP, sin repetición del POST; siguiente operación puede resolver de nuevo.
- HTTPS real por IPv4 con certificado de puesto, autenticación, recuperación de snapshot y conservación de Host.
- Identidad original válida mediante SAN DNS sin SAN IP; rechazo de nombre, CA, hoja sustituida, fecha y EKU incorrectos.
- SignalR LongPolling autenticado, conexión y entrega de un aviso real con el transporte corregido.
- HTTPS IPv6 real con mTLS en loopback, sin dirección IPv4 alternativa.
- Registros sin contraseñas ni tokens.

**Batería anterior de HTTP/sesiones: 33 comprobaciones ejecutadas, 0 fallos.** Se conservan autenticación y renovación, revocación, respuesta a contraseña incorrecta, tiempos de espera antes de cabeceras y durante cuerpo, límite predeterminado de 10 segundos y diagnóstico sin credenciales en registros.

Total: **65 comprobaciones correctas**. Los certificados y datos son sintéticos; no se han importado autoridades del colegio ni cambiado almacenes de confianza del puesto real.

**Límites:** ejecución de componentes en .NET 10/Linux y compilación cruzada de Windows. No se ha ejecutado WPF/.NET Framework 4.8 en este entorno ni el conjunto completo de baterías Windows. La IPv6 silenciosa de regresión se inyecta de forma determinista, no se presenta como reproducción de la pila de Windows exacta. Los servidores de pruebas son loopback con los componentes de seguridad y transporte reales, no la instalación del colegio. La propagación de cambios de agenda entre Dirección y Jefatura sigue pendiente.

## 5. Qué llevar y cómo comprobarlo

1. Descargar `AgendaClara-4.0.4-fallback-r2.zip` y extraerlo en una carpeta nueva en Dirección. No mezclar archivos con r1.
2. Ejecutar `Direccion-portatil/01-Probar-nombre.cmd` con el usuario habitual. Pulsar Diagnosticar y guardar el informe completo.
3. Comprobar que el informe dice revisión `2026-11-05-r2` y servidor configurado `https://jefatura:7443`. No usar el CMD comparativo por IP de r1 para validar esta corrección.
4. Deben observarse selección de ruta, IP elegida, HTTP 200 en autenticación y snapshot, y SignalR conectado. Un timeout de la prueba TCP IPv6 independiente inicial puede seguir apareciendo; lo decisivo es el resultado posterior de la API por nombre.
5. Revisar el informe antes de actualizar el cliente instalado. `Cliente-candidato/AgendaClara.exe` contiene la aplicación corregida; su sustitución requiere cierre de la aplicación, respaldo del EXE anterior y una instalación 4.0.4 con las dependencias correspondientes. Las instrucciones y reversión se incluyen en esa carpeta. No requiere instalador ni cambio de configuración.
6. Tras validar y actualizar el primer puesto, comprobar consulta y edición autorizada, recuperación tras cerrar/abrir y propagación con otro puesto. Sólo entonces extender a los demás clientes.

**No se necesita actualizar, reinstalar ni reinicializar el servidor. No se declara resuelto hasta validar la conexión corregida por nombre en el colegio.**

## 6. Reproducción en desarrollo

Desde `codigo-fuente`:

```text
dotnet build aplicacion/pruebas-transporte/AgendaClara.TransportTests.csproj -c Release
dotnet aplicacion/pruebas-transporte/bin/Release/net10.0/AgendaClara.TransportTests.dll <carpeta-nueva-1>
dotnet build aplicacion/pruebas-sesion/AgendaClara.SessionTests.csproj -c Release
dotnet aplicacion/pruebas-sesion/bin/Release/net10.0/AgendaClara.SessionTests.dll <carpeta-nueva-2>
dotnet build aplicacion/diagnostico-portatil/AgendaClara.Diagnostico.csproj -c Release -p:EnableWindowsTargeting=true
```

Las carpetas finales de pruebas deben no existir. Los servidores de loopback se inician y cierran dentro de cada batería. No hay servicios persistentes que iniciar ni una agenda real que configurar.
