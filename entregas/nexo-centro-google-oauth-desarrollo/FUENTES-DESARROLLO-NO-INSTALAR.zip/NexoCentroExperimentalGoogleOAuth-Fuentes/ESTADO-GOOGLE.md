# Estado verificable de la integración oficial

## Implementado en la copia 4.2.0

- Interfaz con Conectar con Google, Elegir formulario y Copiar enlace para el docente. Sin campos para código, secretos o plantillas.
- SDK oficial Google.Apis.Auth 1.78.0, OAuth de escritorio con PKCE activado y navegador del sistema. La contraseña Google se introduce en Google.
- Google Picker en el navegador. Permiso `drive.file`, admitido por la API oficial Forms para leer, preparar el formulario y obtener respuestas del archivo elegido. No se solicita lectura general de Drive.
- Preparación de código y nombre conservando preguntas y respuestas existentes. La activación del formulario requiere confirmación y conserva sus restricciones de acceso; no se modifican permisos de Drive.
- Construcción del enlace con fecha y grupo, identificador único y controles de correspondencia existentes.
- Lectura oficial Forms API: seis campos de memoria y metadatos de actividad. No se copia el correo del docente.
- Recogida automática cada cinco minutos: en el servidor compartido, o mientras el cliente local está abierto. Señalización para actualizar la agenda.
- Escrituras mediante Store.Apply: versiones, auditoría y protección de memorias existentes. Las respuestas inconsistentes o duplicadas necesitan revisión. No hay asociación por proximidad de fechas.
- Tokens protegidos con DPAPI; no vuelven en las consultas de estado ni se introducen en las URL generadas por el programa. El selector local comprueba ruta aleatoria, Host y Origin, y no crea reservas de puertos de administrador.
- Datos de prueba y perfil propios: NexoCentroExperimentalGoogleOAuth; puerto de servidor de pruebas 7445. No se abre la agenda estable ni la de la versión experimental anterior.

## Bloqueo real de desarrollo

Google exige un proyecto y una aplicación OAuth registrados por el distribuidor del programa. No hay registro, credenciales ni identidad administradora de Google Cloud en este entorno. Tampoco hay herramientas de navegador autenticado con acceso a la consola de Google. La política de salida actual no incluye los servicios de Google.

Esto no se resuelve pidiendo al usuario que cree scripts, pegue secretos o configure proyectos: debe resolverlo quien prepara la aplicación. No se utiliza un client_id ajeno ni de ejemplo para simular disponibilidad.

## Pendiente antes de distribuir a usuarios principiantes

1. Registrar Nexo Centro como cliente de escritorio y habilitar Drive, Forms y Picker en el mismo proyecto. Preparar el consentimiento y el estado de publicación adecuados.
2. Inyectar el registro de aplicación en la compilación del desarrollador; nunca incluir tokens de usuarios en fuentes o paquetes.
3. Ejecutar en Windows con Google real: autorización, selector, preparación y publicación del formulario elegido, cuatro datos prerrellenados, envío de una respuesta, importación, segundo envío y reconexión. Verificar especialmente la conversión entre questionId de Forms y los parámetros entry del enlace: su contrato no queda demostrado por los simuladores.
4. Probar las restricciones de Google Workspace y la elección de formularios privados/compartidos. El programa no evita esas políticas.
5. Comprobar persistencia y actualización desde ambos puestos contra el servidor experimental, conservando las funciones anteriores.

Los indicadores ProductionApproved y LiveContractVerified permanecen falsos. El empaquetado se bloquea. La aplicación se presenta como desarrollo pendiente, no como una conexión lista para usar.

## Pruebas

Los registros de esta revisión se guardan fuera de las fuentes, en /workspace/google42-*.log. Las pruebas automatizadas de REST y selector usan respuestas sintéticas. El éxito de esas pruebas no demuestra una conexión con una cuenta real de Google.
