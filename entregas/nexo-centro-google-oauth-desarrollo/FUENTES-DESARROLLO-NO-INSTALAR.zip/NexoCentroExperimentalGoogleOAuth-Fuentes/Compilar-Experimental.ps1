﻿throw "La distribución está bloqueada hasta registrar la aplicación Google y verificar el recorrido real. Usa Compilar-DesarrolloGoogle.ps1 sólo para compilar y probar el código."
