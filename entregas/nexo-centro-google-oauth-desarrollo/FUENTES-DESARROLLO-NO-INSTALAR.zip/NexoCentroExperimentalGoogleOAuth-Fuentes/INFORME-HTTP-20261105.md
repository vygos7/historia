# AgendaClara 4.0.4 — investigación HTTP, 5 de noviembre de 2026

**Estado: causa del incidente del colegio no demostrada. Entrega de diagnóstico, no reparación verificada.** No se ha accedido a Dirección o Jefatura ni se ha modificado su instalación. El entorno de trabajo es Linux; se ha realizado compilación cruzada del cliente Windows y se han ejecutado pruebas portables de componentes.

## 1. Evidencias y causa

El informe recibido corresponde al 05/11/2026 a las 09:31 UTC (10:31 en Madrid):

- DNS devuelve `fe80::b9a4:e0bd:ea6e:f226%10` y `192.168.6.135`.
- La prueba IPv6 tarda aproximadamente 10 segundos y falla. IPv4 conecta en 3 ms.
- TLS por la conexión de prueba termina correctamente, valida el servidor y presenta el certificado de puesto.
- `POST /api/session` empieza a las 09:31:19.877 UTC y falla a las 09:31:29.930 UTC: unos 10,05 segundos adicionales.
- Dirección `192.168.4.153` y Jefatura `192.168.6.135` pertenecen a `192.168.4.0/22` con la máscara comunicada. No se atribuye el fallo a una diferencia de subred.

**Hallazgo demostrado en el código:** `ConnectionProbe.ProbeAsync` abre un `TcpClient` por IP, establece TLS y cierra esa conexión. Después `RemoteConnection.ConnectAsync` usa otro transporte: un `HttpClientHandler` de .NET Framework 4.8 con destino `https://jefatura:7443`, sin proxy. No reutiliza el socket TCP/TLS que acababa de probarse. Por ello, el éxito de la primera conexión no demuestra la ruta ni el resultado de la petición HTTP.

**Hipótesis A:** el transporte HTTP intenta la IPv6 no accesible y no completa una conexión IPv4 dentro de su propio plazo. El orden DNS y la coincidencia de plazos son compatibles con ello; no demuestran el orden real de intentos de HttpClient ni sus tiempos. No se ha reproducido el comportamiento de Windows/.NET Framework en la red del colegio.

**Hipótesis B:** la petición sí llega y espera en el servidor. La revisión identifica estos puntos:

1. Validación de la autorización del puesto y búsqueda de sesión, ambas dependientes del bloqueo de `SecurityState`.
2. `SecurityState.Login`: bloqueo de seguridad, comprobación de contraseña o renovación/acceso automático, y guardado duradero de `security.json`.
3. Tras crear la sesión, el endpoint espera `ServerEngine.Gate` para guardar el acceso en la auditoría SQLite.
4. `ServerEngine.Backup` conserva ese mismo bloqueo durante la creación y escritura de copias, incluida una ubicación externa si existe. Una copia lenta puede retrasar el registro del acceso aunque la sesión ya se haya creado. Esto es una posibilidad derivada del código, no un fallo observado en Jefatura.

No se ha encontrado un interbloqueo demostrable en el camino de login: su bloqueo de seguridad se libera antes de adquirir el de la agenda. No se han cambiado estos bloqueos ni los permisos de usuarios basándose en una hipótesis.

El timeout anterior abarcaba DNS, conexión, TLS y recepción HTTP. Su texto no distingue esas fases. Tampoco conocemos si la solicitud original llegó al servidor: no se entregaron trazas HTTP de Jefatura.

## 2. Cambios realizados

Se ha corregido la falta de observabilidad que impide distinguir estas causas. No se ha implementado una selección automática de IPv4 ni cambiado DNS, IPv6 o el timeout.

- Cada petición API lleva un `X-Agenda-Request-Id` aleatorio. El servidor instrumentado lo valida como GUID y lo devuelve, o genera uno si no es válido.
- El informe del cliente registra inicio, validación del certificado del transporte HTTP cuando se ejecuta, recepción de cabeceras, recepción completa del cuerpo y fin. Se conserva un único presupuesto global de 10 segundos; el cambio a recepción por cabeceras no deja la lectura del cuerpo sin límite.
- Durante el diagnóstico se muestrean cada 100 ms las tablas TCP IPv4/IPv6 de Windows, filtradas por PID y puerto. Se registran extremos local/remoto, ámbito IPv6 y estados como `SYN_SENT` y `ESTABLISHED`. No se abren conexiones ni se cambian rutas para observarlas.
- **Límite de esa observación:** es por proceso, puede incluir otra petición concurrente y omitir conexiones breves. Su prefijo de ID delimita el intervalo de observación, no prueba por sí solo la propiedad de un socket. El ID y el extremo observado en Jefatura permiten la correlación exacta cuando la petición llega.
- Jefatura puede registrar recepción HTTP antes de validar red/puesto, búsqueda de acceso, lectura de cuerpo, espera/adquisición del bloqueo de seguridad, comprobación de contraseña, persistencia de sesión, espera/adquisición del bloqueo de agenda, auditoría y respuesta. Cada fase incluye tiempo monotónico desde la recepción.
- El registro del servidor usa una cola acotada y escritor independiente, rota alrededor de 1 MiB y conserva un archivo anterior. No espera al disco dentro de la autenticación. Los eventos descartados se contabilizan. No se registran nombres de usuario, contraseñas, tokens, claves ni cuerpos XML.
- La herramienta portátil acepta `--ipv4 192.168.6.135` para una comparación puntual. La URL sólo cambia en memoria; mantiene HTTPS, puerto y validación de identidad. La IP debe estar en el SAN del certificado. Se rechazan destinos públicos y HTTP sin TLS. No es un mecanismo de fallback del cliente instalado ni una recomendación para cambiar su configuración.

Archivos modificados respecto al RAR recibido:

- `aplicacion/cliente/src/RemoteConnection.cs`
- `aplicacion/cliente/src/ConnectionProbe.cs`
- `aplicacion/diagnostico-portatil/Program.cs`
- `aplicacion/servidor/Program.cs`
- `aplicacion/servidor/Security.cs`
- `aplicacion/pruebas-diagnostico/Program.cs`
- `Verificar.ps1`

Archivos nuevos de código/pruebas:

- `aplicacion/cliente/src/HttpSocketObservation.cs`
- `aplicacion/cliente/src/HttpRequestTiming.cs`
- `aplicacion/cliente/src/DiagnosticTarget.cs`
- `aplicacion/servidor/SessionDiagnostics.cs`
- `aplicacion/pruebas-sesion/AgendaClara.SessionTests.csproj`
- `aplicacion/pruebas-sesion/Program.cs`

Se añade este informe. No cambian los proyectos ni las dependencias existentes, el esquema de agenda, el protocolo, los certificados o los instaladores. Se conservan los documentos y el manifiesto anteriores como documentación histórica del paquete original; sus resultados no se presentan como pruebas de esta revisión.

## 3. Pruebas y límites

SDK .NET 10.0.403, runtime 10.0.14. Todas las compilaciones finales indicadas terminaron sin advertencias ni errores.

**Ejecutado:** batería nueva `AgendaClara.SessionTests`, 33 comprobaciones correctas y 0 fallos. Incluye interpretación de tablas TCP sintéticas IPv4/IPv6, filtrado PID/puerto, ámbito IPv6, tabla truncada, ID malicioso, seguridad real de sesiones y renovación, revocación, observador averiado, espera concurrente del bloqueo, HTTPS loopback con certificado de cliente, POST HTTP con creación de sesión, HTTP 401 para contraseña incorrecta, correlación de ID/IP y ausencia de secretos en el registro. Usa `SecurityState` y el middleware de diagnóstico de producción, y los mismos fuentes de temporización HTTP que el cliente.

También se comprobaron tiempos de espera antes de las cabeceras y durante el cuerpo (presupuestos de prueba de 300 ms), cancelación del usuario y el presupuesto predeterminado real de 10 segundos ante un endpoint que tarda 12 segundos. Se rechazaron identidad TLS incorrecta y confianza incorrecta en el servidor sintético.

La primera ejecución detectó que el endpoint sintético de cuerpo lento no había enviado efectivamente sus cabeceras: se corrigió para escribir y vaciar un fragmento antes de bloquear el cuerpo. La ejecución final completa pasa; no se desactivó la comprobación.

**Compilado:** cliente Windows, diagnóstico portátil, servidor, batería Windows existente de diagnóstico (con dos comprobaciones adicionales) y batería existente de regresión funcional del cliente.

**No ejecutado:** WPF/.NET Framework 4.8 en Windows; llamadas reales a IP Helper de Windows; servicio completo con DPAPI y SQLite de Windows; baterías completas Windows de interfaz, red, TLS e instaladores; comunicación física Dirección–Jefatura. El servidor HTTPS de la batería es un host sintético mínimo, no `ServerHost.Create` con la base de agenda real. Las pruebas del transporte usan .NET 10 en Linux, no sustituyen la ejecución net48.

No se afirma que todas las funciones existentes hayan sido verificadas en ejecución ni que la conexión del colegio esté reparada. No se han generado instaladores nuevos.

## 4. Componentes que llevar

`Direccion-portatil/` contiene `Diagnosticar-AgendaClara.exe`, `AgendaClara.exe` como dependencia y sus bibliotecas. Abrir `01-Probar-nombre.cmd`; para la comparación, `02-Comparar-IPv4.cmd`. No sustituir la aplicación instalada por estas copias. La herramienta conserva el aislamiento de sesiones del diagnóstico anterior.

`Jefatura-diagnostico-opcional/AgendaClara.Server.dll` es únicamente el módulo con trazas del servidor. No incluye EXE, runtime ni instalador. No hace falta para las primeras pruebas. Si se necesita, primero validar en la copia de desarrollo Windows y seguir las instrucciones incluidas para sustitución con servicio detenido, respaldo verificado y reversión. No reinstalar ni reinicializar el servidor.

`evidencias/` contiene el resultado final y los registros de compilación. El ZIP separado de fuentes incluye código, pruebas, informe y parche; excluye `bin`, `obj`, credenciales y datos reales.

## 5. Comprobación en el colegio

1. En Dirección, con el mismo usuario de Windows y otras ventanas cerradas, ejecutar la prueba por nombre y guardar el informe.
2. Confirmar que la IP de Jefatura sigue siendo `192.168.6.135`. Ejecutar la comparación IPv4 en una nueva ventana y guardar el segundo informe. Si TLS rechaza el nombre/IP, conservar el error y detener esa comparación; no importar ni aceptar certificados para hacerla pasar.
3. Si se necesita determinar la recepción y las esperas del servidor, usar el módulo opcional de trazas después de validarlo en Windows. Repetir ambas pruebas y recoger `diagnostico/sesiones.jsonl` en la carpeta de datos indicada por `--data`, más la generación anterior si existe.
4. Comparar el mismo ID HTTP entre Dirección y Jefatura. Los tiempos entre fases del servidor distinguen bloqueo de seguridad, comprobación de credenciales, persistencia, bloqueo de agenda, auditoría y salida. La marca `http_received` confirma llegada a la aplicación; no hay que inferirla de un puerto abierto.
5. Si sólo aparece `SYN_SENT` IPv6 durante la petición por nombre, la comparación por IPv4 funciona y el POST por nombre no aparece en un registro del servidor previamente comprobado, la selección de direcciones gana respaldo. Hay que descartar pérdida de eventos o falta de permisos del registro antes de interpretar ausencias.
6. Si aparece `security_lock_wait` sin adquisición, investigar quién conserva ese bloqueo. Si aparece `agenda_lock_wait` después de guardar sesión, comprobar copias y auditoría. Si llegan cabeceras al cliente y no termina el cuerpo, investigar la respuesta y su transporte. Un `pipeline_end` por sí solo no demuestra recepción en Dirección; buscar finalización y el resultado del cliente.

Sólo se declarará solucionado tras verificar autenticación, recuperación de agenda y sincronización entre ambos equipos; si se usa una creación de prueba para comprobar propagación, hacerla con autorización del centro y retirarla después. No es necesario reinstalar el servidor para recoger estas evidencias.

## 6. Reproducir las pruebas de desarrollo

Desde `codigo-fuente`, en una máquina con SDK .NET 10:

```text
dotnet build aplicacion/pruebas-sesion/AgendaClara.SessionTests.csproj -c Release
dotnet aplicacion/pruebas-sesion/bin/Release/net10.0/AgendaClara.SessionTests.dll <carpeta-nueva-de-pruebas>
```

Para compilación cruzada del diagnóstico Windows:

```text
dotnet build aplicacion/diagnostico-portatil/AgendaClara.Diagnostico.csproj -c Release -p:EnableWindowsTargeting=true
```

En Windows, `Verificar.ps1` integra la batería nueva además de las existentes. El script requiere el entorno y las condiciones documentadas originalmente; no se ha ejecutado completo desde Linux.
