@echo off
setlocal
set "DEMODIR=%LOCALAPPDATA%\NexoCentroExperimentalGoogleOAuth\DemoGoogle"
if not exist "%DEMODIR%" mkdir "%DEMODIR%"
if not exist "%DEMODIR%\agenda.sqlite3" copy "%~dp0Datos-iniciales\Agenda-ficticia.sqlite3" "%DEMODIR%\agenda.sqlite3" >nul
if not exist "%DEMODIR%\TrabajoCompartido.xml" copy "%~dp0Datos-iniciales\Configuracion-demo.xml" "%DEMODIR%\TrabajoCompartido.xml" >nul
start "" "%~dp0Cliente\AgendaClara.exe" --agenda "%DEMODIR%\agenda.sqlite3" --config "%DEMODIR%\TrabajoCompartido.xml"
