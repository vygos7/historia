# Nexo Centro 4.0.4 — interfaz r1

Estado: versión de prueba compilada y validada en Windows. Las ocho baterías de la ejecución https://github.com/vygos7/historia/actions/runs/42106266327 (revisión ba5f0a8) terminaron correctamente: 552 comprobaciones, 0 fallos. Falta la revisión visual y de uso del usuario en sus puestos reales; no se ha modificado el colegio.

## Nombre y presentación

- Nexo Centro aparece en la ventana principal, identificación, mensajes de presentación, informes impresos/PDF, asistentes de instalación y accesos directos nuevos.
- Diseño A: calendario amplio, lateral con Calendario, Hoy, Memorias e informes y Ajustes. Se elimina la lista permanente de categorías y su repetición en la leyenda. El filtro desplegable conserva todas las categorías.
- Diseño C en Hoy y en la vista diaria: fichas agrupadas en Todo el día, Mañana y Tarde; calendario auxiliar y próximos acontecimientos a la derecha. Se conservan los datos completos de cada ficha y los mismos comandos de edición.
- El color de categoría se presenta como punto en las citas compactas y una línea discreta en las fichas; los nombres y colores configurados en los datos no se modifican.
- Ajustes mantiene Trabajo compartido, Categorías, Calendario escolar, Copias de seguridad y Resumen de hoy. El resumen de inicio de Windows conserva su comportamiento y su casilla de activación.
- Mes, Semana, Día, Próximos, Resultados, búsqueda, filtros, avisos, edición de fechas/repeticiones/excepciones, tareas, seguimiento, memorias, informes y exportación siguen disponibles.

## Arquitectura conservada

Se comprobó igualdad byte a byte de 18 archivos de lógica de cliente y servidor respecto a la última base validada. Incluyen modelos, planificación, almacenamiento SQLite, trabajo remoto, contratos, TLS, transporte con fallback IPv4/IPv6, plazos HTTP y arranque de Windows. También se conservan las 27 DLL externas del cliente.

El payload del servidor es exactamente el validado anteriormente, SHA-256:
`d2a86d396ba721301fa519c7bddfe20133c8efae0b747b1a0c80bbbe583717a8`.

No hay cambios en esquemas, formatos de agenda/copia/caché, API, autenticación, certificados, sincronización ni reglas de red. El código del instalador conserva sus operaciones: las diferencias son textos literales de marca, versión del envoltorio, nombre de acceso directo y nombres de los paquetes generados. Las evidencias incluyen las huellas y la revisión de esas diferencias.

Se mantienen deliberadamente los nombres técnicos AgendaClara de namespaces, ejecutables internos, carpetas, claves de registro, servicio y regla de firewall. Cambiarlos crearía riesgo de una segunda configuración, pérdida de reconocimiento de certificados o duplicación de servicios. No renombrarlos manualmente. El cambio de marca no requiere migrar los datos.

## Validación

| Batería Windows | Comprobaciones correctas |
|---|---:|
| Datos, migraciones y persistencia | 109 |
| Interfaz WPF real, formularios y tamaños | 149 |
| Transporte HTTPS, TLS y fallback | 32 |
| Sesiones y persistencia segura | 38 |
| Diagnóstico del cliente .NET Framework | 33 |
| Red y sincronización con interfaz compartida | 53 |
| Red y cortafuegos del instalador | 23 |
| Generación, instalación y reparación de puestos | 60 |
| Servicio, actualización y seis reversiones | 55 |
| **Total** | **552** |

Las 25 comprobaciones locales de integridad y empaquetado también pasaron. Las pruebas Windows usan datos sintéticos en un equipo efímero windows-2025, sin instalaciones del colegio. El cliente distribuido se verifica idéntico al ejecutable utilizado por las pruebas. La revisión final sólo incorpora documentación y evidencias: no cambia esos ejecutables.

Las pruebas WPF cubren creación y edición, navegación, búsqueda y filtros, categorías, calendario escolar, avisos, copias, tareas y memorias, resumen diario, arranque y reapertura, y controles sin recortes en tamaños de 960×560, 1100×700 y 1280×800. Las capturas reales de la ejecución se conservan como artefacto `resultados-nexo-centro-ui-r1` en GitHub Actions.

El CI usa sólo `contents: read`, checkout sin credenciales persistentes e informes como artefactos. No realiza commits automáticos. Algunos resúmenes de pruebas heredados incluyen una mención fija a Linux o a Windows pendiente; el entorno real de esta ejecución es windows-2025 y las pruebas específicas de Windows también se ejecutaron. El resultado se identifica por el enlace y las huellas, no por esa etiqueta histórica.

## Uso de la entrega

Para un puesto ya configurado: cerrar el cliente y ejecutar `Instalar-NexoCentro-Cliente.exe` con su usuario de Windows habitual. La conexión y los accesos existentes se conservan. No reinstalar el servidor para probar el diseño.

Para un centro nuevo: ejecutar `Instalar-NexoCentro-Servidor.exe` en su servidor. Genera los EXE de Jefatura, Dirección y Secretaría con la interfaz nueva y con identidades propias del centro. Revisar nombre/IP estable, puerto, subredes autorizadas y permisos entre redes. Se conservan los tres perfiles del firewall, limitados al programa, puerto y redes autorizadas. No se desactiva IPv6 ni TLS.

Se requieren Windows x64 compatible y .NET Framework 4.8 en asistentes y clientes; el servidor conserva su runtime autocontenido. La base central debe estar en disco local y deben mantenerse copias externas y clave de recuperación separada. Los EXE no tienen firma Authenticode: respetar la política del centro.

Antes de extender a todos los puestos, revisar la apariencia y comprobar creación, edición y borrado sincronizados entre dos equipos. Las baterías Pruebas no deben ejecutarse en equipos escolares. Los instaladores y los datos de ejemplo son para revisión de esta versión de interfaz, no una certificación de todas las redes o variantes de Windows.
