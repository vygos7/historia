# AgendaClara 4.0.3 (instalador 1.2.2): puestos en varias subredes

**Fecha:** 03/11/2026 · **Base:** 4.0.2 / instalador 1.2.1 (`D:\Agenda\AgendaClara-4.0.2-desarrollo`, sin modificar)
**Estado:** copia de desarrollo compilada y probada en un solo ordenador. **No se ha instalado nada en los ordenadores del colegio** y no se ha tocado el servidor que funciona en este portátil.

## 1. El problema

En un centro con Jefatura, Dirección y Secretaría en subredes distintas, los puestos no podían conectar: daban «tiempo de espera agotado». No era un fallo de ese colegio, sino del diseño del instalador 4.0.2, así que afectaría a cualquier centro con la red dividida:

| Causa en 4.0.2 | Efecto |
|---|---|
| El instalador solo admitía **una** red autorizada y creaba la regla del cortafuegos únicamente para ella (`RemoteAddresses = esa red`). | Windows descartaba en silencio las conexiones de otras subredes: «tiempo de espera agotado». |
| El servidor guardaba esa única red. Si alguien llegaba desde otra, respondía 403 sin explicación. | El cliente lo mostraba como «usuario no autorizado o sesión caducada». |
| La dirección incluida en los instaladores era el nombre del equipo (`https://JEFATURA:7443`) y el certificado solo valía para ese nombre. | Desde otra subred ese nombre no se encuentra si el centro no tiene DNS interno, y no se podía usar la IP. |
| Al **actualizar** el servidor, las opciones de red estaban bloqueadas, se volvía a leer solo la primera red y no se rehacía la regla del cortafuegos. | No había forma de corregirlo sin instalar de cero. |
| Si Windows tenía la red del servidor marcada como **pública**, la regla no se aplicaba, y nada lo advertía. | Fallo sin explicación, incluso dentro de la misma subred. |

## 2. Qué cambia

**Instalador del servidor** (`instalador/src/Forms.cs`, `Installers.cs`, `Common.cs`)
- **Redes de los puestos (una por línea):** admite varias subredes, hasta 32. Propone todas las redes detectadas en Jefatura e incluye el botón «Autorizar toda la red privada del centro» (10.0.0.0/8, 172.16.0.0/12 y 192.168.0.0/16). Solo acepta redes privadas; si alguna no lo es, indica cuál.
- **Dirección de Jefatura para los puestos:** desplegable con el nombre del equipo, su nombre DNS si pertenece a un dominio, y sus IP privadas. Explica cuándo conviene la IP fija.
- Una línea de resumen en la primera página: «Los puestos se conectarán a https://…:7443 desde: …».
- La regla del cortafuegos incluye **todas** las redes autorizadas.
- **Actualizar el servidor** permite ahora cambiar dirección, redes y puerto. Aplica el cambio en el servidor, rehace la regla del cortafuegos y genera instaladores de puesto nuevos.
- La página de revisión avisa, sin bloquear, de estos casos:
  - puestos en otra subred cuando la dirección elegida es el nombre del equipo;
  - una IP que no pertenece a ese ordenador;
  - la necesidad de que el router deje pasar el puerto;
  - redes que Windows tiene marcadas como públicas.
- Junto a los instaladores se guarda **`Red-y-conexion.txt`** con:
  - la dirección, las IP de Jefatura y las redes autorizadas;
  - los cuatro requisitos para que un puesto conecte;
  - la comprobación `Test-NetConnection` que se ejecuta en el puesto y cómo interpretar su resultado.

**Servidor** (`aplicacion/servidor/`)
- `init` y `recover` aceptan varias redes en `--network` (separadas por comas).
- Nueva orden **`configure-network --data … --host … --network … --port …`**. Cambia la red de un servidor ya instalado y conserva el resto de la configuración. La usa el instalador al actualizar; requiere el servicio detenido.
- El certificado HTTPS del servidor vale para la dirección elegida, el nombre del equipo, su nombre DNS y sus IP privadas. Así se puede pasar del nombre a la IP fija sin crear otra autoridad. Lo emite la misma autoridad del centro, de modo que los puestos ya instalados siguen confiando en él.
- Un puesto de una red no autorizada recibe un mensaje claro con su propia dirección, en lugar de un 403 vacío.

**Cliente** (`aplicacion/cliente/src/RemoteConnection.cs`)
- El rechazo por red no autorizada se muestra como tal y deja de confundirse con un problema de usuario.
- Los mensajes de tiempo de espera y de red muestran la dirección del propio puesto y qué revisar si está en otra subred. Si no se encuentra el nombre, indican la solución: IP fija o DNS del centro.

No cambian el modelo de datos, la agenda, los usuarios, los certificados de los puestos, las copias ni el puerto por defecto (7443).

## 3. Pruebas (03/11/2026, portátil `LAPTOP-HTS6T8CT`, Windows 11)

Todo se ha compilado desde `codigo-fuente/` con el SDK .NET 10.0.403 y el compilador de .NET Framework 4.8. Los instaladores se han generado desde esta misma compilación.

| Batería | Resultado |
|---|---|
| Regresión de datos e interfaz del cliente | **109 + 136, 0 fallos** (igual que la 4.0.2) |
| Seguridad del servidor | **26, 0 fallos**: las 14 anteriores y 12 nuevas (varias redes, IPv4 en IPv6, nombres del certificado, IP en el certificado, `configure-network` conserva la configuración y rechaza redes no válidas sin tocar nada) |
| Red del instalador y mensajes del cliente (nueva, `instalador/pruebas/RedTests.cs`) | **20, 0 fallos**: lista de redes, rechazo de redes públicas, regla del cortafuegos, sugerencias de dirección, lectura de todas las redes al actualizar, avisos, `Red-y-conexion.txt`, mensajes de tiempo de espera y de DNS con la dirección del puesto |
| Certificados TLS | **11, 0 fallos**. Los almacenes de certificados del usuario, antes y después: 25 personales y 342 raíces |
| Indicador de estado | **2, 0 fallos** |
| Asistente del servidor | Se ha dibujado la pantalla con las opciones de red abiertas, sin instalar nada (`verificacion/asistente-opciones-de-red.png`) |

## 4. No probado y pendiente

- **No se han ejecutado las baterías de red multiusuario (53) ni de instalador (60).** Las dos añaden temporalmente una autoridad raíz de prueba al almacén del usuario, y Windows pide confirmarlo a mano. Necesitan tu autorización.
- **No se ha probado con dos ordenadores reales en subredes distintas.** Este portátil está en una sola red (192.168.1.0/24).
- **Lo que queda fuera de AgendaClara:** el router o cortafuegos que separa las subredes tiene que permitir TCP 7443 hacia Jefatura. El instalador lo advierte y lo explica en `Red-y-conexion.txt`, pero no puede configurarlo. Si la red la gestiona otra entidad, hay que pedírselo.
- **El cambio de red pública a privada** no se hace automáticamente: el instalador lo advierte y explica cómo hacerlo.
- **En este portátil hay un servidor AgendaClara instalado y funcionando** (servicio `AgendaClaraServidor`, datos en `C:\ProgramData\AgendaClaraServidor`). No se ha modificado. Durante las pruebas lancé una vez por error el ejecutable del servidor sin carpeta de pruebas. Se detuvo en el primer paso porque la carpeta de datos está bloqueada por el servicio, y no escribió nada.
- Los EXE no tienen firma Authenticode. Comprueba sus SHA-256 en `instaladores/SHA256SUMS.txt`.

## 5. Cómo aplicarlo en un centro con varias subredes

1. En Jefatura, haz una copia cifrada reciente del servidor.
2. Abre `instaladores/Instalar-AgendaClara.exe` como administrador, elige **Actualizar el servidor** y pulsa **Opciones de red…**:
   - **Dirección:** si no hay DNS interno, la **IP fija** de Jefatura. Si Jefatura recibe la IP por DHCP, hay que reservarla en el router.
   - **Redes de los puestos:** una línea por subred (la de Jefatura, la de Dirección, la de Secretaría…), o «Autorizar toda la red privada del centro».
3. Revisa los avisos de la página final e instala.
4. Pide que el router permita TCP 7443 desde esas subredes hacia la IP de Jefatura.
5. En cada puesto, comprueba la conexión con la orden de `Red-y-conexion.txt`. Si **cambiaste la dirección**, instala su instalador nuevo; si solo añadiste redes, el puesto sigue funcionando con el que ya tenía.

## 6. Contenido

```
AgendaClara-4.0.3-desarrollo/
  INFORME-4.0.3.md
  instaladores/      Instalar-AgendaClara.exe (servidor), Reparar-AgendaClara-Cliente.exe, SHA256SUMS.txt
  codigo-fuente/     fuentes completas, incluidas las pruebas nuevas
  compilado/         cliente y servidor publicados (origen de los instaladores)
  verificacion/      resultados y capturas (sin claves ni agendas de prueba)
```
