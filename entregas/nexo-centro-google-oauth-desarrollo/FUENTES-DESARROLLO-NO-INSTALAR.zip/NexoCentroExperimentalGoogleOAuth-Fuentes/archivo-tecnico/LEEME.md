Material de la revisión anterior para auditoría del desarrollo. No son pasos de configuración de la interfaz 4.2.0. No ejecutar scripts en Google ni pedirlos al usuario.
