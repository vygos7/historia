# Conectar el formulario único a la versión EXPERIMENTAL

No se ha cambiado el formulario real ni se ha desplegado nada en tu cuenta. Esta activación requiere que el propietario lo haga en Google. Para la primera prueba, **haz una copia del formulario** y usa únicamente datos ficticios. La aplicación estable no se modifica.

1. Abre la copia del formulario en modo edición. En su dirección identifica el texto entre `/forms/d/` y `/edit`. No es el identificador público que empieza por `1FAIp`.
2. Crea un proyecto independiente en Google Apps Script. Pega `Code.gs` y cambia únicamente `FORM_ID` por ese identificador de edición. El manifiesto `appsscript.json` especifica V8 y zona Europe/Madrid.
3. Revisa el código y ejecuta `prepararFormulario`. Google solicitará permiso para acceder a formularios con tu cuenta. El script sólo abre el formulario configurado: comprueba las preguntas, añade Código y Nombre si faltan y genera la plantilla. No envía respuestas de prueba.
4. Las preguntas de evaluación deben conservar los nombres del PDF facilitado. La fecha debe ser de tipo Fecha y Curso o grupo debe ser texto. El script mueve Código y Nombre junto a los datos iniciales y deja esos datos como obligatorios. No quedan bloqueados: Nexo valida su correspondencia.
5. En el registro privado de ejecución aparecerá la plantilla y un secreto. No compartas ese registro, no lo subas a GitHub ni envíes el secreto por esta conversación.
6. Para probar sólo el enlace y el CSV, copia la plantilla en Ajustes → Evaluaciones Google de la aplicación EXPERIMENTAL. No hace falta desplegar el servicio. Genera un enlace de una actividad guardada con grupo, ábrelo y comprueba los cuatro datos. Responde con datos ficticios, descarga el CSV desde Respuestas de Google Forms e impórtalo en la versión experimental. Revisa y aplica desde la vista previa.
7. Para recogida automática: en Apps Script elige Desplegar → Nueva implementación → Aplicación web. Ejecutar como: propietario. El acceso sin inicio de sesión permite las consultas del servidor; el script exige HMAC, fecha y nonce, y firma sus respuestas. **No publiques la hoja de respuestas.** Si la política de Google Workspace prohíbe este despliegue, no la eludas: usa la importación CSV mientras se evalúa OAuth con el responsable.
8. Copia la URL terminada en `/exec`, la plantilla y el secreto en el panel Google de Jefatura **del servidor experimental**. Guarda con consulta automática desactivada y utiliza Consultar Google ahora. Actualiza la lista y revisa los resultados. El secreto se cifra en el servidor con DPAPI y nunca vuelve al cliente en la consulta de estado.
9. Tras una prueba completa, activa la casilla de importación automática. El intervalo predeterminado son 15 minutos, configurable entre 5 y 1440. Sólo se completan memorias vacías con correspondencia inequívoca y actividad ya realizada. Las existentes, duplicadas, editadas o inconsistentes requieren revisión.
10. Si modificas el código del script después de desplegar, publica una versión nueva de la implementación. Conserva el secreto salvo que quieras revocarlo y actualizar la configuración del servidor.

La lectura se hace directamente desde las respuestas del formulario usando sus identificadores estables; no requiere mantener una lista de actividades ni crear un formulario por salida. Los docentes sólo reciben el enlace. Las respuestas antiguas sin código no se asignan por fecha aproximada.

**No actives «Limitar a 1 respuesta» en el formulario general:** impediría que un mismo docente evaluara otras salidas. Nexo Centro controla una memoria por actividad mediante el código y pone los duplicados pendientes de revisión.

La integración no es un mecanismo de autenticación del docente: el enlace identifica la actividad, pero los campos prerrellenados se pueden editar. Usa las restricciones de respuesta de Google adecuadas al centro y revisa cualquier incidencia. El script no recopila el correo del respondedor; sólo los datos de actividad y los seis campos de memoria.

Las copias estándar de la agenda incluyen las memorias una vez guardadas. La configuración y registro de esta integración se guardan aparte (`google-settings.xml`, `google-evaluations.xml`); no se añade un nuevo formato a las copias ya existentes. Tras una recuperación de la agenda, los enlaces antiguos requieren revisión por cambio de generación. Guarda también la configuración de integración de forma segura; el secreto DPAPI no se traslada automáticamente a otro ordenador.

**Todavía falta probar el ciclo completo con una cuenta real de Google autorizada.** Las comprobaciones de código y los simuladores no sustituyen esa prueba. No instalar en el colegio ni sustituir la versión estable por este prototipo.
