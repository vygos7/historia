/* Pruebas sin conexión ni cuenta Google. Sólo simuladores y datos sintéticos. */
const fs=require('node:fs'),vm=require('node:vm'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const secret='SECRETO-SINTETICO-SOLO-PRUEBAS-123456789';
const fields={code:'1',title:'2',date:'3',group:'4',rating:'5',positives:'6',difficulties:'7',improvements:'8',continuity:'9',justification:'10'};
const properties={FORM_ID:'FORM-SINTETICO',NEXO_SECRET:secret,NEXO_FIELDS:JSON.stringify(fields)};
let cache=new Map(),requests=0;
const values={'1':'NCX-prueba','2':'Cine & teatro','3':'2026-11-05','4':'3.º A','5':'Muy buena','6':'Participación','7':'Ninguna','8':'Tiempo','9':'Sí','10':'Objetivos cumplidos'};
const response={getId:()=> 'RESP-SINTETICA-1',getTimestamp:()=> new Date('2026-11-05T12:00:00Z'),getItemResponses:()=>Object.entries(values).map(([id,value])=>({getItem:()=>({getId:()=>id}),getResponse:()=>value}))};
const form={getId:()=> 'FORM-SINTETICO',getResponses:since=>{requests++;assert.ok(since instanceof Date);return [response];}};
const context=vm.createContext({Date,console,PropertiesService:{getScriptProperties:()=>({getProperty:k=>properties[k]||null})},
  FormApp:{openById:id=>{assert.equal(id,'FORM-SINTETICO');return form;}},
  CacheService:{getScriptCache:()=>({get:k=>cache.get(k),put:(k,v)=>cache.set(k,v)})},
  LockService:{getScriptLock:()=>({tryLock:()=>true,releaseLock:()=>{}})},
  Utilities:{Charset:{UTF_8:'UTF-8'},base64Encode:v=>Buffer.from(v).toString('base64'),base64Decode:v=>Buffer.from(v,'base64'),computeHmacSha256Signature:(p,s)=>crypto.createHmac('sha256',s).update(p).digest(),newBlob:b=>({getDataAsString:()=>Buffer.from(b).toString('utf8')}),formatDate:d=>d.toISOString().slice(0,10)},
  ContentService:{MimeType:{JSON:'json'},createTextOutput:text=>({text,setMimeType(){return this;}})}});
vm.runInContext(fs.readFileSync(__dirname+'/Code.gs','utf8'),context);
let passed=0;
function test(name,run){run();passed++;console.log('OK · '+name);}
function sign(payload){return crypto.createHmac('sha256',secret).update(payload).digest('base64');}
function request(changes={}){return {protocol:1,nonce:crypto.randomBytes(16).toString('hex'),timestamp:Date.now()/1000,sinceUtc:'2026-11-01T00:00:00Z',index:0,limit:100,...changes};}
function envelope(data){let payload=Buffer.from(JSON.stringify(data)).toString('base64');return {payload,signature:sign(payload)};}
function send(env){return JSON.parse(context.doPost({postData:{contents:JSON.stringify(env)}}).text);}
function read(env){assert.equal(env.signature,sign(env.payload));return JSON.parse(Buffer.from(env.payload,'base64').toString('utf8'));}
test('GET nunca devuelve respuestas',()=>assert.equal(JSON.parse(context.doGet().text).ok,false));
test('No responde sin firma válida',()=>{let n=requests;assert.equal(send({payload:'x',signature:'x'}).ok,false);assert.equal(requests,n);});
test('Petición firmada exporta sólo los datos necesarios',()=>{let data=request();let reply=read(send(envelope(data)));assert.equal(reply.nonce,data.nonce);assert.equal(reply.protocol,1);assert.equal(reply.responses[0].code,'NCX-prueba');assert.equal(reply.responses[0].memory.justification,'Objetivos cumplidos');assert.equal(reply.responses[0].date,'2026-11-05');assert.equal(reply.responses[0].responseId,'RESP-SINTETICA-1');assert.equal(JSON.stringify(reply).includes(secret),false);assert.equal(JSON.stringify(reply).includes('email'),false);});
test('Nonce repetido se rechaza',()=>{let env=envelope(request());read(send(env));assert.equal(send(env).ok,false);});
test('Petición caducada se rechaza antes de leer el formulario',()=>{let n=requests;assert.equal(send(envelope(request({timestamp:Date.now()/1000-181}))).ok,false);assert.equal(requests,n);});
test('Fecha inicial inválida se rechaza',()=>assert.equal(send(envelope(request({sinceUtc:'no es fecha'}))).ok,false));
test('Límite excesivo se rechaza',()=>assert.equal(send(envelope(request({limit:101}))).ok,false));
test('Índice negativo se rechaza',()=>assert.equal(send(envelope(request({index:-1}))).ok,false));
test('Versión de protocolo desconocida se rechaza',()=>assert.equal(send(envelope(request({protocol:2}))).ok,false));
test('Fecha ISO se normaliza sin aproximarla',()=>{assert.equal(context.isoDate_('2026-1-2'),'2026-01-02');assert.equal(context.isoDate_('fecha desconocida'),'fecha desconocida');});
test('Cabeceras admiten números y acentos',()=>assert.equal(context.norm_(' 2.  Valoración  general '),'VALORACION GENERAL'));
test('Comparación de firma distingue contenido y longitud',()=>{assert.equal(context.equal_('abc','abc'),true);assert.equal(context.equal_('abc','abcd'),false);assert.equal(context.equal_('abc','abd'),false);});
console.log(`RESUMEN: ${passed} pruebas correctas; 0 fallos. Simulador Apps Script; Google real pendiente.`);
