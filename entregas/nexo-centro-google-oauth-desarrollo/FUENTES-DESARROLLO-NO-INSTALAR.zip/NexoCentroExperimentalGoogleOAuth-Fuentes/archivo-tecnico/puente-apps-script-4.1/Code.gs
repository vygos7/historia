/* Nexo Centro 4.1.0 EXPERIMENTAL. Proyecto independiente de Apps Script.
 * No publica respuestas: doPost exige firma HMAC, fecha y nonce.
 * Ejecutar prepararFormulario() sólo después de revisar este código.
 */
const FORM_ID = 'PEGA_AQUI_EL_ID_DE_LA_URL_DE_EDICION_DEL_FORMULARIO';
const FIELDS = {
  code: ['Código de la actividad'], title: ['Nombre de la actividad'],
  date: ['Fecha de la salida', 'Fecha de realización'], group: ['Curso o grupo', 'Grupo'],
  rating: ['Valoración general'], positives: ['Aspectos positivos'],
  difficulties: ['Incidencias y dificultades'], improvements: ['Propuestas de mejora'],
  continuity: ['¿Se recomienda repetir esta salida en próximos cursos?', 'Continuidad'],
  justification: ['Justificación de la continuidad']
};
function norm_(s) { return String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim().replace(/^\d+[.\s)\-]*/, '').replace(/\s+/g, ' ').toUpperCase(); }
function form_() {
  const id = PropertiesService.getScriptProperties().getProperty('FORM_ID') || FORM_ID;
  if (!id || id.indexOf('PEGA_') === 0) throw new Error('Configura FORM_ID con el identificador de la URL /forms/d/ID/edit.');
  return FormApp.openById(id);
}
function find_(form, names, optional) {
  const matches = form.getItems().filter(i => names.some(n => norm_(i.getTitle()) === norm_(n)));
  if (matches.length > 1 || (!optional && matches.length !== 1)) throw new Error('Falta una pregunta o está duplicada: ' + names[0]);
  return matches[0] || null;
}
function textResponse_(item, value) {
  if (item.getType() === FormApp.ItemType.TEXT) return item.asTextItem().createResponse(value);
  if (item.getType() === FormApp.ItemType.PARAGRAPH_TEXT) return item.asParagraphTextItem().createResponse(value);
  throw new Error('La pregunta debe ser de texto: ' + item.getTitle());
}
function prepararFormulario() {
  const form = form_();
  // Comprobar el formulario original antes de añadir los dos identificadores.
  Object.keys(FIELDS).filter(k => k !== 'code' && k !== 'title').forEach(k => find_(form, FIELDS[k], false));
  let code = find_(form, FIELDS.code, true), title = find_(form, FIELDS.title, true);
  if (!code) code = form.addTextItem().setTitle(FIELDS.code[0]);
  if (!title) title = form.addTextItem().setTitle(FIELDS.title[0]);
  if (code.getType() !== FormApp.ItemType.TEXT || title.getType() !== FormApp.ItemType.TEXT) throw new Error('Código y nombre deben ser preguntas de respuesta corta.');
  code.asTextItem().setRequired(true).setHelpText('Dato rellenado desde Nexo Centro. No lo modifiques.');
  title.asTextItem().setRequired(true).setHelpText('Nombre de la actividad enviado por Jefatura. No lo modifiques.');
  const group = find_(form, FIELDS.group, false), date = find_(form, FIELDS.date, false);
  if (date.getType() !== FormApp.ItemType.DATE) throw new Error('La fecha de la salida debe ser una pregunta de fecha.');
  if (group.getType() === FormApp.ItemType.TEXT) group.asTextItem().setRequired(true);
  else if (group.getType() === FormApp.ItemType.PARAGRAPH_TEXT) group.asParagraphTextItem().setRequired(true);
  else throw new Error('Curso o grupo debe ser texto para permitir el prerrellenado.');
  date.asDateItem().setRequired(true);
  const position = Math.min(group.getIndex(), date.getIndex());
  form.moveItem(code.getIndex(), position);form.moveItem(title.getIndex(), code.getIndex() + 1);
  const ids = {}; Object.keys(FIELDS).forEach(k => ids[k] = String(find_(form, FIELDS[k], false).getId()));
  const properties = PropertiesService.getScriptProperties();
  properties.setProperty('FORM_ID', form.getId());properties.setProperty('NEXO_FIELDS', JSON.stringify(ids));
  if (!properties.getProperty('NEXO_SECRET')) properties.setProperty('NEXO_SECRET', Utilities.getUuid().replace(/-/g, '') + Utilities.getUuid().replace(/-/g, ''));
  mostrarConfiguracion();
}
function plantilla_(form) {
  const response = form.createResponse()
    .withItemResponse(textResponse_(find_(form, FIELDS.code, false), '__NEXO_CODE__'))
    .withItemResponse(textResponse_(find_(form, FIELDS.title, false), '__NEXO_TITLE__'))
    .withItemResponse(textResponse_(find_(form, FIELDS.group, false), '__NEXO_GROUP__'))
    .withItemResponse(find_(form, FIELDS.date, false).asDateItem().createResponse(new Date(2031, 1, 3)));
  const url = response.toPrefilledUrl(), pos = url.indexOf('?');
  if (pos < 0) throw new Error('Google no ha generado parámetros de prerrellenado.');
  let hasDate = false, hasYear = false, hasMonth = false, hasDay = false;
  const parts = url.slice(pos + 1).split('&').map(part => {
    const pair = part.split('='), key = decodeURIComponent(pair.shift()), original = decodeURIComponent(pair.join('=') || '');
    let value = original;
    if (/^2031-0?2-0?3$/.test(value) || /^0?3\/0?2\/2031$/.test(value)) { value = '__NEXO_DATE__'; hasDate = true; }
    else if (/^entry\./.test(key) && /_year$/.test(key) && value === '2031') { value = '__NEXO_YEAR__'; hasYear = true; }
    else if (/^entry\./.test(key) && /_month$/.test(key) && Number(value) === 2) { value = '__NEXO_MONTH__'; hasMonth = true; }
    else if (/^entry\./.test(key) && /_day$/.test(key) && Number(value) === 3) { value = '__NEXO_DAY__'; hasDay = true; }
    return encodeURIComponent(key) + '=' + encodeURIComponent(value);
  });
  if (!(hasDate || (hasYear && hasMonth && hasDay))) throw new Error('Revisar el formato de fecha que devuelve Google; no se ha supuesto un formato.');
  const template = url.slice(0, pos) + '?' + parts.join('&');
  ['__NEXO_CODE__', '__NEXO_TITLE__', '__NEXO_GROUP__'].forEach(token => { if (template.indexOf(token) < 0) throw new Error('Falta parámetro: ' + token); });
  return template;
}
function mostrarConfiguracion() {
  const properties = PropertiesService.getScriptProperties(), secret = properties.getProperty('NEXO_SECRET');
  if (!secret || !properties.getProperty('NEXO_FIELDS')) throw new Error('Ejecuta primero prepararFormulario.');
  // Este registro es privado del propietario del script. NO publicarlo ni enviarlo al chat.
  console.log(JSON.stringify({prefillTemplate: plantilla_(form_()), endpoint: 'PEGA_LA_URL_DEL_DESPLIEGUE_TERMINADA_EN_EXEC', secret: secret, enabled: false, pollMinutes: 15}, null, 2));
}
function hmac_(text, secret) { return Utilities.base64Encode(Utilities.computeHmacSha256Signature(text, secret, Utilities.Charset.UTF_8)); }
function equal_(a, b) { a = String(a || '');b = String(b || '');let difference = a.length ^ b.length;const size = Math.max(a.length, b.length);for (let i = 0; i < size; i++) difference |= (a.charCodeAt(i) || 0) ^ (b.charCodeAt(i) || 0);return difference === 0; }
function output_(value) { return ContentService.createTextOutput(JSON.stringify(value)).setMimeType(ContentService.MimeType.JSON); }
function isoDate_(value) {
  if (value instanceof Date && !isNaN(value.getTime())) return Utilities.formatDate(value, 'Europe/Madrid', 'yyyy-MM-dd');
  const text = String(value || '').trim();
  let match = /^(\d{4})-(\d{1,2})-(\d{1,2})$/.exec(text);
  if (match) return match[1] + '-' + ('0' + match[2]).slice(-2) + '-' + ('0' + match[3]).slice(-2);
  // La fecha que no se reconoce se devuelve para revisión; no se aproxima a ninguna actividad.
  return text;
}
function doGet() { return output_({ok: false, error: 'Servicio privado. Se requiere una petición firmada.'}); }
function doPost(e) {
  try {
    if (!e || !e.postData || !e.postData.contents || e.postData.contents.length > 16000) return output_({ok: false});
    const properties = PropertiesService.getScriptProperties(), secret = properties.getProperty('NEXO_SECRET');
    if (!secret) return output_({ok: false});
    const envelope = JSON.parse(e.postData.contents);
    if (!envelope || typeof envelope.payload !== 'string' || !equal_(hmac_(envelope.payload, secret), envelope.signature)) return output_({ok: false});
    const request = JSON.parse(Utilities.newBlob(Utilities.base64Decode(envelope.payload)).getDataAsString('UTF-8'));
    if (request.protocol !== 1 || !/^[a-f0-9]{32}$/.test(request.nonce || '') || !Number.isFinite(request.timestamp) || Math.abs(Date.now()/1000 - request.timestamp) > 180) return output_({ok: false});
    if (!Number.isInteger(request.index) || request.index < 0 || !Number.isInteger(request.limit) || request.limit < 1 || request.limit > 100) return output_({ok: false});
    const since = new Date(request.sinceUtc);if (isNaN(since.getTime()) || since.getUTCFullYear() < 2020 || since.getTime() > Date.now() + 300000) return output_({ok: false});
    const lock = LockService.getScriptLock();if (!lock.tryLock(3000)) return output_({ok: false});
    try { const cache = CacheService.getScriptCache(), key = 'nexo:' + request.nonce;if (cache.get(key)) return output_({ok: false});cache.put(key, '1', 600); } finally { lock.releaseLock(); }
    const form = form_(), ids = JSON.parse(properties.getProperty('NEXO_FIELDS') || '{}');
    const responses = form.getResponses(since).sort((a,b) => a.getTimestamp().getTime()-b.getTimestamp().getTime() || String(a.getId()).localeCompare(String(b.getId())));
    const page = responses.slice(request.index, request.index + request.limit).map(response => {
      const values = {};response.getItemResponses().forEach(r => values[String(r.getItem().getId())] = r.getResponse());
      const get = key => {const value = values[ids[key]];return value == null ? '' : Array.isArray(value) ? value.join('\n') : String(value);};
      return {responseId: String(response.getId()), code: get('code').trim(), title: get('title'), date: isoDate_(values[ids.date]), group: get('group'), submittedUtc: response.getTimestamp().toISOString(),
        memory: {rating: get('rating'), positives: get('positives'), difficulties: get('difficulties'), improvements: get('improvements'), continuity: get('continuity').trim(), justification: get('justification')}};
    });
    const result = {protocol: 1, nonce: request.nonce, formId: form.getId(), nextIndex: request.index + request.limit < responses.length ? request.index + request.limit : -1, responses: page};
    const payload = Utilities.base64Encode(JSON.stringify(result), Utilities.Charset.UTF_8);
    return output_({payload: payload, signature: hmac_(payload, secret)});
  } catch (error) { return output_({ok: false, error: 'No se ha podido procesar la consulta. Revisar configuración del propietario.'}); }
}
