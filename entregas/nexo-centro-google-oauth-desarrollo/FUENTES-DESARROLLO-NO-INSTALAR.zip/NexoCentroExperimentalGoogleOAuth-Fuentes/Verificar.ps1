﻿param([string]$DotNet='dotnet',[string]$DirectorioPruebas)
$ErrorActionPreference='Stop'
if(-not $DirectorioPruebas){$DirectorioPruebas=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot ('..\pruebas-ac404-'+[DateTime]::Now.ToString('yyyyMMdd-HHmmss'))))}
if(Test-Path -LiteralPath $DirectorioPruebas){throw 'Elige una carpeta nueva y corta para las pruebas; no se reutilizan datos.'}
New-Item -ItemType Directory -Path $DirectorioPruebas | Out-Null
Write-Host 'Sólo datos sintéticos. TLS añade y retira certificados personales de prueba. La regresión usa una clave de registro propia, sin alterar el inicio real.'
function Ejecutar([string]$Nombre,[scriptblock]$Accion){
 & $Accion *> (Join-Path $DirectorioPruebas ($Nombre+'.txt'))
 if($LASTEXITCODE -ne 0){throw "Ha fallado $Nombre. Consulta su registro en $DirectorioPruebas"}
 Write-Host "Correcto: $Nombre"
}
$proyectos=@('pruebas-locales.csproj','pruebas-transporte\AgendaClara.TransportTests.csproj','pruebas-sesion\AgendaClara.SessionTests.csproj','pruebas-seguridad\AgendaClara.SecurityTests.csproj','pruebas-tls\AgendaClara.TlsTests.csproj','pruebas-estado\AgendaClara.StatusTests.csproj','pruebas-interfaz-red\AgendaClara.SharedUI.Tests.csproj','pruebas-red\AgendaClara.NetworkTests.csproj','servidor-pruebas\AgendaClara.ProbeHost.csproj','pruebas-diagnostico\AgendaClara.Diagnostics.Tests.csproj')
foreach($proyecto in $proyectos){
 $ruta=Join-Path $PSScriptRoot ('aplicacion\'+$proyecto)
 Ejecutar ('compilar-'+[IO.Path]::GetFileNameWithoutExtension($ruta)) {& $DotNet build $ruta -c Release --nologo}
}
$fixture=Join-Path $PSScriptRoot 'aplicacion\pruebas\fixtures\agenda-v4-sintetica.sqlite3'
$redOutput=Join-Path $DirectorioPruebas 'herramientas-instalador'
$redTest=Join-Path $redOutput 'RedTests.exe'
Ejecutar 'compilar-red-instalador' {& $DotNet build (Join-Path $PSScriptRoot 'instalador/proyectos/pruebas/AgendaClara.Setup.Tests.csproj') -c Release -o $redOutput -p:TestName=RedTests --nologo}
Ejecutar 'red-instalador' {& $redTest (Join-Path $DirectorioPruebas 'cortafuegos')}
Ejecutar 'regresion' {& (Join-Path $PSScriptRoot 'aplicacion\bin\Release\net48\AgendaClara.Pruebas.exe') (Join-Path $DirectorioPruebas 'datos')}
Ejecutar 'fallback-transporte' {& $DotNet (Join-Path $PSScriptRoot 'aplicacion\pruebas-transporte\bin\Release\net10.0\AgendaClara.TransportTests.dll') (Join-Path $DirectorioPruebas 'fallback-transporte')}
Ejecutar 'sesion-http' {& $DotNet (Join-Path $PSScriptRoot 'aplicacion\pruebas-sesion\bin\Release\net10.0\AgendaClara.SessionTests.dll') (Join-Path $DirectorioPruebas 'sesion-http')}
Ejecutar 'seguridad' {& $DotNet (Join-Path $PSScriptRoot 'aplicacion\pruebas-seguridad\bin\Release\net10.0\AgendaClara.SecurityTests.dll') (Join-Path $DirectorioPruebas 'seguridad')}
Ejecutar 'tls' {& $DotNet (Join-Path $PSScriptRoot 'aplicacion\pruebas-tls\bin\Release\net10.0\AgendaClara.TlsTests.dll') (Join-Path $DirectorioPruebas 'tls')}
Ejecutar 'estado' {& (Join-Path $PSScriptRoot 'aplicacion\pruebas-estado\bin\Release\net48\AgendaClara.StatusTests.exe') (Join-Path $DirectorioPruebas 'estado') $fixture}
Ejecutar 'diagnostico-net48' {& (Join-Path $PSScriptRoot 'aplicacion\pruebas-diagnostico\bin\Release\net48\AgendaClara.Diagnostics.Tests.exe') (Join-Path $DirectorioPruebas 'diag') $DotNet (Join-Path $PSScriptRoot 'aplicacion\servidor-pruebas\bin\Release\net10.0\AgendaClara.ProbeHost.dll')}
Ejecutar 'integracion-red' {& $DotNet (Join-Path $PSScriptRoot 'aplicacion\pruebas-red\bin\Release\net10.0\AgendaClara.NetworkTests.dll') (Join-Path $DirectorioPruebas 'red') $fixture (Join-Path $PSScriptRoot 'aplicacion\pruebas-interfaz-red\bin\Release\net48\AgendaClara.SharedUI.Tests.exe')}
Write-Host 'Las pruebas completas del instalador se preparan con Preparar-Instaladores.ps1 y Compilar-Pruebas.ps1. Las pruebas de servicio sólo se ejecutan en el Windows efímero de CI; no se importan raíces generales en Windows.'
