﻿param([Parameter(Mandatory=$true)][string]$Salida,[string]$DotNet='dotnet')
$ErrorActionPreference='Stop'
New-Item -ItemType Directory -Force -Path $Salida|Out-Null
$buildRoot=Join-Path (Split-Path -Parent ([IO.Path]::GetFullPath($Salida))) 'pruebas-build'
foreach($test in @('RedTests','SimpleTests','ServerInstallTests')) {
 $build=Join-Path $buildRoot $test
 & $DotNet build (Join-Path $PSScriptRoot 'proyectos/pruebas/AgendaClara.Setup.Tests.csproj') -c Release -o $build "-p:TestName=$test" --nologo
 if($LASTEXITCODE-ne0){throw "No se ha compilado $test."}
 Get-ChildItem -LiteralPath $build -File|Copy-Item -Destination $Salida -Force
}

$published=Join-Path (Split-Path -Parent ([IO.Path]::GetFullPath($Salida))) 'payload-root/cliente'
if(-not(Test-Path -LiteralPath (Join-Path $published 'AgendaClara.exe'))){throw 'Falta el cliente publicado de esta entrega.'}
Get-ChildItem -LiteralPath $published -File|Where-Object{$_.Name-ne'manifiesto.json'}|Copy-Item -Destination $Salida -Force
