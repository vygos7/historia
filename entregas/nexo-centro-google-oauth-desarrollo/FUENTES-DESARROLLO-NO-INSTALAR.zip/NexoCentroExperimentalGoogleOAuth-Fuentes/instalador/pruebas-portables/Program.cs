using System.Buffers.Binary;
using System.IO.Compression;
using System.Reflection.Metadata;
using System.Reflection.PortableExecutable;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using AgendaClara.Setup;

static class PackageTests
{
    static int checks;static string scratch;
    static void Check(bool value,string name){if(!value)throw new Exception(name);checks++;Console.WriteLine("CORRECTO: "+name);}
    static bool Rejected(Action action){try{action();return false;}catch(Exception ex)when(ex is IOException || ex is InvalidOperationException || ex is ArgumentException || ex is JsonException){return true;}}
    static string Hash(byte[] bytes)=>Convert.ToHexString(SHA256.HashData(bytes));
    static void Copy(string source,string target)
    {
        Directory.CreateDirectory(target);
        foreach(string p in Directory.GetFiles(source,"*",SearchOption.AllDirectories)){string q=Path.Combine(target,Path.GetRelativePath(source,p));Directory.CreateDirectory(Path.GetDirectoryName(q));File.Copy(p,q);}
    }
    static Dictionary<string,byte[]> Resources(byte[] assembly)
    {
        using var stream=new MemoryStream(assembly);using var pe=new PEReader(stream);var reader=pe.GetMetadataReader();
        var block=pe.GetSectionData(pe.PEHeaders.CorHeader.ResourcesDirectory.RelativeVirtualAddress).GetContent().ToArray();
        var result=new Dictionary<string,byte[]>();
        foreach(var handle in reader.ManifestResources)
        {
            var resource=reader.GetManifestResource(handle);if(!resource.Implementation.IsNil)continue;
            int offset=checked((int)resource.Offset);int length=BinaryPrimitives.ReadInt32LittleEndian(block.AsSpan(offset,4));
            result.Add(reader.GetString(resource.Name),block.AsSpan(offset+4,length).ToArray());
        }
        return result;
    }
    static string AssemblyVersion(byte[] bytes)
    {using var pe=new PEReader(new MemoryStream(bytes));return pe.GetMetadataReader().GetAssemblyDefinition().Version.ToString();}
    static string NativeResources(byte[] bytes)
    {
        using var pe=new PEReader(new MemoryStream(bytes));var section=pe.PEHeaders.SectionHeaders.Single(s=>s.Name==".rsrc");
        return Encoding.UTF8.GetString(pe.GetSectionData(section.VirtualAddress).GetContent().ToArray());
    }
    static object Rule()
    {
        dynamic rule=new System.Dynamic.ExpandoObject();
        rule.Name="AgendaClara servidor HTTPS";rule.Description="prueba";rule.ApplicationName=@"C:\Agenda\servidor.exe";rule.ServiceName="";
        rule.Protocol=6;rule.LocalPorts="7443";rule.RemotePorts="*";rule.LocalAddresses="*";rule.RemoteAddresses="192.168.4.0/22";
        rule.Direction=1;rule.InterfaceTypes="All";rule.Grouping="";rule.Profiles=7;rule.Action=1;rule.Enabled=true;rule.EdgeTraversal=false;rule.Interfaces=null;
        return rule;
    }
    static void FirewallRoundTrip()
    {
        dynamic original=Rule();var snapshot=FirewallSnapshot.Capture((object)original);
        original.LocalPorts="8555";original.RemoteAddresses="10.0.0.0/8";original.Name="cambiado";
        Check(snapshot.LocalPorts=="7443"&&snapshot.RemoteAddresses=="192.168.4.0/22"&&snapshot.Name=="AgendaClara servidor HTTPS","El respaldo del cortafuegos conserva valores independientes de la regla retirada");
        object restored=Rule();snapshot.Apply(restored);
        Check(snapshot.Matches(restored),"La regla se reconstruye con programa, puerto, direcciones, perfiles y estado anteriores");
        ((dynamic)restored).Profiles=3;Check(!snapshot.Matches(restored),"Una restauración que pierde el perfil Público no se confirma");
    }
    static void Transactions()
    {
        string root=Path.Combine(scratch,"transacciones"),source=Path.Combine(root,"origen"),target=Path.Combine(root,"programa");Directory.CreateDirectory(source);Directory.CreateDirectory(target);
        File.WriteAllText(Path.Combine(source,"a.txt"),"nuevo");File.WriteAllText(Path.Combine(source,"c-nuevo.txt"),"nuevo");File.WriteAllText(Path.Combine(source,"z-bloqueado.txt"),"nuevo");
        File.WriteAllText(Path.Combine(target,"a.txt"),"anterior");File.WriteAllText(Path.Combine(target,"ajeno.txt"),"conservar");Directory.CreateDirectory(Path.Combine(target,"z-bloqueado.txt"));
        bool failed=false;using(var operation=new FileDeployment(source,target,Path.Combine(root,"respaldo-fallo")))
        {try{operation.Apply();}catch(Exception ex)when(ex is IOException || ex is UnauthorizedAccessException){failed=true;}}
        Check(failed && File.ReadAllText(Path.Combine(target,"a.txt"))=="anterior","Un fallo parcial de copia restaura los bytes del programa anterior");
        Check(!File.Exists(Path.Combine(target,"c-nuevo.txt")) && File.ReadAllText(Path.Combine(target,"ajeno.txt"))=="conservar","La reversión retira sólo archivos nuevos y conserva los ajenos");
        Directory.Delete(Path.Combine(target,"z-bloqueado.txt"));
        using(var operation=new FileDeployment(source,target,Path.Combine(root,"respaldo-correcto"))){operation.Apply();operation.Commit();}
        Check(File.ReadAllText(Path.Combine(target,"a.txt"))=="nuevo" && File.Exists(Path.Combine(target,"c-nuevo.txt")),"Una copia confirmada conserva la versión nueva");
        Check(Rejected(()=>new FileDeployment(source,Path.Combine(source,"dentro"),Path.Combine(root,"otro-respaldo"))),"No se permiten carpetas de copia solapadas");
        string empty=Path.Combine(root,"vacio");Directory.CreateDirectory(empty);
        Check(Rejected(()=>new FileDeployment(empty,Path.Combine(root,"otro-programa"),Path.Combine(root,"otro-respaldo"))),"Una distribución vacía se rechaza antes de instalar");
    }
    static int Main(string[] args)
    {
        try
        {
            string release=Path.GetFullPath(args[0]);scratch=Path.GetFullPath(args[1]);if(Directory.Exists(scratch))throw new ArgumentException("Usa una carpeta nueva.");Directory.CreateDirectory(scratch);
            string client=Path.Combine(release,"payload-root","cliente"),server=Path.Combine(release,"payload-root","servidor");
            PayloadIntegrity.Validate(client,"cliente");Check(true,"Payload completo del cliente: manifiesto, hashes y revisión r2");
            PayloadIntegrity.Validate(server,"servidor");Check(true,"Payload completo del servidor: manifiesto, hashes y runtime autocontenido");
            Check(Hash(File.ReadAllBytes(Path.Combine(client,"AgendaClara.exe")))==Hash(File.ReadAllBytes(args[2])),"El cliente embebido es idéntico, byte a byte, a la compilación Nexo Centro de referencia");
            byte[] installer=File.ReadAllBytes(Path.Combine(release,"instaladores","Instalar-AgendaClara-Servidor.exe"));var resources=Resources(installer);
            byte[] nested=resources["AgendaClara.Setup.Client"];var child=Resources(nested);
            Check(AssemblyVersion(installer)=="1.2.5.0" && AssemblyVersion(nested)=="1.2.5.0","Ambos instaladores incorporan la versión 1.2.5");
            Check(Hash(nested)==Hash(File.ReadAllBytes(Path.Combine(release,"instaladores","Instalar-AgendaClara-Cliente.exe"))),"El generador del servidor incluye exactamente el instalador nuevo del cliente");
            Check(Hash(child["AgendaClara.Setup.ClientPayload"])==Hash(File.ReadAllBytes(Path.Combine(release,"payload","cliente.zip"))),"Los futuros paquetes de Dirección, Jefatura y Secretaría llevan el payload r2");
            Check(Hash(resources["AgendaClara.Setup.ServerPayload"])==Hash(File.ReadAllBytes(Path.Combine(release,"payload","servidor.zip"))),"El servidor contiene su runtime Windows verificado, no un payload antiguo");
            Check(Hash(resources["AgendaClara.Setup.ClientPayload"])==Hash(child["AgendaClara.Setup.ClientPayload"]),"El payload directo y el anidado del cliente coinciden");
            Check(NativeResources(installer).Contains("requireAdministrator") && NativeResources(nested).Contains("asInvoker"),"Sólo el instalador del servidor solicita elevación; el cliente usa su perfil");
            foreach(var pair in new[]{("cliente",child["AgendaClara.Setup.ClientPayload"]),("servidor",resources["AgendaClara.Setup.ServerPayload"])})
            {
                string folder=Path.Combine(scratch,"recursos",pair.Item1);Directory.CreateDirectory(folder);
                using var zip=new ZipArchive(new MemoryStream(pair.Item2));zip.ExtractToDirectory(folder);
                PayloadIntegrity.Validate(Path.Combine(folder,pair.Item1),pair.Item1);Check(true,"Los recursos realmente embebidos pasan la validación íntegra: "+pair.Item1);
            }
            string tampered=Path.Combine(scratch,"alterado");Copy(client,tampered);
            File.AppendAllText(Path.Combine(tampered,"AgendaClara.exe"),"alterado");Check(Rejected(()=>PayloadIntegrity.Validate(tampered,"cliente")),"Un ejecutable alterado se rechaza antes de copiar");
            File.Copy(Path.Combine(client,"AgendaClara.exe"),Path.Combine(tampered,"AgendaClara.exe"),true);
            File.WriteAllText(Path.Combine(tampered,"ajeno.txt"),"no autorizado");Check(Rejected(()=>PayloadIntegrity.Validate(tampered,"cliente")),"Se rechazan archivos que no figuran en el manifiesto");File.Delete(Path.Combine(tampered,"ajeno.txt"));
            string manifest=File.ReadAllText(Path.Combine(tampered,"manifiesto.json"));
            File.WriteAllText(Path.Combine(tampered,"manifiesto.json"),manifest.Replace("4.0.4-http-r2","4.0.3"));Check(Rejected(()=>PayloadIntegrity.Validate(tampered,"cliente")),"No se acepta una revisión anterior bajo el instalador nuevo");
            var withIdentity=JsonSerializer.Deserialize<PayloadManifest>(manifest);byte[] synthetic=Encoding.UTF8.GetBytes("NO-ES-UNA-CLAVE");
            File.WriteAllBytes(Path.Combine(tampered,"equipo.pfx"),synthetic);withIdentity.Files.Add(new PayloadFile{Path="equipo.pfx",Sha256=Hash(synthetic)});
            File.WriteAllText(Path.Combine(tampered,"manifiesto.json"),JsonSerializer.Serialize(withIdentity));
            Check(Rejected(()=>PayloadIntegrity.Validate(tampered,"cliente")),"Se rechaza una identidad de puesto incluso declarada con una huella correcta");File.Delete(Path.Combine(tampered,"equipo.pfx"));
            File.WriteAllText(Path.Combine(tampered,"manifiesto.json"),manifest);File.Delete(Path.Combine(tampered,"AgendaClara.exe.config"));Check(Rejected(()=>PayloadIntegrity.Validate(tampered,"cliente")),"Se detectan dependencias incompletas");
            File.Delete(Path.Combine(tampered,"manifiesto.json"));Check(Rejected(()=>PayloadIntegrity.Validate(tampered,"cliente")),"Un paquete antiguo sin manifiesto no se reutiliza");
            Transactions();FirewallRoundTrip();Console.WriteLine("RESUMEN: "+checks+" comprobaciones correctas; 0 fallos. Pruebas de empaquetado y copia, no instalación Windows.");return 0;
        }
        catch(Exception ex){Console.Error.WriteLine(ex);return 1;}
    }
}
