using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Reflection;
using System.Security.AccessControl;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Security.Principal;
using System.ServiceProcess;
using System.Threading.Tasks;
using Microsoft.Win32;
using AgendaClara;
using AgendaClara.Setup;
using F=AgendaClara.Setup.Files;

public sealed class ServiceProgress:IProgress<string>{public void Report(string text){Console.WriteLine(text);}}
public static class ServerInstallTests
{
    static readonly DateTime started=DateTime.Now;
    static int count;static string program,data,other,temporary,clientRoot;static RemoteConnection client;static readonly List<string> personal=new List<string>();
    static void Check(bool value,string text){Console.WriteLine((value?"CORRECTO: ":"FALLO: ")+text);if(!value)throw new Exception(text);count++;}
    static int Port(){var listener=new TcpListener(IPAddress.Loopback,0);listener.Start();int port=((IPEndPoint)listener.LocalEndpoint).Port;listener.Stop();return port;}
    static string[] Roots(){using(var s=new X509Store(StoreName.Root,StoreLocation.CurrentUser)){s.Open(OpenFlags.ReadOnly);return s.Certificates.Cast<X509Certificate2>().Select(c=>c.Thumbprint).OrderBy(t=>t).ToArray();}}
    static string Logical(AgendaSnapshot snapshot){snapshot.ServerUtc=DateTime.MinValue;return XmlData.Write(snapshot);}
    static bool OwnService()
    {
        using(var key=Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Services\AgendaClaraServidor"))
        {string path=key==null?"":Convert.ToString(key.GetValue("ImagePath"));return program!=null&&path.IndexOf(Path.Combine(program,"AgendaClara.Server.exe"),StringComparison.OrdinalIgnoreCase)>=0;}
    }
    static void RemoveService()
    {
        if(!OwnService())return;
        using(var service=new ServiceController(ServerInstaller.Service)){service.Refresh();if(service.Status!=ServiceControllerStatus.Stopped){service.Stop();service.WaitForStatus(ServiceControllerStatus.Stopped,TimeSpan.FromSeconds(60));}}
        F.Run(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System),"sc.exe"),new[]{"delete",ServerInstaller.Service},null,30);
    }
    static void DumpServerDiagnostics()
    {
        try
        {
            string trace=data==null?"":Path.Combine(data,"diagnostico","sesiones.jsonl");
            if(File.Exists(trace))foreach(string line in File.ReadAllLines(trace).Reverse().Take(120).Reverse())Console.WriteLine((line.Contains("storage_exception")?"ERROR_SERVIDOR ":"TRAZA_SERVIDOR ")+line);
            using(var log=new System.Diagnostics.EventLog("Application"))
            {
                int total=log.Entries.Count;
                for(int i=total-1;i>=Math.Max(0,total-300);i--)
                {
                    var entry=log.Entries[i];if(entry.TimeGenerated<started.AddSeconds(-2))continue;
                    if(entry.Source.IndexOf("AgendaClara",StringComparison.OrdinalIgnoreCase)>=0 || entry.Message.IndexOf("Error de almacenamiento",StringComparison.OrdinalIgnoreCase)>=0)
                        Console.WriteLine("EVENTO_SERVIDOR "+entry.Source+" "+entry.Message);
                }
            }
        }
        catch(Exception ex){Console.WriteLine("Diagnóstico del servicio no disponible: "+ex.GetType().Name+" HRESULT="+ex.HResult.ToString("X8"));}
    }
    static ServerPlan Plan(string prefix,string fixture)
    {
        string name="AgendaClara-Prueba-"+prefix+"-"+Guid.NewGuid().ToString("N");
        return new ServerPlan{Mode="new",Host="localhost",Network="127.0.0.1/32",Port=Port(),AdminUser="Puesto-Jefatura",AdminPassword=SimplePackage.Secret(),PackagePassword=SimplePackage.Secret(),Agenda=fixture,
            Program=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),name),Data=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),name),
            Packages=Path.Combine(clientRoot,name,"instaladores"),ExportKey=Path.Combine(clientRoot,name,"respaldo","recuperacion.key")};
    }
    static async Task Run(string installer,string fixture)
    {
        if(Environment.GetEnvironmentVariable("GITHUB_ACTIONS")!="true"||Environment.GetEnvironmentVariable("RUNNER_ENVIRONMENT")!="github-hosted")throw new InvalidOperationException("Esta batería registra un servicio y sólo se ejecuta en un Windows efímero hospedado por GitHub.");
        Check(new WindowsPrincipal(WindowsIdentity.GetCurrent()).IsInRole(WindowsBuiltInRole.Administrator),"El ejecutor Windows aislado dispone de permisos para probar servicios y cortafuegos");
        Check(!ServerInstaller.Exists(),"No existe una instalación de AgendaClara que pudiera resultar modificada");
        dynamic policy=Activator.CreateInstance(Type.GetTypeFromProgID("HNetCfg.FwPolicy2"));bool existingRule=false;
        foreach(dynamic rule in policy.Rules)if(rule.Name=="AgendaClara servidor HTTPS")existingRule=true;
        Check(!existingRule,"No existe una regla de AgendaClara ajena a esta prueba");
        F.TestPayload=Assembly.LoadFile(Path.GetFullPath(installer));temporary=F.Extract("AgendaClara.Setup.ServerPayload");
        string clientTemp=F.Extract("AgendaClara.Setup.ClientPayload");string fixtureHash=F.Hash(fixture);var roots=Roots();
        var plan=Plan("A",fixture);program=plan.Program;data=plan.Data;var progress=new ServiceProgress();
        bool complete=false;
        try
        {
            ServerInstaller.Install(plan,Path.Combine(temporary,"servidor"),progress);
            using(var service=new ServiceController(ServerInstaller.Service))Check(service.Status==ServiceControllerStatus.Running,"Una instalación nueva registra e inicia el servicio Windows real");
            Check(OwnService(),"La ruta del servicio corresponde exclusivamente al programa sintético");
            using(var key=Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Services\AgendaClaraServidor"))
            {Check(Convert.ToInt32(key.GetValue("Start"))==2&&Convert.ToInt32(key.GetValue("DelayedAutoStart"))==1,"El servicio queda con inicio automático retrasado");Check(Convert.ToString(key.GetValue("ObjectName")).Equals(@"NT SERVICE\AgendaClaraServidor",StringComparison.OrdinalIgnoreCase),"El servicio usa su cuenta virtual, sin ejecutarse como administrador");}
            dynamic firewall=policy.Rules.Item("AgendaClara servidor HTTPS");
            Check(firewall.Enabled&&firewall.Profiles==7&&firewall.Protocol==6&&firewall.LocalPorts==plan.Port.ToString()&&new[]{"127.0.0.1","127.0.0.1/32","127.0.0.1/255.255.255.255"}.Contains((string)firewall.RemoteAddresses),"La regla real permite sólo TCP, puerto elegido y la red de prueba, con los tres perfiles");
            Check(Convert.ToString(firewall.ApplicationName).Equals(Path.Combine(program,"AgendaClara.Server.exe"),StringComparison.OrdinalIgnoreCase),"La regla se limita al ejecutable instalado");
            var acl=new DirectoryInfo(data).GetAccessControl();var serviceSid=(SecurityIdentifier)new NTAccount("NT SERVICE",ServerInstaller.Service).Translate(typeof(SecurityIdentifier));
            Check(acl.AreAccessRulesProtected&&acl.GetAccessRules(true,true,typeof(SecurityIdentifier)).Cast<FileSystemAccessRule>().Any(r=>r.IdentityReference.Equals(serviceSid)&&r.AccessControlType==AccessControlType.Allow&&(r.FileSystemRights&FileSystemRights.Modify)==FileSystemRights.Modify),"Los datos tienen permisos explícitos para la cuenta del servicio");
            Check(F.Hash(fixture)==fixtureHash,"Instalar conserva sin cambios la agenda sintética de origen");
            var second=Plan("B",fixture);other=second.Program;ServerInstaller.Prepare(second,Path.Combine(temporary,"servidor"),progress);
            Check(F.Hash(Path.Combine(second.Data,"authority.cer"))!=F.Hash(Path.Combine(data,"authority.cer")),"Dos centros nuevos reciben autoridades diferentes, sin reutilizar identidades");
            Check(Directory.GetFiles(plan.Packages,"*.exe").Length==3,"El centro genera los tres instaladores específicos de puestos");
            string config=Path.Combine(clientRoot,"cliente","conexion.xml");
            using(var package=SimplePackage.Open(Path.Combine(plan.Packages,"Instalar-NexoCentro-Jefatura.exe"),plan.PackagePassword))
            {
                using(var cert=new X509Certificate2(File.ReadAllBytes(Path.Combine(package.DirectoryPath,"equipo.pfx")),package.Password,X509KeyStorageFlags.EphemeralKeySet))personal.Add(cert.Thumbprint);
                ClientInstaller.Install(new ClientPlan{Package=package.DirectoryPath,PackagePassword=package.Password,ExpectedHash=package.Hash,VerifiedAuthorityHash=package.Hash,User=package.User,Program=Path.Combine(clientRoot,"cliente","programa"),Configuration=config,AutomaticAccess=true,Offline=true},Path.Combine(clientTemp,"cliente"),progress,false);
            }
            client=new RemoteConnection(SharedConfiguration.Load(config),config);await client.ConnectAsync("");Check(client.CanWrite&&client.IsAdmin,"El cliente generado autentica contra el servicio real con su cuenta y certificado");
            string expected=Logical(client.Snapshot),authority=F.Hash(Path.Combine(data,"authority.cer")),certHash=F.Hash(Path.Combine(data,"server.pfx")),configHash=F.Hash(config);
            plan.Mode="update";plan.Packages=Path.Combine(clientRoot,"actualizados");plan.ExportKey=Path.Combine(clientRoot,"respaldo-actualizado","recuperacion.key");plan.PackagePassword=SimplePackage.Secret();
            ServerInstaller.Install(plan,Path.Combine(temporary,"servidor"),progress);
            Check(F.Hash(Path.Combine(data,"authority.cer"))==authority&&F.Hash(Path.Combine(data,"server.pfx"))==certHash,"Actualizar sin cambiar nombre conserva exactamente la autoridad y el certificado HTTPS");
            Check(F.Hash(config)==configHash,"La actualización del servidor no cambia la conexión del cliente existente");
            await client.SynchronizeAsync();Check(client.CanWrite&&Logical(client.Snapshot)==expected,"El cliente anterior conserva acceso y agenda después de actualizar el servicio");
            int oldPort=plan.Port;
            for(int recovery=1;recovery<=6;recovery++)
            {
            Console.WriteLine("CICLO_RECUPERACION "+recovery);
            var protectedState=new[]{"server.json","server.pfx","authority.cer","security.json","backup-key.dpapi","certificate-password.dpapi"}.ToDictionary(n=>n,n=>F.Hash(Path.Combine(data,n)));
            plan.Port=Port();plan.Host=Environment.MachineName;plan.Packages=Path.Combine(clientRoot,"generacion-fallida-"+recovery);plan.ExportKey=Path.Combine(clientRoot,"respaldo-fallido-"+recovery,"recuperacion.key");plan.PackagePassword=SimplePackage.Secret();
            ServerInstaller.UpdateCheckpoint=stage=>{if(stage=="packages")throw new IOException("Fallo sintético después de generar nuevos accesos.");};
            bool rejected=false;try{ServerInstaller.Install(plan,Path.Combine(temporary,"servidor"),progress);}catch(IOException ex){rejected=true;Console.WriteLine("Diagnóstico del fallo inducido: "+ex);}finally{ServerInstaller.UpdateCheckpoint=null;}
            Check(rejected,"Un fallo de actualización se informa y no se confirma como instalación correcta");
            Check(protectedState.All(item=>F.Hash(Path.Combine(data,item.Key))==item.Value),"La reversión restaura configuración, certificado, seguridad y claves byte a byte");
            policy=Activator.CreateInstance(Type.GetTypeFromProgID("HNetCfg.FwPolicy2"));
            firewall=policy.Rules.Item("AgendaClara servidor HTTPS");Check(firewall.LocalPorts==oldPort.ToString()&&firewall.Profiles==7,"La reversión restaura también la regla del cortafuegos anterior");
            Check(File.Exists(Path.Combine(plan.Packages,"NO-USAR-ACTUALIZACION-INCOMPLETA.txt")),"Los instaladores de una generación fallida quedan identificados como no utilizables");
            using(var service=new ServiceController(ServerInstaller.Service))Check(service.Status==ServiceControllerStatus.Running,"La reversión recupera el servicio que estaba funcionando");
            await client.SynchronizeAsync();Check(client.CanWrite&&Logical(client.Snapshot)==expected,"Después de revertir siguen funcionando el acceso anterior y la agenda");
            }
            Check(Roots().SequenceEqual(roots),"Instalación y actualizaciones no añaden autoridades a la confianza general de Windows");
            if(Directory.Exists(second.Data))Directory.Delete(second.Data,true);
            complete=true;
        }
        finally
        {
            if(client!=null){client.Dispose();client=null;}
            RemoveService();
            if(!complete)DumpServerDiagnostics();
            try{dynamic rule=policy.Rules.Item("AgendaClara servidor HTTPS");if(program!=null&&Convert.ToString(rule.ApplicationName).Equals(Path.Combine(program,"AgendaClara.Server.exe"),StringComparison.OrdinalIgnoreCase))policy.Rules.Remove("AgendaClara servidor HTTPS");}catch(Exception ex)when(ex is System.Runtime.InteropServices.COMException || ex is FileNotFoundException){}
            using(var store=new X509Store(StoreName.My,StoreLocation.CurrentUser)){store.Open(OpenFlags.ReadWrite);foreach(string thumb in personal)foreach(var cert in store.Certificates.Find(X509FindType.FindByThumbprint,thumb,false)){using(var key=cert.GetRSAPrivateKey()){var cng=key as RSACng;if(cng!=null)cng.Key.Delete();}store.Remove(cert);cert.Dispose();}}
            F.RemoveTemporary(temporary);F.RemoveTemporary(clientTemp);
            foreach(string folder in new[]{program,data,other})if(folder!=null&&Directory.Exists(folder))Directory.Delete(folder,true);
        }
        Check(!ServerInstaller.Exists(),"Se retira el servicio creado por las pruebas al terminar");
    }
    [STAThread]public static int Main(string[] args)
    {
        try
        {
            clientRoot=Path.GetFullPath(args[0]);if(Directory.Exists(clientRoot))throw new ArgumentException("Usa una carpeta de pruebas nueva.");Directory.CreateDirectory(clientRoot);
            Run(args[1],Path.GetFullPath(args[2])).GetAwaiter().GetResult();Console.WriteLine("RESUMEN: "+count+" comprobaciones Windows correctas; 0 fallos.");return 0;
        }
        catch(Exception ex){Console.Error.WriteLine(ex);return 1;}
    }
}
