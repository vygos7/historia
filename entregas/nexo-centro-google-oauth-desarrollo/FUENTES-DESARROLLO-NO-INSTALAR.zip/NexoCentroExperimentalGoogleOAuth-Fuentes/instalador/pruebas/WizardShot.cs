using System;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace AgendaClara.Setup
{
    // Draws the first page of the server wizard with the network options open. Installs nothing:
    // the wizard is created, drawn to an image and closed without pressing any button.
    public static class WizardShot
    {
        [STAThread]
        public static int Main(string[] args)
        {
            Application.EnableVisualStyles();
            using(var wizard=new ServerWizard())
            {
                wizard.StartPosition=FormStartPosition.Manual;wizard.Location=new Point(-4000,-4000);wizard.ShowInTaskbar=false;
                wizard.Show();Application.DoEvents();
                foreach(var b in All(wizard).OfType<Button>().Where(b=>b.Text=="Opciones de red…"))b.PerformClick();
                Application.DoEvents();
                var body=All(wizard).OfType<Panel>().First(p=>p.AutoScroll);
                var page=body.Controls[0];
                using(var image=new Bitmap(Math.Max(wizard.Width,page.Width+60),wizard.Height+Math.Max(0,page.Height-body.Height)))
                {
                    int bodyHeight=body.Height;wizard.Height+=Math.Max(0,page.Height-bodyHeight);Application.DoEvents();
                    wizard.DrawToBitmap(image,new Rectangle(0,0,wizard.Width,wizard.Height));
                    image.Save(Path.GetFullPath(args[0]));
                }
                Console.WriteLine("Texto del resumen de red: "+All(wizard).OfType<Label>().Select(l=>l.Text).FirstOrDefault(t=>t.StartsWith("Los puestos se conectarán")));
                wizard.Close();
            }
            return 0;
        }
        static System.Collections.Generic.IEnumerable<Control> All(Control c){foreach(Control child in c.Controls){yield return child;foreach(var x in All(child))yield return x;}}
    }
}
