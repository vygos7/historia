using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Reflection;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using AgendaClara;
using AgendaClara.Setup;
using F=AgendaClara.Setup.Files;
public sealed class DirectProgress:IProgress<string>{public void Report(string value){Console.WriteLine(value);}}
public static class SimpleTests
{
    static int count;static string root;static List<string> results=new List<string>();
    static void Check(bool condition,string name){results.Add((condition?"CORRECTO: ":"FALLO: ")+name);Console.WriteLine(results.Last());if(!String.IsNullOrEmpty(root))File.WriteAllLines(Path.Combine(root,"resultado-parcial.txt"),results,Encoding.UTF8);if(!condition)throw new Exception(name);count++;}
    static IEnumerable<Control> Controls(Control root){yield return root;foreach(Control c in root.Controls)foreach(var d in Controls(c))yield return d;}
    static string[] Roots(){using(var store=new X509Store(StoreName.Root,StoreLocation.CurrentUser)){store.Open(OpenFlags.ReadOnly);return store.Certificates.Cast<X509Certificate2>().Select(c=>c.Thumbprint).OrderBy(x=>x).ToArray();}}
    static string[] Personal(){using(var store=new X509Store(StoreName.My,StoreLocation.CurrentUser)){store.Open(OpenFlags.ReadOnly);return store.Certificates.Cast<X509Certificate2>().Select(c=>c.Thumbprint).OrderBy(x=>x).ToArray();}}
    static void Capture(Form form,string name){form.Show();Application.DoEvents();using(var bmp=new Bitmap(form.Width,form.Height)){form.DrawToBitmap(bmp,new Rectangle(0,0,bmp.Width,bmp.Height));bmp.Save(Path.Combine(root,name));}}
    static async Task Until(Func<bool> predicate,string message,int seconds=30){var end=DateTime.UtcNow.AddSeconds(seconds);while(!predicate() && DateTime.UtcNow<end)await Task.Delay(150);Check(predicate(),message);}
    static async Task Reject(Func<Task> action,string message){bool rejected=false;try{await action();}catch{rejected=true;}Check(rejected,message);}
    [STAThread]public static int Main(string[] args)
    {
        root=Path.GetFullPath(args[0]);Directory.CreateDirectory(root);Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);
        try
        {
#if SETUP_TESTS
            if(args.Length<3)throw new ArgumentException("Indica la ruta del instalador completo que se va a verificar.");
            F.TestPayload=Assembly.LoadFile(Path.GetFullPath(args[2]));
#endif
            using(var form=new ServerWizard()){Capture(form,"01-servidor-simple.png");Check(!Controls(form).OfType<TextBox>().Any(t=>t.UseSystemPasswordChar),"El asistente del servidor no tiene ningún campo de contraseña");Check(!Controls(form).Any(c=>c.AccessibleName!=null && (c.AccessibleName.Contains("Código")||c.AccessibleName.Contains("clave"))),"El servidor no solicita claves ni códigos");form.Close();}
            SynchronizationContext.SetSynchronizationContext(null);Run(args[1]).GetAwaiter().GetResult();results.Add("RESUMEN: "+count+" comprobaciones correctas; 0 fallos.");Console.WriteLine(results.Last());return 0;
        }catch(Exception ex){results.Add("FALLO: "+ex);Console.WriteLine(ex);return 1;}
        finally{File.WriteAllLines(Path.Combine(root,"resultado-pruebas.txt"),results,Encoding.UTF8);}
    }
    static async Task Run(string fixture)
    {
        Check(ConnectionDiagnostics.Explain(new TaskCanceledException(),false).Code=="timeout","Una cancelación de HttpClient por límite de tiempo se identifica como espera agotada");
        Check(ConnectionDiagnostics.Explain(new TaskCanceledException(),true).Code=="cancelled","Una cancelación solicitada se distingue del tiempo de espera");
        Check(ConnectionDiagnostics.Explain(new System.Net.Http.HttpRequestException("synthetic",new SocketException((int)SocketError.HostNotFound)),false).Code=="dns","Un fallo DNS se identifica por el código del sistema");
        Check(ConnectionDiagnostics.Explain(new SocketException((int)SocketError.ConnectionRefused),false).Code=="refused","Un servicio detenido o puerto cerrado se identifica sin afirmar que el equipo esté apagado");
        Check(ConnectionDiagnostics.Explain(new SocketException((int)SocketError.NetworkUnreachable),false).Code=="network","La red o el puerto inaccesibles tienen un diagnóstico específico");
        foreach(string failure in new[]{"name","expired","untrusted","client"})Check(ConnectionDiagnostics.Explain(new System.Net.Http.HttpRequestException(),false,failure).Code=="tls-"+failure,"Se conserva el diagnóstico de validación TLS: "+failure);
        var saved=new SharedConfiguration{ServerAuthority="autoridad-sintetica",AutomaticAccess=true,ClientThumbprint="ABC",UserName="Puesto-Direccion",ServerUrl="https://JEFATURA:7443"};
        var edited=saved.EditConnection(saved.ServerUrl,saved.UserName,saved.ClientThumbprint,true);
        Check(edited.ServerAuthority==saved.ServerAuthority && edited.AutomaticAccess,"Guardar la configuración conserva la autoridad y el acceso automático del puesto");
        Check(!saved.EditConnection(saved.ServerUrl,"otro",saved.ClientThumbprint,true).AutomaticAccess,"Cambiar de usuario no hereda el acceso automático del puesto anterior");
        ConnectionDiagnostics.Record(root,new ConnectionFailure("timeout","password=SECRETO token=SECRETO",new Exception("private-key=SECRETO")));
        Check(!File.ReadAllText(Path.Combine(root,"diagnostico","conexion.log")).Contains("SECRETO"),"El registro guarda códigos y tipos técnicos, sin mensajes con contraseñas, tokens o claves");
        using(var rsa=RSA.Create(2048))
        {
            var request=new CertificateRequest("CN=Autoridad desconocida de prueba",rsa,HashAlgorithmName.SHA256,RSASignaturePadding.Pkcs1);request.CertificateExtensions.Add(new X509BasicConstraintsExtension(true,false,0,true));
            using(var unknown=request.CreateSelfSigned(DateTimeOffset.UtcNow.AddMinutes(-5),DateTimeOffset.UtcNow.AddDays(1)))Check(CertificateTrust.WindowsTrustProblem(unknown).Length>0,"Una autoridad que no está en los almacenes de Windows se detecta como no confiable");
        }
        string[] trustedBefore=Roots(),personalBefore=Personal();bool serviceBefore=ServerInstaller.Exists();string serverTemp=null,clientTemp=null;Process server=null;var clients=new List<RemoteConnection>();var installed=new List<string>();
        try
        {
            var listener=new TcpListener(IPAddress.Loopback,0);listener.Start();int port=((IPEndPoint)listener.LocalEndpoint).Port;listener.Stop();
            serverTemp=F.Extract("AgendaClara.Setup.ServerPayload");clientTemp=F.Extract("AgendaClara.Setup.ClientPayload");
            var plan=new ServerPlan{Mode="new",Host="localhost",Network="127.0.0.1/32",Port=port,AdminUser="Puesto-Jefatura",AdminPassword=SimplePackage.Secret(),PackagePassword=SimplePackage.Secret(),Agenda=Path.GetFullPath(fixture),Program=Path.Combine(root,"Servidor programa"),Data=Path.Combine(root,"Servidor datos"),Packages=Path.Combine(root,"Tres instaladores"),ExportKey=Path.Combine(root,"Tres instaladores","Respaldo del servidor","recuperacion.key")};
            string original=F.Hash(plan.Agenda);ServerInstaller.Prepare(plan,Path.Combine(serverTemp,"servidor"),new DirectProgress());Check(F.Hash(plan.Agenda)==original,"La agenda original se conserva sin cambios");Check(File.Exists(plan.ExportKey),"El respaldo se prepara automáticamente sin pedir una clave");
            var executables=Directory.GetFiles(plan.Packages,"*.exe");Check(executables.Length==3,"Se generan exactamente tres instaladores de cliente independientes");Check(!Directory.GetFiles(plan.Packages,"*.pfx",SearchOption.AllDirectories).Any(),"No quedan paquetes sueltos de certificados para el usuario");
            string executable=Path.Combine(plan.Packages,"Instalar-NexoCentro-Direccion.exe"),copy=Path.Combine(root,"Archivo transportado.exe");File.Copy(executable,copy);using(var moved=SimplePackage.Open(copy,plan.PackagePassword)){Check(moved!=null && moved.Role=="Direccion","El EXE transportado funciona sin ningún archivo junto a él");}
            Check(!Encoding.UTF8.GetString(File.ReadAllBytes(executable)).Contains(plan.PackagePassword),"El EXE no incluye la contraseña que descifra su certificado privado");
            bool wrong=false;try{using(var ignored=SimplePackage.Open(executable,"incorrecta")){} }catch(IOException){wrong=true;}Check(wrong,"Una clave de transporte incorrecta no abre el paquete");
            using(var form=new ClientWizard(executable,Path.Combine(root,"interfaz","config.xml"),plan.PackagePassword)){Capture(form,"02-cliente-direccion.png");Check(!Controls(form).OfType<TextBox>().Any(t=>t.UseSystemPasswordChar),"El cliente no tiene campos de contraseña");Check(Controls(form).OfType<TextBox>().Count()==2,"El primer uso exige contrastar la huella además de la carpeta de instalación");form.Close();}
            SynchronizationContext.SetSynchronizationContext(null);
            var start=new ProcessStartInfo(Path.Combine(plan.Program,"AgendaClara.Server.exe"),"--data "+F.Quote(plan.Data)){UseShellExecute=false,CreateNoWindow=true,RedirectStandardOutput=true,RedirectStandardError=true,WorkingDirectory=plan.Program};server=Process.Start(start);var stdout=server.StandardOutput.ReadToEndAsync();var stderr=server.StandardError.ReadToEndAsync();
            foreach(string role in new[]{"Jefatura","Direccion","Secretaria"})
            {
                using(var package=SimplePackage.Open(Path.Combine(plan.Packages,"Instalar-NexoCentro-"+role+".exe"),plan.PackagePassword))
                {
                    var cp=new ClientPlan{Package=package.DirectoryPath,PackagePassword=package.Password,ExpectedHash=package.Hash,VerifiedAuthorityHash=package.Hash,User=package.User,Program=Path.Combine(root,"Cliente "+role),Configuration=Path.Combine(root,"Conexion "+role,"TrabajoCompartido.xml"),AutomaticAccess=true,Offline=true};cp.Validate();
                    using(var cert=new X509Certificate2(File.ReadAllBytes(Path.Combine(package.DirectoryPath,"equipo.pfx")),package.Password,X509KeyStorageFlags.EphemeralKeySet))installed.Add(cert.Thumbprint);
                    ClientInstaller.Install(cp,Path.Combine(clientTemp,"cliente"),new DirectProgress(),false);var config=SharedConfiguration.Load(cp.Configuration);
                    var firstPersonal=Personal();ClientInstaller.Install(cp,Path.Combine(clientTemp,"cliente"),new DirectProgress(),false);Check(Personal().SequenceEqual(firstPersonal),"Reinstalar "+role+" no duplica el certificado personal");
                    string configHash=F.Hash(cp.Configuration);ClientInstaller.Install(new ClientPlan{UseExisting=true,Program=cp.Program,Configuration=cp.Configuration},Path.Combine(clientTemp,"cliente"),new DirectProgress(),false);Check(F.Hash(cp.Configuration)==configHash,"La reparación genérica conserva la configuración exacta de "+role);
                    using(var rootCert=new X509Certificate2(Path.Combine(package.DirectoryPath,"servidor-raiz.cer"))){bool mismatch=false;try{CertificateTrust.ValidateRoot(rootCert,new string('0',64));}catch(ArgumentException){mismatch=true;}Check(mismatch,"Se rechaza una huella de autoridad ajena antes de confiar en ella");}
                    Check(config.AutomaticAccess && config.ServerAuthority.Length>0,"El cliente de "+role+" queda preparado para entrar sin contraseña y verificar automáticamente su servidor");
                    var remote=new RemoteConnection(config,cp.Configuration);clients.Add(remote);await remote.ConnectAsync("");Check(remote.CanWrite && remote.IsAdmin==(role=="Jefatura"),"Acceso automático real por HTTPS de "+role+" con sus permisos correctos");remote.Start();
                    Check(!File.ReadAllText(cp.Configuration).Contains(package.Password),"La contraseña técnica del paquete no se guarda en la configuración de "+role);
                }
            }
            await Until(()=>clients.All(c=>c.RealtimeConnected),"Los tres puestos establecen SignalR con la autoridad verificada");
            await Reject(()=>clients[2].Admin<List<UserView>>("GET","api/admin/users"),"Secretaría mantiene sus límites de administración");
            var hijack=SharedConfiguration.Load(Path.Combine(root,"Conexion Direccion","TrabajoCompartido.xml"));hijack.UserName="Puesto-Jefatura";
            using(var invalid=new RemoteConnection(hijack,Path.Combine(root,"intento-otro-puesto.xml")))await Reject(()=>invalid.ConnectAsync(""),"Un instalador de Dirección no puede hacerse pasar por Jefatura");
            var stores=clients.Select(c=>new Store(c)).ToArray();var activity=new AgendaEvent{Title="Actividad de instalación simple",Start=new DateTime(2026,11,4),End=new DateTime(2026,11,5),AllDay=true};stores[0].StampNew(activity);activity.Options.Tasks.Add(new PreparationTask{Description="Preparar transporte",Responsible="Secretaría",Attention=true});await Task.Run(()=>stores[0].Save(activity));
            await Until(()=>clients[1].Snapshot.Events.Any(e=>e.Id==activity.Id)&&clients[2].Snapshot.Events.Any(e=>e.Id==activity.Id),"Las actividades se sincronizan automáticamente entre los tres puestos");Check(clients[1].NotificationsReceived>0 && clients[2].NotificationsReceived>0,"Los avisos de cambios llegan por SignalR real");
            var edit=stores[2].EditSession();var memo=edit.Find(activity.Id);memo.Options.Tasks[0].Completed=true;memo.Options.Memory=new ActivityMemory{Rating="Buena",Continuity="No",Justification="Revisar organización"};await Task.Run(()=>edit.Save(memo));await Until(()=>stores[0].Find(activity.Id).Options.Memory.Continuity=="No"&&stores[1].Find(activity.Id).Options.Tasks[0].Completed,"Tareas y memorias se conservan y sincronizan con el acceso automático");
            string secret=Encoding.UTF8.GetString(ProtectedData.Unprotect(File.ReadAllBytes(Path.Combine(plan.Data,"certificate-password.dpapi")),null,DataProtectionScope.LocalMachine));using(var cert=new X509Certificate2(File.ReadAllBytes(Path.Combine(plan.Data,"server.pfx")),secret,X509KeyStorageFlags.EphemeralKeySet))
            {Check(clients[0].ValidateServerCertificate(cert,System.Net.Security.SslPolicyErrors.RemoteCertificateChainErrors),"La autoridad propia se verifica sin instalarla en Windows");Check(!clients[0].ValidateServerCertificate(cert,System.Net.Security.SslPolicyErrors.RemoteCertificateNameMismatch),"Se rechaza un servidor con un nombre incorrecto");var authority=clients[0].Configuration.ServerAuthority;clients[0].Configuration.ServerAuthority=Convert.ToBase64String(cert.RawData);Check(!clients[0].ValidateServerCertificate(cert,System.Net.Security.SslPolicyErrors.RemoteCertificateChainErrors),"Se rechaza una autoridad diferente o no autorizada");clients[0].Configuration.ServerAuthority=authority;}
            string modified=Path.Combine(root,"Instalador dañado.exe");byte[] tampered=File.ReadAllBytes(executable);tampered[tampered.Length-100]^=1;File.WriteAllBytes(modified,tampered);bool rejected=false;try{using(var ignored=SimplePackage.Open(modified,plan.PackagePassword)){} }catch(IOException){rejected=true;}Check(rejected,"Un instalador incompleto o alterado se rechaza automáticamente sin pedir códigos");
            foreach(var client in clients)client.Dispose();clients.Clear();server.Kill();server.WaitForExit();File.WriteAllText(Path.Combine(root,"servidor-prueba.log"),(await stdout)+(await stderr));server.Dispose();server=null;
            using(var offline=new RemoteConnection(SharedConfiguration.Load(Path.Combine(root,"Conexion Direccion","TrabajoCompartido.xml")),Path.Combine(root,"Conexion Direccion","TrabajoCompartido.xml")))Check(offline.CanReadOffline && offline.Snapshot.Events.Any(e=>e.Id==activity.Id),"Dirección puede consultar la agenda cifrada cuando el servidor está apagado");
            string dataHash=F.Hash(Path.Combine(plan.Data,"agenda.sqlite3"));plan.Mode="update";plan.Packages=Path.Combine(root,"Instaladores actualizados");plan.ExportKey=Path.Combine(plan.Packages,"Respaldo del servidor","recuperacion.key");plan.PackagePassword=SimplePackage.Secret();plan.Validate();ServerInstaller.GenerateClients(plan,Path.Combine(plan.Program,"AgendaClara.Server.exe"),new DirectProgress());
            Check(Directory.GetFiles(plan.Packages,"*.exe").Length==3,"La actualización también genera tres instaladores nuevos sin pedir claves");Check(F.Hash(Path.Combine(plan.Data,"agenda.sqlite3"))==dataHash,"Generar nuevos instaladores conserva íntegra la agenda existente");
            server=Process.Start(start);stdout=server.StandardOutput.ReadToEndAsync();stderr=server.StandardError.ReadToEndAsync();
            using(var reconnect=new RemoteConnection(SharedConfiguration.Load(Path.Combine(root,"Conexion Direccion","TrabajoCompartido.xml")),Path.Combine(root,"Conexion Direccion","TrabajoCompartido.xml"))){await reconnect.ConnectAsync("");Check(reconnect.CanWrite && reconnect.Snapshot.Events.Any(e=>e.Id==activity.Id),"Tras reiniciar el servidor se recuperan el acceso automático y los datos sin contraseña");}
            server.Kill();server.WaitForExit();await stdout;await stderr;server.Dispose();server=null;
            Check(Roots().SequenceEqual(trustedBefore),"La confianza se limita a AgendaClara y no se añade ninguna autoridad a Windows");Check(ServerInstaller.Exists()==serviceBefore,"Las pruebas no registran servicios ni modifican el servicio existente");
        }
        finally
        {
            foreach(var client in clients)try{client.Dispose();}catch{}if(server!=null){if(!server.HasExited){server.Kill();server.WaitForExit();}server.Dispose();}
            using(var store=new X509Store(StoreName.My,StoreLocation.CurrentUser)){store.Open(OpenFlags.ReadWrite);foreach(string thumb in installed)foreach(var cert in store.Certificates.Find(X509FindType.FindByThumbprint,thumb,false)){using(var key=cert.GetRSAPrivateKey()){var cng=key as RSACng;if(cng!=null)try{cng.Key.Delete();}catch(CryptographicException){}}store.Remove(cert);cert.Dispose();}}
            string caFile=Path.Combine(root,"Servidor datos","authority.cer");if(File.Exists(caFile))using(var ca=new X509Certificate2(caFile))if(!trustedBefore.Contains(ca.Thumbprint))using(var trusted=new X509Store(StoreName.Root,StoreLocation.CurrentUser)){trusted.Open(OpenFlags.ReadWrite);trusted.Remove(ca);} F.RemoveTemporary(serverTemp);F.RemoveTemporary(clientTemp);Check(Roots().SequenceEqual(trustedBefore),"El almacén raíz permanece intacto al terminar");Check(Personal().SequenceEqual(personalBefore),"Se retiran únicamente los certificados personales creados por las pruebas");
        }
    }
}

