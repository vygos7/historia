using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;

namespace AgendaClara.Setup
{
    // Network options of the installer and the client's connection messages. Changes nothing in Windows:
    // no services, firewall rules or certificates; only files in the given test folder.
    public static class RedTests
    {
        static readonly List<string> log=new List<string>();static int count;
        static void Check(bool value,string text){log.Add((value?"CORRECTO: ":"FALLO: ")+text);Console.WriteLine(log[log.Count-1]);if(!value)throw new Exception(text);count++;}
        static bool Rejected(Action action){try{action();return false;}catch(ArgumentException){return true;}}
        public static int Main(string[] args)
        {
            string root=Path.GetFullPath(args[0]);Directory.CreateDirectory(root);
            try
            {
                var list=NetworkChoice.ParseList("192.168.10.0/24\r\n192.168.30.0/24, 10.20.0.0/16;192.168.10.0/24");
                Check(list.SequenceEqual(new[]{"192.168.10.0/24","192.168.30.0/24","10.20.0.0/16"}),"El instalador admite varias subredes (líneas, comas o punto y coma) sin duplicados");
                Check(NetworkChoice.ParseList(NetworkChoice.AllPrivateRanges).Count==3,"«Autorizar toda la red privada del centro» produce tres redes privadas válidas");
                bool named=false;try{NetworkChoice.ParseList("192.168.10.0/24\n200.1.1.0/24");}catch(ArgumentException ex){named=ex.Message.Contains("200.1.1.0/24");}
                Check(named,"Una red de Internet se rechaza y el mensaje indica cuál es");
                Check(Rejected(()=>NetworkChoice.ParseList("")),"Sin redes no se puede continuar");
                Check(NetworkChoice.InRange(IPAddress.Parse("192.168.30.15"),"192.168.30.0/24") && !NetworkChoice.InRange(IPAddress.Parse("192.168.31.15"),"192.168.30.0/24") && NetworkChoice.InRange(IPAddress.Parse("10.4.5.6"),"10.0.0.0/8"),"Comprobación de pertenencia a una subred");
                Check(ServerInstaller.FirewallAddresses(list)=="192.168.10.0/24,192.168.30.0/24,10.20.0.0/16","La regla del cortafuegos recibe todas las subredes autorizadas");
                dynamic firewall=new System.Dynamic.ExpandoObject();ServerInstaller.ConfigureFirewallRule((object)firewall,@"C:\Prueba\AgendaClara.Server.exe",7443,new[]{"192.168.4.0/22"});
                Check((firewall.Profiles&4)==4 && firewall.Profiles==7,"La regla incluye Público además de Dominio y Privado, también al recrearla para actualizar");
                Check(firewall.ApplicationName==@"C:\Prueba\AgendaClara.Server.exe" && firewall.LocalPorts=="7443" && firewall.RemoteAddresses=="192.168.4.0/22" && firewall.Protocol==6 && firewall.Direction==1 && firewall.Action==1 && firewall.Enabled,"Público conserva el ámbito exacto de programa, TCP 7443 y red autorizada /22");
                Check(Rejected(()=>ServerInstaller.ConfigureFirewallRule((object)new System.Dynamic.ExpandoObject(),@"C:\Prueba\AgendaClara.Server.exe",7443,new[]{"0.0.0.0/0"})),"No se abre el cortafuegos a Internet");
                var hosts=NetworkChoice.HostSuggestions();var own=NetworkChoice.Detect();
                Check(hosts[0]==Environment.MachineName && own.All(n=>hosts.Contains(n.Address)),"Se proponen como dirección el nombre del equipo y sus IP privadas ("+String.Join(", ",hosts)+")");

                string data=Path.Combine(root,"datos");Directory.CreateDirectory(data);
                File.WriteAllText(Path.Combine(data,"server.json"),"{\"PublicHost\":\"JEFATURA\",\"Port\":7443,\"AllowedNetworks\":[\"192.168.10.0/24\",\"192.168.30.0/24\"]}");
                var read=new ServerPlan{Data=data};ServerInstaller.ReadConfiguration(read);
                Check(read.Host=="JEFATURA" && read.Port==7443 && read.Networks.SequenceEqual(new[]{"192.168.10.0/24","192.168.30.0/24"}),"Al actualizar se leen todas las subredes ya configuradas (antes solo la primera)");

                var plan=new ServerPlan{Mode="new",Host="JEFATURA",Network="192.168.10.0/24\n192.168.30.0/24",Port=7443,Program=Path.Combine(root,"programa"),Data=Path.Combine(root,"datos-nuevos"),AdminUser="Puesto-Jefatura",AdminPassword="Contrasena-Admin-2026",PackagePassword="Contrasena-Paquetes-2026",Packages=Path.Combine(root,"paquetes"),ExportKey=Path.Combine(root,"respaldo","recuperacion.key")};
                plan.Validate();
                Check(plan.Networks.Count==2,"El plan de instalación valida varias subredes");
                plan.Network="192.168.10.0/24\n8.8.8.0/24";Check(Rejected(plan.Validate),"El plan rechaza una lista con una red pública");plan.Network="192.168.10.0/24\n192.168.30.0/24";

                string localNet=own.Count>0?own[0].Network:"192.168.1.0/24",localIp=own.Count>0?own[0].Address:"192.168.1.10";
                var warnings=NetworkChoice.Warnings("JEFATURA",new[]{localNet,"192.168.250.0/24"});
                Check(warnings.Any(w=>w.Contains("192.168.250.0/24") && w.Contains("DNS")),"Con puestos en otra subred y nombre de equipo, se avisa de que el nombre puede no encontrarse");
                Check(warnings.Any(w=>w.Contains("routers")),"Con puestos en otra subred, se recuerda que el router debe permitir el puerto");
                Check(!NetworkChoice.Warnings(localIp,new[]{localNet,"192.168.250.0/24"}).Any(w=>w.Contains("DNS")),"Con la IP fija del equipo no se avisa del nombre");
                Check(NetworkChoice.Warnings("192.168.251.77",new[]{localNet}).Any(w=>w.Contains("no pertenece a este ordenador")),"Una IP que no es de este ordenador se señala");
                Check(!NetworkChoice.Warnings("JEFATURA",new[]{localNet}).Any(w=>w.Contains("DNS")||w.Contains("routers")),"Con todos los puestos en la misma subred no hay avisos de red entre subredes");
                Console.WriteLine("Redes marcadas como públicas en este equipo: "+(NetworkChoice.PublicNetworks().Count==0?"ninguna":String.Join(", ",NetworkChoice.PublicNetworks())));

                string guide=ServerInstaller.ConnectionGuide(plan);
                Check(guide.Contains("https://JEFATURA:7443") && guide.Contains("192.168.10.0/24, 192.168.30.0/24") && guide.Contains("Test-NetConnection JEFATURA -Port 7443") && guide.Contains("TCP 7443"),"«Red-y-conexion.txt» indica dirección, redes, puerto y la comprobación para los puestos");

                var timeout=ConnectionDiagnostics.Explain(new SocketException((int)SocketError.TimedOut),false);
                Check(timeout.Code=="timeout" && !timeout.Message.Contains("otra subred") && timeout.Message.Contains("Diagnosticar conexión"),"El tiempo de espera pide diagnóstico por etapas sin atribuirlo a las subredes");
                var locals=ConnectionDiagnostics.LocalAddresses();
                Check(locals.All(a=>timeout.Message.Contains(a)),"El mensaje muestra la dirección de este puesto ("+(locals.Count>0?String.Join(", ",locals):"ninguna detectada")+") para saber qué subred autorizar");
                var dns=ConnectionDiagnostics.Explain(new SocketException((int)SocketError.HostNotFound),false);
                Check(dns.Code=="dns" && dns.Message.Contains("nombre") && dns.Message.Contains("dirección"),"Un fallo DNS identifica el nombre y pide comprobar la dirección");
                Check(ConnectionDiagnostics.Explain(new SocketException((int)SocketError.ConnectionRefused),false).Code=="refused","El rechazo de conexión mantiene su diagnóstico propio");

                log.Add("RESUMEN: "+count+" comprobaciones de red del instalador y del cliente correctas, 0 fallos.");Console.WriteLine(log[log.Count-1]);return 0;
            }
            catch(Exception ex){log.Add("FALLO: "+ex);Console.WriteLine(ex);return 1;}
            finally{File.WriteAllLines(Path.Combine(root,"resultado-red-instalador.txt"),log);}
        }
    }
}
