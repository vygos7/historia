using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
#if NETFRAMEWORK
using System.Web.Script.Serialization;
#else
using System.Text.Json;
#endif
namespace AgendaClara.Setup
{
    public sealed class PayloadFile { public string Path {get;set;} public string Sha256 {get;set;} }
    public sealed class PayloadManifest
    {
        public int Format {get;set;}
        public string Role {get;set;}
        public string ClientRevision {get;set;}
        public List<PayloadFile> Files {get;set;}
    }
    public static class PayloadIntegrity
    {
        public const string ClientRevision="4.2.0-experimental-google-oauth-r1",InstallerVersion="1.3.0";
        public static void Validate(string root,string role)
        {
            string manifest=System.IO.Path.Combine(root,"manifiesto.json");
            if(!File.Exists(manifest))throw new IOException("El paquete no incluye el manifiesto de esta versión. No se reutilizan instaladores anteriores.");
#if NETFRAMEWORK
            var data=new JavaScriptSerializer{MaxJsonLength=4194304}.Deserialize<PayloadManifest>(File.ReadAllText(manifest));
#else
            var data=JsonSerializer.Deserialize<PayloadManifest>(File.ReadAllText(manifest));
#endif
            if(data==null||data.Format!=1||data.Role!=role||data.ClientRevision!=ClientRevision||data.Files==null||data.Files.Count==0)throw new IOException("El paquete no corresponde a esta compilación de Nexo Centro.");
            var expected=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            string prefix=System.IO.Path.GetFullPath(root).TrimEnd(System.IO.Path.DirectorySeparatorChar)+System.IO.Path.DirectorySeparatorChar;
            foreach(var item in data.Files)
            {
                if(item==null||String.IsNullOrEmpty(item.Path)||System.IO.Path.IsPathRooted(item.Path)||item.Path.Contains("\\")||item.Path.Split('/').Any(p=>p==".."||p=="."||p.Length==0)||!expected.Add(item.Path))throw new IOException("Ruta duplicada o no válida en el manifiesto.");
                string target=System.IO.Path.GetFullPath(System.IO.Path.Combine(root,item.Path.Replace('/',System.IO.Path.DirectorySeparatorChar)));
                if(!target.StartsWith(prefix,StringComparison.OrdinalIgnoreCase)||!File.Exists(target)||item.Sha256==null||item.Sha256.Length!=64)throw new IOException("El paquete está incompleto.");
                using(var sha=SHA256.Create())using(var input=File.OpenRead(target))
                    if(BitConverter.ToString(sha.ComputeHash(input)).Replace("-","")!=item.Sha256.ToUpperInvariant())throw new IOException("La huella del archivo no coincide: "+item.Path);
            }
            var actual=Directory.GetFiles(root,"*",SearchOption.AllDirectories).Select(p=>p.Substring(prefix.Length).Replace(System.IO.Path.DirectorySeparatorChar,'/')).Where(p=>p!="manifiesto.json");
            if(!expected.SetEquals(actual))throw new IOException("El paquete contiene archivos no declarados.");
            foreach(string path in expected)
            {
                string name=System.IO.Path.GetFileName(path);
                if(name.EndsWith(".pfx",StringComparison.OrdinalIgnoreCase)||name.EndsWith(".dpapi",StringComparison.OrdinalIgnoreCase)||name.EndsWith(".key",StringComparison.OrdinalIgnoreCase)||new[]{"server.json","security.json","TrabajoCompartido.xml","agenda.sqlite3"}.Contains(name,StringComparer.OrdinalIgnoreCase))throw new IOException("Un paquete general no puede contener identidades o datos de un centro.");
            }
            string[] required=role=="cliente"?new[]{"AgendaClara.exe","AgendaClara.exe.config","Microsoft.AspNetCore.SignalR.Client.dll"}:new[]{"AgendaClara.Server.exe","AgendaClara.Server.dll","AgendaClara.Server.runtimeconfig.json","coreclr.dll","hostfxr.dll"};
            if(required.Any(p=>!expected.Contains(p)))throw new IOException("Faltan componentes necesarios del programa.");
            if(role=="cliente")
            {
                string version=FileVersionInfo.GetVersionInfo(System.IO.Path.Combine(root,"AgendaClara.exe")).ProductVersion??"";
                if(!version.StartsWith(ClientRevision,StringComparison.Ordinal))throw new IOException("El cliente incluido no contiene la corrección r2.");
            }
        }
    }
}
