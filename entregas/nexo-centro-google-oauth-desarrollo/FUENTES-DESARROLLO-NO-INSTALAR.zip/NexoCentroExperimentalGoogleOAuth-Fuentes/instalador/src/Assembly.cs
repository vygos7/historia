using System.Reflection;
using System.Runtime.Versioning;
[assembly:AssemblyTitle("Asistente de instalación de Nexo Centro")]
[assembly:AssemblyProduct("Nexo Centro Experimental")]
[assembly:AssemblyVersion("1.3.0.0")]
[assembly:AssemblyFileVersion("1.3.0.0")]
[assembly:TargetFramework(".NETFramework,Version=v4.8")]


[assembly:AssemblyInformationalVersion("1.3.0-experimental-google-r1")]
