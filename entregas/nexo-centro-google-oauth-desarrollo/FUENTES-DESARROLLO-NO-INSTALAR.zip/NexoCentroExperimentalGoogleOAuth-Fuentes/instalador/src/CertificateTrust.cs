using System;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Xml;

namespace AgendaClara.Setup
{
    public static class CertificateTrust
    {
        [System.Runtime.InteropServices.DllImport("crypt32.dll",SetLastError=true)]
        static extern bool CryptVerifyCertificateSignatureEx(IntPtr provider,uint encoding,uint subjectType,IntPtr subject,uint issuerType,IntPtr issuer,uint flags,IntPtr extra);
        [System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential)]
        struct ChainEngineConfig{public int Size;public IntPtr RestrictedRoot,RestrictedTrust,RestrictedOther;public int AdditionalStores;public IntPtr AdditionalStore;public int Flags,UrlRetrievalTimeout,MaximumCachedCertificates,CycleDetectionModulus;public IntPtr ExclusiveRoot,ExclusiveTrustedPeople;public int ExclusiveFlags;}
        [System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential)]
        struct ChainParameters{public int Size,UsageType,UsageCount;public IntPtr Usages;}
        [System.Runtime.InteropServices.DllImport("crypt32.dll",SetLastError=true)]static extern bool CertCreateCertificateChainEngine(ref ChainEngineConfig config,out IntPtr engine);
        [System.Runtime.InteropServices.DllImport("crypt32.dll")]static extern void CertFreeCertificateChainEngine(IntPtr engine);
        [System.Runtime.InteropServices.DllImport("crypt32.dll",SetLastError=true)]static extern bool CertGetCertificateChain(IntPtr engine,IntPtr certificate,IntPtr time,IntPtr store,ref ChainParameters parameters,int flags,IntPtr reserved,out IntPtr chain);
        [System.Runtime.InteropServices.DllImport("crypt32.dll")]static extern void CertFreeCertificateChain(IntPtr chain);
        // X509Chain uses the process-wide chain engine, which keeps the result it computed before the root was added
        // and reports UntrustedRoot until the process ends. A new engine reads the stores as Windows has them now,
        // so a root blocked by policy is still reported. Returns "" when Windows trusts the root.
        public static string WindowsTrustProblem(X509Certificate2 root)
        {
            var config=new ChainEngineConfig{Size=System.Runtime.InteropServices.Marshal.SizeOf(typeof(ChainEngineConfig))};IntPtr engine,chain;
            if(!CertCreateCertificateChainEngine(ref config,out engine))return "no se pudo comprobar la cadena, error "+System.Runtime.InteropServices.Marshal.GetLastWin32Error();
            try
            {
                var parameters=new ChainParameters{Size=System.Runtime.InteropServices.Marshal.SizeOf(typeof(ChainParameters))};
                if(!CertGetCertificateChain(engine,root.Handle,IntPtr.Zero,IntPtr.Zero,ref parameters,0,IntPtr.Zero,out chain))return "no se pudo comprobar la cadena, error "+System.Runtime.InteropServices.Marshal.GetLastWin32Error();
                int status=System.Runtime.InteropServices.Marshal.ReadInt32(chain,4);CertFreeCertificateChain(chain);
                if(status==0)return "";
                return (status&0x20)!=0?"Windows no la acepta como raíz de confianza para este usuario":(status&0x1)!=0?"fuera de su periodo de validez":(status&0x8)!=0?"firma no válida":"estado de cadena 0x"+status.ToString("X");
            }
            finally{CertFreeCertificateChainEngine(engine);}
        }
        public static string Fingerprint(X509Certificate2 certificate)
        { using(var sha=SHA256.Create())return BitConverter.ToString(sha.ComputeHash(certificate.RawData)).Replace("-",""); }
        public static string Normalize(string value)
        { return System.Text.RegularExpressions.Regex.Replace(value??"","[\\s:-]","").ToUpperInvariant(); }
        public static X509Certificate2 ExistingAuthority(string configuration)
        {
            if(!File.Exists(configuration))return null;
            var xml=new XmlDocument{XmlResolver=null};
            using(var reader=XmlReader.Create(configuration,new XmlReaderSettings{DtdProcessing=DtdProcessing.Prohibit,XmlResolver=null}))xml.Load(reader);
            var node=xml.SelectSingleNode("/SharedConfiguration/ServerAuthority");
            return node==null||node.InnerText.Length==0?null:new X509Certificate2(Convert.FromBase64String(node.InnerText));
        }
        public static void ValidateRoot(X509Certificate2 root,string verifiedHash)
        {
            if(Normalize(verifiedHash).Length!=64||Fingerprint(root)!=Normalize(verifiedHash))
                throw new ArgumentException("La huella de la autoridad no coincide con la verificada. Pide a Jefatura la huella SHA-256 por un medio independiente.");
            if(root.HasPrivateKey || !root.SubjectName.RawData.SequenceEqual(root.IssuerName.RawData) ||
                !root.Extensions.OfType<X509BasicConstraintsExtension>().Any(e=>e.CertificateAuthority) ||
                !root.Extensions.OfType<X509KeyUsageExtension>().Any(e=>(e.KeyUsages&X509KeyUsageFlags.KeyCertSign)!=0))
                throw new ArgumentException("El archivo no es una autoridad raíz pública válida.");
            if(!CryptVerifyCertificateSignatureEx(IntPtr.Zero,1,2,root.Handle,2,root.Handle,0,IntPtr.Zero))throw new ArgumentException("La firma de la autoridad no es válida.");
            using(var chain=new X509Chain())
            {
                chain.ChainPolicy.RevocationMode=X509RevocationMode.NoCheck;
                chain.ChainPolicy.VerificationFlags=X509VerificationFlags.AllowUnknownCertificateAuthority;
                if(!chain.Build(root)||chain.ChainElements.Count!=1 || chain.ChainStatus.Any(s=>s.Status!=X509ChainStatusFlags.UntrustedRoot && s.Status!=X509ChainStatusFlags.NoError))
                    throw new ArgumentException("La autoridad ha caducado o su firma no es válida. No se ha instalado.");
            }
        }
        public static void VerifyForApplication(X509Certificate2 root,string verifiedHash,IProgress<string> progress)
        {
            ValidateRoot(root,verifiedHash);
            progress.Report("Autoridad HTTPS verificada para Nexo Centro. La confianza general de Windows no se modifica.");
        }
        public static void Repair(string configuration,IProgress<string> progress)
        {
            using(var root=ExistingAuthority(configuration))
            {
                if(root==null)throw new IOException("La configuración anterior no conserva la autoridad del servidor. Usa el instalador de tu puesto generado por Jefatura y verifica su huella.");
                var xml=new XmlDocument{XmlResolver=null};using(var reader=XmlReader.Create(configuration,new XmlReaderSettings{DtdProcessing=DtdProcessing.Prohibit,XmlResolver=null}))xml.Load(reader);
                var identity=xml.SelectSingleNode("/SharedConfiguration/ClientThumbprint");
                using(var personal=new X509Store(StoreName.My,StoreLocation.CurrentUser))
                using(var chain=new X509Chain())
                {
                    personal.Open(OpenFlags.ReadOnly);
                    var device=identity==null?null:personal.Certificates.Find(X509FindType.FindByThumbprint,identity.InnerText,false).Cast<X509Certificate2>().FirstOrDefault(c=>c.HasPrivateKey);
                    chain.ChainPolicy.ExtraStore.Add(root);chain.ChainPolicy.RevocationMode=X509RevocationMode.NoCheck;chain.ChainPolicy.VerificationFlags=X509VerificationFlags.AllowUnknownCertificateAuthority;chain.ChainPolicy.ApplicationPolicy.Add(new Oid("1.3.6.1.5.5.7.3.2"));
                    if(device==null||!chain.Build(device)||!chain.ChainElements[chain.ChainElements.Count-1].Certificate.RawData.SequenceEqual(root.RawData))throw new IOException("El certificado de este puesto falta, ha caducado o no corresponde a la autoridad configurada. Usa un instalador de puesto válido de Jefatura.");
                }
                // The previous per-user installation is the trust anchor for repair, never a root fetched over the network.
                VerifyForApplication(root,Fingerprint(root),progress);
            }
        }
    }
}
