using System;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Xml;
using System.Security.Cryptography;

namespace AgendaClara.Setup
{
    public sealed class SimplePackage:IDisposable
    {
        const string Marker="AGENDACLARA-PUESTO-02";
        public string DirectoryPath,Role,Password,Hash,User;
        public static string Secret(){using(var random=RandomNumberGenerator.Create()){byte[] bytes=new byte[48];random.GetBytes(bytes);return Convert.ToBase64String(bytes);}}
        public static void Create(string baseExe,string folder,string destination,string role,string password)
        {
            var xml=new XmlDocument();var root=xml.CreateElement("Puesto");xml.AppendChild(root);
            foreach(var pair in new[]{new[]{"Perfil",role},new[]{"Huella",Files.Hash(Path.Combine(folder,"servidor-raiz.cer"))},new[]{"Usuario",File.ReadAllText(Path.Combine(folder,"usuario.txt")).Trim()}}){var item=xml.CreateElement(pair[0]);item.InnerText=pair[1];root.AppendChild(item);}
            using(var bytes=new MemoryStream())
            {
                using(var zip=new ZipArchive(bytes,ZipArchiveMode.Create,true))
                {
                    foreach(string file in new[]{"equipo.pfx","servidor-raiz.cer","servidor.txt"}){var entry=zip.CreateEntry(file,CompressionLevel.Optimal);using(var output=entry.Open())using(var input=File.OpenRead(Path.Combine(folder,file)))input.CopyTo(output);}
                    var metadata=zip.CreateEntry("puesto.xml");using(var output=metadata.Open()){byte[] data=Encoding.UTF8.GetBytes(xml.OuterXml);output.Write(data,0,data.Length);}
                }
                byte[] payload=Encrypt(bytes.ToArray(),password);using(var output=File.Create(destination))using(var input=File.OpenRead(baseExe))
                {
                    input.CopyTo(output);output.Write(payload,0,payload.Length);using(var sha=SHA256.Create()){byte[] hash=sha.ComputeHash(payload);output.Write(hash,0,hash.Length);}byte[] size=BitConverter.GetBytes((long)payload.Length);output.Write(size,0,size.Length);byte[] marker=Encoding.ASCII.GetBytes(Marker);output.Write(marker,0,marker.Length);
                }
            }
        }
        public static SimplePackage Open(string executable,string password=null)
        {
            byte[] marker=Encoding.ASCII.GetBytes(Marker);using(var input=File.OpenRead(executable))
            {
                int trailer=marker.Length+8+32;if(input.Length<trailer)return null;input.Position=input.Length-marker.Length;byte[] actual=new byte[marker.Length];Read(input,actual);if(!actual.SequenceEqual(marker))return null;
                input.Position=input.Length-marker.Length-8;byte[] size=new byte[8];Read(input,size);long length=BitConverter.ToInt64(size,0);if(length<1||length>1048576||length>input.Length-trailer)throw new IOException("El instalador del puesto está dañado. Vuelve a copiarlo desde Jefatura.");
                byte[] expected=new byte[32];
                input.Position=input.Length-marker.Length-8-32;Read(input,expected);input.Position=input.Length-trailer-length;byte[] payload=new byte[(int)length];Read(input,payload);using(var sha=SHA256.Create())if(!sha.ComputeHash(payload).SequenceEqual(expected))throw new IOException("El instalador del puesto está incompleto o dañado.");
                if(password==null)password=AskPassword();
                payload=Decrypt(payload,password);
                var package=new SimplePackage{DirectoryPath=Path.Combine(Path.GetTempPath(),"AgendaClara-Instalacion-"+Guid.NewGuid().ToString("N"))};Files.OwnFolder(package.DirectoryPath,false);
                try
                {
                    using(var zip=new ZipArchive(new MemoryStream(payload),ZipArchiveMode.Read))
                    {
                        string[] permitted={"equipo.pfx","servidor-raiz.cer","servidor.txt","puesto.xml"};if(zip.Entries.Count!=4)throw new IOException("El instalador del puesto no es válido.");
                        foreach(var entry in zip.Entries){if(!permitted.Contains(entry.FullName)||entry.Length>262144)throw new IOException("El instalador del puesto no es válido.");using(var output=File.Create(Path.Combine(package.DirectoryPath,entry.FullName)))using(var content=entry.Open())content.CopyTo(output);}
                        foreach(string file in permitted)if(!File.Exists(Path.Combine(package.DirectoryPath,file)))throw new IOException("Falta un archivo del puesto.");
                    }
                    var doc=new XmlDocument();doc.XmlResolver=null;using(var reader=XmlReader.Create(Path.Combine(package.DirectoryPath,"puesto.xml"),new XmlReaderSettings{DtdProcessing=DtdProcessing.Prohibit,XmlResolver=null}))doc.Load(reader);
                    package.Role=doc.SelectSingleNode("/Puesto/Perfil").InnerText;package.Password=password;package.Hash=doc.SelectSingleNode("/Puesto/Huella").InnerText;package.User=doc.SelectSingleNode("/Puesto/Usuario").InnerText;
                    if(!new[]{"Jefatura","Direccion","Secretaria"}.Contains(package.Role))throw new IOException("Puesto no válido.");return package;
                }catch{package.Dispose();throw;}
            }
        }
        static byte[] Encrypt(byte[] data,string password)
        {
            byte[] salt=new byte[32];using(var random=RandomNumberGenerator.Create())random.GetBytes(salt);
            using(var derive=new Rfc2898DeriveBytes(password,salt,200000,HashAlgorithmName.SHA256))
            using(var aes=Aes.Create())
            {
                byte[] keys=derive.GetBytes(64);aes.Key=keys.Take(32).ToArray();aes.GenerateIV();
                byte[] encrypted;using(var transform=aes.CreateEncryptor())encrypted=transform.TransformFinalBlock(data,0,data.Length);
                byte[] body=salt.Concat(aes.IV).Concat(encrypted).ToArray();
                using(var mac=new HMACSHA256(keys.Skip(32).ToArray()))return body.Concat(mac.ComputeHash(body)).ToArray();
            }
        }
        static byte[] Decrypt(byte[] data,string password)
        {
            if(data.Length<96)throw new IOException("El paquete cifrado está incompleto.");
            using(var derive=new Rfc2898DeriveBytes(password,data.Take(32).ToArray(),200000,HashAlgorithmName.SHA256))
            using(var aes=Aes.Create())
            {
                byte[] keys=derive.GetBytes(64),body=data.Take(data.Length-32).ToArray(),expected;
                using(var mac=new HMACSHA256(keys.Skip(32).ToArray()))expected=mac.ComputeHash(body);
                int difference=0;for(int i=0;i<32;i++)difference|=expected[i]^data[body.Length+i];
                if(difference!=0)throw new IOException("La clave de transporte no es correcta o el instalador ha sido alterado. Pide una copia válida a Jefatura.");
                aes.Key=keys.Take(32).ToArray();aes.IV=data.Skip(32).Take(16).ToArray();
                using(var transform=aes.CreateDecryptor())return transform.TransformFinalBlock(body,48,body.Length-48);
            }
        }
        static string AskPassword()
        {
            using(var form=new System.Windows.Forms.Form{Text="Nexo Centro · Abrir acceso protegido",Width=580,Height=225,StartPosition=System.Windows.Forms.FormStartPosition.CenterScreen})
            {
                var label=new System.Windows.Forms.Label{Text="Introduce la clave de transporte que Jefatura te ha comunicado por separado. Protege el certificado privado del puesto y solo se usa durante la instalación.",Left=18,Top=15,Width=525,Height=65};
                var box=new System.Windows.Forms.TextBox{Left=18,Top=85,Width=525,UseSystemPasswordChar=true};
                var ok=new System.Windows.Forms.Button{Text="Abrir",Left=340,Top=125,Width=95,DialogResult=System.Windows.Forms.DialogResult.OK};
                var cancel=new System.Windows.Forms.Button{Text="Cancelar",Left=445,Top=125,Width=95,DialogResult=System.Windows.Forms.DialogResult.Cancel};
                form.Controls.AddRange(new System.Windows.Forms.Control[]{label,box,ok,cancel});form.AcceptButton=ok;form.CancelButton=cancel;
                if(form.ShowDialog()!=System.Windows.Forms.DialogResult.OK)throw new OperationCanceledException("Instalación cancelada.");return box.Text;
            }
        }
        static void Read(Stream input,byte[] data){int offset=0;while(offset<data.Length){int count=input.Read(data,offset,data.Length-offset);if(count==0)throw new EndOfStreamException();offset+=count;}}
        public void Dispose(){Files.RemoveTemporary(DirectoryPath);Password="";}
    }
}
