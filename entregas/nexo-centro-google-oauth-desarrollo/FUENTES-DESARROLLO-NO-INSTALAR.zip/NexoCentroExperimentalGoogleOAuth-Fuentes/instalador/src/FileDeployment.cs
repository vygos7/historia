using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;

namespace AgendaClara.Setup
{
    // Conserva sólo los archivos que se van a sustituir y no toca archivos ajenos.
    // El llamador crea el respaldo con permisos restringidos antes de utilizarlo.
    public sealed class FileDeployment : IDisposable
    {
        sealed class Item { public string Source,Target,Backup;public bool Existed; }
        readonly List<Item> items=new List<Item>();
        bool applied,committed,restored;
        public FileDeployment(string source,string destination,string backup)
        {
            source=Path.GetFullPath(source);destination=Path.GetFullPath(destination);backup=Path.GetFullPath(backup);
            if(Within(source,destination)||Within(destination,source)||Within(backup,source)||Within(backup,destination)||Within(source,backup)||Within(destination,backup))throw new IOException("Origen, programa y respaldo deben estar separados.");
            if(!Directory.Exists(source))throw new IOException("No existe el programa que se va a instalar.");
            foreach(string path in Directory.GetFiles(source,"*",SearchOption.AllDirectories))
            {
                if((File.GetAttributes(path)&FileAttributes.ReparsePoint)!=0)throw new IOException("El programa no puede contener enlaces de archivos.");
                string relative=path.Substring(source.Length).TrimStart(Path.DirectorySeparatorChar,Path.AltDirectorySeparatorChar);
                string target=Path.Combine(destination,relative),saved=Path.Combine(backup,relative);
                for(string folder=Path.GetDirectoryName(target);folder!=null && Within(folder,destination);folder=Path.GetDirectoryName(folder))
                    if(Directory.Exists(folder)&&(File.GetAttributes(folder)&FileAttributes.ReparsePoint)!=0)throw new IOException("La carpeta del programa no puede contener enlaces de directorios.");
                if(File.Exists(target)&&(File.GetAttributes(target)&FileAttributes.ReparsePoint)!=0)throw new IOException("El archivo de destino es un enlace.");
                var item=new Item{Source=path,Target=target,Backup=saved,Existed=File.Exists(target)};
                if(item.Existed){Directory.CreateDirectory(Path.GetDirectoryName(saved));File.Copy(target,saved,false);if(Digest(target)!=Digest(saved))throw new IOException("No se ha podido verificar el respaldo del programa.");}
                items.Add(item);
            }
            if(items.Count==0)throw new IOException("El programa está vacío.");
        }
        static bool Within(string path,string root)
        {return path.Equals(root,StringComparison.OrdinalIgnoreCase)||path.StartsWith(root.TrimEnd(Path.DirectorySeparatorChar,Path.AltDirectorySeparatorChar)+Path.DirectorySeparatorChar,StringComparison.OrdinalIgnoreCase);}
        static string Digest(string path){using(var sha=SHA256.Create())using(var input=File.OpenRead(path))return Convert.ToBase64String(sha.ComputeHash(input));}
        public void Apply()
        {
            if(applied)throw new InvalidOperationException("La copia ya se ha iniciado.");applied=true;
            foreach(var item in items){Directory.CreateDirectory(Path.GetDirectoryName(item.Target));File.Copy(item.Source,item.Target,true);if(Digest(item.Source)!=Digest(item.Target))throw new IOException("No se ha podido verificar el programa copiado.");}
        }
        public void Commit(){if(!applied)throw new InvalidOperationException("No se ha copiado el programa.");committed=true;}
        public void Restore()
        {
            if(restored || !applied)return;
            var errors=new List<Exception>();
            foreach(var item in items)
                try
                {
                    if(item.Existed){File.Copy(item.Backup,item.Target,true);if(Digest(item.Backup)!=Digest(item.Target))throw new IOException("El respaldo restaurado no coincide.");}
                    else if(File.Exists(item.Target))File.Delete(item.Target);
                }
                catch(Exception ex)when(ex is IOException || ex is UnauthorizedAccessException){errors.Add(ex);}
            if(errors.Count>0)throw new IOException("No se ha podido restaurar todo el programa. Conserva el respaldo y consulta al responsable.",new AggregateException(errors));
            restored=true;
        }
        public void Dispose(){if(!committed)Restore();}
    }
}
