using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AgendaClara.Setup
{
    public sealed class ServerWizard:Wizard
    {
        readonly ComboBox mode=new ComboBox{DropDownStyle=ComboBoxStyle.DropDownList};
        readonly TextBox agenda=new TextBox(),packages=new TextBox(),network=new TextBox{Multiline=true,Height=84,ScrollBars=ScrollBars.Vertical,AcceptsReturn=true};
        readonly ComboBox host=new ComboBox{DropDownStyle=ComboBoxStyle.DropDown};
        readonly Label networkSummary=new Label{AutoSize=true,MaximumSize=new System.Drawing.Size(810,0),Margin=new Padding(0,4,0,8),ForeColor=System.Drawing.Color.FromArgb(32,48,68)};
        readonly NumericUpDown port=new NumericUpDown{Minimum=1024,Maximum=65535,Value=7445};
        readonly TextBox review=new TextBox{Multiline=true,ReadOnly=true,Height=240,ScrollBars=ScrollBars.Vertical,BackColor=System.Drawing.Color.White};
        readonly Panel advanced=new Panel{AutoSize=true,Dock=DockStyle.Top,Visible=false};
        readonly string programPath=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),"NexoCentroExperimentalGoogleOAuthServidor"),dataPath=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),"NexoCentroExperimentalGoogleOAuthServidor");
        ServerPlan plan;
        public ServerWizard():base("Instalar Nexo Centro · Servidor")
        {
            heading.Text="Nexo Centro en Jefatura";intro.Text="Instala el servidor y crea los tres instaladores de cliente. Con accesos cifrados para cada puesto.";
            host.Items.AddRange(NetworkChoice.HostSuggestions().Cast<object>().ToArray());host.Text=Environment.MachineName;
            var networks=NetworkChoice.Detect();network.Text=networks.Count>0?String.Join(Environment.NewLine,networks.Select(n=>n.Network).Distinct()):"";
            string old=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"AgendaClara","agenda.sqlite3");agenda.Text="";
            packages.Text=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory),"Instaladores Nexo Centro EXPERIMENTAL "+DateTime.Now.ToString("yyyyMMdd-HHmmss"));
            var first=Page();Note(first,"Solo tienes que elegir la agenda que quieres conservar.",true);
            mode.Items.AddRange(new object[]{"Instalar el servidor","Actualizar el servidor","Completar una instalación interrumpida"});Field(first,"Operación",mode);
            Field(first,"Agenda actual (opcional)",Pick(agenda,()=>Open(agenda,"Agenda SQLite|*.sqlite3;*.db|Todos los archivos|*.*")));
            Note(first,"La agenda original se conserva. Si dejas este campo vacío, se crea una nueva.");Field(first,"Guardar los instaladores en",Pick(packages,()=>Folder(packages)));
            Note(first,"Se crearán tres archivos: Instalar-Nexo Centro-Jefatura.exe, Instalar-Nexo Centro-Direccion.exe e Instalar-Nexo Centro-Secretaria.exe. Cada uno llevará dentro su conexión y su perfil.");
            first.Controls.Add(networkSummary,0,first.RowCount++);first.SetColumnSpan(networkSummary,2);
            var toggle=new Button{Text="Opciones de red…",Width=180,Height=34};first.Controls.Add(toggle,0,first.RowCount++);first.SetColumnSpan(toggle,2);
            var options=new TableLayoutPanel{ColumnCount=2,AutoSize=true,Dock=DockStyle.Top};options.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,230));options.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));
            Field(options,"Dirección de Jefatura para los puestos",host);
            Note(options,"El nombre del equipo solo funciona si todos los puestos están en la misma subred o si el DNS del centro lo conoce. Si algún puesto está en otra subred y no hay DNS interno, elige la IP fija de este ordenador.");
            Field(options,"Redes de los puestos (una por línea)",network);
            var everything=new Button{Text="Autorizar toda la red privada del centro",AutoSize=true,Height=32};everything.Click+=(s,e)=>{network.Text=NetworkChoice.AllPrivateRanges.Replace(", ",Environment.NewLine);};
            options.Controls.Add(everything,1,options.RowCount++);
            Note(options,"Añade la subred de cada grupo de puestos que esté en otra red, por ejemplo la de Dirección o Secretaría (192.168.30.0/24). En cada puesto, «ipconfig» muestra su dirección. Solo se admiten redes privadas, nunca Internet.");
            Field(options,"Puerto",port);advanced.Controls.Add(options);first.Controls.Add(advanced,0,first.RowCount++);first.SetColumnSpan(advanced,2);toggle.Click+=(s,e)=>{advanced.Visible=!advanced.Visible;};
            EventHandler summary=(s,e)=>{string list;try{list=String.Join(", ",NetworkChoice.ParseList(network.Text));}catch(ArgumentException ex){list=ex.Message;}networkSummary.Text="Los puestos se conectarán a https://"+host.Text.Trim()+":"+port.Value+" desde: "+list+".";};
            host.TextChanged+=summary;network.TextChanged+=summary;port.ValueChanged+=summary;summary(null,EventArgs.Empty);
            var second=Page();Note(second,"Listo para instalar",true);second.Controls.Add(review,0,second.RowCount++);second.SetColumnSpan(review,2);Note(second,"La conexión y el acceso de los puestos se configuran automáticamente. La clave de transporte se guarda en el respaldo: comunícala por separado. La huella HTTPS se contrasta en Jefatura.");
            mode.SelectedIndexChanged+=(s,e)=>{bool updating=mode.SelectedIndex==1;agenda.Enabled=mode.SelectedIndex==0;packages.Enabled=true;host.Enabled=network.Enabled=port.Enabled=mode.SelectedIndex!=2;if(mode.SelectedIndex>0){var p=new ServerPlan{Program=programPath,Data=dataPath};ServerInstaller.ReadExisting(p);try{ServerInstaller.ReadConfiguration(p);}catch{}if(p.Host.Length>0)host.Text=p.Host;if(p.Network.Length>0)network.Text=p.Network.Replace(", ",Environment.NewLine);port.Value=p.Port;}};
            mode.SelectedIndex=ServerInstaller.Exists()?1:File.Exists(Path.Combine(dataPath,"server.json"))?2:0;ShowPage(0);
        }
        protected override async Task MoveNext()
        {
            if(complete){Close();return;}
            try
            {
                if(index==0)
                {
                    plan=new ServerPlan{Mode=mode.SelectedIndex==0?"new":mode.SelectedIndex==1?"update":"resume",Host=host.Text.Trim(),Network=network.Text.Trim(),Port=(int)port.Value,Program=programPath,Data=dataPath,Agenda=mode.SelectedIndex==0?agenda.Text.Trim():"",Packages=Files.Full(packages.Text),ExportKey=Path.Combine(Files.Full(packages.Text),"Respaldo del servidor","recuperacion.key"),AdminUser="Puesto-Jefatura",AdminPassword=SimplePackage.Secret(),PackagePassword=SimplePackage.Secret()};
                    // An update keeps the network options shown on screen, which may have been changed; resuming uses the prepared ones.
                    if(plan.Mode!="new"){ServerInstaller.ReadExisting(plan);if(plan.Mode!="update")ServerInstaller.ReadConfiguration(plan);}plan.Validate();
                    var warnings=NetworkChoice.Warnings(plan.Host,plan.Networks);
                    review.Text=(plan.Mode=="update"?"Actualizar el servidor conservando la agenda.":"Preparar el servidor y los tres instaladores de cliente.")+"\r\n\r\nDirección para los puestos: https://"+plan.Host+":"+plan.Port+"\r\nRedes autorizadas: "+String.Join(", ",plan.Networks)+"\r\nAgenda: "+(plan.Mode!="new"?"Se conserva la instalada":plan.Agenda.Length==0?"Nueva":plan.Agenda)+"\r\n"+("\r\nLos tres instaladores quedarán en:\r\n"+plan.Packages+"\r\n")+"\r\nLos puestos pedirán la clave de transporte y verificarán la huella HTTPS al instalar."+(plan.Mode=="update"?" Si cambias la dirección, instala en cada puesto su instalador nuevo.":"")
                        +(warnings.Count>0?"\r\n\r\nRevisa antes de continuar:\r\n- "+String.Join("\r\n- ",warnings):"")+"\r\n\r\nJunto a los instaladores se guardará «Red-y-conexion.txt» con la comprobación para los puestos.";ShowPage(1);return;
                }
                await Work(async progress=>{string temporary=null;try{await Task.Run(()=>{temporary=Files.Extract("AgendaClara.Setup.ServerPayload");ServerInstaller.Install(plan,Path.Combine(temporary,"servidor"),progress);});}finally{Files.RemoveTemporary(temporary);plan.AdminPassword=plan.PackagePassword="";}});
                if(complete){intro.Text="Los tres instaladores están preparados. Lleva cada archivo a su puesto y ábrelo con doble clic.";var open=new Button{Text="Ver los tres instaladores",Height=38,Dock=DockStyle.Bottom};open.Click+=(s,e)=>Process.Start(new ProcessStartInfo("explorer.exe",Files.Quote(plan.Packages)){UseShellExecute=true});body.Controls.Add(open);open.BringToFront();}
            }catch(Exception ex){Error(ex);}
        }
    }
    public sealed class ClientWizard:Wizard
    {
        readonly TextBox program=new TextBox(),verifiedHash=new TextBox();readonly CheckBox offline=new CheckBox{Text="Permitir consultar la agenda cuando Jefatura esté apagada",Checked=true,AutoSize=true};
        readonly SimplePackage package;readonly string configuration;ClientPlan plan;
        public ClientWizard():this(System.Reflection.Assembly.GetExecutingAssembly().Location,null){}
        public ClientWizard(string executable,string configurationPath,string transportPassword=null):base("Instalar Nexo Centro")
        {
            configuration=configurationPath??Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"NexoCentroExperimentalGoogleOAuth","TrabajoCompartido.xml");
            package=SimplePackage.Open(executable,transportPassword);FormClosed+=(s,e)=>{if(package!=null)package.Dispose();};
            program.Text=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"Programs","NexoCentroExperimentalGoogleOAuth");
            heading.Text=package==null?"Nexo Centro Experimental":"Nexo Centro · "+(package.Role=="Direccion"?"Dirección":package.Role=="Secretaria"?"Secretaría":"Jefatura");
            intro.Text="Pulsa Instalar. La conexión y el acceso se configuran automáticamente.";var page=Page();
            if(package==null && !File.Exists(configuration)){Note(page,"Abre el instalador de Jefatura, Dirección o Secretaría generado por el servidor. Cada archivo está listo para su puesto.",true);next.Enabled=false;next.Visible=false;intro.Text="Necesitas el instalador que Jefatura ha creado para este puesto.";cancel.Text="Cerrar";back.Visible=false;return;}
            Note(page,package==null?"Se actualizará el programa conservando la conexión actual.":"Este instalador ya lleva la configuración de "+(package.Role=="Direccion"?"Dirección":package.Role=="Secretaria"?"Secretaría":"Jefatura")+". Necesitarás la clave de transporte y, en el primer uso, la huella verificada con Jefatura.",true);
            if(package!=null)
            {
                Note(page,"Servidor: "+File.ReadAllText(Path.Combine(package.DirectoryPath,"servidor.txt")).Trim());
                using(var existing=CertificateTrust.ExistingAuthority(configuration))
                {
                    if(existing==null || CertificateTrust.Fingerprint(existing)!=package.Hash)
                    {
                        Note(page,"Primera instalación o cambio de autoridad: pide a Jefatura la huella SHA-256 del archivo Huella-HTTPS.txt por un medio independiente (por ejemplo, en persona). El código incluido en este mismo EXE solo comprueba integridad y no acredita su origen.");
                        Field(page,"Huella SHA-256 verificada con Jefatura",verifiedHash);
                    }
                }
            }
            Field(page,"Instalar el programa en",Pick(program,()=>Folder(program)));if(package!=null){page.Controls.Add(offline,0,page.RowCount++);page.SetColumnSpan(offline,2);}Note(page,"Se creará un acceso directo en el escritorio. La agenda individual anterior se conserva.");ShowPage(0);back.Visible=false;
        }
        protected override async Task MoveNext()
        {
            if(complete){Close();return;}
            try
            {
                plan=new ClientPlan{Program=Files.Full(program.Text),Configuration=configuration,UseExisting=package==null,AutomaticAccess=package!=null,Offline=offline.Checked};
                if(package!=null){plan.Package=package.DirectoryPath;plan.PackagePassword=package.Password;plan.ExpectedHash=package.Hash;plan.VerifiedAuthorityHash=verifiedHash.Text;plan.User=package.User;}plan.Validate();
                await Work(async progress=>{string temporary=null;try{await Task.Run(()=>{temporary=Files.Extract("AgendaClara.Setup.ClientPayload");ClientInstaller.Install(plan,Path.Combine(temporary,"cliente"),progress);});}finally{Files.RemoveTemporary(temporary);plan.PackagePassword="";}});
                if(complete){intro.Text="Abre Nexo Centro. Este puesto ya tiene su acceso preparado.";var launch=new Button{Text="Abrir Nexo Centro",Height=38,Dock=DockStyle.Bottom};launch.Click+=(s,e)=>Process.Start(Path.Combine(plan.Program,"AgendaClara.exe"));body.Controls.Add(launch);launch.BringToFront();}
            }catch(Exception ex){Error(ex);}
        }
    }
}

