using System;

namespace AgendaClara.Setup
{
    // Valores CLR independientes del objeto COM y de la regla que se va a retirar.
    // No se conserva una regla COM desvinculada para volver a insertarla después.
    public sealed class FirewallSnapshot
    {
        public string Name,Description,ApplicationName,ServiceName,LocalPorts,RemotePorts,LocalAddresses,RemoteAddresses,IcmpTypes,InterfaceTypes,Grouping;
        public int Protocol,Direction,Profiles,Action;
        public bool Enabled,EdgeTraversal;
        public object Interfaces;
        public static FirewallSnapshot Capture(object value)
        {
            dynamic rule=value;
            var snapshot=new FirewallSnapshot{Name=rule.Name,Description=rule.Description,ApplicationName=rule.ApplicationName,ServiceName=rule.ServiceName,
                Protocol=rule.Protocol,LocalAddresses=rule.LocalAddresses,RemoteAddresses=rule.RemoteAddresses,Direction=rule.Direction,
                InterfaceTypes=rule.InterfaceTypes,Grouping=rule.Grouping,Profiles=rule.Profiles,Action=rule.Action,Enabled=rule.Enabled,EdgeTraversal=rule.EdgeTraversal};
            if(snapshot.Protocol==6||snapshot.Protocol==17){snapshot.LocalPorts=rule.LocalPorts;snapshot.RemotePorts=rule.RemotePorts;}
            else if(snapshot.Protocol==1||snapshot.Protocol==58)snapshot.IcmpTypes=rule.IcmpTypesAndCodes;
            object interfaces=rule.Interfaces;var array=interfaces as Array;snapshot.Interfaces=array==null?interfaces:array.Clone();
            return snapshot;
        }
        public void Apply(object value)
        {
            dynamic rule=value;
            rule.Name=Name;rule.Protocol=Protocol;rule.Direction=Direction;rule.Action=Action;
            if(!String.IsNullOrEmpty(Description))rule.Description=Description;
            if(!String.IsNullOrEmpty(ApplicationName))rule.ApplicationName=ApplicationName;
            if(!String.IsNullOrEmpty(ServiceName))rule.ServiceName=ServiceName;
            if(Protocol==6||Protocol==17){rule.LocalPorts=LocalPorts;rule.RemotePorts=RemotePorts;}
            else if(Protocol==1||Protocol==58)rule.IcmpTypesAndCodes=IcmpTypes;
            rule.LocalAddresses=LocalAddresses;rule.RemoteAddresses=RemoteAddresses;
            if(Interfaces!=null)rule.Interfaces=Interfaces;
            rule.InterfaceTypes=InterfaceTypes;
            if(!String.IsNullOrEmpty(Grouping))rule.Grouping=Grouping;
            rule.Profiles=Profiles;rule.EdgeTraversal=EdgeTraversal;rule.Enabled=Enabled;
        }
        public bool Matches(object value)
        {
            var actual=Capture(value);
            return actual.Name==Name&&actual.ApplicationName==ApplicationName&&actual.ServiceName==ServiceName&&actual.Protocol==Protocol&&actual.Direction==Direction&&actual.Action==Action&&
                actual.LocalPorts==LocalPorts&&actual.RemotePorts==RemotePorts&&actual.LocalAddresses==LocalAddresses&&actual.RemoteAddresses==RemoteAddresses&&actual.Profiles==Profiles&&actual.Enabled==Enabled;
        }
    }
}
