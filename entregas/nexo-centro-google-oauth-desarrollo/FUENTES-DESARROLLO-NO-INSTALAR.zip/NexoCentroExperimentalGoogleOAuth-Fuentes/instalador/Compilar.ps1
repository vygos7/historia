﻿throw "Instaladores experimentales no habilitados en esta revisión. Usa la entrega portátil aislada. No se reutiliza el servidor estable ni se actualiza la instalación del colegio."
