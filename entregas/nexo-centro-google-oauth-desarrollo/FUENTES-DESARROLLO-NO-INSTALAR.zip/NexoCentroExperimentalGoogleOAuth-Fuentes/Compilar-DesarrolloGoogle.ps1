﻿param([string]$DotNet='dotnet',[switch]$ValidarInterfazWindows)
$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$false
$projects=@('servidor/AgendaClara.Server.csproj','cliente/AgendaClara.Client.csproj','pruebas-google-ui/Nexo.Google.UI.Pruebas.csproj')
foreach($project in $projects){& $DotNet build (Join-Path $PSScriptRoot ('aplicacion/'+$project)) -c Release;if($LASTEXITCODE-ne0){throw "No se ha compilado $project."}}
foreach($test in @('pruebas-google-oficial/Nexo.Google.Oficial.Pruebas.csproj','pruebas-google/Nexo.Google.Pruebas.csproj','pruebas-core/Nexo.Core.Pruebas.csproj')){
 & $DotNet run --project (Join-Path $PSScriptRoot ('aplicacion/'+$test)) -c Release
 if($LASTEXITCODE-ne0){throw "Han fallado las pruebas $test."}
}
if($ValidarInterfazWindows){
 if($env:OS-ne'Windows_NT'){throw 'La prueba nativa requiere Windows.'}
 & (Join-Path $PSScriptRoot 'aplicacion/pruebas-google-ui/bin/Release/net48/AgendaClara.Pruebas.exe')
 if($LASTEXITCODE-ne0){throw 'Ha fallado la prueba de la interfaz.'}
}
Write-Host 'Código compilado y pruebas ejecutadas. Esto no acredita una conexión real con Google.'
Write-Host 'No se genera un instalador: falta el registro de aplicación y la verificación real documentados en ESTADO-GOOGLE.md.'
