@echo off
cd /d "%~dp0"
"%~dp0Diagnosticar-AgendaClara.exe" --ipv4 192.168.6.135
