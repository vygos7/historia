param([Parameter(Mandatory=$true)][string]$Entrega,[Parameter(Mandatory=$true)][string]$Resultados)
$ErrorActionPreference='Stop';$PSNativeCommandUseErrorActionPreference=$false
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
if($env:OS-ne'Windows_NT'-or$env:GITHUB_ACTIONS-ne'true'-or$env:RUNNER_ENVIRONMENT-ne'github-hosted'){throw 'Sólo Windows efímero hospedado por GitHub. Nunca ejecutar estas pruebas sobre un centro.'}
$Entrega=[IO.Path]::GetFullPath($Entrega);New-Item -ItemType Directory -Force -Path $Resultados|Out-Null;$Resultados=[IO.Path]::GetFullPath($Resultados)
foreach($line in Get-Content -LiteralPath (Join-Path $Entrega 'SHA256SUMS.txt')) {
 if([string]::IsNullOrWhiteSpace($line)){continue};$parts=$line-split'  ',2
 if($parts.Count-ne2){throw 'Manifiesto no válido.'};$file=[IO.Path]::GetFullPath((Join-Path $Entrega $parts[1]))
 if(-not$file.StartsWith($Entrega+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)){throw 'Ruta fuera de la entrega.'}
 if((Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash-ne$parts[0]){throw "Archivo alterado: $($parts[1])"}
}
$tests=Join-Path $Entrega 'Pruebas';$server=Join-Path $Entrega 'Instalar-NexoCentro-Servidor.exe';$fixture=Join-Path $tests 'agenda-v4-sintetica.sqlite3';$script:results=@()
function Ejecutar([string]$Nombre,[string]$Programa,[string[]]$Argumentos) {
 $log=Join-Path $Resultados ($Nombre+'.txt');& $Programa @Argumentos *> $log;$code=$LASTEXITCODE
 Get-Content -LiteralPath $log -Encoding utf8|ForEach-Object{Write-Host $_}
 $summary=Select-String -LiteralPath $log -Pattern 'RESUMEN:'|Select-Object -Last 1
 if($code-ne0) {
  $errors=@(Select-String -LiteralPath $log -Pattern 'Exception:|HRESULT|^FALLO:|^ERROR_SERVIDOR|Diagnóstico del servicio'|Select-Object -Last 7)
  $message=if($errors.Count-gt0){($errors|ForEach-Object{$_.Line})-join' | '}else{'Consultar '+$Nombre+'.txt'}
  $message=$message.Replace('%','%25').Replace("`r",'%0D').Replace("`n",'%0A');Write-Host "::error title=NexoCentro-$Nombre::$message"
 } elseif($null-ne$summary) {
  $message=$summary.Line.Replace('%','%25').Replace("`r",'%0D').Replace("`n",'%0A');Write-Host "::notice title=NexoCentro-$Nombre::$message"
 }
 $script:results+=[ordered]@{Prueba=$Nombre;ExitCode=$code;Resumen=$(if($null-ne$summary){$summary.Line}else{'Sin resumen; consultar registro.'})}
 $script:results|ConvertTo-Json -Depth 4|Set-Content -LiteralPath (Join-Path $Resultados 'baterias.json') -Encoding utf8
}
Ejecutar 'datos-interfaz' (Join-Path $tests 'AgendaClara.Pruebas.exe') @((Join-Path $Resultados 'datos-interfaz'))
Ejecutar 'transporte' 'dotnet' @((Join-Path $tests 'transporte/AgendaClara.TransportTests.dll'),(Join-Path $Resultados 'datos-transporte'))
Ejecutar 'sesiones' 'dotnet' @((Join-Path $tests 'sesion/AgendaClara.SessionTests.dll'),(Join-Path $Resultados 'datos-sesion'))
Ejecutar 'diagnostico-net48' (Join-Path $tests 'AgendaClara.Diagnostics.Tests.exe') @((Join-Path $Resultados 'datos-diagnostico'),'dotnet',(Join-Path $tests 'probe/AgendaClara.ProbeHost.dll'))
Ejecutar 'sincronizacion-interfaz' 'dotnet' @((Join-Path $tests 'red/AgendaClara.NetworkTests.dll'),(Join-Path $Resultados 'datos-red'),$fixture,(Join-Path $tests 'AgendaClara.SharedUI.Tests.exe'))
Ejecutar 'red-instalador' (Join-Path $tests 'RedTests.exe') @((Join-Path $Resultados 'datos-firewall'))
Ejecutar 'integracion-instaladores' (Join-Path $tests 'SimpleTests.exe') @((Join-Path $Resultados 'datos-instaladores'),$fixture,$server)
Ejecutar 'servicio-actualizacion-reversion' (Join-Path $tests 'ServerInstallTests.exe') @((Join-Path $Resultados 'datos-servicio'),$server,$fixture)
if($script:results.Count-ne8-or@($script:results|Where-Object{$_.ExitCode-ne0}).Count-gt0){throw 'No se valida Nexo Centro: revisar baterías fallidas.'}
Write-Host 'NEXO CENTRO: ocho baterías Windows correctas.'
