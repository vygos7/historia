@echo off
cd /d "%~dp0"
"%~dp0Diagnosticar-AgendaClara.exe"
