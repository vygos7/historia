# Nexo Centro 4.2.1

Se ha retirado completamente de esta versión el proceso de formularios Google: menús, botones de las actividades, pantallas, autorización, bibliotecas y recogida de respuestas. Se conservan las tareas, las memorias introducidas manualmente, el historial, los informes, el calendario escolar, las copias de seguridad y el trabajo compartido.

El cliente utiliza el protocolo y las conexiones de la versión estable del colegio. No necesita reinstalar ni actualizar el servidor. Esta copia se ha preparado a partir del código estable conservado, sin alterar las instalaciones o carpetas anteriores.

## Probar la interfaz

Extrae todo el paquete y abre ABRIR-DEMO.cmd. Se abrirá una agenda separada con 187 eventos ficticios. La demo guarda sus datos en %LOCALAPPDATA%\NexoCentroDemo421, sin abrir ni sustituir la agenda del colegio o las demos anteriores.

## Actualizar el cliente que ya está instalado

Cierra el cliente Nexo Centro y ejecuta Instalar-NexoCentro-Cliente.exe manteniendo junto a él su archivo .exe.config. El instalador conserva la conexión existente. Utiliza el cliente actualizado en cada puesto donde quieras esta versión. No hay instalador de servidor en esta entrega y no es necesario generarlo de nuevo para esta retirada de botones.

No restaures los datos ficticios de la demo sobre la agenda del colegio. Las evaluaciones reales se siguen introduciendo desde la ficha de la actividad, en Evaluación y memoria de la actividad.

## Fuentes y compilación

El código de esta revisión está en la carpeta independiente /workspace/nexo-centro-4.2.1-sin-google. Preparar-Cliente.ps1 compila únicamente el cliente y su instalador. El servidor y el núcleo de datos/transporte mantienen el código estable. Las versiones anteriores permanecen conservadas.

Consulta Evidencias para el resultado de las pruebas sobre el paquete entregado.
