@echo off
setlocal
set "DEMODIR=%LOCALAPPDATA%\NexoCentroDemo421"
if not exist "%DEMODIR%" mkdir "%DEMODIR%"
if not exist "%DEMODIR%\agenda.sqlite3" copy "%~dp0Demo\Datos-iniciales\Agenda-demo.sqlite3" "%DEMODIR%\agenda.sqlite3" >nul
if not exist "%DEMODIR%\TrabajoCompartido.xml" copy "%~dp0Demo\Datos-iniciales\Configuracion-demo.xml" "%DEMODIR%\TrabajoCompartido.xml" >nul
start "" "%~dp0Demo\Programa\AgendaClara.exe" --agenda "%DEMODIR%\agenda.sqlite3" --config "%DEMODIR%\TrabajoCompartido.xml"
